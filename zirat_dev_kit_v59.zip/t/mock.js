window.__snd={osc:0,buf:0};
(function(){var A=window.AudioContext||window.webkitAudioContext;if(A){var po=A.prototype.createOscillator,pb=A.prototype.createBufferSource;A.prototype.createOscillator=function(){window.__snd.osc++;return po.apply(this,arguments);};A.prototype.createBufferSource=function(){window.__snd.buf++;return pb.apply(this,arguments);};}})();
window.__pres=[];
window.claude={use:function(n){return Promise.resolve({join:function(c){window.__joined=c;var cb;return Promise.resolve({onPeers:function(f){cb=f;setTimeout(function(){f({peers:[{isMe:true},{isMe:false,presence:{x:300,y:250,hp:80,mh:100,h:2,k:0,d:1,w:0,sc:50,nm:'חבר',m:'survive'}}]});},50);},presence:function(p){window.__pres.push(p);},leave:function(){window.__left=1;},broadcast:function(){},onMessage:function(){}});}});}};
window.__skipIntro=1;
window.__opened=[];window.open=function(u){window.__opened.push(String(u));return null;};
