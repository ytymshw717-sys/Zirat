/* ===== combat effects (3D): hero-specific projectiles, particle trails, muzzle flashes, impacts, explosions, specials, supers, melee slashes, lightning, meteors =====
   Built for phones: every spark in the arena is ONE instanced mesh, every glow ONE point cloud, every smoke puff ONE point cloud (3 draw calls in total),
   two pooled point lights flash on big hits. Gameplay stays in the 2D simulation; this only draws what the simulation does. */
var SHW={shuriken:'star',bow:'arrow',staff:'zap',laser:'beam',orb:'orb',shotgun:'bullet',bomb:'bomb',fire:'flame',flask:'flask',mic:'note',guitar:'wave',boomerang:'boom'};
/* m model · c core · g glow · tr trail · ip impact kind · em trail particles per second · arc lob height · sp spin */
var HSTY={
 0:{m:'star',c:'#e5e7eb',g:'#c4b5fd',tr:'#a78bfa',ip:'spark',em:26},
 2:{m:'zap',c:'#f5e9ff',g:'#c084fc',tr:'#a855f7',ip:'zap',em:34},
 4:{m:'beam',c:'#e0fbff',g:'#22d3ee',tr:'#22d3ee',ip:'zap',em:26},
 5:{m:'tox',c:'#ecfccb',g:'#a3e635',tr:'#84cc16',ip:'poison',em:30},
 6:{m:'arrow',c:'#f8fafc',g:'#bbf7d0',tr:'#dcfce7',ip:'spark',em:22},
 7:{m:'bullet',c:'#fff1b8',g:'#fbbf24',tr:'#fcd34d',ip:'spark',em:14},
 8:{m:'bomb',c:'#1f2937',g:'#fb923c',tr:'#cbd5e1',ip:'fire',em:18,arc:1.15,smoke:1},
 9:{m:'flame',c:'#fff3b0',g:'#f97316',tr:'#ff8a2a',ip:'fire',em:30,smoke:1},
 11:{m:'flask',c:'#34d399',g:'#34d399',tr:'#6ee7b7',ip:'poison',em:22,arc:1.05},
 13:{m:'note',c:'#f9a8d4',g:'#f472b6',tr:'#f472b6',ip:'sound',em:20},
 14:{m:'ghost',c:'#e0f2fe',g:'#7dd3fc',tr:'#bae6fd',ip:'ice',em:28},
 15:{m:'boom',c:'#d97706',g:'#fbbf24',tr:'#fbbf24',ip:'spark',em:20},
 16:{m:'wave',c:'#f0abfc',g:'#d946ef',tr:'#e879f9',ip:'sound',em:24},
 17:{m:'magic',c:'#fffbeb',g:'#facc15',tr:'#fde047',ip:'energy',em:30},
 1:{m:'wave',c:'#e0f2fe',g:'#93c5fd',tr:'#bfdbfe',ip:'spark',em:22},
 3:{m:'bullet',c:'#fff1b8',g:'#f59e0b',tr:'#fbbf24',ip:'spark',em:16},
 18:{m:'tox',c:'#ecfccb',g:'#65a30d',tr:'#a3e635',ip:'poison',em:26},
 19:{m:'axe',c:'#cbd5e1',g:'#f97316',tr:'#fb923c',ip:'spark',em:14}
};
var WSTY={star:HSTY[0],zap:HSTY[2],beam:HSTY[4],orb:HSTY[5],arrow:HSTY[6],bullet:HSTY[7],bomb:HSTY[8],flame:HSTY[9],flask:HSTY[11],note:HSTY[13],wave:HSTY[16],boom:HSTY[15]};
var DSTY={m:'dot',c:'#fffbe6',g:'#fde047',tr:'#fde047',ip:'energy',em:18};
var ESTY={axe:{m:'axe',c:'#cbd5e1',g:'#ef4444',tr:'#f87171',ip:'spark',em:12},laser:{m:'rbolt',c:'#ffe4e6',g:'#ef4444',tr:'#ff4d6d',ip:'zap',em:22},fire:{m:'efire',c:'#fff1c2',g:'#ff5a1f',tr:'#ff6a1f',ip:'fire',em:26,smoke:1},breath:{m:'breath',c:'#fff7cc',g:'#ff6a1f',tr:'#ff7a1a',ip:'fire',em:34,smoke:1},_:{m:'eorb',c:'#fecaca',g:'#ef4444',tr:'#ef4444',ip:'energy',em:16}};
var PHYS={star:1,arrow:1,bullet:1,boom:1,axe:1,bomb:1,flask:1,note:1,wave:1,flame:1,efire:1,breath:1};
var MCOL={1:'#93c5fd',3:'#fbbf24',10:'#f43f5e',12:'#fb923c',18:'#a3e635',19:'#f97316'};
var TRC={};
function shSty(s){var o=s.o,ch=o&&o.ch;if(s.ret)return HSTY[15];if(ch){var st=HSTY[ch.idx];if(st)return st;var w=SHW[ch.wp];if(w&&WSTY[w])return WSTY[w];}if(s.col)return {m:'dot',c:'#fffbe6',g:s.col,tr:s.col,ip:'energy',em:16};return DSTY;}
function heroCol(i,g){try{var c=g&&g.CH?g.CH[i]:null;return (HSTY[i]&&HSTY[i].g)||MCOL[i]||(c&&c.col)||'#fde047';}catch(e){return '#fde047';}}
/* ---------- textures & shared materials ---------- */
function r3glowTex(){if(R3.glowTex)return R3.glowTex;var c=document.createElement('canvas');c.width=c.height=64;var x=c.getContext('2d'),g=x.createRadialGradient(32,32,1,32,32,32);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.3,'rgba(255,255,255,.6)');g.addColorStop(.65,'rgba(255,255,255,.14)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,64,64);R3.glowTex=new THREE.CanvasTexture(c);return R3.glowTex;}
function r3smokeTex(){if(R3.smokeTex)return R3.smokeTex;var c=document.createElement('canvas');c.width=c.height=64;var x=c.getContext('2d');for(var i=0;i<7;i++){var px=20+Math.random()*24,py=20+Math.random()*24,r=12+Math.random()*10,g=x.createRadialGradient(px,py,1,px,py,r);g.addColorStop(0,'rgba(255,255,255,.55)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,64,64);}R3.smokeTex=new THREE.CanvasTexture(c);return R3.smokeTex;}
function r3glow(col,s){var m=new THREE.SpriteMaterial({map:r3glowTex(),color:col,transparent:true,depthWrite:false,depthTest:false,blending:THREE.AdditiveBlending});var sp=new THREE.Sprite(m);sp.scale.set(s,s,1);sp.renderOrder=5;return sp;}
function r3add(c,op){R3.addM=R3.addM||{};var k=c+'|'+(op||1);return R3.addM[k]||(R3.addM[k]=new THREE.MeshBasicMaterial({color:c,transparent:true,opacity:op||1,depthWrite:false,blending:THREE.AdditiveBlending}));}
var RGBC={};function rgb(c){var v=RGBC[c];if(!v){var q=new THREE.Color(c);v=RGBC[c]=[q.r,q.g,q.b];}return v;}
/* ---------- particle engine: sparks (instanced 3D octahedra), glows and smoke (point clouds), all pooled ---------- */
var PVS="attribute vec4 c4;attribute float sz;uniform float scale;varying vec4 vC;void main(){vC=c4;vec4 mv=modelViewMatrix*vec4(position,1.0);gl_PointSize=sz*scale/max(.2,-mv.z);gl_Position=projectionMatrix*mv;}";
var PFS="uniform sampler2D map;varying vec4 vC;void main(){float a=texture2D(map,gl_PointCoord).a*vC.a;if(a<.004)discard;gl_FragColor=vec4(vC.rgb,a);}";
function r3pts(N,blend,tex,dt){var geo=new THREE.BufferGeometry(),pos=new Float32Array(N*3),col=new Float32Array(N*4),sz=new Float32Array(N);
 var a1=new THREE.BufferAttribute(pos,3),a2=new THREE.BufferAttribute(col,4),a3=new THREE.BufferAttribute(sz,1);[a1,a2,a3].forEach(function(a){a.setUsage(THREE.DynamicDrawUsage);});
 geo.setAttribute('position',a1);geo.setAttribute('c4',a2);geo.setAttribute('sz',a3);geo.setDrawRange(0,0);
 var mat=new THREE.ShaderMaterial({uniforms:{map:{value:tex},scale:{value:400}},vertexShader:PVS,fragmentShader:PFS,transparent:true,depthWrite:false,depthTest:dt,blending:blend});
 var p=new THREE.Points(geo,mat);p.frustumCulled=false;p.renderOrder=dt?3:6;R3.sc.add(p);return {o:p,geo:geo,pos:pos,col:col,sz:sz,N:N,L:[],mat:mat};}
function r3P(){if(R3.P)return R3.P;var N=300,mat=new THREE.MeshBasicMaterial({color:'#ffffff',transparent:true,depthWrite:false,blending:THREE.AdditiveBlending}),im=new THREE.InstancedMesh(R3.T.oct,mat,N);
 im.frustumCulled=false;var c=new THREE.Color(1,1,1);for(var i=0;i<N;i++){im.setColorAt(i,c);}im.instanceMatrix.setUsage(THREE.DynamicDrawUsage);im.instanceColor.setUsage(THREE.DynamicDrawUsage);im.count=0;im.renderOrder=4;R3.sc.add(im);
 var bm=new THREE.InstancedMesh(R3.T.box,new THREE.MeshBasicMaterial({color:'#ffffff',transparent:true,depthWrite:false,blending:THREE.AdditiveBlending}),90);bm.frustumCulled=false;for(i=0;i<90;i++)bm.setColorAt(i,c);bm.instanceMatrix.setUsage(THREE.DynamicDrawUsage);bm.count=0;bm.renderOrder=4;R3.sc.add(bm);
 R3.P={im:im,N:N,S:[],G:r3pts(420,THREE.AdditiveBlending,r3glowTex(),false),K:r3pts(170,THREE.NormalBlending,r3smokeTex(),true),bm:bm};return R3.P;}
/* spark: {x,y,z, vx,vy,vz, g gravity, life, s0,s1 sizes, c colour, op, st stretch along motion, fl floor bounce} */
function r3sp(x,y,z,o){var P=r3P();if(P.S.length>=P.N)return;var c=rgb(o.c||'#ffffff');P.S.push({x:x,y:y,z:z,vx:o.vx||0,vy:o.vy||0,vz:o.vz||0,g:o.g||0,dr:o.dr||0,life:o.life||.4,t:0,s0:o.s0||.08,s1:o.s1==null?.02:o.s1,r:c[0],gg:c[1],b:c[2],op:o.op==null?1:o.op,st:o.st||1,rx:Math.random()*6,ry:Math.random()*6,wr:6+Math.random()*8});}
function r3gl(x,y,z,o,smoke){var P=r3P(),S=smoke?P.K:P.G;if(S.L.length>=S.N)return;var c=rgb(o.c||'#ffffff');S.L.push({x:x,y:y,z:z,vx:o.vx||0,vy:o.vy||0,vz:o.vz||0,g:o.g||0,dr:o.dr||0,life:o.life||.3,t:0,s0:o.s0||.5,s1:o.s1==null?.1:o.s1,r:c[0],gg:c[1],b:c[2],op:o.op==null?1:o.op,fi:o.fi||0});}
function r3pstep(L,dt){for(var i=L.length-1;i>=0;i--){var p=L[i];p.t+=dt;if(p.t>=p.life){L[i]=L[L.length-1];L.pop();continue;}
 if(p.dr){var k=Math.max(0,1-p.dr*dt);p.vx*=k;p.vy*=k;p.vz*=k;}p.vy-=p.g*dt;p.x+=p.vx*dt;p.y+=p.vy*dt;p.z+=p.vz*dt;if(p.y<.03){p.y=.03;if(p.vy<0){p.vy*=-.3;p.vx*=.55;p.vz*=.55;}}}}
function r3psStep(dt){if(!R3.P)return;var P=R3.P;r3pstep(P.S,dt);r3pstep(P.G.L,dt);r3pstep(P.K.L,dt);}
var _M4,_Q,_E,_V,_S,_C,_UP,_D;
function r3psFlush(){if(!R3.P)return;var P=R3.P;if(!_M4){_M4=new THREE.Matrix4();_Q=new THREE.Quaternion();_E=new THREE.Euler();_V=new THREE.Vector3();_S=new THREE.Vector3();_C=new THREE.Color();_UP=new THREE.Vector3(0,1,0);_D=new THREE.Vector3();}
 var im=P.im,n=0;for(var i=0;i<P.S.length;i++){var p=P.S[i],k=p.t/p.life,s=p.s0+(p.s1-p.s0)*k,f=Math.pow(1-k,1.2)*p.op;
  if(p.st>1){var sp=Math.hypot(p.vx,p.vy,p.vz);if(sp>.05){_V.set(p.vx/sp,p.vy/sp,p.vz/sp);_Q.setFromUnitVectors(_UP,_V);}else _Q.identity();_S.set(s*.55,s*p.st,s*.55);}
  else{_E.set(p.rx+p.t*p.wr,p.ry+p.t*p.wr*.7,0);_Q.setFromEuler(_E);_S.set(s,s,s);}
  _V.set(p.x,p.y,p.z);_M4.compose(_V,_Q,_S);im.setMatrixAt(n,_M4);_C.setRGB(p.r*f,p.gg*f,p.b*f);im.setColorAt(n,_C);n++;}
 im.count=n;im.instanceMatrix.needsUpdate=true;if(im.instanceColor)im.instanceColor.needsUpdate=true;
 var sc=(R3.h||360)*R3.r.getPixelRatio()*.5/Math.tan(R3.cam.fov*Math.PI/360);
 [P.G,P.K].forEach(function(S){var L=S.L;for(var i=0;i<L.length;i++){var p=L[i],k=p.t/p.life,a=(1-k)*p.op;if(p.fi)a*=Math.min(1,k/p.fi);var o3=i*3,o4=i*4;S.pos[o3]=p.x;S.pos[o3+1]=p.y;S.pos[o3+2]=p.z;S.col[o4]=p.r;S.col[o4+1]=p.gg;S.col[o4+2]=p.b;S.col[o4+3]=a;S.sz[i]=p.s0+(p.s1-p.s0)*k;}
  S.geo.setDrawRange(0,L.length);S.geo.attributes.position.needsUpdate=true;S.geo.attributes.c4.needsUpdate=true;S.geo.attributes.sz.needsUpdate=true;S.mat.uniforms.scale.value=sc;});}
/* the old r3fx API now feeds the particle engine (rings stay as meshes) */
function r3pfx(kind,x,y,z,o){o=o||{};if(kind==='spark'){r3sp(x,y,z,o);return true;}if(kind==='glow'){r3gl(x,y,z,o);return true;}if(kind==='puff'){r3gl(x,y,z,{c:o.c||'#e2e8f0',vx:o.vx,vy:o.vy,vz:o.vz,life:o.life||.45,s0:(o.s0||.1)*2.2,s1:(o.s1||.3)*2.4,op:(o.op==null?.6:o.op),fi:.15},true);return true;}return false;}
/* ---------- flash lights: two pooled point lights (always in the scene so shaders never recompile) ---------- */
function r3lightsInit(){if(R3.FL)return;R3.FL=[];for(var i=0;i<2;i++){var l=new THREE.PointLight('#ffffff',0,6,1.6);l.position.set(0,-30,0);R3.sc.add(l);R3.FL.push({l:l,t:1,d:1,I:0});}}
function r3flash(x,y,z,col,I,dist,dur){if(!R3.FL||R3.low)return;var b=null;R3.FL.forEach(function(f){var cur=f.I*Math.max(0,1-f.t/f.d);if(!b||cur<b.cur){b=f;b.cur=cur;}});if(!b||b.cur>I*.8)return;b.l.color.set(col);b.l.position.set(x,y,z);b.l.distance=dist;b.I=I;b.t=0;b.d=dur;b.l.intensity=I;}
function r3lightsStep(dt){if(!R3.FL)return;R3.FL.forEach(function(f){if(f.I<=0)return;f.t+=dt;var k=1-f.t/f.d;if(k<=0){f.I=0;f.l.intensity=0;}else f.l.intensity=f.I*k*k;});}
function r3lightsOff(){if(!R3.FL)return;R3.FL.forEach(function(f){R3.sc.remove(f.l);});R3.FL=null;}
/* ---------- streak trail behind fast shots ---------- */
function r3trailTex(){if(R3.trTex)return R3.trTex;var c=document.createElement('canvas');c.width=16;c.height=64;var x=c.getContext('2d'),im=x.createImageData(16,64);
 for(var y=0;y<64;y++)for(var i=0;i<16;i++){var along=Math.pow(y/63,1.5),across=Math.max(0,1-Math.abs(i-7.5)/8),a=along*Math.pow(across,1.2),o=(y*16+i)*4;im.data[o]=im.data[o+1]=im.data[o+2]=255;im.data[o+3]=Math.round(255*a);}
 x.putImageData(im,0,0);R3.trTex=new THREE.CanvasTexture(c);return R3.trTex;}
function r3trailGeo(){var T=R3.T;if(T.trail)return T.trail;var g=new THREE.PlaneGeometry(1,1);g.rotateX(-Math.PI/2);g.translate(0,0,-.5);T.trail=g;return g;}
function r3trailMat(col){R3.trMats=R3.trMats||{};return R3.trMats[col]||(R3.trMats[col]=new THREE.MeshBasicMaterial({map:r3trailTex(),color:col,transparent:true,opacity:.9,depthWrite:false,blending:THREE.AdditiveBlending,side:THREE.DoubleSide}));}
function r3trail(col){var a=new THREE.Mesh(r3trailGeo(),r3trailMat(col));a.rotation.z=.35;return a;}
/* ---------- projectile models: real 3D meshes, lit (Lambert) for physical objects, unlit/additive for energy ---------- */
function arc2(){var T=R3.T;return T.arc2||(T.arc2=new THREE.RingGeometry(.68,1,24,1,0,2));}
function shBody(m,st){var T=R3.T,g=new THREE.Group(),u=g.userData;
 function add(geo,mat,sx,sy,sz,x,y,z,rx,ry,rz,par){var o=new THREE.Mesh(geo,mat);o.scale.set(sx,sy,sz);o.position.set(x||0,y||0,z||0);o.rotation.set(rx||0,ry||0,rz||0);(par||g).add(o);return o;}
 var L=function(c){return r3mat(c);},B=function(c,op){return r3mat(c,true,op);},AD=r3add;
 if(m==='star'){var steel=L('#cbd5e1'),hub=L('#334155'),gl=AD('#a78bfa',.4);for(var j=0;j<4;j++){var h=new THREE.Group();h.rotation.y=j*Math.PI/2;add(T.cone,steel,.095,.32,.035,0,0,.17,Math.PI/2,0,0,h);add(T.cone,gl,.12,.36,.02,0,.015,.18,Math.PI/2,0,0,h);g.add(h);}add(T.cyl,hub,.07,.045,.07);add(T.cyl,L('#a78bfa'),.035,.05,.035);u.spinY=28;u.trail=1;}
 else if(m==='arrow'){add(T.cyl,L('#9a6b3d'),.022,.62,.022,0,0,0,Math.PI/2);add(T.cone,L('#e5e7eb'),.055,.17,.055,0,0,.36,Math.PI/2);[-1,1].forEach(function(s){add(T.box,L('#22c55e'),.11,.012,.13,s*.045,0,-.27,0,0,s*.6);});add(T.box,L('#16a34a'),.012,.1,.13,0,.04,-.27);u.trail=1;u.tip=.42;}
 else if(m==='bullet'){add(T.sph,L('#fbbf24'),.065,.065,.13);u.trail=1;}
 else if(m==='zap'){var zz=[];for(var i=0;i<5;i++){zz.push(add(T.box,B('#f5e9ff'),.035,.035,.2,(i%2?1:-1)*.05,0,-.36+i*.18,0,(i%2?1:-1)*.75,0));}add(T.sph,AD('#c084fc',.7),.13,.13,.42);add(T.sph,B('#ffffff'),.06,.06,.06,0,0,.32);u.zz=zz;u.trail=1;}
 else if(m==='beam'){add(T.cyl,B('#ffffff'),.035,.85,.035,0,0,0,Math.PI/2);add(T.cyl,AD('#22d3ee',.75),.085,.95,.085,0,0,0,Math.PI/2);add(T.sph,AD('#67e8f9',.8),.1,.1,.1,0,0,.47);u.trail=1;u.pulse=24;}
 else if(m==='tox'){add(T.sph,B('#f7fee7'),.075,.075,.075);var bub=add(T.sph,L('#84cc16'),.16,.16,.16);bub.material=r3mat('#a3e635',true,.55);var ob=[];for(var q=0;q<3;q++)ob.push(add(T.sph,B('#bef264'),.045,.045,.045));u.ob=ob;u.obR=.22;u.pulse=14;}
 else if(m==='orb'||m==='dot'){add(T.sph,B('#ffffff'),.075,.075,.075);var sh2=add(T.sph,AD(st.g,.75),.15,.15,.15);u.tint=sh2;u.pulse=18;}
 else if(m==='ghost'){add(T.sph,B('#f0f9ff'),.14,.14,.14);add(T.cone,B('#e0f2fe',.85),.12,.26,.12,0,0,-.17,-Math.PI/2);add(T.sph,AD('#7dd3fc',.5),.2,.2,.24);[-1,1].forEach(function(s){add(T.sph,B('#0c4a6e'),.026,.034,.02,s*.05,.04,.125);});u.bob=1;}
 else if(m==='sun'){add(T.sph,B('#fffbeb'),.1,.1,.1);add(T.sph,AD('#fbbf24',.85),.16,.16,.16);var ry=new THREE.Group();for(var r2=0;r2<8;r2++){var hd=new THREE.Group();hd.rotation.y=r2/8*6.283;add(T.cone,AD('#fde047',.9),.045,.15,.045,.23,0,0,0,0,-Math.PI/2,hd);ry.add(hd);}g.add(ry);u.ry=ry;u.pulse=12;}
 else if(m==='magic'){add(T.sph,B('#fdf4ff'),.08,.08,.08);add(T.sph,AD('#c026d3',.7),.16,.16,.16);add(T.sph,AD('#f0abfc',.35),.22,.22,.22);var ry2=new THREE.Group();for(var s3=0;s3<3;s3++){var hd3=new THREE.Group();hd3.rotation.y=s3/3*6.283;add(T.oct,AD('#fde047',.95),.055,.055,.055,.25,0,0,0,0,0,hd3);ry2.add(hd3);}g.add(ry2);u.ry=ry2;u.pulse=14;}
 else if(m==='note'){var pk=L('#f472b6'),nt=new THREE.Group();add(T.sph,pk,.085,.068,.075,-.045,-.08,0,0,0,.4,nt);add(T.box,pk,.026,.25,.026,.03,.045,0,0,0,0,nt);add(T.box,pk,.1,.028,.026,.075,.16,0,0,0,-.5,nt);nt.position.y=.05;g.add(nt);var wr0=[];for(var w=0;w<2;w++){wr0.push(add(arc2(),AD('#f472b6',.75-w*.3),1,1,1,0,0,0,-Math.PI/2,0,-Math.PI/2-1));}u.wr=wr0;u.wrB=.2;u.wob=1;}
 else if(m==='wave'){var wr1=[];for(var w2=0;w2<3;w2++){wr1.push(add(arc2(),AD(w2===1?'#22d3ee':'#e879f9',.95-w2*.2),1,1,1,0,0,0,-Math.PI/2,0,-Math.PI/2-1));}add(T.sph,B('#fdf4ff'),.05,.05,.05);u.wr=wr1;u.wrB=.26;}
 else if(m==='bomb'){add(T.sph,L('#1f2937'),.16,.16,.16);add(T.sph,L('#4b5563'),.05,.05,.03,.07,.08,.11);add(T.cyl,L('#a16207'),.04,.05,.04,0,.17,0);add(T.cyl,L('#78350f'),.012,.1,.012,0,.24,0,0,0,.3);u.spinX=7;u.fuse=1;}
 else if(m==='flask'){var gl2=r3mat('#a7f3d0',true,.45);add(T.sph,gl2,.13,.13,.13);add(T.sph,B('#10b981'),.1,.08,.1,0,-.025,0);add(T.cyl,gl2,.045,.1,.045,0,.15,0);add(T.cyl,L('#92400e'),.05,.05,.05,0,.22,0);u.spinX=8;}
 else if(m==='flame'||m==='efire'||m==='breath'){var big=m==='breath'?1.3:1;add(T.sph,B(m==='flame'?'#fff3b0':'#fff1c2'),.1*big,.1*big,.1*big);var f1=add(T.sph,AD(m==='flame'?'#fb923c':'#ff5a1f',.55),.17*big,.17*big,.22*big,0,0,-.03);var f2=add(T.sph,AD('#dc2626',.3),.23*big,.21*big,.3*big,0,0,-.07);u.fl=[f1,f2];u.flick=1;u.grow=m==='flame'?1:0;}
 else if(m==='boom'){var wd=L('#b45309'),wl=L('#f59e0b');add(T.box,wd,.34,.035,.085,.13,0,0,0,.5);add(T.box,wl,.34,.035,.085,-.13,0,0,0,-.5);add(T.box,L('#fde68a'),.06,.04,.09,0,.01,.05);u.spinY=24;u.trail=1;}
 else if(m==='axe'){var hz=new THREE.Group();add(T.cyl,L('#5b3a29'),.025,.42,.025,0,0,0,0,0,0,hz);add(T.box,L('#cbd5e1'),.2,.16,.03,.08,.15,0,0,0,0,hz);add(T.box,L('#ef4444'),.04,.17,.035,-.02,.15,0,0,0,0,hz);g.add(hz);u.spinX=16;u.trail=1;}
 else if(m==='rbolt'){add(T.cyl,B('#ffe4e6'),.04,.62,.04,0,0,0,Math.PI/2);add(T.cyl,AD('#ef4444',.7),.09,.7,.09,0,0,0,Math.PI/2);u.trail=1;u.pulse=20;}
 else{add(T.sph,B('#fecaca'),.07,.07,.07);add(T.sph,AD('#ef4444',.7),.14,.14,.14);u.pulse=16;}
 return g;}
function r3shotMake(k,st){st=st||DSTY;var g=new THREE.Group(),body=shBody(k,st);g.add(body);var u=g.userData=body.userData;u.body=body;
 if(u.trail){var tr=r3trail(st.tr);g.add(tr);u.tr=tr;}g.traverse(function(o){o.castShadow=false;});return g;}
/* ---------- impacts ---------- */
function r3impact(x,y,z,st,hit,big,dir){var c=st.g,low=R3.low,n=low?3:(big?10:6),ip=st.ip,dx=dir?dir[0]:0,dz=dir?dir[1]:0;
 if(!hit){r3gl(x,y,z,{c:c,life:.16,s0:.55,s1:.2,op:.7});for(var q=0;q<2;q++)r3sp(x,y,z,{c:c,life:.22,vx:(Math.random()-.5)*2,vy:1+Math.random(),vz:(Math.random()-.5)*2,g:8,s0:.05,s1:.01});return;}
 r3gl(x,y,z,{c:'#ffffff',life:.07,s0:big?.8:.6,s1:.3,op:.75});r3gl(x,y,z,{c:c,life:.22,s0:big?1.3:.95,s1:.3,op:.9});
 r3fx('ring',x,.08,z,{c:c,life:.26,s0:.12,s1:big?1.1:.7,op:.85});
 if(!low)r3flash(x,.9,z,c,big?2.2:1.4,big?4.5:3,.18);
 for(var i=0;i<n;i++){var a=Math.random()*6.283,sp=1.6+Math.random()*2.8,vx=Math.cos(a)*sp-dx*1.5,vz=Math.sin(a)*sp-dz*1.5;
  if(ip==='fire')r3sp(x,y,z,{c:i%2?'#fde047':'#fb923c',life:.42,vx:vx*.6,vy:1.4+Math.random()*1.8,vz:vz*.6,g:-1.2,dr:2,s0:.07,s1:.015});
  else if(ip==='zap')r3sp(x,y,z,{c:i%3?c:'#ffffff',life:.18,vx:vx*1.8,vy:(Math.random()-.3)*3,vz:vz*1.8,s0:.06,s1:.02,st:3.2});
  else if(ip==='poison')r3sp(x,y,z,{c:i%2?c:'#d9f99d',life:.45,vx:vx*.7,vy:1.8+Math.random()*1.5,vz:vz*.7,g:9,s0:.075,s1:.04});
  else if(ip==='ice')r3sp(x,y,z,{c:i%2?'#e0f2fe':c,life:.45,vx:vx*.8,vy:1.5+Math.random()*2,vz:vz*.8,g:10,s0:.09,s1:.05,st:1.7});
  else if(ip==='sound'){if(i<2)r3fx('ring',x,.3+i*.25,z,{c:c,life:.3+i*.08,s0:.15,s1:.9+i*.3,op:.8});r3sp(x,y,z,{c:c,life:.3,vx:vx,vy:1+Math.random(),vz:vz,s0:.06,s1:.01});}
  else if(ip==='spark')r3sp(x,y,z,{c:i%2?'#fff7cc':c,life:.24,vx:vx*1.3,vy:1+Math.random()*2.2,vz:vz*1.3,g:7,s0:.055,s1:.015,st:2.4});
  else r3sp(x,y,z,{c:i%2?'#ffffff':c,life:.32,vx:vx,vy:1.2+Math.random()*2,vz:vz,g:6,s0:.07,s1:.02});}
 if(st.smoke&&!low)for(var j=0;j<2;j++)r3gl(x,y,z,{c:'#57534e',life:.6,vy:.8,vx:(Math.random()-.5)*.6,vz:(Math.random()-.5)*.6,s0:.4,s1:1,op:.5,fi:.2},true);
 if(ip==='poison'&&!low)r3gl(x,.2,z,{c:'#65a30d',life:.7,s0:.5,s1:1.3,op:.45,fi:.15},true);}
/* muzzle flash in the shot's colour, sparks thrown forward */
function r3muzzle(x,y,z,st,dx,dz,isPl){r3gl(x,y,z,{c:'#ffffff',life:.06,s0:.45,s1:.25,op:.75});r3gl(x,y,z,{c:st.g,life:.12,s0:.7,s1:.2,op:.85});
 if(!R3.low)for(var i=0;i<3;i++){var sp=3+Math.random()*2.5,j=(Math.random()-.5)*.9;r3sp(x,y,z,{c:i?st.g:'#ffffff',life:.14,vx:(dx+j*dz)*sp,vy:Math.random()*.8,vz:(dz-j*dx)*sp,s0:.05,s1:.01,st:2.6});}
 if(isPl&&(!R3.mzL||R3.lt-R3.mzL>.09)){R3.mzL=R3.lt;r3flash(x,y+.2,z,st.g,1.1,2.6,.08);}}
/* ---------- projectiles every frame ---------- */
function r3shots(g,t){
 var dt=Math.min(.05,Math.max(0,t-(R3.shLt||t)));R3.shLt=t;R3.shM=R3.shM||new Map();R3.eshM=R3.eshM||new Map();
 var pools={};function take(k,st){var key='s2_'+k+(k==='dot'||k==='orb'?st.g:'');var p=pools[key]||(pools[key]=r3pool(key,function(){return r3shotMake(k,st);}));return r3take(p);}
 function pose(m,s,st,r,big,yy,u0){var u=m.userData,b=u.body,vx=s.vx||0,vy=s.vy||0,spd=Math.hypot(vx,vy),sp=spd*R3U,dx=spd?vx/spd:0,dz=spd?vy/spd:0,sc=(big?1.45:1)*Math.max(.8,Math.min(1.6,(s.r||5)/5))*1.25;
  var x=r3x(s.x),z=r3z(s.y),age=t-r.t0,uu=u0,y=yy;if(st.arc&&r.l0>0){y=yy+st.arc*4*uu*(1-uu);}
  if(u.bob)y+=Math.sin(t*9+r.ph)*.06;
  m.position.set(x,y,z);m.rotation.set(0,Math.atan2(vx,vy),0);b.rotation.set(0,0,0);var bs=sc;
  if(st.arc){var vyy=st.arc*4*(1-2*uu)/Math.max(.1,r.l0);b.rotation.x=-Math.atan2(vyy,Math.max(.5,sp))*.6;}
  if(u.spinY)b.rotation.y=t*u.spinY;if(u.spinX)b.rotation.x=t*u.spinX;
  if(u.pulse)bs*=1+Math.sin(t*u.pulse+r.ph)*.09;
  if(u.flick){u.fl[0].scale.x=u.fl[0].scale.y=(u.fl[0].userData.s||(u.fl[0].userData.s=u.fl[0].scale.x))*(1+Math.sin(t*41+r.ph)*.14);u.fl[1].rotation.z=t*9;}
  if(u.grow)bs*=.55+1.25*Math.min(1,uu*1.3)*(uu>.85?(1-uu)/.15*.6+.4:1);
  if(u.wob)b.rotation.z=Math.sin(t*10+r.ph)*.35;
  b.scale.setScalar(bs);
  if(u.zz)for(var i=0;i<u.zz.length;i++){u.zz[i].position.x=(i%2?1:-1)*.05+(Math.random()-.5)*.09;u.zz[i].position.y=(Math.random()-.5)*.06;}
  if(u.ob)for(var j=0;j<u.ob.length;j++){var a=t*9+j*2.094;u.ob[j].position.set(Math.cos(a)*u.obR,Math.sin(a*1.3)*.06,Math.sin(a)*u.obR);}
  if(u.ry)u.ry.rotation.y=t*5;
  if(u.wr)for(var w=0;w<u.wr.length;w++){var ws=(u.wrB+w*.09)*(1+((t*3+w*.33)%1)*.45);u.wr[w].scale.setScalar(ws);u.wr[w].position.z=-ws*.92-w*.05;}
  if(u.tr){var L=s.ret?.5:Math.max(.35,Math.min(1.8,sp*.08))*(big?1.25:1);u.tr.scale.set(Math.min(.5,.13*sc),1,L);u.tr.visible=sp>.5;}
  // particle trail along the real path (works for homing / returning shots too)
  var gl=R3.P?R3.P.G.L.length:0,em=(st.em||16)*(big?1.3:1)*(R3.low?.35:1)*(gl>300?.15:gl>200?.5:1);r.acc=(r.acc||0)+em*dt;var mx=0;
  while(r.acc>=1&&mx++<4){r.acc-=1;var bk=Math.random()*.15;r3gl(x-dx*bk,y+(Math.random()-.5)*.05,z-dz*bk,{c:st.tr,life:.22+Math.random()*.12,s0:.32*sc*(big?1.2:1),s1:.05,op:.85,vy:.15});
   if(st.smoke&&Math.random()<.45)r3gl(x-dx*.2,y,z-dz*.2,{c:'#6b7280',life:.5,vy:.6,s0:.18,s1:.55,op:.38,fi:.25},true);
   if(u.flick&&Math.random()<.5)r3sp(x,y,z,{c:Math.random()<.5?'#fde047':'#fb923c',life:.3,vx:-dx*.8+(Math.random()-.5),vy:.9,vz:-dz*.8+(Math.random()-.5),g:-1,s0:.05,s1:.01});
   if(u.fuse)r3sp(x,y+.28*bs,z,{c:'#fde047',life:.2,vx:(Math.random()-.5)*1.5,vy:1.2,vz:(Math.random()-.5)*1.5,g:4,s0:.04,s1:.01});}
  // bright head glow drawn every frame (no extra draw call)
  var ph=PHYS[st.m];r3gl(x+dx*(u.tip||0)*bs,y,z+dz*(u.tip||0)*bs,{c:st.g,life:.001,s0:(ph?.32:big?.8:.6)*sc,s1:.6*sc,op:ph?.45:big?.7:.85});}
 function track(map,s,st,isPl){var r=map.get(s);if(!r){r={t0:t,l0:s.life||0,ph:Math.random()*6.283,st:st,big:!!s.big};map.set(s,r);var sp0=Math.hypot(s.vx||0,s.vy||0)||1;if(!(s.o&&s.o.mzT>t-.05)){if(s.o)s.o.mzT=t;r3muzzle(r3x(s.x),.72,r3z(s.y),st,(s.vx||0)/sp0,(s.vy||0)/sp0,isPl);}}r.f=R3.frameNo;r.x=s.x;r.y=s.y;return r;}
 g.shots.forEach(function(s){var st=shSty(s),k=st.m,r=track(R3.shM,s,st,!!(s.o&&s.o.ch)),m=take(k,st),u0=r.l0>0?Math.max(0,Math.min(1,1-(s.life||0)/r.l0)):0;
  pose(m,s,st,r,r.big,.72,u0);});
 for(var key in pools)r3end(pools[key]);
 for(var pn in R3.pools)if(pn.indexOf('s2_')===0&&!pools[pn])r3end(r3pool(pn));
 var ep={};
 g.eshots.forEach(function(s){var hero=s.o&&s.o.ch,st=hero?shSty(s):(ESTY[s.k]||ESTY._),k=st.m,r=track(R3.eshM,s,st,false),key='e2_'+k+(k==='dot'||k==='orb'?st.g:''),p=ep[key]||(ep[key]=r3pool(key,function(){return r3shotMake(k,st);})),m=r3take(p),u0=hero&&r.l0>0?Math.max(0,Math.min(1,1-(s.life||0)/r.l0)):0;r.big=!!s.big;pose(m,s,st,r,k==='breath'||!!s.big,hero?.72:.78,u0);});
 for(var pe in R3.pools)if(pe.indexOf('e2_')===0&&!ep[pe])r3end(r3pool(pe));else if(ep[pe])r3end(ep[pe]);
 // shots that vanished this frame: impact where they ended
 function gone(map,near){var fr=R3.frameNo,lst=[];map.forEach(function(r,s){if(r.f!==fr)lst.push(s);});if(lst.length>14){lst.forEach(function(s){map.delete(s);});return;}
  lst.forEach(function(s,i){var r=map.get(s);map.delete(s);if(i>=5)return;var hx=s.x,hy=s.y,hit=s.hitE||near(hx,hy),sp=Math.hypot(s.vx||0,s.vy||0)||1;
   if(r.st.arc&&!s.boom)hit=true;if(s.boom)return; /* bombs: the explosion event draws it */
   r3impact(r3x(hx),.72,r3z(hy),r.st,hit,r.big,[(s.vx||0)/sp,(s.vy||0)/sp]);});}
 gone(R3.shM,function(x,y){return g.enemies.some(function(e){return Math.hypot(e.x-x,e.y-y)<e.r+16;})||(g.structs||[]).some(function(e){return e.hp>0&&Math.hypot(e.x-x,e.y-y)<e.r+16;});});
 gone(R3.eshM,function(x,y){return g.ps.concat(g.tb||[]).some(function(p){return p.hp>0&&Math.hypot(p.x-x,p.y-y)<(p.r||14)+14;});});
}
/* ---------- big moments from the game (event queue) ---------- */
function r3pool1(name,make){var p=R3.pools[name];return p||r3pool(name,make);}
/* fireballs / domes / light pillars: few at a time, each with its own material so it can fade */
function r3blast(kind,x,y,z,col,R,life){R3.BL=R3.BL||[];if(R3.BL.length>10)return;var T=R3.T,geo=kind==='pillar'?T.wallc:kind==='dome'?(T.dome||(T.dome=new THREE.SphereGeometry(1,24,12,0,Math.PI*2,0,Math.PI/2))):T.sph;
 var mt=new THREE.MeshBasicMaterial({color:col,transparent:true,opacity:1,depthWrite:false,blending:THREE.AdditiveBlending,side:kind==='ball'?THREE.FrontSide:THREE.DoubleSide});var m=new THREE.Mesh(geo,mt);m.position.set(x,y,z);m.renderOrder=4;R3.sc.add(m);R3.BL.push({m:m,k:kind,t:0,life:life,R:R,mt:mt,c:new THREE.Color(col)});}
function r3blastStep(dt){var L=R3.BL;if(!L)return;for(var i=L.length-1;i>=0;i--){var b=L[i];b.t+=dt;var p=b.t/b.life;if(p>=1){R3.sc.remove(b.m);b.mt.dispose();L.splice(i,1);continue;}var e=1-Math.pow(1-p,3),f=1-p;
 if(b.k==='ball'){b.m.scale.setScalar(b.R*(.35+.75*e));b.mt.color.copy(b.c).multiplyScalar(f*f*1.2);}
 else if(b.k==='dome'){b.m.scale.set(b.R*e,b.R*e*.55,b.R*e);b.mt.color.copy(b.c).multiplyScalar(f*.7);}
 else{b.m.scale.set(b.R*(1-.3*p),4*e+.5,b.R*(1-.3*p));b.m.position.y=(4*e+.5)/2;b.mt.color.copy(b.c).multiplyScalar(f*.42);}}}
function r3boom(x,z,R,col,low){var lo=R3.low;r3flash(x,1.3,z,'#ffb347',3.4,R*2.6+3,.35);
 r3gl(x,.6,z,{c:'#fff7ed',life:.1,s0:R*1.3,s1:R*.8,op:.85});r3gl(x,.6,z,{c:col,life:.3,s0:R*2,s1:R*.9,op:.85});
 r3blast('ball',x,.35,z,col,R*.9,.38);r3fx('ring',x,.07,z,{c:'#fff7ed',life:.35,s0:R*.3,s1:R*1.5,op:.9});r3fx('ring',x,.06,z,{c:col,life:.5,s0:R*.2,s1:R*1.9,op:.7});
 for(var i=0;i<(lo?6:16);i++){var a=Math.random()*6.283,sp=2.5+Math.random()*4;r3sp(x,.4,z,{c:i%3?col:'#fde047',life:.5+Math.random()*.3,vx:Math.cos(a)*sp,vy:2.5+Math.random()*4,vz:Math.sin(a)*sp,g:12,s0:.1,s1:.03,st:i%2?2:1});}
 if(!lo)for(var j=0;j<7;j++){var b=Math.random()*6.283,r=Math.random()*R*.5;r3gl(x+Math.cos(b)*r,.3,z+Math.sin(b)*r,{c:j%2?'#44403c':'#78716c',life:.9+Math.random()*.4,vx:Math.cos(b)*.6,vy:.9+Math.random()*.6,vz:Math.sin(b)*.6,dr:1,s0:R*.9,s1:R*2,op:.55,fi:.12},true);}}
function r3ring(x,z,col,R,n){for(var i=0;i<n;i++){var a=i/n*6.283;r3sp(x+Math.cos(a)*R*.3,.35,z+Math.sin(a)*R*.3,{c:i%2?col:'#ffffff',life:.4,vx:Math.cos(a)*R*2.4,vy:.8+Math.random(),vz:Math.sin(a)*R*2.4,g:4,dr:3,s0:.09,s1:.02,st:2});}}
function r3rise(x,z,col,n,h){for(var i=0;i<n;i++){var a=Math.random()*6.283,r=Math.random()*.45;r3sp(x+Math.cos(a)*r,.1+Math.random()*.3,z+Math.sin(a)*r,{c:i%2?col:'#ffffff',life:.7+Math.random()*.4,vy:(h||2)+Math.random()*1.5,g:-.5,s0:.07,s1:.02,dr:1});}}
function r3events(g,t){var Q=g.fxq;if(!Q||!Q.length)return;var lo=R3.low;
 for(var qi=0;qi<Q.length&&qi<24;qi++){var ev=Q[qi],x=r3x(ev.x),z=r3z(ev.y),col=ev.h!=null&&ev.h>=0?heroCol(ev.h,g):(ev.c||'#fb923c'),R=(ev.r||40)*R3U;
  if(ev.k==='boom')r3boom(x,z,R,ev.c||(ev.h===11?'#34d399':'#fb923c'));
  else if(ev.k==='sp'){r3fx('ring',x,.08,z,{c:'#ffffff',life:.3,s0:.2,s1:R*1.05,op:.9});r3fx('ring',x,.1,z,{c:col,life:.42,s0:.2,s1:R*1.25,op:.8});r3ring(x,z,col,R,lo?6:14);r3gl(x,.7,z,{c:col,life:.25,s0:R*.8,s1:R*.3,op:.55});r3flash(x,1,z,col,2.2,R+3,.25);}
  else if(ev.k==='sup'){var su=ev.su||'';r3flash(x,1.5,z,col,3.8,7,.55);r3blast('pillar',x,0,z,col,.5,.6);r3gl(x,.8,z,{c:'#ffffff',life:.12,s0:1.5,s1:.8,op:.8});r3gl(x,.8,z,{c:col,life:.4,s0:2.4,s1:.6,op:.7});
   r3fx('ring',x,.08,z,{c:'#ffffff',life:.4,s0:.3,s1:2.2,op:.9});r3fx('ring',x,.1,z,{c:col,life:.6,s0:.3,s1:3,op:.8});r3rise(x,z,col,lo?8:22,3);
   var nov={wall:110,thirst:125,quake:165,sonic:150,sun:110,venom:220,nova:130,freeze:180,encore:200};
   if(nov[su]){var NR=nov[su]*R3U;r3blast('dome',x,0,z,su==='freeze'?'#7dd3fc':su==='venom'?'#84cc16':col,NR,.55);r3ring(x,z,col,NR*.8,lo?8:18);}
   if(su==='freeze'&&!lo)for(var f=0;f<16;f++){var fa=f/16*6.283;r3sp(x+Math.cos(fa)*.4,.3,z+Math.sin(fa)*.4,{c:f%2?'#e0f2fe':'#7dd3fc',life:.8,vx:Math.cos(fa)*3,vy:2.5,vz:Math.sin(fa)*3,g:8,s0:.14,s1:.06,st:1.8});}
   if(su==='encore')for(var e2=0;e2<3;e2++)r3fx('ring',x,.1+e2*.3,z,{c:'#f472b6',life:.55+e2*.1,s0:3,s1:.2,op:.8});
   if(su==='mend'||su==='sun')g.ps.forEach(function(p){if(p.hp>0)r3rise(r3x(p.x),r3z(p.y),su==='sun'?'#fde047':'#4ade80',lo?5:12,2.5);});
   if(su==='shadow'||su==='charge'||su==='duel'||su==='phase'){R3.dash=R3.dash||[];g.ps.forEach(function(p){if(Math.abs(p.x-ev.x)<1&&Math.abs(p.y-ev.y)<1)R3.dash.push({p:p,until:t+(su==='duel'||su==='phase'?1.2:.55),c:col});});}}
  else if(ev.k==='melee'){var a0=Math.atan2(ev.fy,ev.fx),rr=Math.max(.5,(ev.r||50)*R3U);col=MCOL[ev.h]||col;
   for(var i=0;i<(lo?3:7);i++){var aa=a0+(i/6-.5)*1.5,px=x+Math.cos(aa)*rr*.85,pz=z+Math.sin(aa)*rr*.85;r3sp(px,.6,pz,{c:i%2?col:'#ffffff',life:.22,vx:Math.cos(aa)*2.4-Math.sin(aa)*1.6,vy:.6,vz:Math.sin(aa)*2.4+Math.cos(aa)*1.6,s0:.06,s1:.015,st:2.2});}
   r3gl(x+Math.cos(a0)*rr*.7,.6,z+Math.sin(a0)*rr*.7,{c:col,life:.14,s0:rr*1.4,s1:.3,op:.8});}
  else if(ev.k==='mhit'){col=MCOL[ev.h]||col;r3gl(x,.75,z,{c:'#ffffff',life:.07,s0:.8,s1:.4,op:1});r3gl(x,.75,z,{c:col,life:.2,s0:1.1,s1:.3,op:1});r3fx('ring',x,.08,z,{c:col,life:.25,s0:.1,s1:.7,op:.85});
   for(var h2=0;h2<(lo?3:8);h2++){var ha=Math.random()*6.283,hs=2+Math.random()*3;r3sp(x,.7,z,{c:h2%2?col:'#fff7cc',life:.25,vx:Math.cos(ha)*hs,vy:1+Math.random()*2.5,vz:Math.sin(ha)*hs,g:8,s0:.06,s1:.015,st:2.4});}r3flash(x,.9,z,col,1.6,3,.14);}
  else if(ev.k==='phit'){var stp=ev.h!=null&&HSTY[ev.h]?HSTY[ev.h]:DSTY;r3impact(x,.72,z,stp,true,false,null);}
  else if(ev.k==='ecast'){r3fx('ring',x,.1,z,{c:ev.c||'#ef4444',life:.45,s0:.3,s1:R*1.6+1,op:.85});r3gl(x,1,z,{c:ev.c||'#ef4444',life:.3,s0:2.2,s1:.6,op:1});r3flash(x,1.4,z,ev.c||'#ef4444',2.4,5,.3);}}
 Q.length=0;}
/* hero dashes and power-ups leave a glowing after-trail */
function r3dashStep(t){var L=R3.dash;if(!L||!L.length)return;for(var i=L.length-1;i>=0;i--){var d=L[i];if(t>d.until||d.p.hp<=0){L.splice(i,1);continue;}var x=r3x(d.p.x),z=r3z(d.p.y);
 r3gl(x,.55,z,{c:d.c,life:.35,s0:.9,s1:.2,op:.7});if(Math.random()<.6)r3sp(x+(Math.random()-.5)*.3,.3+Math.random()*.5,z+(Math.random()-.5)*.3,{c:d.c,life:.4,vy:.8,s0:.06,s1:.01});}}
/* delayed blasts (cannon, arrow rain, carpet bombs): pulsing target on the ground + the thing falling from the sky */
function r3dly(g,t){R3.dlyM=R3.dlyM||new Map();var fr=R3.frameNo,T=R3.T;
 var p=r3pool('dly2',function(){var gr=new THREE.Group(),ring=new THREE.Mesh(T.flat,r3add('#ff4d4d',.95));ring.rotation.x=-Math.PI/2;ring.position.y=.05;gr.add(ring);var fill=new THREE.Mesh(T.disc,r3add('#ff2d2d',.32));fill.rotation.x=-Math.PI/2;fill.position.y=.045;gr.add(fill);
  var ball=new THREE.Group(),cb=new THREE.Mesh(T.sph,r3mat('#1f2937'));cb.scale.setScalar(.24);ball.add(cb);var cf=new THREE.Mesh(T.sph,r3add('#fb923c',.55));cf.scale.setScalar(.34);ball.add(cf);gr.add(ball);
  var arw=shBody('arrow',HSTY[6]);arw.rotation.x=Math.PI/2;arw.scale.setScalar(1.6);gr.add(arw);var bmb=shBody('bomb',HSTY[8]);bmb.scale.setScalar(1.5);gr.add(bmb);
  gr.userData={ring:ring,fill:fill,ball:ball,arw:arw,bmb:bmb};gr.traverse(function(o){o.castShadow=false;});return gr;});
 g.dly.forEach(function(d){var r=R3.dlyM.get(d);if(!r){r={t0:Math.max(.05,d.t)};R3.dlyM.set(d,r);}r.f=fr;
  var m=r3take(p),u=m.userData,R=(d.s.boom||50)*R3U,k=Math.min(1,Math.max(0,1-d.t/r.t0)),x=r3x(d.s.x),z=r3z(d.s.y),su=d.s.o&&d.s.o.ch?d.s.o.ch.su:'';
  m.position.set(x,0,z);u.ring.scale.setScalar(R*(1+.07*Math.sin(t*16)));u.fill.scale.setScalar(Math.max(.01,R*k));
  var h=.25+6.5*(1-k)*(1-k),ox=-1.4*(1-k),oz=-.9*(1-k),it=su==='rain'?u.arw:su==='carpet'?u.bmb:u.ball;u.arw.visible=it===u.arw;u.bmb.visible=it===u.bmb;u.ball.visible=it===u.ball;
  it.position.set(ox,h,oz);if(it===u.bmb)it.rotation.x=t*6;
  if(Math.random()<.7)r3gl(x+ox,h+.15,z+oz,{c:su==='rain'?'#dcfce7':'#fb923c',life:.3,s0:.5,s1:.1,op:.8,vy:.4});});
 r3end(p);R3.dlyM.forEach(function(r,d){if(r.f!==fr)R3.dlyM.delete(d);});}
/* lightning from the sky: jagged instanced beams, flicker every frame, flash + ring where it lands */
function r3bolts(g,t){var P=r3P(),bm=P.bm,n=0;R3.boltM=R3.boltM||new Map();var fr=R3.frameNo;if(!_M4)r3psFlush();
 g.bolts.forEach(function(b){var r=R3.boltM.get(b);var x=r3x(b.x2),z=r3z(b.y2);if(!r){r={};R3.boltM.set(b,r);r3gl(x,.5,z,{c:'#ffffff',life:.12,s0:2.4,s1:1,op:1});r3gl(x,.5,z,{c:'#a5b4fc',life:.35,s0:2.8,s1:.5,op:1});r3fx('ring',x,.08,z,{c:'#c7d2fe',life:.35,s0:.2,s1:1.6,op:.9});
   for(var i=0;i<(R3.low?4:10);i++){var a=Math.random()*6.283,sp=2+Math.random()*3;r3sp(x,.3,z,{c:i%2?'#e0e7ff':'#818cf8',life:.3,vx:Math.cos(a)*sp,vy:1+Math.random()*3,vz:Math.sin(a)*sp,g:8,s0:.06,s1:.015,st:2.6});}r3flash(x,2,z,'#a5b4fc',3,6,.3);}
  r.f=fr;var segs=6,px=x+(Math.random()-.5)*.8,py=7,pz=z+(Math.random()-.5)*.8,fade=Math.max(0,Math.min(1,b.t/.35));
  for(var s=0;s<segs;s++){var k=(s+1)/segs,nx=s===segs-1?x:x+(px-x)*(1-k)+(Math.random()-.5)*.55,ny=7*(1-k),nz=s===segs-1?z:z+(pz-z)*(1-k)+(Math.random()-.5)*.55;
   if(n<90){_V.set((px+nx)/2,(py+ny)/2,(pz+nz)/2);var dx=nx-px,dy=ny-py,dz=nz-pz,len=Math.hypot(dx,dy,dz);_S.set(.07+.05*fade,len,.07+.05*fade);_D.set(dx/len,dy/len,dz/len);_Q.setFromUnitVectors(_UP,_D);_M4.compose(_V,_Q,_S);bm.setMatrixAt(n,_M4);_C.setRGB(.75*fade+.25,.8*fade+.2,1);bm.setColorAt(n,_C);n++;}
   if(Math.random()<.4)r3gl(nx,ny,nz,{c:'#c7d2fe',life:.001,s0:.9,s1:.9,op:.6*fade});px=nx;py=ny;pz=nz;}});
 bm.count=n;bm.instanceMatrix.needsUpdate=true;if(bm.instanceColor)bm.instanceColor.needsUpdate=true;R3.boltM.forEach(function(r,b){if(r.f!==fr)R3.boltM.delete(b);});}
/* compile everything once at load so the first shot / first explosion never stutters */
function r3warmFx(tmp){r3P();r3lightsInit();var all={};for(var i in HSTY)all[HSTY[i].m]=HSTY[i];for(var e in ESTY)all[ESTY[e].m]=ESTY[e];all.dot=DSTY;
 for(var k in all){var o=r3shotMake(k,all[k]);o.position.set(0,-50,0);R3.sc.add(o);tmp.push(o);}
 ['ball','dome','pillar'].forEach(function(k){r3blast(k,0,-50,0,'#ffffff',1,.01);});r3gl(0,-50,0,{life:.01});r3gl(0,-50,0,{life:.01},true);r3sp(0,-50,0,{life:.01});r3psFlush();}
