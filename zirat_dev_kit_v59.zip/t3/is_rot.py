# painted screens follow the phone: portrait shows the list layout, turning to landscape swaps to the painted screen (and back); buttons still work
import sys
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
res=[]
def ok(n,c):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True)
    c.add_init_script(path='/home/claude/t/mock.js')
    c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify({owned:[0,1,3,5],gold:500,dm:150,xp:400}))}catch(e){}')
    pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
    pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3500)
    def act(a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;b.style.display='none';document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(400)
    isw=lambda:pg.evaluate("!!document.querySelector('#ov .isW')")
    for s,chk in [('cfg','[data-a="tg:mu"]'),('prof','#pnm'),('online','#oc'),('pass','[data-a="menu"]'),('cat:hr','[data-a="cg:hr:prof"]')]:
        act('menu');act(s)
        ok(s+' portrait: list layout',not isw() and pg.evaluate("!!document.querySelector('#ov %s')"%chk.replace('"','\\"')))
        pg.set_viewport_size({'width':844,'height':390});pg.wait_for_timeout(700)
        ok(s+' turned to landscape: painted screen',isw() and pg.evaluate("!!document.querySelector('#ov %s')"%chk.replace('"','\\"')))
        pg.set_viewport_size({'width':390,'height':844});pg.wait_for_timeout(700)
        ok(s+' back to portrait: list layout again',not isw())
    pg.set_viewport_size({'width':844,'height':390});pg.wait_for_timeout(500)
    # controls on the painted screens really work
    act('menu');act('cfg');m0=pg.evaluate("__arena().sv.cfg.mu");pg.click('#ov [data-a="tg:mu"]');pg.wait_for_timeout(300)
    ok('settings: tapping a row flips the switch',pg.evaluate("__arena().sv.cfg.mu")!=m0 and pg.evaluate("document.querySelectorAll('#ov .isSw.on').length")>=0)
    pg.click('#ov [data-a="q:1"]');pg.wait_for_timeout(300);ok('settings: quality HD selected',pg.evaluate("__arena().sv.cfg.q")==1 and pg.evaluate("!!document.querySelector('#ov .isQ.on[data-a=\"q:1\"]')"))
    pg.click('#ov [data-a="menu"]');pg.wait_for_timeout(400);ok('settings: back to main menu',pg.evaluate("!!document.querySelector('#ov [data-main]')"))
    act('menu');act('pass');pg.click('#ov [data-a="claim:1:f"]');pg.wait_for_timeout(400);ok('pass: claim level 1 reward',pg.evaluate("!!__arena().sv.cl[1]"))
    pg.click('#ov [data-a="rbuy"]');pg.wait_for_timeout(400);ok('pass: buy gold track with diamonds',pg.evaluate("__arena().sv.rp===true") and 'פתוח' in pg.inner_text('#ov'))
    act('menu');act('prof');pg.fill('#pnm','בדיקה');pg.click('#ov [data-a="pn"]');pg.wait_for_timeout(400);ok('profile: name saved',pg.evaluate("__arena().sv.nm")=='בדיקה')
    pg.click('#ov [data-a="av:3"]');pg.wait_for_timeout(400);ok('profile: avatar picked, hero shown on the pedestal',pg.evaluate("__arena().sv.av")==3 and pg.evaluate("!!document.querySelector('#ov .isAv img, #ov .isAv canvas')"))
    pg.click('#ov [data-a="xfer"]');pg.wait_for_timeout(400);ok('profile: transfer link box opens',pg.evaluate("!!document.getElementById('xferTxt')"))
    act('menu');act('cat:hr');pg.click('#ov [data-a="cg:hr:prof"]');pg.wait_for_timeout(400);ok('hub → profile',pg.evaluate("!!document.getElementById('pnm')"))
    pg.click('#ov [data-a="menu"]');pg.wait_for_timeout(400);ok('profile back → heroes hub',isw() and pg.evaluate("!!document.querySelector('#ov [data-a=\"cg:hr:pick:0\"]')"))
    print('errors',E[:3])
    n=sum(res);print('SUMMARY %d/%d'%(n,len(res)))
