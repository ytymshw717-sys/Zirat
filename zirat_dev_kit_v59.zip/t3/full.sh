#!/bin/bash
# full regression: save, network, rotation, UI/game suites
cd /home/claude
SP=/tmp/claude-0/-home-claude/b0ae6ea6-7673-5629-85ca-afcd48e28043/scratchpad
cp arena3_new.html $SP/arena3_new.html
pkill -f "http.server 9912" 2>/dev/null; (cd $SP && python3 -m http.server 9912 >/dev/null 2>&1 &)
for i in $(seq 1 30); do curl -s -o /dev/null http://127.0.0.1:9912/arena3_new.html && break; sleep 0.5; done
run(){ echo "=== $*"; timeout 900 python3 "$@" 2>&1 | grep -E "PASS|FAIL|SUMMARY|Error|error" | grep -v "^PASS" ; }
run net/t_save.py arena3_new.html
bash net/start_sig.sh
run net/t_net.py
run net/t_relay.py
run net/t_ng.py
for p in $(pgrep -f "^node net/sig.js"); do kill $p; done
echo "=== net/t_drop.py"; timeout 900 python3 net/t_drop.py arena3_new.html 2>&1 | grep -E "joined:"
echo "=== t3/rot3.py"; timeout 900 python3 t3/rot3.py 2>&1 | grep -o "^[0-9x]* \|fits.: [A-Za-z]*\|errors \[.*\]" | sort | uniq -c
for t in t3/t9.py t3/t13.py t3/t12.py t3/t11.py t3/t3.py t3/t7.py; do run $t; done
run t/t1.py arena3_new.html
echo "=== t/t2.py"; timeout 900 python3 t/t2.py arena3_new.html 2>&1 | grep -E "^windows|ERRORS" | cut -c1-300
for t in t3/t4.py t3/t6.py t3/t10.py t3/t14.py t3/t15.py; do run $t; done
run t3/layout.py arena3_new.html
run t3/crawl.py arena3_new.html
run t3/monkey.py arena3_new.html
run t3/team_t.py arena3_new.html
run t3/combat_t.py arena3_new.html
run t3/legal_t.py
run t3/is_rot.py arena3_new.html
run t3/box_t.py arena3_new.html
run t3/joy_t.py arena3_new.html
echo DONE
