# layout audit: every screen x many phone sizes (landscape + portrait); reports overflow, offscreen controls, overlapping controls
import sys,json
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
SIZES=[(932,430),(844,390),(812,375),(740,360),(667,375),(568,320),(390,844),(375,667),(360,740),(320,568)]
SCREENS=['menu','pick:0','hp:0:3','heroes','hi:0','shop','skall','cat:rw','cat:hr','cat:md','maps','cfg','prof','online','tr','qs','pass']
AUD="""(function(){var vw=innerWidth,vh=innerHeight,iss=[];
 function vis(e){var r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>2&&r.height>2&&s.visibility!=='hidden'&&s.display!=='none'&&+s.opacity>0.05;}
 function inHScroll(e){for(var p=e.parentElement;p&&p.id!=='ov';p=p.parentElement){var s=getComputedStyle(p);if((s.overflowX==='auto'||s.overflowX==='scroll')&&p.scrollWidth>p.clientWidth+2)return true;}return false;}
 var ov=document.getElementById('ov');
 if(document.documentElement.scrollWidth>vw+1)iss.push('page wider than screen '+document.documentElement.scrollWidth);
 if(ov&&ov.scrollWidth>ov.clientWidth+2)iss.push('overlay scrolls sideways '+ov.scrollWidth+'>'+ov.clientWidth);
 var els=[].slice.call(document.querySelectorAll('#ov button,#ov .chip,#ov input,#ov select')).filter(vis);
 els.forEach(function(e){var r=e.getBoundingClientRect();if((r.left<-1||r.right>vw+1)&&!inHScroll(e))iss.push('off-screen: '+(e.dataset.a||e.id||e.textContent.trim().slice(0,14))+' ['+Math.round(r.left)+','+Math.round(r.right)+']');});
 for(var i=0;i<els.length;i++)for(var j=i+1;j<els.length;j++){var a=els[i],b=els[j];if(a.contains(b)||b.contains(a))continue;
  var A=a.getBoundingClientRect(),B=b.getBoundingClientRect(),w=Math.min(A.right,B.right)-Math.max(A.left,B.left),h=Math.min(A.bottom,B.bottom)-Math.max(A.top,B.top);
  if(w>3&&h>3){var ar=w*h/Math.min(A.width*A.height,B.width*B.height);if(ar>.15)iss.push('overlap: '+(a.dataset.a||a.textContent.trim().slice(0,10))+' x '+(b.dataset.a||b.textContent.trim().slice(0,10))+' '+Math.round(ar*100)+'%');}}
 // small tap targets
 els.forEach(function(e){if(e.tagName!=='BUTTON')return;var r=e.getBoundingClientRect();if(r.width<26||r.height<22)iss.push('tiny button: '+(e.dataset.a||e.textContent.trim().slice(0,10))+' '+Math.round(r.width)+'x'+Math.round(r.height));});
 // text spilling out of its button
 els.forEach(function(e){if(e.scrollWidth>e.clientWidth+4&&getComputedStyle(e).overflow!=='visible'&&!inHScroll(e))iss.push('text cut: '+(e.dataset.a||e.textContent.trim().slice(0,14)));});
 return iss;})()"""
res={}
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for vp in SIZES:
        tag='%dx%d'%vp;c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=True,is_mobile=True,device_scale_factor=1)
        c.add_init_script(path='/home/claude/t/mock.js');c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify({owned:[0,1,3,5],gold:500,dm:60}))}catch(e){}')
        pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
        pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3500)
        def act(a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;b.style.display='none';document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(500)
        for s in SCREENS:
            act('menu');act(s);pg.wait_for_timeout(300)
            iss=pg.evaluate(AUD)
            if s=='menu' and pg.evaluate("document.getElementById('ov').scrollHeight>innerHeight+2"):iss.append('main menu needs scrolling')
            if iss:res.setdefault(tag,{})[s]=iss[:8]
            if vp in[(844,390),(568,320),(390,844),(320,568)]:pg.screenshot(path='/home/claude/t3/lay/%s_%s.png'%(tag,s.replace(':','_')))
        act('menu');act('play');pg.wait_for_timeout(1500)
        hud=pg.evaluate("""(function(){var o=[];function R(id){var e=document.getElementById(id);if(!e)return null;var r=e.getBoundingClientRect();return r.width?r:null;}
          var ids=['js','atk','spb','sup','gad','top'],rs=ids.map(R);
          for(var i=0;i<ids.length;i++){var a=rs[i];if(!a)continue;if(a.left<-1||a.right>innerWidth+1||a.top<-1||a.bottom>innerHeight+1)o.push(ids[i]+' off-screen');
           for(var j=i+1;j<ids.length;j++){var b=rs[j];if(!b)continue;var w=Math.min(a.right,b.right)-Math.max(a.left,b.left),h=Math.min(a.bottom,b.bottom)-Math.max(a.top,b.top);if(w>4&&h>4)o.push(ids[i]+' overlaps '+ids[j]);}}
          if(document.documentElement.scrollWidth>innerWidth+1)o.push('game page wider than screen');return o;})()""")
        if hud:res.setdefault(tag,{})['game']=hud
        if vp in[(844,390),(568,320),(390,844),(320,568)]:pg.screenshot(path='/home/claude/t3/lay/%s_game.png'%tag)
        if E:res.setdefault(tag,{})['errors']=E[:3]
        print(tag,'screens with issues:',len(res.get(tag,{})),flush=True);c.close()
json.dump(res,open('/home/claude/t3/lay/report.json','w'),ensure_ascii=False,indent=1)
n=sum(len(v) for v in res.values());print(('PASS' if n==0 else 'FAIL')+' layout audit: %d screens x %d sizes, screens with problems: %d'%(len(SCREENS)+1,len(SIZES),n));print('SUMMARY %d/1'%(1 if n==0 else 0))
