import time
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:9911/arena3_new.html'
INIT=open('/home/claude/net/mock_sa.js').read()+";window.__SIG='ws://127.0.0.1:9911/peerjs';window.__NETMAX=3;"
res=[];errs=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
def act(pg,a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a)
def ovt(pg):return pg.evaluate("document.getElementById('ov').innerText")
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    def page(url,tag,extra=''):
        c=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True);c.add_init_script(script=INIT+extra)
        pg=c.new_page();pg.on('pageerror',lambda e:errs.append(tag+':'+str(e)));pg.goto(url);pg.wait_for_timeout(3500);return pg
    def joined(pg,t=30):
        for i in range(t*2):
            if pg.evaluate("!!__net().rm"):return True
            pg.wait_for_timeout(500)
        return False
    H=page(BASE,'host');act(H,'online');H.wait_for_timeout(300);act(H,'onew');H.wait_for_timeout(2500);code=H.evaluate("__net().ocode")
    ok('host room created',H.evaluate("!!__net().rm"),code)
    t0=time.time();R1=page(BASE+'#room-'+code,'relay1',';window.__NODIRECT=1;')
    ok('friend with BLOCKED direct link still joins (fallback through room server)',joined(R1) and R1.evaluate("__net().rm.relay===true"),'%.1fs'%(time.time()-t0))
    D1=page(BASE+'#room-'+code,'direct1');ok('second friend joins directly',joined(D1) and not D1.evaluate("__net().rm.relay"))
    H.wait_for_timeout(1200)
    ok('host screen shows a friend is joining (diagnostics)','חבר' in H.evaluate("(document.getElementById('roomTry')||{}).textContent||''"),H.evaluate("(document.getElementById('roomTry')||{}).textContent||''"))
    ok('version label shown on both phones','גרסה 57' in ovt(H) and 'גרסה 57' in ovt(R1))
    ok('host sees both friends (3 / 3)',H.evaluate("__net().opeers.length")==2 and '3 / 3' in ovt(H),str(H.evaluate("__net().opeers.length")))
    ok('blocked friend sees host + other friend',R1.evaluate("__net().opeers.length")==2)
    R2=page(BASE+'#room-'+code,'relay2',';window.__NODIRECT=1;');
    for i in range(40):
        if 'החדר מלא' in ovt(R2):break
        R2.wait_for_timeout(500)
    ok('room full message also on the fallback route','החדר מלא' in ovt(R2),ovt(R2)[:70])
    for pg in (H,R1,D1):act(pg,'menu');pg.wait_for_timeout(300);act(pg,'mode:survive');pg.wait_for_timeout(300)
    for i in range(40):
        if H.evaluate("__net().opeers.every(function(q){return q.presence&&q.presence.m==='survive'})"):break
        H.wait_for_timeout(250)
    me=R1.evaluate("__net().rm.me");R1.keyboard.down('KeyD');R1.wait_for_timeout(2500);R1.keyboard.up('KeyD');H.wait_for_timeout(1500)
    x=R1.evaluate("__arena().ps[0].x");seen=H.evaluate("(function(id){var q=__net().opeers.filter(function(p){return p.peer===id})[0];return q&&q.presence&&q.presence.x})(%r)"%me)
    ok('blocked friend moves → host sees him move',seen is not None and abs(seen-x)<60 and abs(seen-480)>5,'%s vs %s'%(seen,x))
    hx=H.evaluate("__arena().ps[0].x");rs=R1.evaluate("__net().opeers.map(function(q){return q.presence&&q.presence.m})")
    ok('blocked friend sees the others in the game',len(rs)==2 and all(m=='survive' for m in rs),str(rs))
    ok('friends drawn as 3D heroes for the blocked friend',R1.evaluate("G3.r3state()&&G3.r3state().ents")>=3)
    time.sleep(13)
    ok('fallback link stays alive (no drop after 13s)',R1.evaluate("!!__net().rm") and H.evaluate("__net().opeers.length")==2)
    act(D1,'pz');act(D1,'menu');D1.wait_for_timeout(300);act(D1,'online');D1.wait_for_timeout(300);act(D1,'ol');H.wait_for_timeout(1500)
    ok('a friend leaves → host count drops',H.evaluate("__net().opeers.length")==1)
    act(R1,'pz');act(R1,'menu');R1.wait_for_timeout(300);act(R1,'online');R1.wait_for_timeout(300)
    act(H,'pz');act(H,'menu');H.wait_for_timeout(300);act(H,'online');H.wait_for_timeout(300);act(H,'ol')
    for i in range(30):
        if 'המארח סגר' in ovt(R1):break
        R1.wait_for_timeout(500)
    ok('host closes → blocked friend is told','המארח סגר' in ovt(R1),ovt(R1)[:70])
    ok('no JS errors',not errs,str(errs[:4]))
    print('SUMMARY %d/%d'%(sum(res),len(res)))
