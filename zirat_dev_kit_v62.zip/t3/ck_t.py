# cookie notice: shows once on first launch, "הבנתי" hides it for good, "פרטים" opens the privacy page; legal page has cookies + security sections; painted buttons press in
import sys
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
res=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True);c.add_init_script(path='/home/claude/t/mock.js');c.add_init_script(script='window.__ckTest=1')
    pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
    pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(4500)
    ok('notice shows on first launch',pg.evaluate("!!document.getElementById('ckN')"))
    pg.click('#ckN [data-ck=ok]');pg.wait_for_timeout(300)
    ok('הבנתי hides it',not pg.evaluate("!!document.getElementById('ckN')"))
    pg.reload();pg.wait_for_timeout(4500)
    ok('stays hidden after reload',not pg.evaluate("!!document.getElementById('ckN')"))
    c.close();c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True);c.add_init_script(path='/home/claude/t/mock.js');c.add_init_script(script='window.__ckTest=1')
    pg=c.new_page();pg.on('pageerror',lambda e:E.append(str(e)));pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(4500)
    pg.click('#ckN [data-ck=more]');pg.wait_for_timeout(500)
    t=pg.evaluate("document.getElementById('ov').innerText")
    ok('פרטים opens privacy page with cookies + security',"עוגיות (Cookies)" in t and "אבטחה" in t)
    ok('CSP meta present',pg.evaluate("!!document.querySelector('meta[http-equiv=\"Content-Security-Policy\"]')"))
    pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('cat:hr')");pg.wait_for_timeout(1200)
    bt=pg.query_selector("#ov .isT[data-a='cg:hr:prof']");bb=bt.bounding_box()
    pg.mouse.move(bb['x']+bb['width']/2,bb['y']+bb['height']/2);pg.mouse.down();pg.wait_for_timeout(60)
    ok('painted button presses in under the finger','prs' in bt.get_attribute('class'))
    ok('painted button shows its own piece of the picture','url' in pg.evaluate("getComputedStyle(document.querySelector(\"#ov .isT[data-a='cg:hr:prof']\")).backgroundImage"))
    pg.mouse.up();pg.wait_for_timeout(800)
    ok('tap still opens the screen',pg.evaluate("(document.querySelector('#ov .isH')||{}).textContent||''").find('פרופיל')>=0)
    pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('cfg')");pg.wait_for_timeout(1200)
    r=pg.evaluate("Array.from(document.querySelectorAll('#ov .isT[data-a^=\"tg:\"]')).map(function(b){return getComputedStyle(b).backgroundImage})")
    ok('settings rows keep their painted labels (no cut-out drawn over them)',len(r)==7 and all(x=='none' for x in r),str(r[:2]))
    ok('no errors',not E,str(E[:3]))
    print('SUMMARY %d/%d'%(sum(res),len(res)))
