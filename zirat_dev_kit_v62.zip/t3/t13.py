import math
from playwright.sync_api import sync_playwright
res=[];errs=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True,device_scale_factor=2)
    c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append('con:'+m.text) if m.type=='error' else None)
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3500)
    def act(a):pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='%s';document.getElementById('ov').appendChild(b);b.click();})()"%a);pg.wait_for_timeout(60)
    for m in ['survive','siege','boss','heist','gems','hot','ball','show','train']:
        act('mode:'+m);pg.wait_for_timeout(1800)
        pg.keyboard.down('KeyD');pg.keyboard.down('Space');pg.wait_for_timeout(900);pg.keyboard.up('KeyD');pg.keyboard.up('Space')
        s=pg.evaluate("G3.r3state()")
        hud=pg.evaluate("(function(){var c=document.getElementById('cv'),x=c.getContext('2d'),d=x.getImageData(0,0,c.width,c.height).data,n=0;for(var i=3;i<d.length;i+=400)if(d[i]>0)n++;return n})()")
        ok('mode %s renders in 3D'%m,s and s['calls']>10 and pg.evaluate("document.getElementById('cv3').style.display")=='block',str(s and s['calls']))
        ok('   health bars / HUD drawn over 3D',hud>20,str(hud))
        ok('   game running',pg.evaluate("__arena().state") in ('play','shop','over'))
        pg.keyboard.press('KeyP');pg.wait_for_timeout(80);act('menu')
    # camera rotation keeps controls correct
    act('mode:survive');pg.wait_for_timeout(1500);pg.evaluate("__arena().enemies.forEach(function(e){e.stun=99;e.cd=99;})")
    for yaw in [0,1.57,3.14,4.2]:
        for start in [(480,270),(360,330),(600,200)]:
            pg.evaluate("__yaw(%f);var p=__arena().ps[0];p.x=%d;p.y=%d;__arena().obs.length=0"%(yaw,start[0],start[1]));pg.wait_for_timeout(900)
            a=pg.evaluate("(function(){var p=__arena().ps[0];return [p.x,p.y]})()")
            pg.keyboard.down('KeyD');pg.wait_for_timeout(450);pg.keyboard.up('KeyD');pg.wait_for_timeout(200)
            r=pg.evaluate("(function(a){var p=__arena().ps[0];var A=G3.r3proj(a[0],a[1],0),B=G3.r3proj(p.x,p.y,0);return [B[0]-A[0],B[1]-A[1]]})(%s)"%a)
            if math.hypot(*r)>3:break
        l=math.hypot(*r) or 1
        ok('camera yaw %.2f: right = right on screen'%yaw,r[0]/l>.85,str([round(v) for v in r])+' '+pg.evaluate('__arena().state')+' hp='+str(pg.evaluate('__arena().ps[0].hp'))+' en='+str(pg.evaluate('__arena().enemies.length')))
    pg.evaluate("__yaw(0)")
    # spin + super visuals do not break
    pg.evaluate("var p=__arena().ps[0];p.spcd=0;p.sup=100");pg.keyboard.down('KeyK');pg.wait_for_timeout(700);pg.keyboard.up('KeyK');pg.wait_for_timeout(200)
    ok('spin works in 3D',pg.evaluate("__arena().ps[0].spcd")>0,pg.evaluate('__arena().state'))
    # toggle 3D world off → classic 2.5D, on again → 3D
    pg.keyboard.press('KeyP');pg.wait_for_timeout(80);act('menu')
    act('cfg');ok('settings has 3D world switch',pg.evaluate("!!document.querySelector('[data-a=\"tg:r3\"]')"))
    act('tg:r3');act('menu');act('mode:survive');pg.wait_for_timeout(1200)
    ok('switch off → classic 2.5D drawing',pg.evaluate("document.getElementById('cv3').style.display")=='none' and pg.evaluate("A3.sv.cfg.r3")==False)
    pg.keyboard.press('KeyP');pg.wait_for_timeout(80);act('menu');act('cfg');act('tg:r3');act('menu');act('mode:survive');pg.wait_for_timeout(1200)
    for _w in range(10):
        if pg.evaluate("document.getElementById('cv3').style.display")=='block':break
        pg.wait_for_timeout(300)
    ok('switch on → 3D again',pg.evaluate("document.getElementById('cv3').style.display")=='block')
    # online friend shows as 3D hero
    pg.keyboard.press('KeyP');pg.wait_for_timeout(80);act('menu');act('shop');act('cg:shop:online');pg.fill('#oc','r3test');act('oj');pg.wait_for_timeout(400);act('menu');act('menu')
    act('mode:survive');pg.wait_for_timeout(1500)
    ok('online join inside Claude opens the room on the game site',pg.evaluate("window.__opened&&window.__opened.slice(-1)[0]")=='https://ytymshw717-sys.github.io/Zirat/?v=62#room-r3test')
    pg.screenshot(path='/home/claude/t3/r3_online.png')
    b.close()
print('ERRORS',errs);print('SUMMARY %d/%d'%(sum(res),len(res)))
