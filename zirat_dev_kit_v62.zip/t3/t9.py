from playwright.sync_api import sync_playwright
res=[];errs=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch()
    for vp in [(844,390),(390,844),(1280,720)]:
        tag='%dx%d'%vp
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=vp[0]<1000,is_mobile=vp[0]<1000)
        c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();pg.on('pageerror',lambda e:errs.append(tag+str(e)))
        pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3300)
        def click(a):
            n=pg.evaluate("(function(){var b=[].filter.call(document.querySelectorAll('#ov [data-a]'),function(x){return x.dataset.a==='%s'})[0];if(!b)return 0;b.click();return 1})()"%a);pg.wait_for_timeout(120);return n
        ok(tag+' skins button no longer on main screen',not pg.evaluate("!!document.querySelector('#ov [data-a=skall]')"))
        click('cat:hr');ok(tag+' skins inside heroes window',click('cg:hr:skall')==1 and pg.evaluate("document.querySelectorAll('#ov [data-a^=\"cg:sk:skins:\"]').length")>0)
        click('menu');click('menu')
        click('shop');click('cg:shop:online')
        ok(tag+' online window (inside Claude) sends rooms to the game site',pg.evaluate("(function(){var a=document.getElementById('siteNew');return !!a&&a.getAttribute('href')==='https://ytymshw717-sys.github.io/Zirat/?v=62#host'&&a.target==='_blank'})()") and 'בלי Claude' in pg.inner_text('#ov'))
        ok(tag+' no Claude-room create button any more',not pg.evaluate("!!document.querySelector('#ov [data-a=onew]')"))
        ok(tag+' room window fits width',pg.evaluate("document.getElementById('ov').scrollWidth<=document.getElementById('ov').clientWidth+1"))
        pg.screenshot(path='/home/claude/t3/room_%s.png'%tag)
        click('menu');ok(tag+' back to shop','חנות' in pg.inner_text('#ov'))
        # joining by typed code opens that room on the game site (not Claude)
        click('cg:shop:online');pg.fill('#oc','friend9');click('oj');pg.wait_for_timeout(300)
        ok(tag+' join friend code → opens site room',pg.evaluate("window.__opened.slice(-1)[0]")=='https://ytymshw717-sys.github.io/Zirat/?v=62#room-friend9' and pg.evaluate("!window.__joined") and 'github.io' in pg.inner_html('#ov'),str(pg.evaluate("window.__opened")))
        c.close()
    # opening the shared link auto-joins
    c=b.new_context(viewport={'width':844,'height':390});c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('file:///home/claude/arena3_new.html#room-ab12cd');pg.wait_for_timeout(9000)
    ok('old Claude room link → points to the same room on the game site',pg.evaluate("[].some.call(document.querySelectorAll('#ov a'),function(a){return a.getAttribute('href')==='https://ytymshw717-sys.github.io/Zirat/?v=62#room-ab12cd'})") and not pg.evaluate("window.__joined"),pg.inner_text('#ov')[:120])
    # QR decodes back to the link (round trip via library)
    c.close();b.close()
print('ERRORS',errs);print('SUMMARY %d/%d'%(sum(res),len(res)))
