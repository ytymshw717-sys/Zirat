import sys,math,json,time
from playwright.sync_api import sync_playwright
F='file:///home/claude/'+(sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html')
out='/home/claude/t/'
res=[];errs=[]
def ok(n,c,info=''):
    res.append((n,bool(c),info));print(('PASS ' if c else 'FAIL ')+n,info,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--autoplay-policy=no-user-gesture-required'])
    for vp,mob in [((844,390),True),((1280,720),False),((390,844),True)]:
        tag='%dx%d'%vp
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=mob,is_mobile=mob,device_scale_factor=2 if mob else 1)
        c.add_init_script(path='/home/claude/t/mock.js')
        pg=c.new_page();pg.on('pageerror',lambda e:errs.append(tag+':'+str(e)));pg.on('console',lambda m:errs.append(tag+' console:'+m.text) if m.type=='error' else None)
        pg.goto(F);pg.wait_for_timeout(600)
        ok(tag+' splash shown','טוען' in pg.inner_text('#ov'))
        pg.wait_for_timeout(2800)
        ok(tag+' menu after splash',pg.evaluate("document.querySelector('#ov [data-a=play]')!==null"))
        if tag=='1280x720':
            # online
            pg.evaluate("document.querySelector('[data-a=shop]').click()");pg.wait_for_timeout(200);pg.evaluate("document.querySelector('[data-a=\"cg:shop:online\"]').click()")
            pg.wait_for_timeout(300)
            has=pg.evaluate("!!document.getElementById('oc')")
            ok(tag+' online window has room input',has)
            if has:
                pg.fill('#oc','test1');pg.click('[data-a=oj]');pg.wait_for_timeout(400)
                ok(tag+' join opens the room on the game site',pg.evaluate("window.__opened.slice(-1)[0]")=='https://ytymshw717-sys.github.io/Zirat/?v=62#room-test1',pg.inner_text('#ov')[:60])
            pg.evaluate("document.querySelector('[data-a=menu]').click()");pg.wait_for_timeout(200)
            ok(tag+' online back returns to shop','חנות' in pg.inner_text('#ov'))
            pg.evaluate("document.querySelector('[data-a=menu]').click()");pg.wait_for_timeout(200)
        pg.evaluate("document.querySelector('#ov [data-a=play]').click()");pg.wait_for_timeout(1500)
        st=pg.evaluate("__arena().state");ok(tag+' play state',st=='play',st)
        if st!='play':
            pg.screenshot(path=out+tag+'_fail.png');c.close();continue
        pg.evaluate("__arena().enemies.forEach(function(e){e.stun=99;e.cd=99;})");
        def ens():
            for _ in range(3):
                if pg.evaluate("__arena().state")=='shop':pg.evaluate("document.querySelector('[data-a=next]').click()");pg.wait_for_timeout(200)
        def pos():return pg.evaluate("[__arena().ps[0].x,__arena().ps[0].y]")
        def hold(k,ms):
            pg.keyboard.down(k);pg.wait_for_timeout(ms);pg.keyboard.up(k)
        # yaw 0 movement
        pg.evaluate("__yaw(0)")
        for k,ex in [('KeyD',(1,0)),('KeyA',(-1,0)),('KeyS',(0,1)),('KeyW',(0,-1))]:
            pg.evaluate("__arena().enemies.forEach(function(e){e.stun=99;e.cd=99;});var p=__arena().ps[0];p.x=480;p.y=270;p.hp=p.mhp;__arena().obs.length=0")
            a=pos();hold(k,800);bb=pos();d=(bb[0]-a[0],bb[1]-a[1]);l=math.hypot(*d) or 1
            ok(tag+" yaw0 "+k,l>15 and (d[0]*ex[0]+d[1]*ex[1])/l>.9,str(d)+pg.evaluate("__arena().state+document.getElementById('ov').className")+pg.evaluate("document.getElementById('ov').innerText.slice(0,50)"))
        # rotate by key X
        y0=pg.evaluate("__yaw()");hold('KeyX',1500);y1=pg.evaluate("__yaw()")
        ok(tag+' KeyX rotates camera',y1>y0+.3,'%.2f->%.2f'%(y0,y1))
        hold('KeyC',80);ok(tag+' KeyC resets',pg.evaluate("__yaw()")==0)
        # rotated movement for several angles
        for ang in [math.pi/2,math.pi,3*math.pi/4,5.5]:
            pg.evaluate("__yaw(%f)"%ang)
            for k,sx in [('KeyD',(1,0)),('KeyW',(0,-1))]:
                pg.evaluate("__arena().enemies.forEach(function(e){e.stun=99;e.cd=99;});var p=__arena().ps[0];p.x=480;p.y=270;p.hp=p.mhp;__arena().obs.length=0")
                a=pos();hold(k,1000);bb=pos();d=(bb[0]-a[0],bb[1]-a[1]);l=math.hypot(*d) or 1
                # expected world = R(-yaw)*screen
                cs,sn=math.cos(ang),math.sin(ang);ew=(sx[0]*cs+sx[1]*sn,-sx[0]*sn+sx[1]*cs)
                ok(tag+' yaw%.2f %s maps screen dir'%(ang,k),l>12 and (d[0]*ew[0]+d[1]*ew[1])/l>.9,str((round(d[0]),round(d[1]))))
        # canvas non-blank and screenshot rotated
        pg.evaluate("__yaw(0.7)");pg.wait_for_timeout(250)
        pg.screenshot(path=out+tag+'_yaw.png')
        var=pg.evaluate("(function(){var c=document.getElementById('cv'),x=c.getContext('2d'),d=x.getImageData(0,0,c.width,c.height).data,s={};for(var i=0;i<d.length;i+=4000)s[d[i]+','+d[i+1]+','+d[i+2]]=1;return Object.keys(s).length;})()")
        r3s=pg.evaluate("G3.r3state()")
        ok(tag+' rotated view has content',var>40 or (r3s and r3s['calls']>10),'2d colors=%s 3d=%s'%(var,r3s and r3s['calls']))
        # touch rotate buttons
        if mob:
            vis=pg.evaluate("(function(){var r=document.getElementById('rr').getBoundingClientRect();return r.width>0&&r.right<=innerWidth+1&&r.top>=0})()")
            ok(tag+' rotate button visible',vis)
            pg.evaluate("__yaw(0)")
            pg.tap('#rr');pg.wait_for_timeout(150)
            yv=pg.evaluate("__yaw()");ok(tag+' tap ⟳ rotates 45°',abs(yv-math.pi/4)<.05,'%.3f'%yv)
            pg.tap('#rl');pg.wait_for_timeout(150);ok(tag+' tap ⟲ back to 0',pg.evaluate("__yaw()")==0)
            print('A',pg.evaluate("[__arena().state,__arena().enemies.length,__arena().wave,document.querySelectorAll('[data-a=next]').length]"));ens();print('B',pg.evaluate("[__arena().state,__arena().enemies.length]"));pg.wait_for_timeout(1500);print('C',pg.evaluate("[__arena().state,__arena().enemies.length]"));ens();pg.evaluate("__arena().enemies.forEach(function(e){e.stun=99;e.cd=99;})");pg.evaluate("__arena().enemies.push({t:'dummy',x:100,y:100,r:13,hp:9999,maxhp:9999,state:'chase',wind:0,cd:99,stun:99,kx:0,ky:0,flash:0,dir:1,walk:0,speed:0})")
            # joystick drag at yaw pi/2 : drag right -> world up
            pg.evaluate("__yaw(Math.PI/2);var p=__arena().ps[0];p.x=480;p.y=270;__arena().obs.length=0")
            r=pg.evaluate("(function(){var r=document.getElementById('js').getBoundingClientRect();return [r.left+r.width/2,r.top+r.height/2]})()")
            print('pre-touch',pg.evaluate("[__arena().state,__arena().enemies.length]"))
            a=pos()
            cdp=c.new_cdp_session(pg)
            def tp(t,x,y):cdp.send('Input.dispatchTouchEvent',{'type':t,'touchPoints':[] if t=='touchEnd' else [{'x':x,'y':y,'id':1}]})
            tp('touchStart',r[0],r[1]);
            for i in range(1,6):tp('touchMove',r[0]+i*10,r[1]);pg.wait_for_timeout(30)
            pg.wait_for_timeout(300);tp('touchEnd',0,0);bb=pos();d=(bb[0]-a[0],bb[1]-a[1]);l=math.hypot(*d) or 1
            ok(tag+' joystick right at yaw90 -> world up',l>10 and -d[1]/l>.85,str((round(d[0]),round(d[1])))+pg.evaluate("__arena().state")+str(r)+pg.evaluate("(function(){var e=document.elementFromPoint(%f,%f);return e.id+'/'+e.className})()"%(r[0],r[1])))
            pg.evaluate("__yaw(0)")
        ens()
        # attack works when rotated
        pg.evaluate("__yaw(1.2);var A=__arena(),p=A.ps[0];p.x=480;p.y=270;A.enemies.forEach(function(e){e.stun=99;e.cd=99;})")
        sc0=pg.evaluate("__arena().score")
        pg.evaluate("(function(){var A=__arena(),p=A.ps[0];A.enemies.push({t:'grunt',x:p.x+(p.ch.rng?Math.min(p.ch.rng*.5,40):30),y:p.y,r:13,hp:2,maxhp:2,state:'chase',wind:0,cd:9,stun:5,kx:0,ky:0,flash:0,dir:1,walk:0,speed:0,tst:1});p.fx=1;p.fy=0;})()")
        for i in range(12):hold('Space',60);pg.wait_for_timeout(60)
        hp=pg.evaluate("(function(){var e=__arena().enemies;var t=e.filter(function(q){return q.tst;})[0];return t?t.hp:-1;})()")
        ok(tag+' attack hits enemy while rotated',hp<2,str(hp))
        # sound
        so=pg.evaluate("window.__snd");ok(tag+' sound nodes created',so['osc']>0,json.dumps(so))
        # pause/resume and 2.5D toggle off resets yaw
        ens();pg.keyboard.press('KeyP');pg.wait_for_timeout(150);ok(tag+' pause',pg.evaluate("__arena().state")=='pause')
        pg.evaluate("__arena().sv.cfg.v25=false");pg.wait_for_timeout(100)
        ok(tag+' 2.5D off forces yaw 0',pg.evaluate("__yaw()")==0)
        pg.evaluate("__arena().sv.cfg.v25=true")
        if tag=='1280x720':
            ok(tag+' online join inside Claude went to the game site (presence is tested on the site, net/t_net.py)',pg.evaluate("window.__opened.length")>0)
        c.close()
    b.close()
print('ERRORS',errs)
print('SUMMARY %d/%d'%(sum(1 for r in res if r[1]),len(res)))
