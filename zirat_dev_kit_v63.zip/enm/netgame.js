/* ===== shared online match: the host runs the one real game; friends steer their own hero and see the host's world (enemies, shots, effects) ===== */
var NG={vs:0,side:0,sides:{},mp:[],gone:{},vsB:[],mySid:0,on:0,host:0,cli:0,me:'',hn:'',pl:{},ids:new WeakMap(),nid:1,seen:new WeakSet(),acc:{fx:[],fl:[],pt:[],sd:[]},snd:[],sT:0,O:{},rT:0,iv:90,ivA:90,last:0,pend:[],sq:0,ac:0,sc:0,uc:0,gc:0,iT:0,kp:{},st:'play',wiF:null,lost:0,hp:{}};
var NGA=['ps','enemies','tbots','structs','shots','eshots','drops','chests','allies','dly','bolts'],NGOB=['zone','gas','bl','safeS','tmark'];
var NGI={x:1,y:1,walk:1,atk:1,wind:1,spin:1,fx:1,fy:1,hp:1,sup:1,t:1};
var NGOWN={x:1,y:1,fx:1,fy:1,dir:1,walk:1,atk:1,kx:1,ky:1,ax:1,ay:1,aimO:1,manS:1,spA:1,net:1};
function ngA(n){switch(n){case 'ps':return ps;case 'enemies':return enemies;case 'tbots':return tbots;case 'structs':return structs;case 'shots':return shots;case 'eshots':return eshots;case 'drops':return drops;case 'chests':return chests;case 'allies':return allies;case 'dly':return dly;case 'bolts':return bolts;}return [];}
function ngSA(n,v){switch(n){case 'ps':ps=v;break;case 'enemies':enemies=v;break;case 'tbots':tbots=v;break;case 'structs':structs=v;break;case 'shots':shots=v;break;case 'eshots':eshots=v;break;case 'drops':drops=v;break;case 'chests':chests=v;break;case 'allies':allies=v;break;case 'dly':dly=v;break;case 'bolts':bolts=v;break;}}
function ngO(n){switch(n){case 'zone':return zone;case 'gas':return gas;case 'bl':return bl;case 'safeS':return safeS;case 'tmark':return tmark;}return null;}
function ngSO(n,v){switch(n){case 'zone':zone=v;break;case 'gas':gas=v;break;case 'bl':bl=v;break;case 'safeS':safeS=v;break;case 'tmark':tmark=v;break;}}
function ngGlob(){return {sc:score,wv:wave,gl:goal,bn:banner,bt:bannerText,sk:shake,sf:sflash,bs:bscore,gm:gems,gg:gemGoal,ho:hot,tk:tko,tt:tTime,ts:tSudden,hs:HSTOP,gT:gT,cn:coins,st:state,up:UP};}
function ngSetGlob(g){if(!g)return;score=g.sc|0;wave=g.wv|0;goal=g.gl|0;if(!(NG.side===1&&banner>0&&/הופלת/.test(bannerText))){banner=+g.bn||0;bannerText=g.bt||'';}shake=Math.max(shake,+g.sk||0);sflash=Math.max(sflash,+g.sf||0);if(g.bs)bscore=g.bs;gems=g.gm|0;gemGoal=g.gg|0;hot=+g.ho||0;if(g.tk)tko=NG.side===1?[g.tk[1],g.tk[0]]:g.tk;tTime=+g.tt||0;tSudden=!!g.ts;gT=+g.gT||0;if(g.up)UP=g.up;if(g.cn!=null&&g.cn!==coins){coins=g.cn|0;try{cnEl.textContent=coins;}catch(e){}}try{if(scEl.textContent!==String(score))scEl.textContent=score;}catch(e){}NG.st=g.st||'play';}
/* ---- playout clock: the other side's timestamps -> ours. o = near-minimum offset, j = how late messages usually are (wifi bursts) ---- */
function ngClk(c,off){if(c.o==null||off<c.o)c.o=off;else c.o+=(off-c.o)*.001;var j=off-c.o;c.j=c.j==null?j:c.j+(j-c.j)*(j>c.j?.25:.03);}
/* a friend's hero on the host: positions are played back from a short buffer, so bursts arrive as smooth walking instead of freeze-and-jump */
function ngPos(N,tpMin){var B=N.buf;if(!B||!B.length||N.ck==null)return null;var now=performance.now(),C=N.ck,D=Math.max(25,Math.min(300,(N.iv||45)+2.5*(C.j||0)+10)),t=now-C.o-D,i,a=null,b=null;
 for(i=B.length-1;i>=0;i--){if((B[i].tp|0)<tpMin)break;if(B[i].t<=t){a=B[i];b=B[i+1]||null;break;}b=B[i];}
 if(!a){if(!b)return null;a=b;b=null;}
 if(!b){var l=B[B.length-1];if(l!==a||!a.p||(l.tp|0)<tpMin)return {x:a.x,y:a.y,fx:a.fx,fy:a.fy,d:a.d,w:a.w};var e=Math.min(80,t-a.t)/Math.max(20,a.t-a.p.t);if(e<=0||(a.p.tp|0)!==(a.tp|0))return {x:a.x,y:a.y,fx:a.fx,fy:a.fy,d:a.d,w:a.w};return {x:a.x+(a.x-a.p.x)*e,y:a.y+(a.y-a.p.y)*e,fx:a.fx,fy:a.fy,d:a.d,w:a.w};}
 var f=(t-a.t)/Math.max(1,b.t-a.t);f=Math.max(0,Math.min(1,f));if((a.tp|0)!==(b.tp|0))f=f<1?0:1;
 return {x:a.x+(b.x-a.x)*f,y:a.y+(b.y-a.y)*f,fx:f<.5?a.fx:b.fx,fy:f<.5?a.fy:b.fy,d:f<.5?a.d:b.d,w:a.w+(b.w-a.w)*f};}
/* ---- encode (host) ---- */
function ngId(o){var i=NG.ids.get(o);if(!i){i=NG.nid++;NG.ids.set(o,i);}return i;}
function ngIsCh(v){return typeof v.nk==='string'&&typeof v.sp==='number'&&typeof v.hp==='number';}
function ngV(v,d){var t=typeof v;
 if(t==='number')return isFinite(v)?Math.round(v*100)/100:0;
 if(t==='string'||t==='boolean'||v==null)return v;
 if(t!=='object')return undefined;
 if(d>0){var id=NG.ids.get(v);if(id)return {$r:id};}
 if(ngIsCh(v))return {$c:[v.idx|0,v.skn|0]};
 if(d>=3||v.nodeType||v.isObject3D||v instanceof HTMLElement)return undefined;
 if(Array.isArray(v)){if(v.length>48)return undefined;return v.map(function(x){var y=ngV(x,d+1);return y===undefined?null:y;});}
 var o={},n=0;for(var k in v){if(!Object.prototype.hasOwnProperty.call(v,k)||k.charCodeAt(0)===95)continue;var y=ngV(v[k],d+1);if(y!==undefined){o[k]=y;if(++n>40)break;}}return o;}
function ngEnt(e){var o=ngV(e,0);if(o&&typeof o==='object'&&!Array.isArray(o))o.$i=ngId(e);return o;}
function ngSnap(full){
 NGA.forEach(function(n){ngA(n).forEach(function(e){if(e&&typeof e==='object')ngId(e);});});
 var S={t:'sn',q:++NG.sq,ht:Math.round(performance.now()),a:{},o:{},g:ngGlob(),ev:NG.acc};
 NGA.forEach(function(n){S.a[n]=ngA(n).map(ngEnt);});
 NGOB.forEach(function(n){var v=ngO(n);S.o[n]=v?ngV(v,1):null;});
 if(full)S.f={obs:obs.map(function(o){return ngV(o,1);}),bu:bushes.map(function(o){return ngV(o,1);})};
 NG.acc={fx:[],fl:[],pt:[],sd:[]};return S;}
/* ---- host side ---- */
function ngHostWant(){return !!(rm&&rm.net&&rm.isHost&&rm.send&&opeers.length&&mode!=='pvp');}
function ngAddPeers(vs){NG.vs=vs?1:0;NG.sides={};NG.mp=[];NG.vsB=[];NG.gone={};NG.pl={};opeers.forEach(function(q,qi){var s=q.presence||{};if(NG.mp.length>=5)return;var sd=vs?(qi%2===0?1:0):0;NG.sides[q.peer]=sd;NG.mp.push(q.peer);
 if(sd===1){var hB=CH[s.h|0]?s.h|0:0;NG.vsB.push({peer:q.peer,h:hB,k:s.k|0,nm:String(s.nm||CH[hB].nk).slice(0,14),lm:Math.max(1,Math.min(2,+s.lm||1)),lv:s.lv|0});NG.pl[q.peer]={x:0,y:0,tp:0,ac:0,sc:0,uc:0,gc:0,t:Date.now()};return;}var h=CH[s.h|0]?s.h|0:0,k=s.k|0,lm=Math.max(1,Math.min(2,+s.lm||1));
 var p=mkPlayer(0);p.i=ps.length;p.ch=skinnedK(h,k);p.ch.idx=h;p.ch.skn=k;p.lm=lm;p.mhp=p.hp=Math.round(p.ch.hp*lm);p.nlv=s.lv|0;p.net=q.peer;p.nm=String(s.nm||p.ch.nk).slice(0,14);p.x=ps[0].x+44*p.i;p.y=ps[0].y;p.tpN=0;ps.push(p);NG.pl[q.peer]={x:p.x,y:p.y,tp:0,ac:0,sc:0,uc:0,gc:0,t:Date.now()};});}
function ngHostBegin(){NG.on=1;NG.host=1;NG.cli=0;NG.acc={fx:[],fl:[],pt:[],sd:[]};NG.snd=[];NG.sT=0;NG.rT=0;NG.seen=new WeakSet();fl.forEach(function(f){NG.seen.add(f);});parts.forEach(function(f){NG.seen.add(f);});
 ps.forEach(function(p){if(p.net){p._lx=p.x;p._ly=p.y;p._ix=p.x;p._iy=p.y;}});
 NG.mp.forEach(function(id){var gs={t:'gs',m:mode,sg:stage,wi:WI,df:dfi,W:W,H:H,hn:String(sv.nm||'').slice(0,14),hh:ps[0]?ps[0].ch.idx:0,vs:NG.vs,sd:NG.sides[id]|0};try{rm.send(id,gs);}catch(e){}});
 var s0=ngSnap(true);NG.mp.forEach(function(id){try{rm.send(id,s0);}catch(e){}});NG.sT=0;}
function ngInp(pl){var N=NG.pl[pl.net];if(!N)return {x:0,y:0,a:false,s:false,u:false,g:false};
 if(Math.hypot(pl.x-(pl._ix==null?pl.x:pl._ix),pl.y-(pl._iy==null?pl.y:pl._iy))>50)pl.tpN=(pl.tpN||0)+1;
 var m0=Math.hypot(pl.kx||0,pl.ky||0);if(m0>(pl._km1||0)+40){pl.kn=(pl.kn||0)+1;pl.kix=Math.round(pl.kx);pl.kiy=Math.round(pl.ky);}pl._km0=m0;pl._km1=m0;   /* moved by the game (respawn, goal reset…): the friend must jump there too */
 if((N.tp|0)>=(pl.tpN|0)&&pl.hp>0){var P=ngPos(N,pl.tpN|0)||N;pl.x=Math.max(pl.r,Math.min(W-pl.r,+P.x||pl.x));pl.y=Math.max(pl.r,Math.min(H-pl.r,+P.y||pl.y));if(P.fx||P.fy){pl.fx=+P.fx||0;pl.fy=+P.fy||0;}pl.dir=P.d<0?-1:1;pl.walk=+P.w||0;}
 pl._ix=pl.x;pl._iy=pl.y;
 var a=!!N.ah,s=false,u=false,g=false;
 if((N.ac|0)>(pl._ac|0)){pl._ac=N.ac|0;a=true;if(N.ao>0){pl.ax=+N.ax||0;pl.ay=+N.ay||0;pl.aimP=N.ap==null?1:+N.ap;pl.aimO=Math.max(pl.aimO||0,+N.ao||0);}}
 if((N.sc|0)>(pl._sc|0)){pl._sc=N.sc|0;s=true;if(N.sa)pl.spA=N.sa;}
 if((N.uc|0)>(pl._uc|0)){pl._uc=N.uc|0;u=true;if(N.ms){pl.manS=true;pl.fx=+N.fx||pl.fx;pl.fy=+N.fy||pl.fy;}}
 if((N.gc|0)>(pl._gc|0)){pl._gc=N.gc|0;g=true;}
 if(pl.uh&&!u)pl.uh=false;if(pl.sph&&!s)pl.sph=false;if(pl.gh&&!g)pl.gh=false;
 return {x:0,y:0,a:a,s:s,u:u,g:g};}
function ngRivalMake(e,sl){var ch=skinnedK(sl.h,sl.k|0);ch.idx=sl.h;ch.skn=sl.k|0;e.ch=ch;e.net=sl.net;e.nm=sl.nm;e.bot=0;var hp=Math.max(6,Math.round(ch.hp/10*(sl.lm||1)));e.hp=e.maxhp=e.mhp=hp;e.speed=ch.sp;e.sup=0;e.spcd=0;e.cd=.25;}
function ngRival(e,dt){
 ['cd','atk','inv','spcd'].forEach(function(k){if(e[k]>0)e[k]-=dt;});if(e.flash>0)e.lh=tTime;e.stun=0;e.mw=0;
 var N=NG.pl[e.net]||{},id=NG.ids.get(e)||ngId(e);
 var m0=Math.hypot(e.kx||0,e.ky||0);if(m0>(e._km1||0)+40){e.kn=(e.kn||0)+1;e.kix=Math.round(e.kx);e.kiy=Math.round(e.ky);}e._km1=m0*Math.max(0,1-9*dt);
 if((N.sid|0)===id&&N.x!=null){var P=ngPos(N,0)||N;e.x=Math.max(e.r,Math.min(W-e.r,+P.x));e.y=Math.max(e.r,Math.min(H-e.r,+P.y));if(P.fx||P.fy){e.fx=+P.fx||0;e.fy=+P.fy||0;}e.dir=P.d<0?-1:1;e.walk=+P.w||0;e.kx=e.ky=0;}
 function aim(){var ax=e.fx||0,ay=e.fy||1;if(N.ao>0&&(N.ax||N.ay)){ax=+N.ax;ay=+N.ay;}else{var best=null,bd=e.ch.kind?e.ch.rng+30:85;tFoes(1).forEach(function(p){if(!tVisible(p,e))return;var d=Math.hypot(p.x-e.x,p.y-e.y);if(d<bd){bd=d;best=p;}});if(best){var l=bd||1;ax=(best.x-e.x)/l;ay=(best.y-e.y)/l;}}var l2=Math.hypot(ax,ay)||1;e.fx=ax/l2;e.fy=ay/l2;e.dir=e.fx<0?-1:1;}
 if((N.ac|0)>(e._ac|0)||(N.ah&&!(e.cd>0))){e._ac=Math.max(e._ac|0,N.ac|0);if(!(e.cd>0)){aim();var R=e.ch.rng||60;if(e.ch.kind){tFire(e,{x:e.x+e.fx*R*.9,y:e.y+e.fy*R*.9});e.atk=.18;}else tMelee(e);e.cd=e.ch.cd*(e.ch.kind?1.05:1);e.la=tTime;}}
 if((N.sc|0)>(e._sc|0)){e._sc=N.sc|0;if(!(e.spcd>0)){aim();e.spcd=6;e.la=tTime;if(e.ch.kind){var a0=Math.atan2(e.fy,e.fx),dm=tDmg(e);for(var q=-2;q<=2;q++){var an=a0+q*.16;eshots.push({x:e.x+Math.cos(an)*14,y:e.y+Math.sin(an)*14,vx:Math.cos(an)*420,vy:Math.sin(an)*420,life:(e.ch.rng||200)/420,dmg:Math.round(dm*.8),o:e,r:5});}}else{fxe({k:'melee',x:e.x,y:e.y,fx:e.fx,fy:e.fy,r:90,h:e.ch.idx});tFoes(1).forEach(function(p){if(Math.hypot(p.x-e.x,p.y-e.y)<=80+p.r)tHit(p,Math.round(tDmg(e)*1.1),e.x,e.y);});}}}
 if((N.uc|0)>(e._uc|0)){e._uc=N.uc|0;if((e.sup||0)>=100){e.sup=0;aim();tSuper(e);e.la=tTime;}}
 e.sup=Math.min(100,(e.sup||0)+dt*5);
 tRegen(e,dt);}
function ngHostMsg(src,x){if(!x||!NG.host)return;
 if(x.t==='in'){var N=NG.pl[src];if(!N)return;if((x.q|0)<(N.q|0))return;x.t0=Date.now();var B=N.buf||[],ck=N.ck||{},iv=N.iv||45;
  if(x.ct!=null&&x.x!=null){var now=performance.now(),L=B[B.length-1];if(L&&x.ct<=L.t){if(x.ct<L.t-1000){B=[];ck={};L=null;}else{x.buf=B;x.ck=ck;x.iv=iv;NG.pl[src]=x;return;}}   /* friend reloaded: new clock */
   ngClk(ck,now-x.ct);if(L){var g=x.ct-L.t;if(g>5&&g<600)iv=iv*.85+g*.15;}B.push({t:x.ct,x:+x.x,y:+x.y,fx:+x.fx||0,fy:+x.fy||0,d:x.d,w:+x.w||0,tp:x.tp|0,p:L&&(L.tp|0)===(x.tp|0)?{t:L.t,x:L.x,y:L.y}:null});if(L)L.p=null;while(B.length>40)B.shift();}
  x.buf=B;x.ck=ck;x.iv=iv;NG.pl[src]=x;}
 else if(x.t==='lv'){ngDrop(src);}}
function ngDrop(id){var i=-1;ps.forEach(function(p,j){if(p.net===id)i=j;});if(i>0){var p=ps[i];ps.splice(i,1);float(p.x,p.y-30,'👋 '+(p.nm||'חבר')+' יצא','#fde68a');}
 (tSlots||[]).forEach(function(sl){if(sl.net===id){sl.net=null;if(sl.e){sl.e.net=null;sl.e.bot=1;float(sl.e.x,sl.e.y-30,'👋 '+(sl.nm||'חבר')+' יצא','#fde68a');}}});
 delete NG.pl[id];delete NG.gone[id];NG.mp=NG.mp.filter(function(x){return x!==id;});}
function ngHostFrame(dt){if(!NG.on||!NG.host)return;
 if(!rm){ngStop();return;}
 for(var i=0;i<fxq.length&&NG.acc.fx.length<40;i++){var v=ngV(fxq[i],1);if(v)NG.acc.fx.push(v);}
 for(i=0;i<fl.length;i++){var f=fl[i];if(NG.seen.has(f))continue;NG.seen.add(f);if(NG.acc.fl.length<16)NG.acc.fl.push(ngV(f,1));}
 for(i=0;i<parts.length;i++){var q=parts[i];if(NG.seen.has(q))continue;NG.seen.add(q);if(NG.acc.pt.length<60)NG.acc.pt.push([Math.round(q.x),Math.round(q.y),Math.round(q.vx),Math.round(q.vy),Math.round(q.life*100)/100,q.c,q.r||0]);}
 if(NG.snd.length){NG.acc.sd=NG.acc.sd.concat(NG.snd).slice(-10);NG.snd=[];}
 var alive={},tn=Date.now();opeers.forEach(function(q){alive[q.peer]=1;});
 NG.mp.slice().forEach(function(id){if(alive[id]){delete NG.gone[id];return;}if(!NG.gone[id])NG.gone[id]=tn;else if(tn-NG.gone[id]>9000)ngDrop(id);});   /* a short drop (switching to the backup path) is not a leave */
 var fr=Math.max(0,1-10*Math.min(dt,.034));ps.forEach(function(p){if(!p.net)return;   /* the game runs in steps of up to 1/30 s */var m=Math.hypot(p.kx||0,p.ky||0);if(m>(p._km0||0)*fr+40){p.kn=(p.kn||0)+1;p.kix=Math.round(p.kx);p.kiy=Math.round(p.ky);}p._km1=m;p._lx=p.x;p._ly=p.y;});
 var nw=performance.now();if(nw<NG.sT)return;
 var rel=false;NG.mp.forEach(function(id){if(rm.via&&rm.via(id)==='r')rel=true;});NG.sT=nw+(rel?220:66);
 var S=ngSnap(false);NG.mp.forEach(function(id){if(!NG.gone[id])try{rm.send(id,S,true);}catch(e){}});
 if(!NG.mp.length){NG.on=0;NG.host=0;}}
function ngHostIdle(){if(!NG.on||!NG.host||!rm)return;var n=Date.now();if(n-NG.rT<400)return;NG.rT=n;var S={t:'sn',q:++NG.sq,ht:Math.round(performance.now()),a:null,g:ngGlob(),ev:{fx:[],fl:[],pt:[],sd:[]}};NG.mp.forEach(function(id){try{rm.send(id,S,true);}catch(e){}});}
function ngEnd(why){if(!NG.on)return;
 if(NG.host&&rm)NG.mp.forEach(function(id){var wA=why==='win',w=NG.vs&&NG.sides[id]===1?!wA&&why!=='ab':wA;try{rm.send(id,{t:'ge',w:w?1:0,ab:why==='ab'?1:0,sc:score,wv:wave});}catch(e){}});
 if(NG.cli&&rm&&why==='ab')try{rm.send({t:'lv'});}catch(e){}
 ngStop();}
function ngStop(){NG.on=0;NG.host=0;NG.cli=0;NG.pl={};NG.O={};NG.pend=[];NG.wiF=null;NG.mp=[];NG.gone={};NG.vs=0;NG.side=0;NG.mySid=0;try{document.body.classList.remove('ngW');}catch(e){}var w=document.getElementById('ngWait');if(w)w.remove();}
/* ---- friend side ---- */
function ngCliMsg(x){if(!x)return;
 if(x.t==='gs'){ngCliStart(x);return;}
 if(!NG.cli)return;
 if(x.t==='sn'){NG.rx=Date.now();if((x.q|0)<=(NG.lq|0))return;NG.lq=x.q|0;if(x.ht!=null)ngClk(NG.ck,performance.now()-x.ht);NG.pend.push(x);if(NG.pend.length>14)ngApply(NG.pend.shift(),performance.now());}
 else if(x.t==='ge'){var w=x.w,ab=x.ab;ngStop();if(state==='pause')state='play';if(state!=='play')return;if(ab){netMsg='👋 המארח יצא מהמשחק.';menu();if(rm)online(netMsg);return;}score=x.sc|0;wave=x.wv|0;if(w)victory();else gameOver();}}
function ngCliStart(x){
 if(state==='play'||state==='pause'||state==='shop'){state='menu';try{releaseAll();}catch(e){}}
 NG.on=1;NG.cli=1;NG.host=0;NG.O={};NG.pend=[];NG.lq=0;NG.sq=0;NG.rx=Date.now();NG.vs=x.vs?1:0;NG.side=x.sd|0;NG.mySid=0;NG.ac=NG.sc=NG.uc=NG.gc=0;NG.kp={};NG.hn=x.hn||'';NG.me=rm&&rm.me||'';NG.iT=0;NG.rT=0;NG.ivA=90;NG.last=0;NG.lht=0;NG.ck={};NG.st='play';NG.lost=0;
 mode=x.m;stage=x.sg==null?-1:x.sg;if(DF[x.df])dfi=x.df;NG.wiF=x.wi|0;np=1;
 try{start();}catch(e){}
 if(state!=='play'){ngStop();return;}
 NGA.forEach(function(n){if(n!=='ps')ngSA(n,[]);});NGOB.forEach(function(n){ngSO(n,null);});tSlots=[];
 var me=ps[0];me.kn=0;me.tpN=0;me.lm=lvm(0);NG.O={};
 float(me.x,me.y-40,'🌐 משחק משותף עם '+(NG.hn||'המארח'),'#93c5fd');}
function ngDec(v,refs){if(v==null||typeof v!=='object')return v;
 if(v.$r!=null){refs.push(v);return v;}
 if(v.$c){var c=skinnedK(CH[v.$c[0]]?v.$c[0]:0,v.$c[1]|0);c.idx=v.$c[0]|0;c.skn=v.$c[1]|0;return c;}
 if(Array.isArray(v))return v.map(function(x){return ngDec(x,refs);});
 var o={};for(var k in v)o[k]=ngDec(v[k],refs);return o;}
function ngRes(o,depth){if(!o||typeof o!=='object'||depth>3)return o;for(var k in o){var v=o[k];if(v&&typeof v==='object'){if(v.$r!=null)o[k]=NG.O[v.$r]||null;else if(!v.isObject3D)ngRes(v,depth+1);}}return o;}
function ngApply(S,now){
 if(S.g)ngSetGlob(S.g);
 if(S.f){obs=S.f.obs.map(function(o){return ngDec(o,[]);});bushes=S.f.bu.map(function(o){return ngDec(o,[]);});}
 var ev=S.ev||{};
 (ev.fx||[]).forEach(function(f){fxq.push(ngDec(f,[]));});
 (ev.fl||[]).forEach(function(f){if(f&&fl.length<40)fl.push(ngDec(f,[]));});
 (ev.pt||[]).forEach(function(q){if(parts.length<160)parts.push({x:q[0],y:q[1],vx:q[2],vy:q[3],life:q[4],c:q[5],r:q[6]});});
 (ev.sd||[]).forEach(function(s){try{if(s[0]===0)beep(s[1],s[2],s[3],s[4],s[5],1);else noise(s[1],s[2],s[3],1);}catch(e){}});
 if(!S.a)return;
 if(S.ht!=null&&NG.lht){var gap=S.ht-NG.lht;if(gap>15&&gap<1000)NG.ivA=gap;}else if(NG.last){gap=now-NG.last;if(gap>20&&gap<1000)NG.ivA=NG.ivA*.7+gap*.3;}NG.last=now;var segF=S.ht!=null&&NG.lht&&NG.rt!=null;if(S.ht!=null){NG.ra=segF?NG.lht:NG.rt;NG.lht=S.ht;}else NG.ra=null;
 var keep={},me=ps[0],newMe=null,myE=null,myId=0;
 NGA.forEach(function(n){var L=S.a[n];if(!L)return;var out=[];
  L.forEach(function(enc){if(!enc||enc.$i==null)return;var id=enc.$i;keep[id]=1;
   if(n==='ps'&&enc.net&&enc.net===NG.me){NG.O[id]=me;newMe=enc;return;}
   if(n==='enemies'&&enc.net&&enc.net===NG.me){NG.O[id]=me;myE=enc;myId=id;return;}
   var o=NG.O[id],fresh=!o;if(fresh)o=NG.O[id]={};
   var refs=[];for(var k in enc){if(k==='$i')continue;var v=ngDec(enc[k],refs);
    if(NGI[k]&&typeof v==='number'&&!fresh&&typeof o[k]==='number'&&!(k==='x'&&Math.abs(v-o[k])>140)&&!(k==='y'&&Math.abs(v-o[k])>140)){o['_f'+k]=segF&&typeof o['_t'+k]==='number'?o['_t'+k]:o[k];o['_t'+k]=v;}
    else{o[k]=v;if(NGI[k]){delete o['_f'+k];delete o['_t'+k];}}}
   o._t0=now;out.push(o);});
  if(n==='ps')out.unshift(me);
  ngSA(n,out);});
 for(var id in NG.O)if(!keep[id]&&NG.O[id]!==me)delete NG.O[id];
 NGA.forEach(function(n){ngA(n).forEach(function(o){if(o!==me)ngRes(o,0);});});
 NGOB.forEach(function(n){var v=S.o&&S.o[n];if(v==null){ngSO(n,null);return;}var cur=ngO(n),d=ngDec(v,[]);if(cur&&typeof cur==='object'){for(var k in d)cur[k]=d[k];}else ngSO(n,d);ngRes(ngO(n),0);});
 if(newMe){for(var k in newMe){if(k==='$i'||NGOWN[k])continue;me[k]=ngDec(newMe[k],[]);}
  if((newMe.kn|0)>(me.kn0|0)){me.kn0=newMe.kn|0;me.kx=+newMe.kix||0;me.ky=+newMe.kiy||0;}
  if((newMe.tpN|0)>(me.tpA|0)){me.tpA=newMe.tpN|0;me.x=+newMe.x||me.x;me.y=+newMe.y||me.y;}
  NG.lost=0;}
 else if(myE){NG.lost=0;var hp0=me.hp;me.hp=+myE.hp||0;me.mhp=+myE.maxhp||me.mhp;['sup','spcd','cd','inv','flash'].forEach(function(k){if(myE[k]!=null)me[k]=+myE[k];});
  if(NG.mySid!==myId){NG.mySid=myId;me.x=+myE.x;me.y=+myE.y;me.kx=me.ky=0;me.kn0=myE.kn|0;}
  else if((myE.kn|0)>(me.kn0|0)){me.kn0=myE.kn|0;me.kx=+myE.kix||0;me.ky=+myE.kiy||0;}}
 else if(NG.side===1){if(me.hp>0&&NG.mySid){me.hp=0;bannerText='💀 הופלת! חוזר בעוד 3…';banner=1.6;}NG.lost=0;}
 else NG.lost++;
 if(NG.side===1){var foes=ps.filter(function(o){return o!==me;}).concat(tbots),mates=enemies.filter(function(o){return o.t==='hero';}),mons=enemies.filter(function(o){return o.t!=='hero';});
  foes.forEach(function(o){o.t='hero';if(o.maxhp==null||o.mhp!=null)o.maxhp=o.mhp||o.maxhp;if(!o.net&&!o.bot)o.nm=NG.hn||o.nm;});mates.forEach(function(o){if(o.mhp==null)o.mhp=o.maxhp;});
  ps=[me];tbots=mates;enemies=mons.concat(foes);}}
function ngLerp(now){var iv=Math.max(40,Math.min(400,NG.ivA)),rt=NG.ra!=null&&NG.lht&&NG.ck&&NG.ck.o!=null?now-NG.ck.o-Math.max(15,Math.min(300,2.5*(NG.ck.j||0)+15)):null,aR=rt==null?null:Math.max(0,(rt-NG.ra)/Math.max(1,NG.lht-NG.ra));
 NGA.forEach(function(n){ngA(n).forEach(function(o){if(o===ps[0]||o._t0==null)return;var a=aR!=null&&o._t0===NG.last?aR:Math.min(1.25,(now-o._t0)/iv);
  if((n==='shots'||n==='eshots')&&typeof o.vx==='number'&&o._tx!=null){var tt=(now-o._t0)/1000;o.x=o._tx+o.vx*tt;o.y=o._ty+(o.vy||0)*tt;return;}
  for(var k in NGI){var f=o['_f'+k];if(f==null)continue;var t=o['_t'+k];o[k]=f+(t-f)*Math.min(1,a);}});});}
function ngCliUpdate(dt){
 var now=performance.now();
 /* playout: draw the host world a little in the past (rt, host clock). The next snapshot is taken in when rt reaches the previous one, then everything walks to it exactly by its time */
 var C=NG.ck||{};NG.rt=C.o==null?null:now-C.o-Math.max(15,Math.min(300,2.5*(C.j||0)+15));
 while(NG.pend.length){var S=NG.pend[0];if(NG.rt!=null&&S.ht!=null&&S.a&&!S.f&&NG.lht&&NG.rt<NG.lht&&NG.pend.length<10)break;NG.pend.shift();try{ngApply(S,now);}catch(e){}}
 if(!NG.on||!NG.cli)return;
 var gap=Date.now()-(NG.rx||Date.now());
 if(!rm||gap>40000){ngStop();netMsg=rm?'📡 החיבור למארח נותק.':(netMsg||'📡 החיבור לחדר נותק.');menu();online(netMsg);return;}
 NG.gap=gap;
 ngLerp(now);
 var me=ps[0],k=inp(0),K=Object.assign({},keys,kd);
 if(banner>0)banner-=dt;if(shake>0)shake-=dt;if(sflash>0)sflash-=dt;
 if(me&&me.hp>0&&NG.st==='play'){var sp=me.ch.sp*(me.bS>0?1.4:1)*((UP&&UP.spd)||1);
  if(k.x||k.y){var kl=Math.hypot(k.x,k.y);me.fx=k.x/kl;me.fy=k.y/kl;if(k.x)me.dir=k.x<0?-1:1;me.walk+=dt*14;}
  me.x+=k.x*sp*dt+(me.kx||0)*dt;me.y+=k.y*sp*dt+(me.ky||0)*dt;var fr=Math.max(0,1-10*dt);me.kx=(me.kx||0)*fr;me.ky=(me.ky||0)*fr;
  me.x=Math.max(me.r,Math.min(W-me.r,me.x));me.y=Math.max(me.r,Math.min(H-me.r,me.y));try{pushOut(me);}catch(e){}
  if(me.atk>0)me.atk-=dt;if(me.aimO>0)me.aimO-=dt;
  var ka=!!(K.Space||K.KeyJ||atkHeld),ks=!!(K.KeyK||K.KeyE),ku=!!(K.KeyL||K.KeyQ),kg=!!K.KeyG;
  if(atkQ||(ka&&!NG.kp.a)){NG.ac++;NG.aoA=me.aimO>0?me.aimO:0;if(!(me.cd>0))me.atk=Math.max(me.atk||0,.18);}
  if(spQ||(ks&&!NG.kp.s))NG.sc++;if(supQ||(ku&&!NG.kp.u))NG.uc++;if(gadQ||(kg&&!NG.kp.g))NG.gc++;
  NG.kp={a:ka,s:ks,u:ku,g:kg};NG.ah=ka;}
 else NG.ah=false;
 atkQ=false;spQ=false;supQ=false;gadQ=false;kd={};
 parts.forEach(function(q){q.life-=dt;q.vy+=420*dt;q.x+=q.vx*dt;q.y+=q.vy*dt;});parts=parts.filter(function(q){return q.life>0;});
 fl.forEach(function(f){f.life-=dt;f.y-=28*dt;});fl=fl.filter(function(f){return f.life>0;});
 chests.forEach(function(c){c.t=(c.t||0)+dt;});drops.forEach(function(d){d.t=(d.t||0)+dt;});
 try{ps.forEach(function(p){p.inBush=p.hp>0&&!!inBush(p);});}catch(e){}
 try{uiBtns(me);var cc=Math.ceil(Math.max(0,me.spcd||0));if(cc!==spShown){spShown=cc;spBtn.textContent=cc>0?cc:'💥';spBtn.classList.toggle('cool',cc>0);}}catch(e){}
 if(now>=NG.iT&&rm&&me){var rel=rm.relayed&&rm.relayed();NG.iT=now+(rel?120:45);
  try{rm.send({t:'in',q:++NG.sq,ct:Math.round(performance.now()),x:Math.round(me.x*10)/10,y:Math.round(me.y*10)/10,fx:Math.round(me.fx*100)/100,fy:Math.round(me.fy*100)/100,d:me.dir,w:Math.round(me.walk*10)/10,tp:me.tpA|0,sid:NG.mySid|0,ah:NG.ah?1:0,ac:NG.ac,sc:NG.sc,uc:NG.uc,gc:NG.gc,ax:Math.round((me.ax||0)*100)/100,ap:Math.round((me.aimP==null?1:me.aimP)*100)/100,ay:Math.round((me.ay||0)*100)/100,ao:NG.aoA||0,ms:me.manS?1:0,sa:me.spA||null},true);}catch(e){}
  me.manS=false;}
 ngWaitUI();}
function ngCliIdle(){if(!NG.on||!NG.cli||!rm||!ps[0])return;var me=ps[0];try{rm.send({t:'in',q:++NG.sq,ct:Math.round(performance.now()),x:me.x,y:me.y,fx:me.fx,fy:me.fy,d:me.dir,w:0,tp:me.tpA|0,sid:NG.mySid|0,ah:0,ac:NG.ac,sc:NG.sc,uc:NG.uc,gc:NG.gc,ao:0});}catch(e){}}
document.addEventListener('visibilitychange',function(){if(document.hidden)try{ngCliIdle();}catch(e){}});
function ngWaitUI(){var t=(NG.gap||0)>2500?'📡 מחכה לחיבור עם המארח…':NG.st==='pause'?'⏸ המארח עצר את המשחק…':NG.st==='shop'?'🏪 המארח בוחר שדרוגים לכל הקבוצה…':NG.lost>40?'📡 מחכה לחיבור עם המארח…':'';var w=document.getElementById('ngWait');
 if(!t){if(w)w.remove();return;}if(!w){w=document.createElement('div');w.id='ngWait';document.body.appendChild(w);}if(w.textContent!==t)w.textContent=t;}
function ngLabel(p){if(NG.host&&p.net)return p.nm||'';if(NG.cli&&p!==ps[0])return p.net?(p.nm||''):(NG.hn||'מארח');return '';}
function ngBadge(){if(!NG.on)return '';var n=ps.length;return '🌐 '+n+' שחקנים במשחק';}
