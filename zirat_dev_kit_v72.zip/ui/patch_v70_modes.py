# v70: modes screen in the player's painted style (portrait art + live list on top; landscape = same list in 2 columns)
# Run on the v69 stage (ui/stage_v69.html). Needs ui/mds_b64.txt, ui/mdsb_b64.txt.
ST = '/home/claude/arena3_stage.html'
s = open(ST, encoding='utf-8').read()
def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:90]); s = s.replace(a, b)
MDS = open('/home/claude/ui/mds_b64.txt').read().strip(); MDSB = open('/home/claude/ui/mdsb_b64.txt').read().strip()

# 1) art
rep("var IMGB={hub:", "var MDSIMG='" + MDS + "';\nvar IMGB={mds:'" + MDSB + "',hub:")
rep("function imgSrc(k){return {hub:HUBIMG,", "function imgSrc(k){return {mds:MDSIMG,hub:HUBIMG,")

# 2) styles
CSS = r"""
/* v70 modes screen: the painting is the backdrop (castle, title, back arrow); the list, highlight and play button are live */
#ov .mdW .isA{width:min(100vw,56.71vh);aspect-ratio:1170/2063;--u:min(1vw,.5671vh)}
@supports (width:1cqw){#ov .mdW .isA{width:min(100cqw,56.71cqh);--u:min(1cqw,.5671cqh)}}
#ov .mdW .mdH{left:0;top:0;width:1px;height:1px;opacity:0;pointer-events:none;font-size:1px}
#ov .mdW .mdP{left:5.2%;top:14%;width:89.6%;height:68.6%;display:flex;flex-direction:column;border-radius:calc(var(--u)*6);background:linear-gradient(180deg,#1b2f9a,#0e1d6b 18%,#0b185c);border:calc(var(--u)*.9) solid #3a5ef0;box-shadow:0 0 0 calc(var(--u)*.6) #0a1240,0 0 calc(var(--u)*4) rgba(70,130,255,.55),inset 0 calc(var(--u)*.8) 0 rgba(160,200,255,.25);overflow:hidden;text-align:right}
#ov .mdW .mdS{flex:1;min-height:0;overflow-y:auto;overscroll-behavior:contain;padding:calc(var(--u)*2.4) calc(var(--u)*2.6) calc(var(--u)*3);display:flex;flex-direction:column;gap:calc(var(--u)*2.4);scrollbar-width:none}
#ov .mdW .mdS::-webkit-scrollbar{display:none}
#ov .mdW .mdL{align-self:flex-start;margin:calc(var(--u)*1) 0 calc(var(--u)*-.6);padding:calc(var(--u)*1) calc(var(--u)*4);border-radius:calc(var(--u)*2.6) calc(var(--u)*2.6) calc(var(--u)*2.6) 0;background:linear-gradient(180deg,#1a2a7a,#0c1650);border:calc(var(--u)*.5) solid #2f4fd6;color:#cfe0ff;font-size:calc(var(--u)*4);font-weight:900;text-shadow:0 2px 0 #050a2a}
#ov .mdW .mdR{position:relative;flex:none;display:flex;align-items:center;gap:calc(var(--u)*3.2);width:100%;min-height:calc(var(--u)*19);padding:calc(var(--u)*2) calc(var(--u)*2.6);border-radius:calc(var(--u)*4.4);background:linear-gradient(180deg,#24348a,#1a2672 55%,#16205f);border:calc(var(--u)*.7) solid #2f4fd6;box-shadow:0 0 0 calc(var(--u)*.5) #0a1240,0 calc(var(--u)*1) 0 #070d33,inset 0 calc(var(--u)*.6) 0 rgba(150,190,255,.22);color:#fff;text-align:right;font-family:inherit;animation:none;transition:transform .1s}
#ov .mdW .mdR:active{transform:translateY(2px) scale(.985)}
#ov .mdW .mdR.mdOn{border-color:#ffd54a;background:linear-gradient(180deg,#2b3690,#1f2a78 55%,#1a2368);box-shadow:0 0 0 calc(var(--u)*.5) #6b4a00,0 0 calc(var(--u)*3.4) rgba(255,190,40,.85),0 0 calc(var(--u)*7) rgba(255,170,20,.35),inset 0 calc(var(--u)*.6) 0 rgba(255,230,150,.25)}
#ov .mdW .mdI{flex:none;order:-1;width:calc(var(--u)*15);height:calc(var(--u)*15);border-radius:calc(var(--u)*3.6);display:flex;align-items:center;justify-content:center;background:linear-gradient(180deg,var(--c1),var(--c2));border:calc(var(--u)*.6) solid rgba(10,18,64,.9);box-shadow:inset 0 calc(var(--u)*1) 0 rgba(255,255,255,.35),inset 0 calc(var(--u)*-1) 0 rgba(0,0,0,.2)}
#ov .mdW .mdI svg{width:62%;height:62%;filter:drop-shadow(0 2px 0 rgba(0,0,0,.35))}
#ov .mdW .mdT{flex:1;min-width:0;display:flex;flex-direction:column;gap:calc(var(--u)*.8)}
#ov .mdW .mdT b{font-size:calc(var(--u)*5.6);font-weight:900;line-height:1.1;text-shadow:0 2px 0 #050a2a}
#ov .mdW .mdT small{font-size:calc(var(--u)*3.6);font-weight:700;color:#cbd8ff;line-height:1.2}
#ov .mdW .mdB{flex:none;padding:calc(var(--u)*1) calc(var(--u)*3.2);border-radius:999px;background:linear-gradient(180deg,#ffe66b,#f5b52a);border:calc(var(--u)*.5) solid #5a3a06;color:#3b2402;font-size:calc(var(--u)*3.4);font-weight:900;box-shadow:0 calc(var(--u)*.6) 0 #8a4f0c}
#ov .mdW .mdB.ev{background:linear-gradient(180deg,#ff9b5c,#f0521f);color:#2a0a00}
#ov .mdW .mdK{flex:none;width:calc(var(--u)*8);height:calc(var(--u)*8)}
#ov .mdW .mdBar{flex:none;margin:0;border-radius:0;border:0;border-top:calc(var(--u)*.5) solid #2f4fd6;background:linear-gradient(180deg,#121f6a,#0a1450);box-shadow:none;padding:calc(var(--u)*1.6) calc(var(--u)*2);gap:calc(var(--u)*1.6)}
#ov .mdW .mdBar small{font-size:calc(var(--u)*3.6);color:#cbd8ff}
#ov .mdW .mdBar .chip{min-height:calc(var(--u)*9);padding:0 calc(var(--u)*3);font-size:calc(var(--u)*3.6)}
#ov .mdW .mdBkL{display:none;align-items:center;justify-content:center;padding:0;border-radius:calc(var(--u)*2.6);background:linear-gradient(180deg,#ffe66b,#f5b52a);border:calc(var(--u)*.6) solid #3b2508;box-shadow:0 calc(var(--u)*.8) 0 #8a4f0c;animation:none}
#ov .mdW .mdBkL svg{width:60%;height:60%}
#ov .mdW .mdGo{left:14.4%;top:85.4%;width:71.2%;height:9.6%;display:flex;align-items:center;justify-content:center;gap:calc(var(--u)*3);border-radius:calc(var(--u)*6);background:linear-gradient(180deg,#fff36b,#ffd94a 40%,#f4b53a);border:calc(var(--u)*.9) solid #3b2508;box-shadow:inset 0 calc(var(--u)*1) 0 rgba(255,255,255,.6),0 calc(var(--u)*1.6) 0 #c4621c,0 calc(var(--u)*2.4) 0 #3b2508,0 0 calc(var(--u)*5) rgba(255,200,60,.45);color:#241505;font-family:inherit;font-size:calc(var(--u)*7);font-weight:900;animation:none;transition:transform .1s}
#ov .mdW .mdGo:active{transform:translateY(3px)}
#ov .mdW .mdGo svg{width:calc(var(--u)*10);height:calc(var(--u)*10);flex:none}
#ov .mdW .mdGo span{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:78%}
@media (orientation:landscape){
 #ov .mdW .isA{width:100%;height:100%;aspect-ratio:auto;background:none;--u:min(.8vh,.5vw)}
 @supports (width:1cqw){#ov .mdW .isA{width:100%;--u:min(.8cqh,.5cqw)}}
 #ov .mdW .mdH{left:50%;top:calc(var(--u)*2.4);width:auto;height:auto;opacity:1;transform:translateX(-50%);padding:calc(var(--u)*1.2) calc(var(--u)*5);border-radius:calc(var(--u)*3);background:linear-gradient(180deg,#203a9c,#101d5a);border:calc(var(--u)*.6) solid #e8b84a;box-shadow:0 0 16px rgba(80,150,255,.6),0 4px 0 rgba(0,0,0,.5);font-size:calc(var(--u)*5.4);white-space:nowrap}
 #ov .mdW .mdP{left:50%;top:calc(var(--u)*13.5);width:min(94%,980px);height:calc(100% - var(--u)*34);transform:translateX(-50%)}
 #ov .mdW .mdS{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));align-content:start;gap:calc(var(--u)*2.2) calc(var(--u)*3)}
 #ov .mdW .mdL{grid-column:1/-1}
 #ov .mdW .mdR{min-height:calc(var(--u)*16)}
 #ov .mdW .mdI{width:calc(var(--u)*12);height:calc(var(--u)*12)}
 #ov .mdW .mdT b{font-size:calc(var(--u)*4.6)}#ov .mdW .mdT small{font-size:calc(var(--u)*3.2)}
 #ov .mdW .mdGo{left:50%;top:auto;bottom:calc(var(--u)*3.4);width:min(46%,460px);height:calc(var(--u)*14);transform:translateX(-50%);font-size:calc(var(--u)*6)}
 #ov .mdW .mdGo:active{transform:translateX(-50%) translateY(3px)}
 #ov .mdW .mdBkP{display:none}
 #ov .mdW .mdBkL{display:flex;right:calc(var(--u)*3);top:calc(var(--u)*2.4);width:calc(var(--u)*11);height:calc(var(--u)*11)}
}
"""
rep("#ov .mdBar .chip.sel{", CSS.strip() + "\n#ov .mdBar .chip.sel{")

# 3) screen
JS = r"""
var MDX={survive:['גלים בלי סוף של מפלצות','#5a9bff','#1f55d6','M7.5 8.5a3.5 3.5 0 1 0 0 7c3.5 0 5.5-7 9-7a3.5 3.5 0 1 1 0 7c-3.5 0-5.5-7-9-7z'],
 team:['3 נגד 3 · ראשונים ל-10 הדחות','#ff5a4a','#c81e1e','M14.5 17.5L3 6V3h3l11.5 11.5M13 19l6-6M16 16l4 4M19 21l2-2M9.5 17.5L21 6V3h-3L6.5 14.5M11 19l-6-6M8 16l-4 4M5 21l-2-2'],
 siege:['הפל את המגדלים והמבצר','#ffb347','#c46a12','M3 21V9h3V6h3v3h6V6h3v3h3v12zM10 21v-5h4v5'],
 boss:['מפלצת ענקית אחת','#ff6b9a','#b81d55','M5 4l3 4M19 4l-3 4M12 7a7 7 0 0 0-7 7v3a3 3 0 0 0 3 3h8a3 3 0 0 0 3-3v-3a7 7 0 0 0-7-7zM9.5 13h.01M14.5 13h.01M9 17h6'],
 heist:['הגן על האוצר מהגלים','#ffd84a','#c79410','M3 10h18v10H3zM3 10l2-5h14l2 5M10 14h4'],
 gems:['אסוף קריסטלים מהמפלצות','#6fd8ff','#1c94d6','M6 3h12l4 6-10 12L2 9zM2 9h20M12 21L8 9l4-6 4 6z'],
 hot:['החזק את מוקד הלהבה','#ff8a3d','#d9381c','M12 3c1.5 3.5 5.5 5.5 5.5 10.5a5.5 5.5 0 0 1-11 0c0-2.8 1.6-4.4 2.6-6 .9 1.8 1.9 2.6 2.9 2.6 0-2.6-1-4.4 0-7.1z'],
 ball:['3 נגד 3 · הכנס כדור לשער','#5fd16a','#23913a','M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18zM12 8l3.6 2.6-1.4 4.2H9.8L8.4 10.6z'],
 show:['1 נגד 9 · רעל נסגר','#b25cff','#6d1fd6','M3 17h18l-1.5-9-4.5 4-3-6-3 6-4.5-4zM5 20.5h14'],
 pvp:['נגד חברים בקוד חדר','#ffad42','#e06a10','M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18zM3 12h18M12 3c3 3.2 3 14.8 0 18M12 3c-3 3.2-3 14.8 0 18'],
 '3d':['קרב בעולם תלת־ממד','#3fe0c8','#0f9a8a','M12 2.5l8.5 4.8v9.4L12 21.5l-8.5-4.8V7.3zM12 12l8.5-4.7M12 12v9.5M12 12L3.5 7.3'],
 board:['שלבים, כוכבים ופרסים','#8f8cff','#4b45d6','M5 21V4M5 4h11l-2 4 2 4H5'],
 train:['למד לשחק בלי לחץ','#a3b3cc','#5b6b85','M12 3a9 9 0 1 0 0 18a9 9 0 1 0 0-18zM12 7.5a4.5 4.5 0 1 0 0 9a4.5 4.5 0 1 0 0-9zM12 11.2a.8.8 0 1 0 0 1.6a.8.8 0 1 0 0-1.6z']};
var MDSEC=[['נגד גיבורים',['team','show','ball','pvp']],['נגד מפלצות',['survive','gems','boss','siege','heist','hot']],['עוד',['3d','board','train']]];
function mdSvg(p,c,w){return `<svg viewBox='0 0 24 24' fill='none' stroke='${c||'#fff'}' stroke-width='${w||2.2}' stroke-linecap='round' stroke-linejoin='round' aria-hidden='true'><path d='${p}'/></svg>`;}
function modesIS(){
 var ev=evNow(),sc=(document.querySelector('#ov .mdS')||{}).scrollTop||0,nm={},h='';MODES.forEach(function(m){nm[m[0]]=m[2];});nm.board='מסע';nm.train='אימון';
 MDSEC.forEach(function(sec){h+=`<h2 class='mdL'>${sec[0]}</h2>`;sec[1].forEach(function(id){var x=MDX[id],isM=!!MODES.filter(function(m){return m[0]===id;}).length,on=isM&&selMode===id,
  a=isM?'sm:'+id:'cg:md:'+id,bd=id===ev?`<span class='mdB ev'>אירוע</span>`:id==='show'?`<span class='mdB'>חדש</span>`:'';
  h+=`<button class='mdR${on?' mdOn':''}' data-a='${a}'${on?" aria-current='true'":''}><i class='mdI' style='--c1:${x[1]};--c2:${x[2]}'>${mdSvg(x[3])}</i><span class='mdT'><b>${nm[id]}</b><small>${x[0]}</small></span>${bd}${on?`<span class='mdK'>${mdSvg('M4 12.5l5 5 11-11','#ffd54a',3.4)}</span>`:''}</button>`;});});
 var bar=`<div class='mdBar'><small>קושי:</small>`;DF.forEach(function(d,j){bar+=`<button class='chip${j===dfi?' sel':''}' data-a='df2:${j}'>${d[0]}</button>`;});bar+=`</div>`;
 showOv(`<i data-scr></i><i data-res></i><div class='isW mdW' style="--vi:url('${imgU('mds')}');--vb:url('${IMGB.mds}')"><div class='isA'>${isFxH('mds')}<h1 class='mdH'>🎮 מצבי משחק</h1><button class='isT mdBkP' data-a='menu' aria-label='חזרה' style='left:82%;top:3.2%;width:11.8%;height:7%'></button><button class='mdBkL' data-a='menu' aria-label='חזרה'>${mdSvg('M9 6l6 6-6 6','#3b2508',3.4)}</button><div class='mdP'><div class='mdS'>${h}</div>${bar}</div><button class='mdGo' data-a='play'>${mdSvg(MDX.team[3],'#241505',2.6)}<span>שחק · ${nm[selMode]||''}</span></button></div></div>`);
 var el=document.querySelector('#ov .mdS');if(el){if(sc)el.scrollTop=sc;else{var o=el.querySelector('.mdR.mdOn');if(o&&o.offsetTop>el.clientHeight*.6)el.scrollTop=o.offsetTop-el.clientHeight*.35;}}}
"""
rep("function catWin(k){", JS.strip() + "\nfunction catWin(k){")
rep(" else{var ev=evNow();h=`<i data-scr></i><div class='pkH'><i>🎮</i><span>מצבי משחק</span></div><div class='mdG'>`;",
    " else{modesIS();return;var ev=evNow();h=`<i data-scr></i><div class='pkH'><i>🎮</i><span>מצבי משחק</span></div><div class='mdG'>`;")

# 4) tapping a mode selects it in place (the play button on this screen starts it); from elsewhere 'sm:' still goes back to the menu
rep('if(a[0]==="sm"){selMode=a[1];menu();}', 'if(a[0]==="sm"){selMode=a[1];if(document.querySelector("#ov .mdW"))catWin("md");else menu();}')

s = s.replace("var NETVER='69'", "var NETVER='70'")
open(ST, 'w', encoding='utf-8').write(s)
print('v70 modes patched')
