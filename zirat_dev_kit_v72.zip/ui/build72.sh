#!/bin/bash
# rebuild v72: g3 arm poses + stage changes on top of v71
set -e
cd /home/claude
cp ui/g3_v71.js g3/g3.js && python3 ui/patch_v72_g3.py
cp ui/stage_v71.html arena3_stage.html && python3 ui/patch_v72_stage.py
python3 enm/sync_blocks.py
bash t3/emb_stage.sh >/dev/null
cp arena3_gfx.html arena3_new.html
grep -o "NETVER='[0-9]*'" arena3_new.html
