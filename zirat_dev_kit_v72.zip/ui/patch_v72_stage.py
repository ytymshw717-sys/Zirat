# v72 (player's list): no shop between waves, sound/camera in settings (not in pause), no "style" options,
# auto-fire, health regen, top-bar AUTO button. Runs on ui/stage_v71.html.
import re
P='/home/claude/arena3_stage.html'
s=open(P,encoding='utf-8').read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:110]);s=s.replace(a,b)

s,k=re.subn(r"NETVER='\d+'","NETVER='72'",s);assert k>=1

# ---------- 1. no shop between waves: full heal + revive, short breather ----------
rep('''   bannerText="גל נוקה! ❤️";banner=1.3;
   ps.forEach(function(p){if(p.hp<=0){p.hp=Math.round(p.mhp/2);p.inv=1.5;float(p.x,p.y-30,"קם לתחייה!","#86efac");}else p.hp=Math.min(p.mhp,p.hp+25);});
   addCoins(20+wave*5);if(goal&&wave>=goal){victory();return;}spawnChest(false);beep(600,.2,"triangle",.06,900);showShop();
  }
  spawnDelay=1.8;''','''   bannerText="גל נוקה! ❤️ חיים מלאים";banner=1.6;
   ps.forEach(function(p){if(p.hp<=0){p.hp=p.mhp;p.inv=1.5;float(p.x,p.y-30,"קם לתחייה!","#86efac");}else p.hp=p.mhp;});
   addCoins(20+wave*5);if(goal&&wave>=goal){victory();return;}spawnChest(false);beep(600,.2,"triangle",.06,900);
  }
  spawnDelay=wave>0?2.4:1.8;''')
rep('''  ps.forEach(function(p){if(p.hp<=0){p.hp=Math.round(p.mhp/2);p.inv=1.5;}});
  spawnChest(true);
  if(state==='play')showShop();''','''  ps.forEach(function(p){if(p.hp<=0){p.hp=Math.round(p.mhp/2);p.inv=1.5;}else p.hp=Math.min(p.mhp,p.hp+Math.round(p.mhp*.35));});
  spawnChest(true);''')

# ---------- 2. regen + auto-fire in the player loop ----------
rep('''  var k=pl.net?ngInp(pl):inp(i),ch=pl.ch;
  if(pl.inv>0)pl.inv-=dt;''','''  var k=pl.net?ngInp(pl):inp(i),ch=pl.ch;
  if(i===0&&!pl.net&&sv.cfg.af&&!k.a&&pl.cd<=0&&!aiming){var afT=afTgt(pl);if(afT){pl._tg=afT;k.a=true;}}
  if(pl.lhp!=null&&pl.hp<pl.lhp-.01)pl.rgT=0;pl.rgT=(pl.rgT||0)+dt;if(pl.rgT>3&&pl.hp<pl.mhp){pl.hp=Math.min(pl.mhp,pl.hp+pl.mhp*.12*dt);if((pl.rgP=(pl.rgP||0)-dt)<=0&&parts.length<120){pl.rgP=.3;parts.push({x:pl.x+(Math.random()-.5)*18,y:pl.y-6,vx:0,vy:-34,life:.5,c:'#86efac',r:0});}}pl.lhp=pl.hp;
  if(pl.inv>0)pl.inv-=dt;''')
rep('function autoTgt(pl,R){','''/* v72 auto-fire: nearest visible rival inside this hero's real reach (same reach the bots use) */
function afTgt(pl){var ch=pl.ch,b=null,bd=1e9;for(var i=0;i<enemies.length;i++){var e=enemies[i];if(e.hp<=0||e.hid||e.ghost)continue;var d=Math.hypot(e.x-pl.x,e.y-pl.y),R=ch.kind?ch.rng+8:ch.rng+(e.r||14)+2;if(d<=R&&d<bd){bd=d;b=e;}}return b;}
function afSet(on){sv.cfg.af=!!on;save();var b=document.getElementById('afb');if(b){b.classList.toggle('on',!!on);b.setAttribute('aria-pressed',!!on);}}
function autoTgt(pl,R){''')

# ---------- 3. AUTO button next to pause (battle only) ----------
rep('<button class="ib" id="snd">🔊</button><button class="ib" id="pz">⏸</button></div>',
    '<button class="ib" id="snd">🔊</button><button class="ib" id="afb" aria-label="ירי אוטומטי" aria-pressed="false">🎯 אוטו</button><button class="ib" id="pz">⏸</button></div>')
rep("bindAim2(supBtn,'sup');","try{var afb=document.getElementById('afb');afb.addEventListener('click',function(e){e.stopPropagation();afSet(!sv.cfg.af);beep(sv.cfg.af?880:440,.08,'triangle',.05);});afSet(!!sv.cfg.af);}catch(x){}bindAim2(supBtn,'sup');")

# ---------- 4. pause = resume / menu only ----------
rep('''function pauseOv(){showOv('<h1>⏸ מושהה</h1><button class="big" data-a="res">המשך</button><div class="pzRow"><button data-a="psnd">'+(snd?'🔊 צליל':'🔇 צליל')+'</button><button data-a="pyaw:-1" title="סובב מצלמה">⟲ מצלמה</button><button data-a="pyaw:1" title="סובב מצלמה">מצלמה ⟳</button>'+(YAW?'<button data-a="pyaw:0">↺ ישר</button>':'')+'</div><button class="c" style="width:auto;padding:0 14px" data-a="menu">תפריט</button>'+tnHtml());}''',
'''function pauseOv(){showOv('<h1>⏸ מושהה</h1><button class="big" data-a="res">המשך</button><button class="c" style="width:auto;padding:0 14px" data-a="menu">תפריט</button><small>🔊 צליל, 🎥 מצלמה ו־🎯 ירי אוטומטי — בהגדרות ⚙️</small>'+tnHtml());}''')

# ---------- 5. settings: no style switches; auto-fire + camera instead ----------
rep('''${tg('v25','🎮 תצוגת 2.5D (זווית אלכסונית)',sv.cfg.v25!==false)}${tg('c3','🧊 דמויות תלת־ממד (כבוי = ציור קלאסי)',sv.cfg.c3!==false)}${tg('r3','🌍 עולם תלת־ממד בכל המצבים (כבוי = 2.5D)',sv.cfg.r3!==false)}</div>''',
'''${tg('af','🎯 ירי אוטומטי',!!sv.cfg.af)}<div class='tg'><span>🎥 זווית מצלמה · ${yawDeg()}°</span><span><button class='c' style='width:auto;padding:0 12px' data-a='cyaw:-1' aria-label='סובב מצלמה שמאלה'>⟲</button> <button class='c' style='width:auto;padding:0 12px' data-a='cyaw:1' aria-label='סובב מצלמה ימינה'>⟳</button></span></div></div>''')
rep('''<small>טיפ: גרור את הכפתורים האדום, צהוב וכוכב לכיוון ידני, או הקש לכיוון אוטומטי</small>''','''<small>טיפ: גרור את הכפתורים האדום, צהוב וכוכב לכיוון ידני, או הקש לכיוון אוטומטי · כל מפה עם מראה משלה</small>''')
rep('''var R=[['sn',snd,'אפקטים'],['mu',sv.cfg.mu,'מוזיקה'],['vo',sv.cfg.vo,'קולות גיבורים'],['vb',sv.cfg.vb,'רטט'],['v25',sv.cfg.v25!==false,'תצוגת 2.5D'],['c3',sv.cfg.c3!==false,'דמויות תלת־ממד'],['r3',sv.cfg.r3!==false,'עולם תלת־ממד']],C=[23.2,31,38.7,46.4,54.2,62,69.7],h='';''',
'''var R=[['sn',snd,'אפקטים'],['mu',sv.cfg.mu,'מוזיקה'],['vo',sv.cfg.vo,'קולות גיבורים'],['vb',sv.cfg.vb,'רטט']],C=[23.2,31,38.7,46.4],h='';
 h+=`<div class='isCov' style='${isPos(13.2,50.2,73.6,23.8)}'><div class='isCovR'><span>🎯 ירי אוטומטי</span><button class='isSw isSwB${sv.cfg.af?' on':''}' data-a='tg:af' aria-label='ירי אוטומטי' aria-pressed='${!!sv.cfg.af}'><i></i></button></div><div class='isCovR'><span>🎥 זווית מצלמה · ${yawDeg()}°</span><span class='isCovB'><button data-a='cyaw:-1' aria-label='סובב מצלמה שמאלה'>⟲</button><button data-a='cyaw:1' aria-label='סובב מצלמה ימינה'>⟳</button></span></div></div>`;''')
rep('''else sv.cfg[k2]=!sv.cfg[k2];save();settings();}''','''else if(k2==="af")afSet(!sv.cfg.af);else sv.cfg[k2]=!sv.cfg[k2];save();settings();}else if(a[0]==="cyaw"){YAWV=0;YAW=((Math.round(YAW/(Math.PI/4))+(+a[1]))*(Math.PI/4)+6.2832)%6.2832;if(YAW<.01||YAW>6.27)YAW=0;sv.cfg.yaw=YAW;save();if(state!=="play"&&state!=="pause")settings();}''')
rep('function settingsIS(){','function yawDeg(){return Math.round(YAW*180/Math.PI)%360;}\nfunction settingsIS(){')

# ---------- 6. 'קרב 3D' leaves the modes list ----------
rep("['עוד',['3d','board','train']]","['עוד',['board','train']]")

# ---------- 7. old saves: forget the removed style switches once; camera angle from settings ----------
rep('''sv.ui=o.ui||null;}}catch(e){}''','''sv.ui=o.ui||null;}}catch(e){}
if(!sv.cfg.m72&&!window.__NOMIG){delete sv.cfg.v25;delete sv.cfg.c3;delete sv.cfg.r3;sv.cfg.v25=sv.cfg.c3=sv.cfg.r3=true;sv.cfg.m72=1;}
try{if(typeof sv.cfg.yaw==="number"&&sv.cfg.v25!==false)YAW=sv.cfg.yaw;}catch(e){}''')

# ---------- 8. HUD: pill region starts after the whole top-left group (pause + AUTO) ----------
rep("var pz=document.getElementById('pz').getBoundingClientRect(),cr=cv.getBoundingClientRect();PZR.l=pz.width&&cr.width?Math.max(0,(pz.right-cr.left)*VW/cr.width):0;",
    "var pz=document.getElementById('top').getBoundingClientRect(),cr=cv.getBoundingClientRect();PZR.l=pz.width&&cr.width?Math.max(0,(pz.right-cr.left)*VW/cr.width):0;")

# ---------- CSS ----------
CSS='''<style>/* v72: AUTO button (battle only) + settings panel over the old style rows */
#afb{display:none!important}
body.inb #afb{display:inline-flex!important;align-items:center;justify-content:center;width:auto;min-width:78px;height:44px;padding:0 12px;border-radius:12px;font:900 14px system-ui,Arial;color:#dbe7ff;background:linear-gradient(180deg,#2a3a7a,#18235a);border:2px solid #6b84d8;box-shadow:0 3px 0 #0a1238,inset 0 2px 0 rgba(255,255,255,.2);margin-left:6px;white-space:nowrap}
body.inb #afb.on{color:#fff;background:linear-gradient(180deg,#5ee05a,#2fa83a 60%,#1f7a2a);border-color:#c8ffc0;box-shadow:0 0 12px rgba(90,230,90,.75),0 3px 0 #0b4a14,inset 0 2px 0 rgba(255,255,255,.4)}
#ov .isA .isCov{display:flex;flex-direction:column;justify-content:space-evenly;padding:0 calc(var(--u)*2.4);border-radius:calc(var(--u)*1.4);background:linear-gradient(180deg,#1a2b6e,#0f1c4f);border:calc(var(--u)*.22) solid #4f6fd8;box-shadow:0 0 calc(var(--u)*1) rgba(80,130,255,.45),inset 0 2px 0 rgba(255,255,255,.12);font-size:calc(var(--u)*2.3)}
#ov .isA .isCovR{display:flex;align-items:center;justify-content:space-between;gap:calc(var(--u)*2)}
#ov .isA .isSwB{position:relative;pointer-events:auto;width:max(56px,calc(var(--u)*8));height:max(30px,calc(var(--u)*4.2));padding:0}
#ov .isA .isCovB{display:flex;gap:calc(var(--u)*1.2)}
#ov .isA .isCovB button{width:max(48px,calc(var(--u)*7));height:max(30px,calc(var(--u)*4.2));border-radius:calc(var(--u)*1);border:calc(var(--u)*.22) solid #8fd0ff;background:linear-gradient(180deg,#2a52c8,#163294 60%,#0f2370);color:#fff;font-size:calc(var(--u)*2.3);padding:0}
</style>
</head>'''
rep('</style>\n</head>','</style>\n'+CSS)
open(P,'w',encoding='utf-8').write(s)
print('ok')
