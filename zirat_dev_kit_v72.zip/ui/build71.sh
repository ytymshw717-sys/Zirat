#!/bin/bash
# rebuild v71 from the v70 stage + patch (team.js already carries the kill attribution)
set -e
cd /home/claude
cp ui/stage_v70.html arena3_stage.html
python3 ui/patch_v71_hud.py
python3 enm/sync_blocks.py
bash t3/emb_stage.sh >/dev/null
cp arena3_gfx.html arena3_new.html
grep -o "NETVER='[0-9]*'" arena3_new.html
