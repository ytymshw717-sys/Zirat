# v71: battle HUD like the player's pictures
#  - in battle only a blue pause button stays on top (title, score, sound and camera buttons move to the pause menu)
#  - one dark info pill on top (segments: cubes / remaining / time), quest pill under it, kill feed under that
#  - mini-map top-right (you, allies, visible rivals, bushes, gas ring, ball, zone, cubes)
#  - glossy colored action buttons: red attack with crosshair, gold star super with charge ring,
#    green lightning gadget with a count badge, purple special
#  - portrait battle: the top bar floats over the arena (taller view) and the page turns dark
import re,sys
P='/home/claude/arena3_stage.html'
s=open(P,encoding='utf-8').read()
def rep(a,b,n=1):
    global s
    c=s.count(a)
    assert c==n,(c,a[:90])
    s=s.replace(a,b)

# ---------- version ----------
s,k=re.subn(r"NETVER='\d+'","NETVER='71'",s);assert k>=1,k

# ---------- CSS ----------
STAR="<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><path fill='white' stroke='%23000' stroke-opacity='.28' stroke-width='5' stroke-linejoin='round' d='M50 7l12.6 26.4 28.9 3.7-21.2 20 5.5 28.7L50 71.9 24.2 85.8l5.5-28.7-21.2-20 28.9-3.7z'/></svg>"
BOLT="<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><path fill='white' stroke='%23000' stroke-opacity='.25' stroke-width='5' stroke-linejoin='round' d='M58 5L19 57h25l-8 38 45-55H55z'/></svg>"
CROSS="<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><g fill='none' stroke='white' stroke-width='9' stroke-linecap='round'><circle cx='50' cy='50' r='27'/><path d='M50 5v20M50 75v20M5 50h20M75 50h20'/></g><circle cx='50' cy='50' r='8' fill='white'/></svg>"
CSS='''<style>/* v71 battle HUD (player's pictures): pause button only on top, colored glossy action buttons */
body.inb #top{position:absolute;top:0;left:0;right:auto;z-index:5;background:none;border:0;box-shadow:none;padding:calc(env(safe-area-inset-top,0px) + 6px) 6px 0 calc(env(safe-area-inset-left,0px) + 8px);pointer-events:none}
body.inb #top>*{pointer-events:auto}
body.inb #top>span:first-child,body.inb #top .tsc,body.inb #top #sp,body.inb #snd,body.inb #rl,body.inb #rr{display:none}
body.inb #pz{width:44px;height:44px;border-radius:12px;font-size:0;color:transparent;background:linear-gradient(180deg,#4f8bff,#2457e0 55%,#1a3fb0);border:2px solid #a9d0ff;box-shadow:0 0 10px rgba(90,150,255,.6),0 3px 0 #0b1d5c,inset 0 2px 0 rgba(255,255,255,.45)}
body.inb #pz:before{content:"";width:5px;height:16px;border-radius:2px;background:#fff;box-shadow:9px 0 0 #fff;transform:translateX(-4.5px)}
@media (orientation:portrait){body.inb{background:radial-gradient(130% 70% at 50% 100%,#1d2775,#0d1238 72%)}}
body.inb #rot{top:auto;bottom:calc(env(safe-area-inset-bottom,0px) + 215px)}
#acts #sup,#acts #gad,#acts #spb{display:flex;align-items:center;justify-content:center;padding:0}
#atk{font-size:0;color:transparent;background:radial-gradient(circle at 38% 28%,#ff9a9a,#f2343e 40%,#c8141f 72%,#8c0a13);border:3px solid #ff8f8f;box-shadow:0 0 0 3px rgba(255,60,60,.35),0 0 20px rgba(255,40,40,.75),0 5px 0 #5c060d,inset 0 -6px 10px rgba(0,0,0,.25),inset 0 4px 6px rgba(255,255,255,.35)}
#atk:before{width:56%;height:56%;margin:0;background:url("data:image/svg+xml,CROSS") center/contain no-repeat}
#sup{font-size:0;color:transparent;border:4px solid transparent;background:radial-gradient(circle at 38% 30%,#9aa9c8,#56658a 55%,#323c5c) padding-box,conic-gradient(#ffd21f var(--ch,0deg),rgba(255,255,255,.22) 0) border-box;box-shadow:0 0 0 2px #141c48,0 4px 0 #0a1030}
#sup:before{content:"";width:60%;height:60%;background:url("data:image/svg+xml,STAR") center/contain no-repeat;opacity:.8;pointer-events:none}
#sup.rdy{background:radial-gradient(circle at 38% 30%,#fff6b8,#ffd21f 45%,#e69500 85%) padding-box,linear-gradient(#fff3b0,#ffb300) border-box;box-shadow:0 0 0 2px #6b3f00,0 0 18px rgba(255,200,40,.95),0 4px 0 #5c3600}
#sup.rdy:before{opacity:1}
#sup.lk{font-size:19px;color:#fff;background:radial-gradient(circle at 38% 30%,#8c9ab5,#4b5875 60%,#2c3550) padding-box,linear-gradient(#6b7896,#3a4560) border-box}
#sup.lk:before,#gad.lk:before{display:none}
#gad{font-size:0;color:#fff;background:radial-gradient(circle at 38% 30%,#a6f5a0,#34c23f 50%,#168024 88%);border:3px solid #d4ffcc;box-shadow:0 0 0 2px #0c4a16,0 0 12px rgba(80,230,100,.6),0 4px 0 #083a10}
#gad:before{content:"";width:56%;height:56%;background:url("data:image/svg+xml,BOLT") center/contain no-repeat;pointer-events:none}
#gad b{position:absolute;top:-6px;right:-6px;min-width:21px;height:21px;padding:0 4px;border-radius:11px;background:#0f172a;border:2px solid #fff;color:#fff;font:900 12px/17px system-ui,Arial;text-align:center;pointer-events:none}
#gad.lk{font-size:17px;background:radial-gradient(circle at 38% 30%,#8c9ab5,#4b5875 60%,#2c3550);border-color:#6b7896;box-shadow:0 0 0 2px #1d2547,0 4px 0 #0a1030}
#spb{color:#fff;background:radial-gradient(circle at 38% 30%,#efc4ff,#b04cf5 48%,#6f1fb8 86%);border:3px solid #f3dcff;box-shadow:0 0 0 2px #3b0f6b,0 0 12px rgba(190,100,255,.6),0 4px 0 #2a0850;text-shadow:0 2px 0 rgba(0,0,0,.35)}
#spb.cool{background:radial-gradient(circle at 38% 30%,#a3adc2,#5f6a84 60%,#3a4360);border-color:#8792ad;box-shadow:0 0 0 2px #1d2547,0 4px 0 #0a1030;color:#fff}
#ov .pzRow{display:flex;gap:8px;justify-content:center;flex-wrap:wrap}
#ov .pzRow button{min-width:46px;height:40px;padding:0 12px;border-radius:12px;font-weight:800;font-size:15px;color:#fff;background:linear-gradient(180deg,#3d74e8,#1f43a8 58%,#16307e);border:2px solid #9fd0ff;box-shadow:0 3px 0 #0a1a4a,inset 0 2px 0 rgba(255,255,255,.35)}
</style>
</head>'''.replace('CROSS',CROSS).replace('STAR',STAR).replace('BOLT',BOLT)
rep('</style>\n</head>','</style>\n'+CSS.split('</head>')[0]+'</head>')

# ---------- buttons: classes instead of inline backgrounds ----------
old_ui=s[s.index('function uiBtns(p){'):]
old_ui=old_ui[:old_ui.index('\n}\n')+3]
new_ui='''function uiBtns(p){
 var cs=canSuper(p),cg=canGad(p),s=cs?Math.floor(p.sup||0):-2,g=cg?p.gads:-2;
 if(s!==uiS){uiS=s;supBtn.style.background='';if(!cs){supBtn.textContent='🔒';supBtn.classList.add('lk');supBtn.classList.remove('rdy');}else{supBtn.textContent='⭐';supBtn.classList.remove('lk');supBtn.style.setProperty('--ch',(s*3.6)+'deg');supBtn.classList.toggle('rdy',s>=100);}}
 if(g!==uiG){uiG=g;if(!cg){gadBtn.textContent='🔒';gadBtn.classList.add('lk');gadBtn.style.opacity=.6;}else{gadBtn.classList.remove('lk');gadBtn.innerHTML='<b>'+g+'</b>';gadBtn.style.opacity=g>0?1:.45;}}
}
'''
rep(old_ui,new_ui)
rep("bindAim2(supBtn,'sup');","supBtn.setAttribute('aria-label','מכת־על');gadBtn.setAttribute('aria-label','כלי עזר');try{document.getElementById('atk').setAttribute('aria-label','הכה');}catch(x){}bindAim2(supBtn,'sup');")

# ---------- in-battle body class ----------
rep(' try{rotTick(dt);}catch(e){}\n',' try{rotTick(dt);}catch(e){}\n var ibN=state==="play"||state==="pause";if(ibN!==INB){INB=ibN;document.body.classList.toggle("inb",ibN);}\n')
rep('var last=0;\nvar AQ={n:0,s:0};','var last=0,INB=false;\nvar AQ={n:0,s:0};')

# ---------- pause menu: sound + camera ----------
rep('''function pause(){if(state!=="play")return;state="pause";releaseAll();ngCliIdle();showOv('<h1>⏸ מושהה</h1><button class="big" data-a="res">המשך</button><button class="c" style="width:auto;padding:0 14px" data-a="menu">תפריט</button>'+tnHtml());}''',
'''function pause(){if(state!=="play")return;state="pause";releaseAll();ngCliIdle();pauseOv();}
function pauseOv(){showOv('<h1>⏸ מושהה</h1><button class="big" data-a="res">המשך</button><div class="pzRow"><button data-a="psnd">'+(snd?'🔊 צליל':'🔇 צליל')+'</button><button data-a="pyaw:-1" title="סובב מצלמה">⟲ מצלמה</button><button data-a="pyaw:1" title="סובב מצלמה">מצלמה ⟳</button>'+(YAW?'<button data-a="pyaw:0">↺ ישר</button>':'')+'</div><button class="c" style="width:auto;padding:0 14px" data-a="menu">תפריט</button>'+tnHtml());}''')
rep(''' else if(a[0]==="res")resume();''',''' else if(a[0]==="psnd"){snd=!snd;document.getElementById("snd").textContent=snd?"🔊":"🔇";if(state==="pause")pauseOv();}
 else if(a[0]==="pyaw"){var yv=+a[1];YAWV=0;YAW=yv?((Math.round(YAW/(Math.PI/4))+yv)*(Math.PI/4)+6.2832)%6.2832:0;if(YAW<.01||YAW>6.27)YAW=0;if(state==="pause")pauseOv();}
 else if(a[0]==="res")resume();''')
rep('''if(state==="pause"){state="play";pause();}''','''if(state==="pause"){pauseOv();}''')

# ---------- kill attribution ----------
rep("dropLoot(e);if(!hb){sv.st.k++;qp(\"kill\",1);}","if(e.ch)e._kb=o;dropLoot(e);if(!hb){sv.st.k++;qp(\"kill\",1);}")

# ---------- HUD on the canvas ----------
a=s.index(' if(Q){\n  var tx="🎯 "+Q.t+" ("')
b=s.index('\n}\n\n// loop',a)
s=s[:a]+' hud71();'+s[b:]
HUD='''
/* v71 battle HUD (player's pictures): info pill, quest, kill feed, mini-map */
var KF=[],KFP=[],KFT=0,PZR={t:0,l:0};
window.__kf=function(){return KF.map(function(k){return k.s.map(function(q){return q[0];}).join('');});};
function hRR(x,y,w,h,r){ctx.beginPath();ctx.moveTo(x+r,y);ctx.arcTo(x+w,y,x+w,y+h,r);ctx.arcTo(x+w,y+h,x,y+h,r);ctx.arcTo(x,y+h,x,y,r);ctx.arcTo(x,y,x+w,y,r);ctx.closePath();}
function hNm(o){return o===ps[0]?'אתה':String(o.nm||(o.ch&&(o.ch.nk||o.ch.n))||'').slice(0,12);}
function hMine(o){return ps.indexOf(o)>=0||tbots.indexOf(o)>=0;}
function kfAdd(v){var k=v._kb,vc=hMine(v)?'#93c5fd':'#fca5a5',S;v._kb=null;
 if(k&&k.ch&&k!==v)S=[[hNm(k),hMine(k)?'#93c5fd':'#fca5a5'],[' ⚔️ ','#ffffff'],['💀 '+hNm(v),vc]];
 else if(v===ps[0])S=[['💀 הודחת!','#fca5a5']];
 else S=[['💀 ','#ffffff'],[hNm(v),vc]];
 KF.unshift({s:S,t:3.6});if(KF.length>3)KF.length=3;}
function kfTick(dt){
 if(state!=='play'){KFP=[];return;}
 var cur=[];ps.forEach(function(p){cur.push(p);});tbots.forEach(function(b){cur.push(b);});enemies.forEach(function(e){if(e.ch)cur.push(e);});
 cur.forEach(function(o){if(o.hp<=0){if(!o._kfd){o._kfd=1;kfAdd(o);}}else o._kfd=0;});
 KFP.forEach(function(o){if(!o._kfd&&o.hp<=0&&cur.indexOf(o)<0){o._kfd=1;kfAdd(o);}});
 KFP=cur;
 for(var i=KF.length-1;i>=0;i--){KF[i].t-=dt;if(KF[i].t<=0)KF.splice(i,1);}
}
/* segments drawn right to left (Hebrew order) inside one pill */
function segW(S,font){ctx.font=font;var w=0;S.forEach(function(q){q.w=ctx.measureText(q[0]).width;w+=q.w;});return w;}
function segPill(S,cx,y,h,font,pad,sep,bg,bd){
 var w=segW(S,font),gap=sep?13:0,W2=w+gap*(S.length-1)+pad*2,x=cx+W2/2-pad;
 hRR(cx-W2/2,y,W2,h,h/2);ctx.fillStyle=bg;ctx.fill();ctx.lineWidth=1.5;ctx.strokeStyle=bd;ctx.stroke();
 ctx.textAlign='right';ctx.textBaseline='middle';
 S.forEach(function(q,i){ctx.fillStyle=q[1];ctx.fillText(q[0],x,y+h/2+.5);x-=q.w;if(sep&&i<S.length-1){ctx.fillStyle='rgba(255,255,255,.28)';ctx.fillRect(x-gap/2-.75,y+5,1.5,h-10);x-=gap;}});
 ctx.textBaseline='alphabetic';return W2;}
function miniMap(mx,my,mw,mh){
 hRR(mx,my,mw,mh,8);ctx.fillStyle='rgba(10,14,42,.8)';ctx.fill();ctx.lineWidth=1.5;ctx.strokeStyle='rgba(130,160,255,.6)';ctx.stroke();
 ctx.save();hRR(mx+1,my+1,mw-2,mh-2,7);ctx.clip();
 var sx=(mw-8)/W,sy=(mh-8)/H,ox=mx+4,oy=my+4,c=Math.cos(YAW),n=Math.sin(YAW);
 function P(x,y){var dx=x-W/2,dy=y-H/2;if(YAW){var rx=dx*c-dy*n,ry=dx*n+dy*c;dx=rx;dy=ry;}return [ox+(dx+W/2)*sx,oy+(dy+H/2)*sy];}
 function dot(x,y,r,col,ring){var q=P(x,y);ctx.beginPath();ctx.arc(q[0],q[1],r,0,6.283);ctx.fillStyle=col;ctx.fill();if(ring){ctx.lineWidth=1.2;ctx.strokeStyle=ring;ctx.stroke();}}
 var q0=P(0,0),q1=P(W,0),q2=P(W,H),q3=P(0,H);ctx.beginPath();ctx.moveTo(q0[0],q0[1]);ctx.lineTo(q1[0],q1[1]);ctx.lineTo(q2[0],q2[1]);ctx.lineTo(q3[0],q3[1]);ctx.closePath();ctx.fillStyle='rgba(70,90,190,.35)';ctx.fill();
 ctx.fillStyle='rgba(74,190,90,.45)';bushes.forEach(function(b){var q=P(b.x,b.y);ctx.beginPath();ctx.arc(q[0],q[1],Math.max(1.5,b.r*sx),0,6.283);ctx.fill();});
 if(zone)dot(zone.x,zone.y,Math.max(2,zone.r*sx),'rgba(255,140,40,.45)');
 if(gas&&mode==='show'){var g=P(gas.x,gas.y);ctx.beginPath();ctx.arc(g[0],g[1],Math.max(2,gas.r*sx),0,6.283);ctx.setLineDash([3,3]);ctx.lineWidth=1.5;ctx.strokeStyle='#facc15';ctx.stroke();ctx.setLineDash([]);}
 drops.forEach(function(d){if(d.k==='cube')dot(d.x,d.y,1.6,'#c084fc');});
 if(safeS&&safeS.hp>0)dot(safeS.x,safeS.y,3,'#facc15');
 if(bl)dot(bl.x,bl.y,2.4,'#ffffff');
 enemies.forEach(function(e){if(e.hp>0&&!e.hid)dot(e.x,e.y,e.ch?2.8:1.9,'#ff4d5e');});
 tbots.forEach(function(b){if(b.hp>0)dot(b.x,b.y,2.6,'#5fa8ff');});
 ps.forEach(function(p,i){if(p.hp>0)dot(p.x,p.y,i?2.6:3.3,i?'#5fa8ff':'#3b82f6',i?null:'#ffffff');});
 ctx.restore();}
function hud71(){
 var now=performance.now(),dt=KFT?Math.min(1,(now-KFT)/1000):0;KFT=now;kfTick(dt);
 var solo=ps.length===1&&r3A(),mm=solo&&state==='play',land=VW>VH*1.2,mw=land?104:84,mh=Math.round(mw*H/W),mx=VW-mw-6,my=6;
 if(now>PZR.t){PZR.t=now+500;try{var pz=document.getElementById('pz').getBoundingClientRect(),cr=cv.getBoundingClientRect();PZR.l=pz.width&&cr.width?Math.max(0,(pz.right-cr.left)*VW/cr.width):0;}catch(e){PZR.l=0;}}
 var y=solo?6:29,xL=Math.max(4,PZR.l+5),xR=mm?mx-5:VW-4;
 if(mm)miniMap(mx,my,mw,mh);
 var gx0=modeText(),gx=gx0?gx0:mode==='siege'?'🏰 הרוס את המגדלים ואז את הלב':(goal?'🏁 גל '+wave+'/'+goal:'♾️ אינסוף · גל '+wave);
 var S=gx.split(' · ').map(function(t){return [t,/\\d:\\d\\d|הארכה/.test(t)?'#fde047':'#ffffff'];});
 if(mode==='show'&&ps[0])S.unshift(['💎 '+(ps[0].cubes||0),'#e9d5ff']);
 var F1='900 13px system-ui,Arial',w1=segW(S,F1)+13*(S.length-1)+28,cx=VW/2;
 if(cx-w1/2<xL||cx+w1/2>xR){if(w1<=xR-xL)cx=(xL+xR)/2;else{y=mm?my+mh+4:y;cx=VW/2;}}
 segPill(S,cx,y,24,F1,14,true,'rgba(12,16,46,.88)','rgba(130,150,255,.5)');y+=28;
 if(Q){segPill([['🎯 '+Q.t+' ('+Math.min(Q.p,Q.g)+'/'+Q.g+')','#fde68a']],cx,y,18,'800 11px system-ui,Arial',10,false,'rgba(12,16,46,.8)','rgba(232,184,74,.55)');y+=22;}
 KF.forEach(function(k){ctx.globalAlpha=Math.min(1,k.t*2);segPill(k.s,cx,y,17,'800 10.5px system-ui,Arial',9,false,'rgba(8,10,30,.72)','rgba(255,255,255,.18)');y+=20;});ctx.globalAlpha=1;
}
'''
rep('\n// loop\nvar last=0,INB=false;',HUD+'\n// loop\nvar last=0,INB=false;')

open(P,'w',encoding='utf-8').write(s)
print('ok')
