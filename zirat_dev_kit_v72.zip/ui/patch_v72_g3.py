# v72 (g3.js): less robotic arms. The old poses lifted BOTH arms forward and inward ("hands to the middle"):
#  - battle aim (ranged heroes): now one shooting arm forward, the other arm relaxed at the side, shoulder turned in
#  - menu acts: shoot (same one-arm aim), guard -> bouncy ready stance looking around, cast -> one arm up to the sky
import sys
P='/home/claude/g3/g3.js'
s=open(P,encoding='utf-8').read()
def rep(a,b,n=1):
    global s
    c=s.count(a);assert c==n,(c,a[:100]);s=s.replace(a,b)

# battle: aim pose for ranged heroes
rep("""   v.arms[1].rotation.set(v.arms[1].rotation.x*(1-aw)+(-1.48+.6*rc)*aw,rv*.25*rc*aw,-.12+.1*rc*aw);if(v.fore)v.fore[1].rotation.x=fb*(1-aw)-.06*aw;
   v.arms[0].rotation.x=v.arms[0].rotation.x*(1-aw)-1.0*aw;v.arms[0].rotation.z=v.arms[0].rotation.z*(1-aw)-.28*aw;if(v.fore)v.fore[0].rotation.x=fb*(1-aw)-.4*aw;
   v.torso.rotation.x-=.16*rc;v.torso.rotation.y+=-.1*aw+rv*.12*rc;v.head.rotation.x=v.head.rotation.x*(1-aw)+(-.05+.1*rc)*aw;v.body.position.z-=.08*rc;}}""",
"""   v.arms[1].rotation.set(v.arms[1].rotation.x*(1-aw)+(-1.3+.5*rc)*aw,rv*.25*rc*aw,v.arms[1].rotation.z*(1-aw)+(-.1+.08*rc)*aw);if(v.fore)v.fore[1].rotation.x=fb*(1-aw)-.12*aw;
   v.arms[0].rotation.x=v.arms[0].rotation.x*(1-.7*aw)+.18*.7*aw;v.arms[0].rotation.z=v.arms[0].rotation.z*(1-aw)+.24*aw;if(v.fore)v.fore[0].rotation.x=fb*(1-aw)-.45*aw;
   v.torso.rotation.x-=.12*rc;v.torso.rotation.y+=-.3*aw+rv*.12*rc;v.head.rotation.y+=.22*aw;v.head.rotation.x=v.head.rotation.x*(1-aw)+(-.05+.08*rc)*aw;v.body.position.z-=.06*rc;}}""")
rep("if(newSh){if(ranged){e.rc=1;e.aimH=.5;","if(newSh){if(ranged){e.rc=1;e.aimH=.35;")

# menu acts
import re
a=s.index(' shoot:[1.4,function(v,p){');b=s.index('\n',a)
s=s[:a]+""" shoot:[1.4,function(v,p){var aim=Math.min(1,p*4)*(p>.85?(1-p)/.15:1),rc=p>.25&&p<.85?Math.abs(Math.sin((p-.25)*Math.PI*5))*.25:0;v.arms[1].rotation.x=-1.3*aim+rc;v.arms[1].rotation.z=-.1;v.arms[0].rotation.x=.18*aim;v.arms[0].rotation.z=.12+.14*aim;if(v.fore)v.fore[0].rotation.x=-.45*aim;v.torso.rotation.y=-.3*aim;v.head.rotation.y=.22*aim;v.torso.rotation.x=-rc*.3;}],"""+s[b:]
a=s.index(' guard:[1.6,function(v,p){');b=s.index('\n',a)
s=s[:a]+""" guard:[1.6,function(v,p){var g=p>.85?(1-p)/.15:Math.min(1,p*5),b=Math.abs(Math.sin(p*Math.PI*4)),lk=Math.sin(p*Math.PI*2);v.arms[0].rotation.z=.12+.22*g;v.arms[1].rotation.z=-.12-.22*g;v.arms[0].rotation.x=.12*g*lk;v.arms[1].rotation.x=-.12*g*lk;v.legs[0].rotation.z=-.1*g;v.legs[1].rotation.z=.1*g;v.body.position.y+=.06*b*g-.04*g;v.head.rotation.y=.45*lk*g;v.torso.rotation.y=.15*lk*g;}],"""+s[b:]
a=s.index(' cast:[1.6,function(v,p){');b=s.index('\n',a)
s=s[:a]+""" cast:[1.6,function(v,p){var u=Math.sin(p*Math.PI);v.arms[1].rotation.x=-2.6*u;v.arms[1].rotation.z=-.15*u;v.arms[0].rotation.x=-.3*u;v.arms[0].rotation.z=.12+.8*u;v.body.position.y+=.15*u;v.torso.rotation.x=-.12*u;v.head.rotation.x=-.2*u;}]"""+s[b:]
open(P,'w',encoding='utf-8').write(s)
print('ok')
