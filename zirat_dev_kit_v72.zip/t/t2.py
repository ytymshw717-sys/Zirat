import sys
from playwright.sync_api import sync_playwright
F='file:///home/claude/'+sys.argv[1];errs=[];res=[]
with sync_playwright() as p:
    b=p.chromium.launch();c=b.new_context(viewport={'width':932,'height':430},has_touch=True,is_mobile=True)
    c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto(F);pg.wait_for_timeout(3300)
    for w in ['shop','skins','tr','qs','pass','prof','cfg','maps','heroes','online','pick:0','hi:0']:
        pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='%s';document.getElementById('ov').appendChild(b);b.click();})()"%w);pg.wait_for_timeout(250)
        t=pg.inner_text('#ov');res.append((w,len(t)));
        pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='menu';document.getElementById('ov').appendChild(b);b.click();})()");pg.wait_for_timeout(150)
    print('windows',res)
    for m in ['survive','siege','boss','heist','gems','hot','ball','show','train']:
        for yaw in [0,1.1]:
            pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='mode:%s';document.getElementById('ov').appendChild(b);b.click();})()"%m)
            pg.wait_for_timeout(300);pg.evaluate("__yaw(%f)"%yaw)
            pg.keyboard.down('KeyD');pg.keyboard.down('Space');pg.wait_for_timeout(1500);pg.keyboard.up('KeyD');pg.keyboard.up('Space')
            s=pg.evaluate("[__arena().state,__arena().mode,Math.round(__arena().ps[0].x)]");print(m,yaw,s)
            if m=='siege' and yaw:pg.screenshot(path='/home/claude/t/siege_yaw.png')
            pg.keyboard.press('KeyP');pg.wait_for_timeout(100)
            pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='menu';document.getElementById('ov').appendChild(b);b.click();})()");pg.wait_for_timeout(200)
    print('ERRORS',errs)
