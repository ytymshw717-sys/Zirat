# cut a floating companion (separate piece) out of an older GLB and add it to a ux hero json as "pet"
# usage: python3 -I pet_conv.py RAW.npz TEX.jpg HERO.json size_in_game_units  (RAW from the extraction step: V,F,UV in the GLB's own axes, facing +X)
import sys, json, struct, subprocess, io, base64, os
import numpy as np
from PIL import Image
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from scipy.spatial import cKDTree
R = np.load(sys.argv[1]); tex = Image.open(sys.argv[2]).convert('RGB'); HJ = sys.argv[3]; SIZE = float(sys.argv[4]); TMP = '/tmp/uxc/'
P = R['V'].astype(np.float64); F = R['F'].astype(np.int64); UV = R['UV'].astype(np.float64)
P = np.stack([-P[:, 2], P[:, 1], P[:, 0]], 1)           # face +Z like the heroes
P = (P - (P.max(0) + P.min(0)) / 2) / (P.max(0) - P.min(0)).max() * SIZE
nv = len(P); e = np.concatenate([F[:, [0, 1]], F[:, [1, 2]]])
_, chart = connected_components(coo_matrix((np.ones(len(e)), (e[:, 0], e[:, 1])), shape=(nv, nv)), directed=False)
key = np.round(P / 1e-7).astype(np.int64); _, wid, inv = np.unique(key, axis=0, return_index=True, return_inverse=True); inv = inv.ravel()
WP = P[wid]; WF = inv[F]; WF = WF[(WF[:, 0] != WF[:, 1]) & (WF[:, 1] != WF[:, 2]) & (WF[:, 0] != WF[:, 2])]
with open(TMP + 'pi', 'wb') as f: f.write(struct.pack('<ii', len(WP), len(WF))); f.write(WP.astype(np.float32).tobytes()); f.write(WF.astype(np.int32).tobytes())
subprocess.run(['/home/claude/mx/qsimp2', TMP + 'pi', TMP + 'po', '1600'], check=True, stdout=subprocess.DEVNULL)
q = open(TMP + 'po', 'rb').read(); lnv, lnf = struct.unpack('<ii', q[:8])
LV = np.frombuffer(q, np.float32, lnv * 3, 8).reshape(-1, 3).astype(np.float64); LF = np.frombuffer(q, np.int32, lnf * 3, 8 + lnv * 12).reshape(-1, 3)
_, nt = cKDTree(P[F].mean(1)).query(LV[LF].mean(1)); lch = chart[F[nt, 0]]; cUV = np.zeros((lnf, 3, 2))
order = np.argsort(chart); bnd = np.searchsorted(chart[order], np.arange(chart.max() + 2))
for c in np.unique(lch):
    vid = order[bnd[c]:bnd[c + 1]]; sel = np.where(lch == c)[0]; _, k = cKDTree(P[vid]).query(LV[LF[sel]].reshape(-1, 3)); cUV[sel] = UV[vid[k]].reshape(-1, 3, 2)
# crop the texture to the pet's UV box
u0, v0 = cUV.reshape(-1, 2).min(0); u1, v1 = cUV.reshape(-1, 2).max(0); W, H = tex.size
box = (int(u0 * W) - 2, int(v0 * H) - 2, int(np.ceil(u1 * W)) + 2, int(np.ceil(v1 * H)) + 2); box = (max(0, box[0]), max(0, box[1]), min(W, box[2]), min(H, box[3]))
crop = tex.crop(box); cUV[..., 0] = (cUV[..., 0] * W - box[0]) / (box[2] - box[0]); cUV[..., 1] = (cUV[..., 1] * H - box[1]) / (box[3] - box[1])
crop.thumbnail((256, 256)); tb = io.BytesIO(); crop.save(tb, 'WEBP', quality=85, method=6)
cv = LF.reshape(-1); cu = np.round(cUV.reshape(-1, 2) * 8192).astype(np.int64); k2 = np.stack([cv, cu[:, 0], cu[:, 1]], 1)
uk, fidx = np.unique(k2, axis=0, return_inverse=True); fidx = fidx.ravel(); FV = LV[uk[:, 0]]; FU = uk[:, 1:] / 8192.0; FF = fidx.reshape(-1, 3)
mn, mx = FV.min(0), FV.max(0); qp = np.round((FV - mn) / (mx - mn) * 65535).astype(np.uint16); qu = np.round(np.clip(FU, 0, 1) * 65535).astype(np.uint16)
blob = qp.tobytes() + qu.tobytes() + FF.astype(np.uint16).tobytes()
D = json.load(open(HJ))
D['pet'] = {'nv': len(FV), 'nf': len(FF), 'mn': [round(float(x), 4) for x in mn], 'mx': [round(float(x), 4) for x in mx], 'd': base64.b64encode(blob).decode(), 'tex': 'data:image/webp;base64,' + base64.b64encode(tb.getvalue()).decode()}
json.dump(D, open(HJ, 'w'), separators=(',', ':'))
np.savez(TMP + 'pet_low.npz', V=FV, F=FF, UV=FU); crop.save(TMP + 'pet_tex.png')
print('pet', len(FV), 'verts', len(FF), 'tris', 'tex', crop.size, len(tb.getvalue()) // 1024, 'KB', 'json KB', os.path.getsize(HJ) // 1024)
