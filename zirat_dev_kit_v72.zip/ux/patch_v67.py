# v67: Bo (14) as a rigged hero + Nova re-exported (centred); clips on the 11 game joints for battle (run, death);
# '@clip' stage acts (menu dances, victory, lose). Run on the v66 sources.
import re
G = '/home/claude/g3/g3.js'; ST = '/home/claude/arena3_stage.html'
s = open(G, encoding='utf-8').read()
def rep(a, b, n=1):
    global s
    assert s.count(a) == n, (s.count(a), a[:80]); s = s.replace(a, b)

# 1) model entries
L = s.split('\n')
for idx, f in ((11, '/home/claude/ux/nova.json'), (14, '/home/claude/ux/bo.json')):
    hit = [i for i, l in enumerate(L) if l.startswith('%d:{' % idx) and '"nv"' in l[:20]]
    assert len(hit) == 1, (idx, hit); L[hit[0]] = '%d:' % idx + open(f, encoding='utf-8').read() + ','
s = '\n'.join(L)

# 2) uxGeo: group clips (11 game joints) next to the bone clips
rep("""  var Q=new Int16Array(qa.buffer),QF=new Float32Array(Q.length);for(i=0;i<Q.length;i++)QF[i]=Q[i]/32767;clips[cn]={n:c.n,fps:c.fps,dur:c.dur,q:QF,h:new Float32Array(ha.buffer),nb:nb};}""",
"""  var Q=new Int16Array(qa.buffer),QF=new Float32Array(Q.length);for(i=0;i<Q.length;i++)QF[i]=Q[i]/32767;clips[cn]={n:c.n,fps:c.fps,dur:c.dur,q:QF,h:new Float32Array(ha.buffer),nb:nb};
  if(c.gq){var gq=new Int16Array(uxB64(c.gq).buffer),GF=new Float32Array(gq.length);for(i=0;i<gq.length;i++)GF[i]=gq[i]/32767;clips[cn].gq=GF;clips[cn].gp=new Float32Array(uxB64(c.gp).buffer);}}""")

# 3) helpers: group-clip player + stage clip acts
rep("function uxRest(v){", r"""function uxB64(s){var b=atob(s),u=new Uint8Array(b.length);for(var i=0;i<b.length;i++)u[i]=b.charCodeAt(i);return u;}
/* clip retargeted onto the 11 game joints (body A): used in battle, so shooting, hits and supers still layer on top.
   A hero without its own copy borrows it from another rigged hero (all Tripo rigs share one skeleton). */
function uxGClip(v,name){var c=v&&v.ux&&v.ux.clips[name];if(c&&c.gq)return c;if(!v||!v.ux)return null;
 for(var k in GLBM){var m=GLBM[k];if(m&&m.ux&&m.clips&&m.clips[name]&&m.clips[name].gq){var g=uxGeo(k).clips[name];if(g&&g.gq)return g;}}return null;}
var UXQ=new THREE.Quaternion(),UX1=new THREE.Vector3(1,1,1);
function uxG(v,name,t,w){var c=uxGClip(v,name);if(!c||!v.fore||!v.knee)return false;
 var f=Math.max(0,Math.min(c.n-1.0001,t*c.fps)),i0=f|0,i1=i0+1,a=f-i0,Q=c.gq,P=c.gp,G=[v.body,v.torso,v.head,v.legs[0],v.knee[0],v.legs[1],v.knee[1],v.arms[0],v.fore[0],v.arms[1],v.fore[1]];
 for(var b=0;b<11;b++){var k0=(i0*11+b)*4,k1=(i1*11+b)*4;UXQ.set(Q[k0]+(Q[k1]-Q[k0])*a,Q[k0+1]+(Q[k1+1]-Q[k0+1])*a,Q[k0+2]+(Q[k1+2]-Q[k0+2])*a,Q[k0+3]+(Q[k1+3]-Q[k0+3])*a).normalize();
  if(w>=.999)G[b].quaternion.copy(UXQ);else G[b].quaternion.slerp(UXQ,w);}
 var bp=v.body.position;bp.x+=(P[i0*3]+(P[i1*3]-P[i0*3])*a-bp.x)*w;bp.y+=(P[i0*3+1]+(P[i1*3+1]-P[i0*3+1])*a-bp.y)*w;bp.z+=(P[i0*3+2]+(P[i1*3+2]-P[i0*3+2])*a-bp.z)*w;
 v.body.scale.lerp(UX1,w);v.torso.scale.lerp(UX1,w);return true;}
/* stage: '@name' plays that clip on the real bones; screen moves map to a hero's own clips when it has them */
var UXMAP={victory:['clap','dance_05'],wave:['greet_04'],ball:['basketball_shot'],angry:['defeat_03','angry_03'],angry2:['angry_02']},UXMENU=['dance_05','basketball_shot','flip','greet_04','dive'];
function uxAct(v,n){var c=v&&v.ux&&v.ux.clips[n];if(!c)return null;ACTS['@'+n]=[c.dur,function(v2,p){var c2=v2.ux&&v2.ux.clips[n];if(c2)uxPlay(v2,n,p*c2.dur);}];return '@'+n;}
function uxRest(v){""")
# 3b) companion that floats beside a hero (Bo's spirit), from the "pet" entry of its model
rep(" V.ux={B:B,bones:bones,hip:hip,clips:U.clips};}",
""" V.ux={B:B,bones:bones,hip:hip,clips:U.clips};
 if(m.pet){var pm=uxPet(id);if(pm){V.g.add(pm);V.pet=pm;}}}
var GLBP={};
function uxPet(id){var m=GLBM[id].pet;if(!GLBP[id]){var u=uxB64(m.d),nv=m.nv,nf=m.nf,o=0;
  var q=new Uint16Array(u.buffer.slice(0,nv*6)),uv=new Uint16Array(u.buffer.slice(nv*6,nv*10)),ix=new Uint16Array(u.buffer.slice(nv*10,nv*10+nf*6));
  var P=new Float32Array(nv*3),UV=new Float32Array(nv*2);for(var i=0;i<nv*3;i++){var c=i%3;P[i]=m.mn[c]+q[i]/65535*(m.mx[c]-m.mn[c]);}for(i=0;i<nv*2;i++)UV[i]=uv[i]/65535;
  var g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(P,3));g.setAttribute('uv',new THREE.BufferAttribute(UV,2));g.setIndex(new THREE.BufferAttribute(ix,1));g.computeVertexNormals();
  var im=new Image(),tx=new THREE.Texture(im);tx.flipY=false;im.onload=function(){tx.needsUpdate=true;};im.src=m.tex;
  GLBP[id]={g:g,mt:new THREE.MeshToonMaterial({map:tx,gradientMap:toonGrad(),emissive:new THREE.Color('#5eead4'),emissiveIntensity:.12})};}
 var P2=GLBP[id],pm=new THREE.Mesh(P2.g,P2.mt),pp=m.pos||[.62,2.02,-.08];pm.position.set(pp[0],pp[1],pp[2]);pm.castShadow=true;pm.userData={y0:pp[1],ph:Math.random()*6};
 pm.onBeforeRender=function(){var t=performance.now()/1000+this.userData.ph;this.position.y=this.userData.y0+Math.sin(t*2.2)*.07;this.rotation.set(Math.sin(t*1.3)*.06,Math.sin(t*.9)*.35,Math.sin(t*1.7)*.08);};
 return pm;}""")

# 4) battle: run blended by walk weight, death clip before the tomb
rep(""" var dead=!peer&&pl.hp<=0;v.g.visible=!dead;e.tomb.visible=dead;e.ring.visible=!dead;""",
""" var dead=!peer&&pl.hp<=0;
 if(!dead)e.dT=0;else if(v.ux){var fc=uxGClip(v,'fall');e.dT=(e.dT||0)+dt;
  if(fc&&e.dT<fc.dur+1.4){v.g.visible=true;e.tomb.visible=false;e.ring.visible=false;e.aura.visible=e.shield.visible=e.spin.visible=e.swing.visible=false;e.px=null;
   v.g.scale.setScalar(s);v.g.rotation.set(0,e.face||0,0);uxG(v,'fall',Math.min(e.dT,fc.dur),1);for(var di=0;di<v.mats.length-1;di++){var dm=v.mats[di];if(dm.emissive)dm.emissive.setRGB(0,0,0);}return;}}
 v.g.visible=!dead;e.tomb.visible=dead;e.ring.visible=!dead;""")
rep(""" var fb=-.3-.9*ww;if(v.fore){v.fore[0].rotation.set(fb,0,0);v.fore[1].rotation.set(fb,0,0);}
 // dust while running""",
""" var fb=-.3-.9*ww;if(v.fore){v.fore[0].rotation.set(fb,0,0);v.fore[1].rotation.set(fb,0,0);}
 if(v.ux&&ww>.01){var rc0=uxGClip(v,'run');if(rc0)uxG(v,'run',(((e.ph*.6/6.2832)%1)+1)%1*rc0.dur,ww);}
 // dust while running""")

# 5) stage: menu list from the hero's clips; screen moves -> clips
rep("if(ch.hat==='band'||ch.hat==='horn')l.splice(2,0,'punch');var gm=typeof GLBM!=='undefined'&&GLBM[ch.idx];if(gm&&gm.clips&&gm.clips.basketball_shot&&!(ch.skn>0)){l.unshift('ball');l.splice(3,0,'ball');}return l;}",
    "if(ch.hat==='band'||ch.hat==='horn')l.splice(2,0,'punch');var gm=typeof GLBM!=='undefined'&&GLBM[ch.idx],mc=gm&&gm.clips&&!(ch.skn>0)?UXMENU.filter(function(n){return gm.clips[n];}):[];"
    "if(mc.length>=3){l=[];mc.forEach(function(n,i){l.push('@'+n);if(i%2)l.push('guard');});}else if(mc.length){l.unshift('ball');l.splice(3,0,'ball');}return l;}")
rep("function shPlay(){if(!SH||!SH.v)return;var l=SH.acts;SH.act=l[SH.ai%l.length];if(UXA[SH.act]&&!SH.v.ux)SH.act='guard';",
    "function shPlay(){if(!SH||!SH.v)return;var l=SH.acts;SH.act=l[SH.ai%l.length];"
    "if(SH.v.ux){var a0=SH.act,cl=SH.v.ux.clips,cand=a0.charAt(0)==='@'?[a0.slice(1)]:(UXMAP[a0]||[]).filter(function(n){return cl[n];});"
    "if(cand.length){SH.vk=(SH.vk||0)+1;SH.act=uxAct(SH.v,cand[SH.vk%cand.length])||'guard';}}"
    "if(SH.act.charAt(0)==='@'&&!ACTS[SH.act])SH.act='guard';if(UXA[SH.act]&&!SH.v.ux)SH.act='guard';")
rep("  if(SH.frz){ACTS[SH.frz[0]][1](v,SH.frz[1]);SH.yaw=SH.frz[2];}",
    "  if(SH.frz){var fa=SH.frz[0];if(fa.charAt(0)==='@'&&!ACTS[fa])fa=uxAct(v,fa.slice(1))||'guard';"
    "if(fa.charAt(0)==='#'&&!ACTS[fa]){var gn=fa.slice(1);ACTS[fa]=[1,function(v2,p){var gc=uxGClip(v2,gn);if(gc)uxG(v2,gn,p*gc.dur,1);}];}ACTS[fa][1](v,SH.frz[1]);SH.yaw=SH.frz[2];}")
rep("_v:function(){return SH&&SH.v;},", "_v:function(){return SH&&SH.v;},_r3p:function(px,py){try{var q=new THREE.Vector3(r3x(px),.9,r3z(py));q.project(R3.cam);return [q.x,q.y];}catch(e){return null;}},")
open(G, 'w', encoding='utf-8').write(s)

h = open(ST, encoding='utf-8').read()
assert h.count("var NETVER='66'") == 1; h = h.replace("var NETVER='66'", "var NETVER='67'")
open(ST, 'w', encoding='utf-8').write(h)
print('patched v67')
