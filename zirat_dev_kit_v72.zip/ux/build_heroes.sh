#!/bin/bash
# rebuild all rigged heroes: bo (14, with spirit pet) + nova (11)
set -e
cd /home/claude/ux
python3 -I ux_conv.py /mnt/user-data/uploads/3d_chibi_character.glb bo.json $(python3 -c "print((0.960571+1.000078)*1.3)") 12000 '{"clap":4.6}' run,fall | grep "face fixes"
python3 -I pet_conv.py spirit_raw.npz wolf_tex.jpg bo.json 0.42
python3 -I ux_conv.py /mnt/user-data/uploads/stylized_character_3d_model.glb nova.json $(python3 -c "print((0.956101+1.000421)*1.3)") 12000 '{}' '' | grep "face fixes"
python3 - <<'PY'
import json
for f in ('bo.json','nova.json'):
    D=json.load(open(f));D['fl']=.2;json.dump(D,open(f,'w'),separators=(',',':'))
PY
