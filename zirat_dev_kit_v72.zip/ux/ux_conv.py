# Tripo rigged+animated GLB -> compact game data for one hero (Nova, idx 11).
# Output /home/claude/nova/nova.json : mesh (decimated, UV), two skins (11 game groups + 23 real bones), clips, joints, webp texture.
# usage: python3 -I nova_conv.py SRC.glb [target_tris]
import sys, os, json, struct, io, base64, subprocess
import numpy as np
from PIL import Image
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
from scipy.spatial import cKDTree

# usage: python3 -I ux_conv.py SRC.glb OUT.json HEIGHT [tris] [clipmax-json] [gclips-csv]
SRC = sys.argv[1]; OUTF = sys.argv[2]; TARGET = int(sys.argv[4]) if len(sys.argv) > 4 else 12000
CLIPMAX = json.loads(sys.argv[5]) if len(sys.argv) > 5 else {}; GCL = [x for x in (sys.argv[6] if len(sys.argv) > 6 else '').split(',') if x]
H = os.path.dirname(os.path.abspath(__file__)); TMP = '/tmp/uxc/'; os.makedirs(TMP, exist_ok=True)
QS = '/home/claude/mx/qsimp2'
H_TARGET = float(sys.argv[3])   # game-unit height (old model: (mx_y-mn_y)*k)
FPS = 20

d = open(SRC, 'rb').read(); o = 12; ch = []
while o < len(d):
    cl, ct = struct.unpack('<II', d[o:o + 8]); ch.append(d[o + 8:o + 8 + cl]); o += 8 + cl
J = json.loads(ch[0]); B = ch[1]; NODES = J['nodes']
def acc(i):
    a = J['accessors'][i]; v = J['bufferViews'][a['bufferView']]
    dt = {5126: np.float32, 5125: np.uint32, 5123: np.uint16, 5121: np.uint8}[a['componentType']]
    n = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4, 'MAT4': 16}[a['type']]; isz = np.dtype(dt).itemsize
    st = v.get('byteStride', n * isz); off = v.get('byteOffset', 0) + a.get('byteOffset', 0)
    arr = np.frombuffer(B, np.uint8)[off:off + st * a['count']].reshape(a['count'], st)[:, :n * isz].copy().view(dt).reshape(a['count'], n)
    if a.get('normalized') and dt != np.float32: arr = arr.astype(np.float32) / np.iinfo(dt).max
    return arr
p = J['meshes'][0]['primitives'][0]
P = acc(p['attributes']['POSITION']).astype(np.float64); UV = acc(p['attributes']['TEXCOORD_0']).astype(np.float64)
JT = acc(p['attributes']['JOINTS_0']).astype(int); WT = acc(p['attributes']['WEIGHTS_0']).astype(np.float64)
I = acc(p['indices']).astype(np.int64).reshape(-1, 3)
mt = J['materials'][p['material']]; im = J['images'][J['textures'][mt['pbrMetallicRoughness']['baseColorTexture']['index']]['source']]
bv = J['bufferViews'][im['bufferView']]; tex = Image.open(io.BytesIO(B[bv.get('byteOffset', 0):bv.get('byteOffset', 0) + bv['byteLength']])).convert('RGB')
skin = J['skins'][0]; joints = skin['joints']; parent = {c: i for i, n in enumerate(NODES) for c in n.get('children', [])}
name = {i: NODES[i].get('name', '') for i in range(len(NODES))}

def qm(q):
    x, y, z, w = q
    return np.array([[1 - 2 * (y * y + z * z), 2 * (x * y - z * w), 2 * (x * z + y * w)], [2 * (x * y + z * w), 1 - 2 * (x * x + z * z), 2 * (y * z - x * w)], [2 * (x * z - y * w), 2 * (y * z + x * w), 1 - 2 * (x * x + y * y)]])
def trs(n, ov=None):
    nd = NODES[n]; ov = (ov or {}).get(n, {})
    return np.array(ov.get('translation', nd.get('translation', [0, 0, 0])), float), np.array(ov.get('rotation', nd.get('rotation', [0, 0, 0, 1])), float), np.array(ov.get('scale', nd.get('scale', [1, 1, 1])), float)
def local(n, ov=None):
    t, r, s = trs(n, ov); M = np.eye(4); M[:3, :3] = qm(r) * s; M[:3, 3] = t; return M
def world(n, ov=None, c=None):
    c = {} if c is None else c
    if n in c: return c[n]
    M = local(n, ov); c[n] = (world(parent[n], ov, c) @ M) if n in parent else M; return c[n]

# ---- keep 23 bones: drop leaf chains (fingers, twist, share, toes, face) and merge their weights upward
KEEP = ['BoneRoot', 'Hip', 'Pelvis', 'L_Thigh', 'L_Calf', 'L_Foot', 'R_Thigh', 'R_Calf', 'R_Foot', 'Waist', 'Spine01', 'Spine02',
        'NeckTwist01', 'NeckTwist02', 'Head', 'L_Clavicle', 'L_Upperarm', 'L_Forearm', 'L_Hand', 'R_Clavicle', 'R_Upperarm', 'R_Forearm', 'R_Hand']
nid = {name[i]: i for i in range(len(NODES))}; keep_nodes = [nid[k] for k in KEEP]; kidx = {n: i for i, n in enumerate(keep_nodes)}
def kept_anc(n):
    while n not in kidx: n = parent[n]
    return kidx[n]
jmap = np.array([kept_anc(j) for j in joints])

# ---- 11 game groups (order of glbHero's skeleton): body torso head legL kneeL legR kneeR armL foreL armR foreR ; "L" = negative x
c0 = {}; rest_w = {n: world(n, None, c0) for n in keep_nodes}
negL = 'L' if rest_w[nid['L_Upperarm']][0, 3] < 0 else 'R'; posR = 'R' if negL == 'L' else 'L'
G = {'BoneRoot': 0, 'Hip': 0, 'Pelvis': 0, 'Waist': 0, 'Spine01': 1, 'Spine02': 1, 'NeckTwist01': 2, 'NeckTwist02': 2, 'Head': 2}
for side, (lg, kn, ar, fo) in ((negL, (3, 4, 7, 8)), (posR, (5, 6, 9, 10))):
    G[side + '_Thigh'] = lg; G[side + '_Calf'] = kn; G[side + '_Foot'] = kn; G[side + '_Clavicle'] = 1; G[side + '_Upperarm'] = ar; G[side + '_Forearm'] = fo; G[side + '_Hand'] = fo
gmap = np.array([G[k] for k in KEEP])

def top4(idx, w, nb):
    acc_ = np.zeros((len(idx), nb))
    for k in range(idx.shape[1]): np.add.at(acc_, (np.arange(len(idx)), idx[:, k]), w[:, k])
    o_ = np.argsort(-acc_, 1)[:, :4]; ww = np.take_along_axis(acc_, o_, 1); ww /= ww.sum(1, keepdims=True) + 1e-12
    return o_, ww
bi_hi, bw_hi = top4(jmap[JT], WT, len(KEEP))

# ---- decimate (weld, quadric) ; UV by chart of nearest hi triangle ; skin by nearest hi vertex
nv = len(P); e = np.concatenate([I[:, [0, 1]], I[:, [1, 2]]])
_, chart = connected_components(coo_matrix((np.ones(len(e)), (e[:, 0], e[:, 1])), shape=(nv, nv)), directed=False)
key = np.round(P / 1e-6).astype(np.int64); _, wid, inv = np.unique(key, axis=0, return_index=True, return_inverse=True); inv = inv.ravel()
WP = P[wid]; WF = inv[I]; WF = WF[(WF[:, 0] != WF[:, 1]) & (WF[:, 1] != WF[:, 2]) & (WF[:, 0] != WF[:, 2])]
with open(TMP + 'qi', 'wb') as f: f.write(struct.pack('<ii', len(WP), len(WF))); f.write(WP.astype(np.float32).tobytes()); f.write(WF.astype(np.int32).tobytes())
subprocess.run([QS, TMP + 'qi', TMP + 'qo', str(TARGET)], check=True, stdout=subprocess.DEVNULL)
q = open(TMP + 'qo', 'rb').read(); lnv, lnf = struct.unpack('<ii', q[:8])
LV = np.frombuffer(q, np.float32, lnv * 3, 8).reshape(-1, 3).astype(np.float64); LF = np.frombuffer(q, np.int32, lnf * 3, 8 + lnv * 12).reshape(-1, 3)
_, nt = cKDTree(P[I].mean(1)).query(LV[LF].mean(1)); lchart = chart[I[nt, 0]]
cUV = np.zeros((lnf, 3, 2)); order = np.argsort(chart); bnd = np.searchsorted(chart[order], np.arange(chart.max() + 2))
for c in np.unique(lchart):
    vid = order[bnd[c]:bnd[c + 1]]; sel = np.where(lchart == c)[0]; _, k = cKDTree(P[vid]).query(LV[LF[sel]].reshape(-1, 3)); cUV[sel] = UV[vid[k]].reshape(-1, 3, 2)
_, hv = cKDTree(P).query(LV)
# final vertices = unique (low vertex, uv) pairs
cv = LF.reshape(-1); cu = np.round(cUV.reshape(-1, 2) * 8192).astype(np.int64)
k2 = np.stack([cv, cu[:, 0], cu[:, 1]], 1); uk, fidx = np.unique(k2, axis=0, return_inverse=True); fidx = fidx.ravel()
FV = LV[uk[:, 0]]; FUV = uk[:, 1:] / 8192.0; FF = fidx.reshape(-1, 3); fb_i = bi_hi[hv[uk[:, 0]]]; fb_w = bw_hi[hv[uk[:, 0]]]
gi, gw = top4(gmap[fb_i], fb_w, 11)
print('low', len(FV), 'verts', len(FF), 'tris')

# ---- game units: uniform scale + lift
S = H_TARGET / (P[:, 1].max() - P[:, 1].min()); Y0 = -P[:, 1].min() * S + 0.01
_pel = world(nid['Pelvis'])[:3, 3] * S; OFS = np.array([-_pel[0], Y0, -_pel[2]])   # centre on the pelvis (turns in place), feet on the floor
FVg = FV * S + OFS
def bone_local(n, ov=None):
    t, r, s_ = trs(n, ov); t = t * S
    if NODES[n].get('name') == 'BoneRoot': t = t + OFS
    return t, r
bones = []
for n in keep_nodes:
    t, r = bone_local(n); pn = parent.get(n); bones.append([NODES[n]['name'], kidx[pn] if pn in kidx else -1] + [round(float(x), 5) for x in t] + [round(float(x), 6) for x in r])

# ---- arms-down bind pose for the game's procedural rig (battle): rotate each arm subtree about the shoulder (LBS with real weights)
DOWN = np.radians(68)
sub = {s_: set() for s_ in 'LR'}
for bi, n in enumerate(keep_nodes):
    m = n
    while m in parent:
        for s_ in 'LR':
            if name[m] == s_ + '_Upperarm': sub[s_].add(bi)
        m = parent[m]
    for s_ in 'LR':
        if name[n] == s_ + '_Upperarm': sub[s_].add(bi)
def Rz(a): c_, s2 = np.cos(a), np.sin(a); return np.array([[c_, -s2, 0], [s2, c_, 0], [0, 0, 1]])
Mb = np.tile(np.eye(4), (len(KEEP), 1, 1))
for s_ in 'LR':
    shp = rest_w[nid[s_ + '_Upperarm']][:3, 3] * S + OFS; ang = DOWN if shp[0] < 0 else -DOWN
    M = np.eye(4); M[:3, :3] = Rz(ang); M[:3, 3] = shp - Rz(ang) @ shp
    for bi in sub[s_]: Mb[bi] = M
Ph = np.c_[FVg, np.ones(len(FVg))]; FVd = np.zeros_like(FVg)
for k in range(4): FVd += fb_w[:, k:k + 1] * np.einsum('nij,nj->ni', Mb[fb_i[:, k]], Ph)[:, :3]
def posed(nm):
    v = np.append(rest_w[nid[nm]][:3, 3] * S + OFS, 1); bi = kidx[nid[nm]]; return (Mb[bi] @ v)[:3]
# ---- joints for the game's procedural rig (game units, from rest world positions)
def wpos(nm): return rest_w[nid[nm]][:3, 3] * S + OFS
def r3(v): return [round(float(x), 4) for x in v]
sh = {s_: posed(s_ + '_Upperarm') for s_ in 'LR'}; el = {s_: posed(s_ + '_Forearm') for s_ in 'LR'}; hd = {s_: posed(s_ + '_Hand') for s_ in 'LR'}
hip = wpos(negL + '_Thigh'); knee = wpos(negL + '_Calf')
hip2 = wpos(posR + '_Thigh'); knee2 = wpos(posR + '_Calf')
JJ = {'hip': r3([(abs(hip[0]) + abs(hip2[0])) / 2, hip[1], hip[2]]), 'knee': r3([(abs(knee[0]) + abs(knee2[0])) / 2, knee[1], knee[2]]), 'shL': r3(sh[negL]), 'elL': r3(el[negL]), 'hdL': r3(hd[negL]),
      'shR': r3(sh[posR]), 'elR': r3(el[posR]), 'hdR': r3(hd[posR]), 'nk': r3([0, wpos('NeckTwist02')[1], wpos('NeckTwist02')[2]]), 'tor': r3([0, wpos('Spine01')[1], wpos('Spine01')[2]])}

# ---- clips: resample at FPS, rotations of kept bones + Hip translation with horizontal drift removed
def sample(ai, t):
    a = J['animations'][ai]; ov = {}
    for chn in a['channels']:
        s_ = a['samplers'][chn['sampler']]; ti = acc(s_['input']).ravel(); vo = acc(s_['output']); t2 = min(t, ti[-1])
        k = int(np.clip(np.searchsorted(ti, t2), 1, len(ti) - 1)); f = (t2 - ti[k - 1]) / max(ti[k] - ti[k - 1], 1e-9)
        if s_.get('interpolation') == 'STEP': f = 0.0 if t2 < ti[k] else 1.0
        v = vo[k - 1] * (1 - f) + vo[k] * f
        if chn['target']['path'] == 'rotation': v = v / np.linalg.norm(v)
        ov.setdefault(chn['target']['node'], {})[chn['target']['path']] = v
    return ov
hipn = nid['Hip']; rootW = world(nid['BoneRoot']); rootWi = np.linalg.inv(rootW)
def m2q(R):
    t = np.trace(R)
    if t > 0: s_ = np.sqrt(t + 1) * 2; return np.array([(R[2, 1] - R[1, 2]) / s_, (R[0, 2] - R[2, 0]) / s_, (R[1, 0] - R[0, 1]) / s_, s_ / 4])
    i = int(np.argmax([R[0, 0], R[1, 1], R[2, 2]])); j_, k_ = (i + 1) % 3, (i + 2) % 3
    s_ = np.sqrt(1 + R[i, i] - R[j_, j_] - R[k_, k_]) * 2; q_ = np.zeros(4); q_[i] = s_ / 4; q_[j_] = (R[j_, i] + R[i, j_]) / s_; q_[k_] = (R[k_, i] + R[i, k_]) / s_; q_[3] = (R[k_, j_] - R[j_, k_]) / s_; return q_
# group clips: the clip retargeted onto the game's 11 joints (A body, arms bound 68deg down) -> works with the procedural battle rig
GB = ['Pelvis', 'Spine02', 'Head', negL + '_Thigh', negL + '_Calf', posR + '_Thigh', posR + '_Calf', negL + '_Upperarm', negL + '_Forearm', posR + '_Upperarm', posR + '_Forearm']
GBn = [nid[b] for b in GB]; c0g = {}; R0g = [world(n, None, c0g)[:3, :3] for n in GBn]; pel0 = world(nid['Pelvis'], None, c0g)[:3, 3] * S + OFS
RZ = {}
for s_ in (negL, posR):
    shp = rest_w[nid[s_ + '_Upperarm']][:3, 3]; RZ[s_] = Rz(DOWN if shp[0] < 0 else -DOWN)
def gpose(ov, drift):
    c = {}; D = [world(n, ov, c)[:3, :3] @ R0g[i].T for i, n in enumerate(GBn)]
    Gb, Gt, Gh = D[0], D[1], D[2]; Gl0, Gk0, Gl1, Gk1 = D[3], D[4], D[5], D[6]
    Ga0 = D[7] @ RZ[negL].T; Gf0 = D[8] @ RZ[negL].T; Ga1 = D[9] @ RZ[posR].T; Gf1 = D[10] @ RZ[posR].T
    loc = [Gb, Gb.T @ Gt, Gt.T @ Gh, Gb.T @ Gl0, Gl0.T @ Gk0, Gb.T @ Gl1, Gl1.T @ Gk1, Gt.T @ Ga0, Ga0.T @ Gf0, Gt.T @ Ga1, Ga1.T @ Gf1]
    pel = world(nid['Pelvis'], ov, c)[:3, 3] * S + OFS; pel[[0, 2]] -= drift * S
    return [m2q(R) for R in loc], pel - Gb @ pel0

# ---- keep hands out of the (big chibi) head: per frame swing the arm away about the shoulder, smoothed over time
from scipy.ndimage import maximum_filter1d, gaussian_filter1d
def qmul(a, b):
    x1, y1, z1, w1 = a; x2, y2, z2, w2 = b
    return np.array([w1*x2 + x1*w2 + y1*z2 - z1*y2, w1*y2 - x1*z2 + y1*w2 + z1*x2, w1*z2 + x1*y2 - y1*x2 + z1*w2, w1*w2 - x1*x2 - y1*y2 - z1*z2])
def qconj(q): return np.array([-q[0], -q[1], -q[2], q[3]])
def aqm(k, a):
    k = k / (np.linalg.norm(k) + 1e-12); K = np.array([[0, -k[2], k[1]], [k[2], 0, -k[0]], [-k[1], k[0], 0]])
    return np.eye(3) + np.sin(a) * K + (1 - np.cos(a)) * K @ K
def gwm(n, ov, c): M = world(n, ov, c).copy(); M[:3, 3] = M[:3, 3] * S + OFS; return M
W0i = {n: np.linalg.inv(gwm(n, None, {})) for n in keep_nodes}
topb = fb_i[np.arange(len(fb_i)), np.argmax(fb_w, 1)]; topw = fb_w.max(1)
headV = np.where((topb == kidx[nid['Head']]) & (topw > .5))[0]
VN = np.zeros_like(FVg); fnrm = np.cross(FVg[FF[:, 1]] - FVg[FF[:, 0]], FVg[FF[:, 2]] - FVg[FF[:, 0]])
for k in range(3): np.add.at(VN, FF[:, k], fnrm)
VN /= np.linalg.norm(VN, axis=1, keepdims=True) + 1e-12
hP = FVg[headV]; hN = VN[headV]; htree = cKDTree(hP); hc0 = hP.mean(0); H0 = gwm(nid['Head'], None, {})
from scipy.spatial import Delaunay
HULL = Delaunay(hc0 + (hP - hc0) * 0.86)   # slightly shrunk head hull: touching the hair is fine, going through is not
armV = {s_: np.where(np.isin(topb, [kidx[nid[s_ + '_Forearm']], kidx[nid[s_ + '_Hand']]]) & (topw > .5))[0] for s_ in 'LR'}
FACE_LOG = []
def face_fix(ovs, cname):
    n_ = len(ovs); ang = {s_: np.zeros(n_) for s_ in 'LR'}; axs = {s_: np.zeros((n_, 3)) for s_ in 'LR'}; raw = {s_: np.zeros(n_, int) for s_ in 'LR'}
    for fi, ov in enumerate(ovs):
        c = {}; mats = np.array([gwm(n, ov, c) @ W0i[n] for n in keep_nodes])
        Hw = gwm(nid['Head'], ov, c); toH = H0 @ np.linalg.inv(Hw); hc = (Hw @ np.linalg.inv(H0) @ np.append(hc0, 1))[:3]
        def pen(Xw):
            Xr = Xw @ toH[:3, :3].T + toH[:3, 3]; return int((HULL.find_simplex(Xr) >= 0).sum())
        for s_ in 'LR':
            ids = armV[s_]; Phs = np.c_[FVg[ids], np.ones(len(ids))]; X = np.zeros((len(ids), 3))
            for k in range(4): X += fb_w[ids, k:k + 1] * np.einsum('nij,nj->ni', mats[fb_i[ids, k]], Phs)[:, :3]
            p0 = pen(X); raw[s_][fi] = p0
            if p0 <= 3: continue
            Sh = gwm(nid[s_ + '_Upperarm'], ov, c)[:3, 3]; cen = X.mean(0); a_ = cen - Sh; d_ = (cen - hc) * np.array([1.0, 0.0, 0.4])   # push sideways (a little forward), keep the hand's height
            if abs(d_[0]) < 0.03: d_[0] = (1.0 if Sh[0] >= hc[0] else -1.0) * 0.05
            d_ = d_ - a_ * (d_ @ a_) / (a_ @ a_)
            if np.linalg.norm(d_) < 1e-6: d_ = np.array([1.0 if cen[0] >= hc[0] else -1.0, 0, 0])
            k_ = np.cross(a_, d_); k_ /= np.linalg.norm(k_) + 1e-12; th = 0
            for step in range(1, 21):
                th = np.radians(3 * step)
                if pen((X - Sh) @ aqm(k_, th).T + Sh) <= 3: break
            ang[s_][fi] = th; axs[s_][fi] = k_
    for s_ in 'LR':
        a0 = ang[s_]
        if a0.max() <= 0: continue
        nz = np.where(a0 > 0)[0]; A = axs[s_].copy()
        for fi in range(n_):
            if a0[fi] <= 0: A[fi] = axs[s_][nz[np.argmin(np.abs(nz - fi))]]
        A = gaussian_filter1d(A, 2, axis=0, mode='nearest'); A /= np.linalg.norm(A, axis=1, keepdims=True) + 1e-12
        a1 = gaussian_filter1d(maximum_filter1d(a0, 7, mode='nearest'), 1.5, mode='nearest')
        un = nid[s_ + '_Upperarm']; pn = parent[un]
        for fi, ov in enumerate(ovs):
            if a1[fi] < 1e-3: continue
            qp = m2q(world(pn, ov, {})[:3, :3]); qR = np.append(A[fi] * np.sin(a1[fi] / 2), np.cos(a1[fi] / 2)); ql = trs(un, ov)[1]
            q2 = qmul(qmul(qmul(qconj(qp), qR), qp), ql); ov.setdefault(un, {})['rotation'] = q2 / np.linalg.norm(q2)
        FACE_LOG.append((cname, s_, int((a0 > 0).sum()), round(float(np.degrees(a0.max())), 1)))
clips = {}
for ai, a in enumerate(J['animations']):
    dur = float(max(acc(s_['input']).max() for s_ in a['samplers'])); dur = min(dur, CLIPMAX.get(a['name'], dur)); nfr = int(round(dur * FPS)) + 1
    GQ = np.zeros((nfr, 11, 4)); GP = np.zeros((nfr, 3)); doG = a['name'] in GCL
    Q = np.zeros((nfr, len(KEEP), 4)); HT = np.zeros((nfr, 3)); x0z0 = None
    OVS = [sample(ai, min(dur, fi / FPS)) for fi in range(nfr)]
    if os.environ.get('NOFACE') != '1': face_fix(OVS, a['name'])
    for fi in range(nfr):
        ov = OVS[fi]
        for bi, n in enumerate(keep_nodes): Q[fi, bi] = trs(n, ov)[1]
        hw = world(hipn, ov)[:3, 3]
        if x0z0 is None: x0z0 = hw[[0, 2]].copy()
        hw2 = np.array([x0z0[0], hw[1], x0z0[1], 1.0]); HT[fi] = (rootWi @ hw2)[:3] * S
        if doG: q_, p_ = gpose(ov, hw[[0, 2]] - x0z0); GQ[fi] = q_; GP[fi] = p_
    for bi in range(len(KEEP)):  # keep quaternion signs continuous
        for fi in range(1, nfr):
            if Q[fi, bi] @ Q[fi - 1, bi] < 0: Q[fi, bi] *= -1
    qd = np.round(Q * 32767).astype(np.int16).tobytes(); hd_ = HT.astype(np.float32).tobytes()
    clips[a['name']] = {'dur': round(dur, 4), 'n': nfr, 'fps': FPS, 'q': base64.b64encode(qd).decode(), 'h': base64.b64encode(hd_).decode()}
    if doG:
        for bi in range(11):
            for fi in range(1, nfr):
                if GQ[fi, bi] @ GQ[fi - 1, bi] < 0: GQ[fi, bi] *= -1
        clips[a['name']]['gq'] = base64.b64encode(np.round(GQ * 32767).astype(np.int16).tobytes()).decode(); clips[a['name']]['gp'] = base64.b64encode(GP.astype(np.float32).tobytes()).decode()
    print('clip', a['name'], nfr, 'frames')

# ---- pack mesh: pos u16 quantised in [mn,mx], uv u16, index u16, group skin u8x4+u8x4, bone skin u8x4+u8x4
mn = np.minimum(FVg.min(0), FVd.min(0)); mx = np.maximum(FVg.max(0), FVd.max(0)); qp = np.round((FVg - mn) / (mx - mn) * 65535).astype(np.uint16); qd2 = np.round((FVd - mn) / (mx - mn) * 65535).astype(np.uint16)
quv = np.round(np.clip(FUV, 0, 1) * 65535).astype(np.uint16)
def w8(w):
    o_ = np.floor(w * 255).astype(int); r = 255 - o_.sum(1); o_[np.arange(len(o_)), np.argmax(w, 1)] += r; return o_.astype(np.uint8)
blob = qp.tobytes() + qd2.tobytes() + quv.tobytes() + FF.astype(np.uint16).tobytes() + gi.astype(np.uint8).tobytes() + w8(gw).tobytes() + fb_i.astype(np.uint8).tobytes() + w8(fb_w).tobytes()
t2 = tex.resize((1024, 1024), Image.LANCZOS); tb = io.BytesIO(); t2.save(tb, 'WEBP', quality=82, method=6)
out = {'ux': 1, 'nv': len(FV), 'nf': len(FF), 'mn': r3(mn), 'mx': r3(mx), 'j': JJ, 'k': 1.3, 'bones': bones, 'clips': clips, 'nowp': 1, 'am': .8,
       'd': base64.b64encode(blob).decode(), 'tex': 'data:image/webp;base64,' + base64.b64encode(tb.getvalue()).decode()}
json.dump(out, open(OUTF, 'w'), separators=(',', ':'))
print('face fixes', FACE_LOG); print('json KB', os.path.getsize(OUTF) // 1024, 'tex KB', len(tb.getvalue()) // 1024, 'mesh KB', len(blob) // 1024, 'negL', negL, 'S', round(S, 4))
print(json.dumps(JJ))
