# before/after renders of clips on the real bones (body B). usage: cmp_clip.py before.json after.json out.png clip:frac,clip:frac,...
import json, base64, io, sys, numpy as np, importlib.util
from PIL import Image, ImageDraw
spec = importlib.util.spec_from_file_location('r', '/home/claude/mx/render_core.py'); R = importlib.util.module_from_spec(spec); spec.loader.exec_module(R)
def load(fn):
    D = json.load(open(fn)); nv, nf = D['nv'], D['nf']; b = base64.b64decode(D['d']); o = [0]
    def take(dt, n):
        a = np.frombuffer(b, dt, n, o[0]); o[0] += a.nbytes; return a
    mn, mx = np.array(D['mn']), np.array(D['mx'])
    P1 = mn + take(np.uint16, nv * 3).reshape(-1, 3) / 65535 * (mx - mn); take(np.uint16, nv * 3)
    UV = take(np.uint16, nv * 2).reshape(-1, 2) / 65535; F = take(np.uint16, nf * 3).reshape(-1, 3).astype(int)
    take(np.uint8, nv * 8); bi = take(np.uint8, nv * 4).reshape(-1, 4).astype(int); bw = take(np.uint8, nv * 4).reshape(-1, 4) / 255
    tex = np.array(Image.open(io.BytesIO(base64.b64decode(D['tex'].split(',')[1]))).convert('RGB'))
    return D, P1, UV, F, bi, bw, tex
def qm(q):
    x, y, z, w = q / np.linalg.norm(q); return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])
def pose(D, P1, bi, bw, cn, frac):
    bones = D['bones']; c = D['clips'][cn]; n = c['n']; Q = np.frombuffer(base64.b64decode(c['q']), np.int16).reshape(n, len(bones), 4) / 32767; HT = np.frombuffer(base64.b64decode(c['h']), np.float32).reshape(n, 3)
    f = int(round(frac * (n - 1)))
    def W(Qf, Hf):
        out = []
        for i, bb in enumerate(bones):
            t = np.array(bb[2:5]); q = np.array(bb[5:9]) if Qf is None else Qf[i]
            if Hf is not None and bb[0] == 'Hip': t = Hf
            M = np.eye(4); M[:3, :3] = qm(q); M[:3, 3] = t; out.append((out[bb[1]] if bb[1] >= 0 else np.eye(4)) @ M)
        return np.array(out)
    M = np.einsum('bij,bjk->bik', W(Q[f], HT[f]), np.linalg.inv(W(None, None))); Ph = np.c_[P1, np.ones(len(P1))]; X = np.zeros((len(P1), 3))
    for k in range(4): X += bw[:, k:k+1] * np.einsum('nij,nj->ni', M[bi[:, k]], Ph)[:, :3]
    return X
A = load(sys.argv[1]); B = load(sys.argv[2]); items = [x.split(':') for x in sys.argv[4].split(',')]
rows = []
for L in (A, B):
    D, P1, UV, F, bi, bw, tex = L; ims = []
    for cn, fr in items:
        X = pose(D, P1, bi, bw, cn, float(fr)); yaw = float(sys.argv[5]) if len(sys.argv) > 5 else 0.0
        im = Image.fromarray(R.rast((X - [0, 0, 0]) * (180 / 2.6), F, UV, F, tex, yaw, 240)); ImageDraw.Draw(im).text((4, 4), cn + ' ' + fr, fill=(0, 0, 0)); ims.append(np.array(im))
    rows.append(np.concatenate(ims, 1))
Image.fromarray(np.concatenate(rows, 0)).save(sys.argv[3]); print('ok')
