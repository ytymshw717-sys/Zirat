# v69: "last one standing" (mode 'show') = free-for-all of 10 heroes (you + 9 smart hero bots), power cubes, ranking.
# Run on the v68 stage (ux/stage_v68.html) AFTER enm/team.js has the v69 brain (sync_blocks copies it in).
ST = '/home/claude/arena3_stage.html'
s = open(ST, encoding='utf-8').read()
def rep(a, b):
    global s
    assert s.count(a) == 1, (s.count(a), a[:90]); s = s.replace(a, b)

# 1) setup: 9 rival heroes around the ring, each on its own side
rep("if(mode==='show'){gas={x:W/2,y:H/2,r:Math.hypot(W,H)/2+10};gT=3;var ty=['grunt','fast','archer','tank','grunt','archer','fast'];for(var si=0;si<7;si++){var an=si/7*6.283;spawnMinion(W/2+Math.cos(an)*150,H/2+Math.sin(an)*150,ty[si]);}}",
    "if(mode==='show'){gas={x:W/2,y:H/2,r:Math.hypot(W,H)/2+10};gT=4;tTime=0;showInit();}")
rep("function showTick(dt){",
r"""/* v69: free-for-all - you against 9 hero bots that also fight each other; cubes make you stronger; the gas closes in */
var SHOWN=9;
function showInit(){var ex=ps.map(function(p){return p.ch.idx;}),hs=tPick(SHOWN,ex),R=Math.min(W,H)*.42,a0=Math.random()*6.283,n=SHOWN+ps.length;
 ps.forEach(function(p,i){var a=a0+i/n*6.283;p.x=W/2+Math.cos(a)*R;p.y=H/2+Math.sin(a)*R;});
 hs.forEach(function(h,i){var e=mkRival(h,0),a=a0+(ps.length+i)/n*6.283;e.x=Math.max(30,Math.min(W-30,W/2+Math.cos(a)*R));e.y=Math.max(30,Math.min(H-30,H/2+Math.sin(a)*R));e.ffa=1;e.tm=2+i;e.cubes=0;e.inv=1.2;e.cd=1+Math.random();e.spcd=6+Math.random()*6;enemies.push(e);});
 bannerText='☠️ האחרון שנשאר · 10 גיבורים, רק אחד שורד!';banner=2.4;}
function showRank(){return 1+enemies.filter(function(e){return e.t==='hero'&&e.hp>0;}).length;}
function showTick(dt){tTime+=dt;""")
rep(""" enemies.forEach(function(e){if(e.hp>0&&Math.hypot(e.x-g.x,e.y-g.y)>g.r){e.hp-=dt*1.4;if(e.hp<=0){burst(e.x,e.y,T[e.t].col,10);score+=T[e.t].pts;scEl.textContent=score;}}});""",
""" enemies.forEach(function(e){if(e.hp>0&&Math.hypot(e.x-g.x,e.y-g.y)>g.r){if(e.t==='hero'){e.hp-=dt*(e.maxhp||10)*.09;if(e.hp<=0){e.hp=0;burst(e.x,e.y,e.ch.col,12);ffaDrop(e);float(e.x,e.y-30,'☠️ '+(e.ch.nk||''),'#a3e635');}}else{e.hp-=dt*1.4;if(e.hp<=0){burst(e.x,e.y,T[e.t].col,10);score+=T[e.t].pts;scEl.textContent=score;}}}});
 enemies.forEach(function(e){if(e.t!=='hero'||e.hp<=0)return;drops.forEach(function(d){if(d.k==='cube'&&!d.got&&Math.hypot(d.x-e.x,d.y-e.y)<e.r+12){d.got=1;e.cubes=(e.cubes||0)+1;e.maxhp=(e.maxhp||10)*1.1;e.mhp=e.maxhp;e.hp=Math.min(e.maxhp,e.hp+e.maxhp*.12);float(e.x,e.y-34,'💎','#d8b4fe');}});});""")
rep(" gT-=dt;if(gT<=0){gT=7;var a=Math.random()*6.283,r=Math.random()*(g.r-30);", " gT-=dt;if(gT<=0){gT=9;var a=Math.random()*6.283,r=Math.random()*(g.r-30);")

# 2) bot projectiles also hit the other bots
rep("""   if(s.life>0&&s.o&&s.o.ch&&!s.pierce)for(var k=0;k<obs.length;k++){""",
"""   if(s.life>0&&s.o&&s.o.ffa){for(var fi=0;fi<enemies.length;fi++){var fe=enemies[fi];if(fe===s.o||fe.t!=='hero'||fe.hp<=0)continue;if(segD(ox,oy,s.x,s.y,fe.x,fe.y)<fe.r+rr){if(s.pierce){s.hit=s.hit||[];if(s.hit.indexOf(fe)>=0)continue;s.hit.push(fe);ffaHurt(fe,s.dmg,s.x-s.vx,s.y-s.vy,s.o);continue;}if(s.boom)eBoom(s);else ffaHurt(fe,s.dmg,s.x-s.vx,s.y-s.vy,s.o);s.life=0;break;}}}
   if(s.life>0&&s.o&&s.o.ch&&!s.pierce)for(var k=0;k<obs.length;k++){""")

# 3) a hero you knock out drops its cubes
rep("function dropLoot(e){", "function dropLoot(e){if(mode==='show'&&e.t==='hero'){ffaDrop(e);return;}")

# 4) lose screen tells your place
rep("""<small>גל "+wave+" · ניקוד "+score+"</small>""",
    """<small>"+(mode==='show'?"🏅 מקום "+showRank()+" מתוך "+(SHOWN+1):"גל "+wave+" · ניקוד "+score)+"</small>""")

s = s.replace("var NETVER='68'", "var NETVER='69'")
open(ST, 'w', encoding='utf-8').write(s)
print('patched v69 stage')
