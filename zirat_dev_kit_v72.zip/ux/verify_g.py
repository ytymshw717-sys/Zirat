# compare: clip on the real 23 bones (body B) vs the same clip retargeted to the 11 game joints (body A). usage: verify_g.py hero.json out.png clip1,clip2
import json, base64, io, sys, numpy as np, importlib.util
from PIL import Image, ImageDraw
spec = importlib.util.spec_from_file_location('r', '/home/claude/mx/render_core.py'); R = importlib.util.module_from_spec(spec); spec.loader.exec_module(R)
D = json.load(open(sys.argv[1])); nv, nf = D['nv'], D['nf']; b = base64.b64decode(D['d']); o = 0
def take(dt, n):
    global o; a = np.frombuffer(b, dt, n, o); o += a.nbytes; return a
mn, mx = np.array(D['mn']), np.array(D['mx'])
P1 = mn + take(np.uint16, nv * 3).reshape(-1, 3) / 65535 * (mx - mn); P2 = mn + take(np.uint16, nv * 3).reshape(-1, 3) / 65535 * (mx - mn)
UV = take(np.uint16, nv * 2).reshape(-1, 2) / 65535; F = take(np.uint16, nf * 3).reshape(-1, 3).astype(int)
gi = take(np.uint8, nv * 4).reshape(-1, 4).astype(int); gw = take(np.uint8, nv * 4).reshape(-1, 4) / 255; bi = take(np.uint8, nv * 4).reshape(-1, 4).astype(int); bw = take(np.uint8, nv * 4).reshape(-1, 4) / 255
tex = np.array(Image.open(io.BytesIO(base64.b64decode(D['tex'].split(',')[1]))).convert('RGB')); bones = D['bones']; Jj = D['j']
def qm(q):
    x, y, z, w = q / np.linalg.norm(q); return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])
def M4(R_, t): M = np.eye(4); M[:3, :3] = R_; M[:3, 3] = t; return M
# --- B: real bones
def bworlds(Q=None, HT=None):
    W = []
    for i, bb in enumerate(bones):
        t = np.array(bb[2:5]); q = np.array(bb[5:9]) if Q is None else Q[i]
        if HT is not None and bb[0] == 'Hip': t = HT
        W.append((W[bb[1]] if bb[1] >= 0 else np.eye(4)) @ M4(qm(q), t))
    return np.array(W)
B0i = np.linalg.inv(bworlds())
def lbs(P, idx, w, M):
    Ph = np.c_[P, np.ones(len(P))]; out = np.zeros((len(P), 3))
    for k in range(4): out += w[:, k:k+1] * np.einsum('nij,nj->ni', M[idx[:, k]], Ph)[:, :3]
    return out
# --- A: the 11 game joints, same hierarchy/pivots as glbHero
tor = np.array([0, Jj['tor'][1], Jj['tor'][2]]); hip = Jj['hip']; kn = Jj['knee']
def gworlds(Lq=None, bp=None):
    I3 = np.eye(3); L = [qm(q) for q in Lq] if Lq is not None else [I3] * 11; bp = np.zeros(3) if bp is None else bp
    body = M4(L[0], bp); torso = body @ M4(L[1], tor); head = torso @ M4(L[2], np.array([0, Jj['nk'][1], Jj['nk'][2]]) - tor)
    W = [body, torso, head]
    for i, s in ((0, -1), (1, 1)):
        leg = body @ M4(L[3 + 2 * i], np.array([s * hip[0], hip[1], hip[2]])); knee = leg @ M4(L[4 + 2 * i], np.array([0, kn[1] - hip[1], kn[2] - hip[2]])); W += [leg, knee]
    for i, (S_, E_) in enumerate(((Jj['shL'], Jj['elL']), (Jj['shR'], Jj['elR']))):
        arm = torso @ M4(L[7 + 2 * i], np.array(S_) - tor); fore = arm @ M4(L[8 + 2 * i], np.array(E_) - np.array(S_)); W += [arm, fore]
    return np.array(W)
G0i = np.linalg.inv(gworlds())
def rr(V, S=260): return R.rast(V * (180 / 2.6), F, UV, F, tex, 0.35, S)
rows = []
for cn in sys.argv[3].split(','):
    c = D['clips'][cn]; n = c['n']; Q = np.frombuffer(base64.b64decode(c['q']), np.int16).reshape(n, len(bones), 4) / 32767; HT = np.frombuffer(base64.b64decode(c['h']), np.float32).reshape(n, 3)
    GQ = np.frombuffer(base64.b64decode(c['gq']), np.int16).reshape(n, 11, 4) / 32767; GP = np.frombuffer(base64.b64decode(c['gp']), np.float32).reshape(n, 3)
    fr = np.linspace(0, n - 1, 4).astype(int); top = []; bot = []
    for f in fr:
        top.append(rr(lbs(P1, bi, bw, np.einsum('bij,bjk->bik', bworlds(Q[f], HT[f]), B0i))))
        bot.append(rr(lbs(P2, gi, gw, np.einsum('bij,bjk->bik', gworlds(GQ[f], GP[f]), G0i))))
    im = Image.fromarray(np.concatenate([np.concatenate(top, 1), np.concatenate(bot, 1)], 0)); ImageDraw.Draw(im).text((4, 4), cn + ': top = real bones, bottom = 11 game joints', fill=(0, 0, 0)); rows.append(np.array(im))
Image.fromarray(np.concatenate(rows, 0)).save(sys.argv[2]); print('ok')
