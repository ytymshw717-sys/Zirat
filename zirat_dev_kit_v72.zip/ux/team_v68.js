/* ===== 3 נגד 3: you (+ local friends) and hero bots vs 3 hero bots. Knock-outs score; everyone respawns after 3s and heals when out of combat; first to 10 or the most after 2:30 wins ===== */
var tbots=[],tko=[0,0],tTime=0,tSlots=[],TEAMKO=10,TEAMT=150,tSudden=false;
T.hero={r:14,hp:10,sp:150,col:'#ef4444',dmg:10,wind:.3,reach:30,pts:40};
function tPos(tm,i){var n=Math.max(0,Math.min(2,i));return {x:W/2+(n-1)*86,y:tm?78:H-78};}
function tPick(n,ex){var pool=[];for(var i=0;i<CH.length;i++)if(ex.indexOf(i)<0)pool.push(i);for(var k=pool.length-1;k>0;k--){var j=Math.floor(Math.random()*(k+1)),t=pool[k];pool[k]=pool[j];pool[j]=t;}return pool.slice(0,n);}
function tCh(h){var c=skinnedK(h,Math.random()<.3?1+Math.floor(Math.random()*3):0);c.idx=h;return c;}
function mkAlly(h,i){var ch=tCh(h),q=tPos(0,i);return {i:9+i,bot:1,tm:0,ch:ch,x:q.x,y:q.y,r:14,hp:ch.hp,mhp:ch.hp,lm:1,sup:0,uh:false,gh:false,gads:0,cubes:0,fx:0,fy:-1,dir:1,inv:1.5,cd:.6,atk:0,kx:0,ky:0,walk:0,spcd:0,spin:0,sph:false,bS:0,bD:0,sh:0,flash:0,rt:0,sf:1,sfT:0,lh:-9,la:-9,slot:i};}
function mkRival(h,i){var ch=tCh(h),q=tPos(1,i),m=DF[dfi]?DF[dfi][1]:1,hp=Math.max(6,Math.round(ch.hp/10*m));return {t:'hero',ch:ch,tm:1,bot:1,x:q.x,y:q.y,r:14,hp:hp,maxhp:hp,mhp:hp,state:'chase',wind:0,cd:1,stun:0,kx:0,ky:0,flash:0,dir:1,walk:0,speed:ch.sp*.82,fx:0,fy:1,atk:0,inv:1.5,sup:0,spcd:7+Math.random()*5,sf:1,sfT:0,lh:-9,mw:0,slot:i};}
function teamInit(){tko=[0,0];tTime=0;TEAMKO=10;tSudden=false;tbots=[];
 if(typeof NG!=='undefined'&&NG.vs&&NG.vsB){var nA=ps.length,B=NG.vsB,nB=B.length,xv=ps.map(function(p){return p.ch.idx;}).concat(B.map(function(b){return b.h;})),a2=tPick(Math.max(0,nB-nA),xv);xv=xv.concat(a2);var r2=tPick(Math.max(0,nA-nB),xv);
  ps.forEach(function(p,i){var q=tPos(0,i);p.x=q.x;p.y=q.y;p.fx=0;p.fy=-1;p.lh=-9;p.la=-9;p.rt=0;});a2.forEach(function(h,i){tbots.push(mkAlly(h,nA+i));});
  tSlots=B.map(function(b){return {h:b.h,k:b.k,net:b.peer,nm:b.nm,lm:b.lm,e:null,rt:.05};}).concat(r2.map(function(h,i){return {h:h,e:null,rt:.8+i*.25};}));
  TEAMKO=5;bannerText='⚔️ קרב אונליין · '+TEAMKO+' הפלות מנצחות!';banner=2.4;return;}
var nP=Math.min(3,ps.length||np),ex=ps.length?ps.map(function(p){return p.ch.idx;}):sel.slice(0,np),al=tPick(Math.max(0,3-nP),ex);ex=ex.concat(al);var rv=tPick(3,ex);
 ps.forEach(function(p,i){var q=tPos(0,i);p.x=q.x;p.y=q.y;p.fx=0;p.fy=-1;p.lh=-9;p.la=-9;p.rt=0;});
 al.forEach(function(h,i){tbots.push(mkAlly(h,nP+i));});
 tSlots=rv.map(function(h,i){return {h:h,e:null,rt:.8+i*.25};});
 bannerText='👥 3 נגד 3 · '+TEAMKO+' הפלות מנצחות!';banner=2.2;}
function tFoes(tm){if(tm===1){var o=ps.filter(function(p){return p.hp>0;});tbots.forEach(function(b){if(b.hp>0)o.push(b);});return o;}return enemies.filter(function(e){return e.hp>0&&e.t==='hero';});}
function tVisible(tg,from){return !(tg.inBush&&!(tg.rev>0)&&Math.hypot(tg.x-from.x,tg.y-from.y)>75);}
/* steering: keep the right distance for the weapon, strafe to dodge, slide around rocks, back off when low */
function tSteer(b,tg,td,dt,sp,noKb){var ranged=!!b.ch.kind,pref=ranged?Math.max(70,b.ch.rng*.72):0,vx=0,vy=0;
 b.sfT-=dt;if(b.sfT<=0){b.sfT=.9+Math.random()*1.2;b.sf=Math.random()<.5?-1:1;}
 var low=b.hp/(b.mhp||b.maxhp||1)<.3;
 if(tg){var dx=(tg.x-b.x)/(td||1),dy=(tg.y-b.y)/(td||1);
  if(low&&td<190){var by=b.tm?60:H-60;vx=-dx*.7;vy=(by-b.y>0?1:-1)*.7;}
  else if(td>pref+18){vx=dx;vy=dy;}else if(ranged&&td<pref-28){vx=-dx*.8;vy=-dy*.8;}
  var st=ranged?.75:.35;vx+=-dy*b.sf*st;vy+=dx*b.sf*st;}
 else{var cy=H/2+(b.tm?-60:60);vx=(W/2-b.x)/120;vy=(cy-b.y)/120;}
 var l=Math.hypot(vx,vy);if(l<.05)return false;vx/=l;vy/=l;
 for(var k=0;k<obs.length;k++){var o=obs[k];if(o.k==='void')continue;var ox=o.x-b.x,oy=o.y-b.y,ahead=ox*vx+oy*vy;if(ahead>0&&ahead<o.r+30){var side=Math.abs(ox*vy-oy*vx);if(side<o.r+b.r){var s=(ox*vy-oy*vx)>0?1:-1;var nx=vx*Math.cos(1.2*s)-vy*Math.sin(1.2*s),ny=vx*Math.sin(1.2*s)+vy*Math.cos(1.2*s);vx=nx;vy=ny;break;}}}
 if(noKb){b.x+=vx*sp*dt;b.y+=vy*sp*dt;}else{b.x+=vx*sp*dt+b.kx*dt;b.y+=vy*sp*dt+b.ky*dt;var fr=Math.max(0,1-9*dt);b.kx*=fr;b.ky*=fr;}
 b.x=Math.max(b.r,Math.min(W-b.r,b.x));b.y=Math.max(b.r,Math.min(H-b.r,b.y));pushOut(b);b.walk+=dt*14;
 if(!(b.atk>0)&&!(tg&&td<(b.ch.rng||60)+40)){b.fx=vx;b.fy=vy;}if(Math.abs(b.fx)>.05)b.dir=b.fx<0?-1:1;return true;}
function tRegen(o,dt,hpKey){var mx=o.mhp||o.maxhp;if(o.hp>0&&o.hp<mx&&tTime-(o.lh||-9)>3&&tTime-(o.la||-9)>2.5)o.hp=Math.min(mx,o.hp+mx*.13*dt);}
/* hero bot on the player's side: uses the same attack code as the player */
function allyTick(b,dt){
 if(b.hp<=0){b.rt-=dt;if(b.rt<=0){var q=tPos(0,b.slot);b.x=q.x;b.y=q.y;b.hp=b.mhp;b.inv=2;b.kx=b.ky=0;float(b.x,b.y-30,'חזר לקרב!','#93c5fd');}return;}
 ['inv','cd','atk','spcd','spin','bS','bD','sh','flash'].forEach(function(k){if(b[k]>0)b[k]-=dt;});
 var fo=tFoes(0),tg=null,td=1e9;fo.forEach(function(e){if(e.hid)return;var d=Math.hypot(e.x-b.x,e.y-b.y);if(d<td){td=d;tg=e;}});
 tSteer(b,tg,td,dt,b.ch.sp*.85);
 var reach=b.ch.kind?b.ch.rng+12:b.ch.rng+(tg?tg.r:14)+4;
 if(tg&&td<=reach&&b.cd<=0){var s0=snd;snd=false;try{doAttack(b);}finally{snd=s0;}b.la=tTime;b.cd*=1.15+Math.random()*.2;}
 if((b.sup||0)>=100&&tg&&td<150){b.sup=0;fxe({k:'sup',x:b.x,y:b.y,su:'nova',h:b.ch.idx,fx:b.fx,fy:b.fy});var s1=snd;snd=false;try{nova(b,115,3,.5);}finally{snd=s1;}}
 tRegen(b,dt);}
function botHurt(b,dmg,fx,fy){if(b.hp<=0||b.inv>0||b.sh>0||state!=='play')return;b.hp=Math.max(0,b.hp-dmg);b.flash=.14;b.lh=tTime;var dx=b.x-fx,dy=b.y-fy,d=Math.hypot(dx,dy)||1;b.kx=dx/d*200;b.ky=dy/d*200;
 if(b.hp<=0){burst(b.x,b.y,b.ch.col,12);b.rt=3;tko[1]++;float(b.x,b.y-30,'💀 '+b.ch.nk,'#f87171');}}
/* hero bot on the other team (lives in the enemies list, so every attack, special and super of the player hits it) */
function heroBot(e,dt){if(e.net){ngRival(e,dt);return;}
 if(e.cd>0)e.cd-=dt;if(e.atk>0)e.atk-=dt;if(e.inv>0)e.inv-=dt;if(e.spcd>0)e.spcd-=dt;if(e.flash>0)e.lh=tTime;
 if(e.stun>0){e.stun-=dt;return;}
 var fo=tFoes(1),tg=null,td=1e9;fo.forEach(function(p){if(!tVisible(p,e))return;var d=Math.hypot(p.x-e.x,p.y-e.y);if(d<td){td=d;tg=p;}});
 var ranged=!!e.ch.kind;
 if(e.mw>0){e.mw-=dt;if(e.mw<=0)tMelee(e);}else tSteer(e,tg,td,dt,e.speed,true);
 if(tg&&e.cd<=0){var dx=tg.x-e.x,dy=tg.y-e.y,d=td||1;
  if(ranged&&td<=e.ch.rng+10){e.fx=dx/d;e.fy=dy/d;tFire(e,tg);e.cd=e.ch.cd*1.7+Math.random()*.25;e.atk=.18;}
  else if(!ranged&&td<=e.ch.rng+tg.r+6){e.fx=dx/d;e.fy=dy/d;e.mw=.2;e.cd=e.ch.cd*1.6+.15;}}
 if(e.spcd<=0&&tg&&td<170){e.spcd=11+Math.random()*6;tSuper(e);}
 tRegen(e,dt);}
function tDmg(e){var m=e.net?1:(DF[dfi]?DF[dfi][2]:1);return Math.max(3,Math.round(e.ch.dmg*(e.ch.kind&&!MELK[e.ch.kind]?8:11)*(.7+.3*m)));}
function tHit(o,dmg,sx,sy){if(o.bot)botHurt(o,dmg,sx,sy);else hurt(o,dmg,sx,sy);}
function tMelee(e){var R=e.ch.rng+6,dm=tDmg(e);e.atk=.18;fxe({k:'melee',x:e.x,y:e.y,fx:e.fx,fy:e.fy,r:e.ch.rng,h:e.ch.idx});
 tFoes(1).forEach(function(p){var dx=p.x-e.x,dy=p.y-e.y,d=Math.hypot(dx,dy)||1;if(d<=R+p.r&&(d<p.r+e.r+6||(dx*e.fx+dy*e.fy)/d>.25)){tHit(p,dm,e.x,e.y);fxe({k:'mhit',x:p.x,y:p.y,h:e.ch.idx});}});}
function tFire(e,tg){var ch=e.ch,k=ch.kind,dm=tDmg(e),lead=DF[dfi]&&dfi>=2?.18:0,ax=tg.x+(tg.vx||0)*lead,ay=tg.y+(tg.vy||0)*lead,a=Math.atan2(ay-e.y,ax-e.x)+(Math.random()-.5)*.14,dd=Math.hypot(tg.x-e.x,tg.y-e.y);
 if(k==='spread')dm=Math.max(2,Math.round(dm/(ch.pel||3)*1.6));else if(k==='twin')dm=Math.max(2,Math.round(dm*.6));else if(k==='burst')dm=Math.max(2,Math.round(dm*.45));
 var n0=eshots.length;heroShoot(e,a,dm,dd,'e');for(var i=n0;i<eshots.length;i++)if(eshots[i].boom)eshots[i].r=7;}
function tSuper(e){fxe({k:'sup',x:e.x,y:e.y,su:'nova',h:e.ch.idx,fx:e.fx,fy:e.fy});var dm=Math.round(tDmg(e)*1.6);
 if(e.ch.kind){for(var q=0;q<10;q++){var an=q/10*6.283;eshots.push({x:e.x,y:e.y,vx:Math.cos(an)*320,vy:Math.sin(an)*320,life:.85,dmg:dm,o:e,r:5,big:1});}}
 else tFoes(1).forEach(function(p){if(Math.hypot(p.x-e.x,p.y-e.y)<=115+p.r)tHit(p,dm+6,e.x,e.y);});}
function eBoom(s){if(s.bd)return;s.bd=1;if(s.pool&&acid.length<8)acid.push({x:s.x,y:s.y,r:s.boom,t:2,tk:.2,d:Math.max(1,Math.round((s.dmg||3)*.3)),o:s.o,side:'e'});fxe({k:'boom',x:s.x,y:s.y,r:s.boom,h:s.o&&s.o.ch?s.o.ch.idx:-1});shake=Math.max(shake,.1);
 ps.forEach(function(p){if(p.hp>0&&Math.hypot(p.x-s.x,p.y-s.y)<=s.boom+p.r)hurt(p,s.dmg,s.x,s.y);});tbots.forEach(function(b){if(b.hp>0&&Math.hypot(b.x-s.x,b.y-s.y)<=s.boom+b.r)botHurt(b,s.dmg,s.x,s.y);});}
/* player knocked out in team mode: back in 3 seconds instead of game over */
function teamDown(p){p.rt=3;tko[1]++;bannerText='💀 הופלת! חוזר בעוד 3…';banner=1.6;}
function teamTick(dt){tTime+=dt;
 ps.forEach(function(p,i){if(p.hp<=0&&p.rt>0){p.rt-=dt;if(p.rt<=0){var q=tPos(0,i);p.x=q.x;p.y=q.y;p.hp=p.mhp;p.inv=2;p.kx=p.ky=0;float(p.x,p.y-30,'חזרת לקרב!','#86efac');}}if(p.hp>0)tRegen(p,dt);p.vx=(p.x-(p.ox==null?p.x:p.ox))/Math.max(dt,.001);p.vy=(p.y-(p.oy==null?p.y:p.oy))/Math.max(dt,.001);p.ox=p.x;p.oy=p.y;});
 tbots.forEach(function(b){allyTick(b,dt);b.vx=(b.x-(b.ox==null?b.x:b.ox))/Math.max(dt,.001);b.vy=(b.y-(b.oy==null?b.y:b.oy))/Math.max(dt,.001);b.ox=b.x;b.oy=b.y;});
 // keep allies from stacking on the player
 var tm=ps.filter(function(p){return p.hp>0;}).concat(tbots.filter(function(b){return b.hp>0;}));for(var a=0;a<tm.length;a++)for(var c=a+1;c<tm.length;c++){var A=tm[a],B=tm[c],ex=B.x-A.x,ey=B.y-A.y,ed=Math.hypot(ex,ey),mn=A.r+B.r;if(ed<mn&&ed>.001){var pu=(mn-ed)/2;ex/=ed;ey/=ed;if(A.bot){A.x-=ex*pu;A.y-=ey*pu;}if(B.bot){B.x+=ex*pu;B.y+=ey*pu;}}}
 tSlots.forEach(function(s,i){if(s.e&&(s.e.hp<=0||enemies.indexOf(s.e)<0)){s.e=null;s.rt=3;tko[0]++;beep(780,.18,'triangle',.06,1200);}
  if(!s.e){s.rt-=dt;if(s.rt<=0){s.e=mkRival(s.h,i);if(s.net)ngRivalMake(s.e,s);enemies.push(s.e);}}});
 var lim=TEAMKO;if(tko[0]>=lim&&tko[0]>tko[1]){victory();return;}if(tko[1]>=lim&&tko[1]>tko[0]){gameOver();return;}
 if(tTime>=TEAMT){if(tko[0]>tko[1])victory();else if(tko[1]>tko[0])gameOver();else if(!tSudden){tSudden=true;TEAMKO=tko[0]+1;bannerText='⚡ הארכה! ההפלה הבאה מנצחת';banner=2;}}}
function teamText(){var s=Math.max(0,Math.ceil(TEAMT-tTime)),mm=Math.floor(s/60),ss=s%60;return '👥 אתם '+tko[0]+' · יריבים '+tko[1]+' · '+(tSudden?'הארכה!':mm+':'+(ss<10?'0':'')+ss);}
