# Put the rigged Nova (ux model: real UV texture, 23-bone clips) into g3.js + stage. Run on clean v65 sources.
import json, re
G = '/home/claude/g3/g3.js'; ST = '/home/claude/arena3_stage.html'
s = open(G, encoding='utf-8').read()
nova = open('/home/claude/nova/nova.json', encoding='utf-8').read()

# 1) model entry 11
lines = s.split('\n'); hit = [i for i, l in enumerate(lines) if l.startswith('11:{"nv"')]
assert len(hit) == 1; lines[hit[0]] = '11:' + nova + ','; s = '\n'.join(lines)

# 2) glbHero: ux geometry/material + attach the clip skeleton
a = "var m=GLBM[id],G=glbGeo(id),J=m.j,bm=m.bm||[.4,.09,.47];\n var mt=glbMat(id);"
assert s.count(a) == 1
s = s.replace(a, "var m=GLBM[id],G=m.ux?uxGeo(id).a:glbGeo(id),J=m.j,bm=m.bm||[.4,.09,.47];\n var mt=m.ux?uxMat(id):glbMat(id);")
a = " V.mats=[mt,V.ring.material];V.face=null;V.glb=sm;V.am=+GLBM[id].am||1;\n return true;}"
assert s.count(a) == 1
UX = r'''
/* ===== rigged heroes (ux models, v66): a real UV texture and a 23-bone skeleton from the player's Tripo export.
   Two skinned bodies share one geometry layout: A (arms down, skinned to the 11 game joints, so every procedural move in battle works)
   and B (the original T bind on the real bones, used to play the exported clips on the stage: menu dances, lose screen). */
function uxGeo(id){if(GLBG[id])return GLBG[id];
 var m=GLBM[id],bs=atob(m.d),u8=new Uint8Array(bs.length);for(var i=0;i<bs.length;i++)u8[i]=bs.charCodeAt(i);
 var nv=m.nv,nf=m.nf,o=0;function u16(n){var a=new Uint16Array(u8.buffer.slice(o,o+n*2));o+=n*2;return a;}function u8a(n){var a=u8.subarray(o,o+n);o+=n;return a;}
 var p1=u16(nv*3),p2=u16(nv*3),uv=u16(nv*2),ix=u16(nf*3),gi=u8a(nv*4),gw=u8a(nv*4),bi=u8a(nv*4),bw=u8a(nv*4),mn=m.mn,mx=m.mx;
 function pos(q){var f=new Float32Array(nv*3);for(var i=0;i<nv*3;i++){var c=i%3;f[i]=mn[c]+q[i]/65535*(mx[c]-mn[c]);}return f;}
 var UV=new Float32Array(nv*2);for(i=0;i<nv*2;i++)UV[i]=uv[i]/65535;
 function geo(P,si,sw){var g=new THREE.BufferGeometry(),SI=new Uint16Array(nv*4),SW=new Float32Array(nv*4);for(var k=0;k<nv*4;k++){SI[k]=si[k];SW[k]=sw[k]/255;}
  g.setAttribute('position',new THREE.BufferAttribute(P,3));g.setAttribute('uv',new THREE.BufferAttribute(UV,2));g.setIndex(new THREE.BufferAttribute(ix,1));g.computeVertexNormals();
  g.setAttribute('skinIndex',new THREE.Uint16BufferAttribute(SI,4));g.setAttribute('skinWeight',new THREE.BufferAttribute(SW,4));g.computeBoundingSphere();g.computeBoundingBox();return g;}
 var clips={},nb=m.bones.length;for(var cn in m.clips){var c=m.clips[cn],qb=atob(c.q),hb=atob(c.h),qa=new Uint8Array(qb.length),ha=new Uint8Array(hb.length);
  for(i=0;i<qb.length;i++)qa[i]=qb.charCodeAt(i);for(i=0;i<hb.length;i++)ha[i]=hb.charCodeAt(i);
  var Q=new Int16Array(qa.buffer),QF=new Float32Array(Q.length);for(i=0;i<Q.length;i++)QF[i]=Q[i]/32767;clips[cn]={n:c.n,fps:c.fps,dur:c.dur,q:QF,h:new Float32Array(ha.buffer),nb:nb};}
 GLBG[id]={a:geo(pos(p2),gi,gw),b:geo(pos(p1),bi,bw),clips:clips};return GLBG[id];}
function uxMat(id){
 var m=GLBM[id],tx=glbTex(id);tx.flipY=false;
 var mt=new THREE.MeshToonMaterial({color:'#ffffff',map:tx,gradientMap:toonGrad(),skinning:true,side:THREE.DoubleSide});
 mt.onBeforeCompile=function(sh){sh.uniforms.uFlat={value:m.fl!=null?m.fl:.35};
  sh.fragmentShader='uniform float uFlat;\n'+sh.fragmentShader.replace('vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;','vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;\noutgoingLight=mix(outgoingLight,diffuseColor.rgb*1.04+totalEmissiveRadiance,uFlat);');
  rimHook(sh);mt.userData.sh=sh;};
 mt.customProgramCacheKey=function(){return 'uxMat';};return mt;}
function uxAttach(V,id,mt){
 var m=GLBM[id],U=uxGeo(id),root=new THREE.Object3D();V.g.add(root);
 var bones=m.bones.map(function(b){var o=new THREE.Bone();o.name=b[0];o.position.set(b[2],b[3],b[4]);o.quaternion.set(b[5],b[6],b[7],b[8]);return o;});
 m.bones.forEach(function(b,i){(b[1]>=0?bones[b[1]]:root).add(bones[i]);});
 var B=new THREE.SkinnedMesh(U.b,mt);B.frustumCulled=false;B.castShadow=true;root.add(B);
 V.g.updateMatrixWorld(true);var sk=new THREE.Skeleton(bones);B.bind(sk);B.visible=false;
 var hip=-1;bones.forEach(function(o,i){if(o.name==='Hip')hip=i;});
 V.ux={B:B,bones:bones,hip:hip,clips:U.clips};}
/* pose the real skeleton at time t of a clip and show body B; returns false when this hero has no such clip */
function uxPlay(v,name,t){var U=v&&v.ux,c=U&&U.clips[name];if(!c)return false;
 var f=Math.max(0,Math.min(c.n-1.0001,t*c.fps)),i0=f|0,i1=i0+1,a=f-i0,nb=c.nb,Q=c.q;
 for(var b=0;b<nb;b++){var k0=(i0*nb+b)*4,k1=(i1*nb+b)*4;U.bones[b].quaternion.set(Q[k0]+(Q[k1]-Q[k0])*a,Q[k0+1]+(Q[k1+1]-Q[k0+1])*a,Q[k0+2]+(Q[k1+2]-Q[k0+2])*a,Q[k0+3]+(Q[k1+3]-Q[k0+3])*a).normalize();}
 if(U.hip>=0){var H=c.h;U.bones[U.hip].position.set(H[i0*3]+(H[i1*3]-H[i0*3])*a,H[i0*3+1]+(H[i1*3+1]-H[i0*3+1])*a,H[i0*3+2]+(H[i1*3+2]-H[i0*3+2])*a);}
 if(v.glb)v.glb.visible=false;U.B.visible=true;return true;}
function uxRest(v){if(v&&v.ux){if(v.glb)v.glb.visible=true;v.ux.B.visible=false;}}
function uxDur(n,d){for(var k in GLBM){var c=GLBM[k].clips;if(c&&c[n])return c[n].dur;}return d;}
'''
s = s.replace(a, " V.mats=[mt,V.ring.material];V.face=null;V.glb=sm;V.am=+GLBM[id].am||1;\n if(m.ux)uxAttach(V,id,mt);\n return true;}" + UX)

# 3) stage acts: clip moves (fallback to a procedural move for heroes without clips)
a = "function shActs(ch){"
assert s.count(a) == 1
ACT = r'''ACTS.ball=[uxDur('basketball_shot',6.6),function(v,p){if(!uxPlay(v,'basketball_shot',p*ACTS.ball[0]))ACTS.shoot[1](v,Math.min(1,p*3));}];
ACTS.angry=[uxDur('angry_03',3.6),function(v,p){if(!uxPlay(v,'angry_03',p*ACTS.angry[0]))ACTS.guard[1](v,Math.min(1,p*2));}];
ACTS.angry2=[uxDur('angry_02',2.2),function(v,p){if(!uxPlay(v,'angry_02',p*ACTS.angry2[0]))ACTS.guard[1](v,Math.min(1,p*1.4));}];
var UXA={ball:1,angry:1,angry2:1};
'''
s = s.replace(a, ACT + a)
a = "if(ch.hat==='band'||ch.hat==='horn')l.splice(2,0,'punch');return l;}"
assert s.count(a) == 1
s = s.replace(a, "if(ch.hat==='band'||ch.hat==='horn')l.splice(2,0,'punch');var gm=typeof GLBM!=='undefined'&&GLBM[ch.idx];if(gm&&gm.clips&&gm.clips.basketball_shot&&!(ch.skn>0)){l.unshift('ball');l.splice(3,0,'ball');}return l;}")
a = "function shPlay(){if(!SH||!SH.v)return;var l=SH.acts;SH.act=l[SH.ai%l.length];"
assert s.count(a) == 1
s = s.replace(a, a + "if(UXA[SH.act]&&!SH.v.ux)SH.act='guard';")
a = "function shPose(v,t){\n"
assert s.count(a) == 1
s = s.replace(a, a + " uxRest(v);\n")
open(G, 'w', encoding='utf-8').write(s)

# 4) stage: lose screen plays the angry clips (heroes without clips fall back to 'guard')
h = open(ST, encoding='utf-8').read()
a = "acts:win?['victory','wave','victory','guard']:['guard']}"
assert h.count(a) == 1
h = h.replace(a, "acts:win?['victory','wave','victory','guard']:['angry','angry2']}")
h = h.replace("var NETVER='65'", "var NETVER='66'")
open(ST, 'w', encoding='utf-8').write(h)
print('patched')
