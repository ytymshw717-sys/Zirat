# decode nova.json exactly like the game will, and render: T bind, arms-down bind, clip frames (23-bone LBS) -> PNG
import json, base64, io, sys, numpy as np, importlib.util
from PIL import Image
spec = importlib.util.spec_from_file_location('r', '/home/claude/mx/render_core.py'); R = importlib.util.module_from_spec(spec); spec.loader.exec_module(R)
D = json.load(open('/home/claude/nova/nova.json')); nv, nf = D['nv'], D['nf']; b = base64.b64decode(D['d']); o = 0
def take(dt, n):
    global o; a = np.frombuffer(b, dt, n, o); o += a.nbytes; return a
mn, mx = np.array(D['mn']), np.array(D['mx'])
P1 = mn + take(np.uint16, nv * 3).reshape(-1, 3) / 65535 * (mx - mn); P2 = mn + take(np.uint16, nv * 3).reshape(-1, 3) / 65535 * (mx - mn)
UV = take(np.uint16, nv * 2).reshape(-1, 2) / 65535; F = take(np.uint16, nf * 3).reshape(-1, 3).astype(int)
gi = take(np.uint8, nv * 4).reshape(-1, 4); gw = take(np.uint8, nv * 4).reshape(-1, 4) / 255; bi = take(np.uint8, nv * 4).reshape(-1, 4).astype(int); bw = take(np.uint8, nv * 4).reshape(-1, 4) / 255
assert o == len(b), (o, len(b))
tex = np.array(Image.open(io.BytesIO(base64.b64decode(D['tex'].split(',')[1]))).convert('RGB'))
bones = D['bones']
def qm(q):
    x, y, z, w = q / np.linalg.norm(q); return np.array([[1-2*(y*y+z*z), 2*(x*y-z*w), 2*(x*z+y*w)], [2*(x*y+z*w), 1-2*(x*x+z*z), 2*(y*z-x*w)], [2*(x*z-y*w), 2*(y*z+x*w), 1-2*(x*x+y*y)]])
def worlds(Q=None, HT=None):
    W = []
    for i, bb in enumerate(bones):
        t = np.array(bb[2:5]); q = np.array(bb[5:9]) if Q is None else Q[i]
        if HT is not None and bb[0] == 'Hip': t = HT
        M = np.eye(4); M[:3, :3] = qm(q); M[:3, 3] = t
        W.append(W[bb[1]] @ M if bb[1] >= 0 else M)
    return np.array(W)
W0inv = np.linalg.inv(worlds())
def skinned(Q, HT):
    Wt = worlds(Q, HT); M = np.einsum('bij,bjk->bik', Wt, W0inv); Ph = np.c_[P1, np.ones(nv)]; out = np.zeros((nv, 3))
    for k in range(4): out += bw[:, k:k+1] * np.einsum('nij,nj->ni', M[bi[:, k]], Ph)[:, :3]
    return out
uvi = F
def rr(V, rot=0, S=300):
    Vc = (V - np.array([0, 0, 0])) * (180 / 2.6)  # render_core expects ~cm
    return R.rast(Vc, F, UV, uvi, tex, rot, S)
row1 = [rr(P1), rr(P2), rr(P2, np.pi / 2)]
rows = [np.concatenate(row1 + [np.full_like(row1[0], 235)], 1)]
for nm, c in D['clips'].items():
    n = c['n']; Q = np.frombuffer(base64.b64decode(c['q']), np.int16).reshape(n, len(bones), 4) / 32767; HT = np.frombuffer(base64.b64decode(c['h']), np.float32).reshape(n, 3)
    rows.append(np.concatenate([rr(skinned(Q[f], HT[f])) for f in np.linspace(0, n - 1, 4).astype(int)], 1))
Image.fromarray(np.concatenate(rows, 0)).save('/tmp/nova/verify.png'); print('ok', nv, nf, list(D['clips']))
