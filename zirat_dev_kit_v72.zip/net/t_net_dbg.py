import time,re
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:9911/arena3_new.html'
INIT=open('/home/claude/net/mock_sa.js').read()+";window.__SIG='ws://127.0.0.1:9911/peerjs';window.__NETMAX=3;"
res=[];errs=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
def act(pg,a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a)
def ovt(pg):return pg.evaluate("document.getElementById('ov').innerText")
def wait_text(pg,txt,t=25):
    for i in range(int(t*4)):
        if txt in ovt(pg):return True
        pg.wait_for_timeout(250)
    return False
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    def page(url,tag,vp=(390,844),mob=True):
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=mob,is_mobile=mob);c.add_init_script(script=INIT)
        pg=c.new_page();pg.on('pageerror',lambda e:errs.append(tag+':'+str(e)));pg.on('console',lambda m:errs.append(tag+' console:'+m.text) if m.type=='error' else None)
        pg.goto(url);pg.wait_for_timeout(3500);return pg
    H=page(BASE,'host',(1280,720),False)
    ok('standalone: no Claude, room service ready',H.evaluate("!window.claude&&!!__net().room&&__net().room.net===1"))
    act(H,'online');H.wait_for_timeout(300);ok('online window says direct connection, no Claude needed','בלי Claude' in ovt(H))
    act(H,'onew');ok('host: room created',wait_text(H,'קוד החדר',15),ovt(H)[:80])
    code=H.evaluate("__net().ocode");link=H.evaluate("document.getElementById('roomLink').textContent")
    ok('link is the game address + room code (not Claude)',link==BASE+'?v=43#room-'+code and 'claude' not in link,link)
    ok('QR encodes exactly that link',H.evaluate("(function(){var q=qrcode(0,'M');q.addData(%r);q.make();return q.createDataURL(5,2)===document.getElementById('roomQR').src;})()"%link))
    F1=page(link,'f1');ok('friend 1 opens link → joins room automatically',wait_text(F1,'מחובר',30) and F1.evaluate("(function(n){return !!n.rm&&n.rm.net&&!n.rm.isHost&&n.ocode})(__net())")==code,ovt(F1)[:60])
    if not res[-1]:print('F1 LOG:',F1.evaluate("(window.__NL||[]).join(' | ')"));print('H LOG:',H.evaluate("(window.__NL||[]).join(' | ')"))
    F2=page(link,'f2');ok('friend 2 joins same room',wait_text(F2,'מחובר',30))
    H.wait_for_timeout(800)
    ok('host sees 3 players (3 / 3)',H.evaluate("__net().opeers.length")==2 and '3 / 3' in ovt(H),ovt(H)[:120])
    ok('friend 1 sees host + friend 2',F1.evaluate("__net().opeers.length")==2)
    F3=page(link,'f3');ok('friend 3: room full message',wait_text(F3,'החדר מלא',30),ovt(F3)[:80])
    F4=page(BASE+'#room-zzzzzz','f4');ok('unknown room: room does not exist message',wait_text(F4,'החדר לא קיים',30),ovt(F4)[:80])
    F5=page(BASE+'#room-!!','f5');ok('invalid link: message',wait_text(F5,'קישור ההזמנה לא תקין',15),ovt(F5)[:80])
    # shared game state: everyone plays, presence flows both ways
    for pg in (H,F1,F2):act(pg,'menu');pg.wait_for_timeout(300);act(pg,'mode:survive');pg.wait_for_timeout(400)
    for i in range(40):
        if H.evaluate("__net().opeers.every(function(q){return q.presence&&q.presence.m==='survive'})"):break
        H.wait_for_timeout(250)
    hp=H.evaluate("__net().opeers.map(function(q){return q.presence&&[q.presence.h,q.presence.m,typeof q.presence.x]})")
    ok('host receives friends live state (hero, mode, position)',len(hp)==2 and all(x and x[1]=='survive' and x[2]=='number' for x in hp),str(hp))
    x0=F1.evaluate("__arena().ps[0].x");F1.keyboard.down('KeyD');F1.wait_for_timeout(900);F1.keyboard.up('KeyD');H.wait_for_timeout(800)
    me1=F1.evaluate("__net().rm.me");seen=H.evaluate("(function(id){var q=__net().opeers.filter(function(p){return p.peer===id})[0];return q&&q.presence&&q.presence.x})(%r)"%me1)
    print("DBG F1 x now",F1.evaluate("__arena().ps[0].x"),"state",F1.evaluate("__arena().state"),"seen",seen,"x0",x0,"hostH",H.evaluate("__arena().state"));ok("friend moves",seen is not None and abs(seen-F1.evaluate("__arena().ps[0].x"))<40 and abs(seen-x0)>5,'%s -> %s'%(x0,seen))
    f2sees=F2.evaluate("__net().opeers.map(function(q){return q.presence&&q.presence.m})")
    ok('friend 2 sees host + friend 1 in game',len(f2sees)==2 and all(m=='survive' for m in f2sees),str(f2sees))
    ok('peers drawn in game (no errors)',F2.evaluate("__arena().state")=='play')
    ok('friends drawn as 3D heroes in the host world',H.evaluate("G3.r3state()&&G3.r3state().ents")>=3,str(H.evaluate("G3.r3state()&&G3.r3state().ents")))
    # host leaves → friends told
    act(F1,'pz');act(F1,'menu');F1.wait_for_timeout(300);act(F1,'online');F1.wait_for_timeout(300)
    act(H,'menu');H.wait_for_timeout(300);act(H,'online');H.wait_for_timeout(300);act(H,'ol');H.wait_for_timeout(1500)
    ok('host leaves → friend told the host closed the room',wait_text(F1,'המארח סגר',10) and F1.evaluate("__net().rm")==None,ovt(F1)[:80])
    F6=page(BASE+'#host','f6');ok("site link '#host' creates a room automatically",wait_text(F6,'קוד החדר',30) and F6.evaluate("(function(n){return !!n.rm&&n.rm.isHost})(__net())") and F6.evaluate("location.hash")=='',ovt(F6)[:80])
    ok('no JS errors',not errs,str(errs[:5]))
    print('SUMMARY %d/%d'%(sum(res),len(res)));print('ERRORS',errs[:6])
