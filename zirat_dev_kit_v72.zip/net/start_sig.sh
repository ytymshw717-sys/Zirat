#!/bin/bash
for p in $(pgrep -f "^node net/sig.js"); do kill $p; done
cd /home/claude && (node net/sig.js 9911 /home/claude > net/sig.log 2>&1 &)
for i in $(seq 1 40); do curl -s -o /dev/null http://127.0.0.1:9911/arena3_new.html && exit 0; sleep 0.5; done; exit 1
