import subprocess,time,os,sys
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html';BASE='http://127.0.0.1:9911/'+F
INIT=open('/home/claude/net/mock_sa.js').read()+";window.__SIG='ws://127.0.0.1:9911/peerjs';window.__WS=[];(function(){var W=window.WebSocket;window.WebSocket=function(u,p){var w=p?new W(u,p):new W(u);window.__WS.push(w);return w;};window.WebSocket.prototype=W.prototype;window.WebSocket.OPEN=1;})();"
env=dict(os.environ,KEEP='1');srv=subprocess.Popen(['node','/home/claude/net/sig.js','9911','/home/claude'],env=env,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(1.5)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    def page(url):
        c=b.new_context(viewport={'width':390,'height':844});c.add_init_script(script=INIT);pg=c.new_page();pg.goto(url);pg.wait_for_timeout(3500);return pg
    H=page(BASE)
    for a in ('online','onew'):H.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);H.wait_for_timeout(300)
    H.wait_for_timeout(2500);code=H.evaluate("__net().ocode")
    H.evaluate("window.__WS.forEach(function(w){try{w.close()}catch(e){}})");H.wait_for_timeout(7000)   # host link drops; server keeps the stale entry (like a frozen iPhone)
    Fr=page(BASE+'#room-'+code);t0=time.time();ok=False
    while time.time()-t0<30:
        if Fr.evaluate("!!__net().rm"):ok=True;break
        Fr.wait_for_timeout(500)
    print(F,'friend joins after host link dropped & resumed:',ok,'(%.0fs)'%(time.time()-t0));print('host log:',H.evaluate("(window.__NL||[]).slice(-6).join(' | ')"))
srv.terminate()
