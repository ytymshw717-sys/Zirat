from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:9911/arena3_new.html'
INIT=open('/home/claude/net/mock_sa.js').read()+";window.__SIG='ws://127.0.0.1:9911/peerjs';window.__NETMAX=3;"
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    def page(url):
        c=b.new_context(viewport={'width':390,'height':844});c.add_init_script(script=INIT);pg=c.new_page();L=[]
        pg.on('console',lambda m:L.append(m.type+':'+m.text[:150]));pg.on('pageerror',lambda e:L.append('ERR '+str(e)[:150]));pg.goto(url);pg.wait_for_timeout(3500);return pg,L
    H,LH=page(BASE)
    for a in ('online','onew'):
        H.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);H.wait_for_timeout(300)
    H.wait_for_timeout(3000);code=H.evaluate("__net().ocode");print('code',code,'host rm',H.evaluate("!!__net().rm"))
    F,LF=page(BASE+'#room-'+code)
    for i in range(0,24,2):
        F.wait_for_timeout(2000);print(i,F.evaluate("document.getElementById('ov').innerText.replace(/\\n/g,' | ').slice(0,90)"),'rm:',F.evaluate("!!__net().rm"),flush=True)
        if F.evaluate("!!__net().rm"):break
    print('F console',LF[:6]);print('H console',LH[:6])
