import subprocess,time,os,signal
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:9911/arena3.preReconn.html'
INIT=open('/home/claude/net/mock_sa.js').read()+";window.__SIG='ws://127.0.0.1:9911/peerjs';"
def start():return subprocess.Popen(['node','/home/claude/net/sig.js','9911','/home/claude'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
srv=start();time.sleep(1.5);res=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    def page(url):
        c=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True);c.add_init_script(script=INIT);pg=c.new_page();pg.goto(url);pg.wait_for_timeout(3500);return pg
    H=page(BASE)
    for a in ('online','onew'):
        H.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);H.wait_for_timeout(300)
    H.wait_for_timeout(2500);code=H.evaluate("__net().ocode");ok('room created',H.evaluate("!!__net().rm"),code)
    srv.terminate();srv.wait();time.sleep(2);srv=start();time.sleep(6)
    F=page(BASE+'#room-'+code)
    for i in range(15):
        if F.evaluate("!!__net().rm"):break
        F.wait_for_timeout(1000)
    ok('after the room server dropped and came back, a friend still joins the same room',F.evaluate("!!__net().rm") and H.evaluate("__net().opeers.length")==1,F.evaluate("document.getElementById('ov').innerText.slice(0,80)"))
    print('SUMMARY %d/%d'%(sum(res),len(res)))
srv.terminate()
