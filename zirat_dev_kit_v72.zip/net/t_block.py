import sys,time
from playwright.sync_api import sync_playwright
F=sys.argv[1];BASE='http://127.0.0.1:9911/'+F
INIT=open('/home/claude/net/mock_sa.js').read()+";window.__SIG='ws://127.0.0.1:9911/peerjs';"
BLOCK=""";(function(){var R=window.RTCPeerConnection;if(!R)return;var P=R.prototype;P.addIceCandidate=function(){return Promise.resolve();};
var d=Object.getOwnPropertyDescriptor(P,'onicecandidate');Object.defineProperty(P,'onicecandidate',{set:function(f){d.set.call(this,function(){});},get:function(){return null;},configurable:true});})();"""
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    def page(url,extra=''):
        c=b.new_context(viewport={'width':390,'height':844});c.add_init_script(script=INIT+extra);pg=c.new_page();pg.goto(url);pg.wait_for_timeout(3500);return pg
    H=page(BASE)
    for a in ('online','onew'):H.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);H.wait_for_timeout(300)
    H.wait_for_timeout(2500);code=H.evaluate("__net().ocode")
    Fr=page(BASE+'#room-'+code,BLOCK);t0=time.time();ok=False
    while time.time()-t0<32:
        if Fr.evaluate("!!__net().rm"):ok=True;break
        Fr.wait_for_timeout(500)
    print(F,'friend behind a blocked network joined:',ok,'(%.0fs)'%(time.time()-t0),'| friend screen:',Fr.evaluate("document.getElementById('ov').innerText.split('\\n').slice(-3).join(' / ')")[:120])
