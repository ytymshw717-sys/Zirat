/* ===== חדרים עצמאיים: חיבור ישיר בין מכשירים (WebRTC) דרך שרת תיווך ציבורי בפרוטוקול PeerJS — בלי ספריות חיצוניות ===== */
var NetP=(function(){
 var MAX=6,PFX='zirat-giborim-v1-';
 function SIG(){return window.__SIG||'wss://0.peerjs.com:443/peerjs';}
 var ICE=[{urls:'stun:stun.l.google.com:19302'},{urls:['turn:eu-0.turn.peerjs.com:3478','turn:us-0.turn.peerjs.com:3478'],username:'peerjs',credential:'peerjsp'}];
 function rid(){return Math.random().toString(36).slice(2,10)+Math.random().toString(36).slice(2,8);}
 function J(o){try{return JSON.stringify(o);}catch(e){return '{}';}}
 function P(s){try{return JSON.parse(s);}catch(e){return null;}}
 function cand(c){return c&&c.toJSON?c.toJSON():c;}
 function sigOpen(id){return new Promise(function(res,rej){
  var ws,done=false,hb=null,S={on:null,onclose:null,send:function(o){try{if(ws.readyState===1)ws.send(J(o));}catch(e){}},close:function(){clearInterval(hb);S.on=null;try{ws.close();}catch(e){}}};
  try{ws=new WebSocket(SIG()+'?key=peerjs&id='+encodeURIComponent(id)+'&token='+rid()+'&version=1.5.4');}catch(e){rej('net');return;}
  var to=setTimeout(function(){if(!done){done=true;try{ws.close();}catch(e){}rej('net');}},10000);
  ws.onmessage=function(ev){var m=P(ev.data);if(!m)return;
   if(!done){if(m.type==='OPEN'){done=true;clearTimeout(to);hb=setInterval(function(){S.send({type:'HEARTBEAT'});},5000);res(S);}
    else if(m.type==='ID-TAKEN'||m.type==='ERROR'){done=true;clearTimeout(to);try{ws.close();}catch(e){}rej(m.type==='ID-TAKEN'?'taken':'net');}return;}
   if(S.on)S.on(m);};
  ws.onerror=function(){if(!done){done=true;clearTimeout(to);rej('net');}};
  ws.onclose=function(){clearInterval(hb);if(!done){done=true;clearTimeout(to);rej('net');}else if(S.onclose)S.onclose();};
 });}
 function list2peers(l,me){return {peers:(l||[]).map(function(x){return {peer:x.p,id:x.p,peerId:x.p,isMe:x.p===me,presence:x.d||null};})};}
 /* host: owns the room id, accepts up to MAX-1 friends, relays everyone's presence 10x/sec */
 function host(code){return sigOpen(PFX+code).then(function(S){
  var me='h-'+rid(),cl={},mine=null,cb=null,alive=true,R;
  function joined(){var n=0;for(var k in cl)if(cl[k].ok)n++;return n;}
  function drop(id){var c=cl[id];if(!c)return;delete cl[id];try{c.ch&&c.ch.close();}catch(e){}try{c.pc.close();}catch(e){}}
  function snap(){var l=[{p:me,d:mine}];for(var k in cl)if(cl[k].ok)l.push({p:k,d:cl[k].d});return l;}
  function push(){if(!alive)return;var l=snap(),s=J({t:'peers',l:l});for(var k in cl){var c=cl[k];if(c.ok&&c.ch&&c.ch.readyState==='open')try{c.ch.send(s);}catch(e){}}if(cb)try{cb(list2peers(l,me));}catch(e){}}
  var tick=setInterval(push,100);
  S.on=function(m){var src=m.src;if(!src)return;
   if(m.type==='OFFER'&&m.payload&&m.payload.sdp){drop(src);
    var pc=new RTCPeerConnection({iceServers:ICE}),c={pc:pc,ch:null,d:null,ok:false,pend:[]};cl[src]=c;
    pc.onicecandidate=function(e){if(e.candidate)S.send({type:'CANDIDATE',dst:src,payload:{candidate:cand(e.candidate),type:'data'}});};
    pc.onconnectionstatechange=function(){if(pc.connectionState==='failed'||pc.connectionState==='closed')drop(src);};
    pc.ondatachannel=function(e){c.ch=e.channel;
     c.ch.onopen=function(){if(joined()>=MAX-1){try{c.ch.send(J({t:'full',max:MAX}));}catch(x){}setTimeout(function(){drop(src);},800);return;}c.ok=true;try{c.ch.send(J({t:'hi',you:src,max:MAX}));}catch(x){}push();};
     c.ch.onmessage=function(ev){var x=P(ev.data);if(!x)return;if(x.t==='p')c.d=x.d;else if(x.t==='bye')drop(src);};
     c.ch.onclose=function(){drop(src);};};
    pc.setRemoteDescription(m.payload.sdp).then(function(){(c.pend||[]).forEach(function(k){pc.addIceCandidate(k).catch(function(){});});c.pend=null;return pc.createAnswer();})
     .then(function(a){return pc.setLocalDescription(a);}).then(function(){S.send({type:'ANSWER',dst:src,payload:{sdp:pc.localDescription,type:'data'}});}).catch(function(){drop(src);});}
   else if(m.type==='CANDIDATE'&&cl[src]&&m.payload){var c2=cl[src];if(c2.pend)c2.pend.push(m.payload.candidate);else c2.pc.addIceCandidate(m.payload.candidate).catch(function(){});}
  };
  R={net:1,isHost:true,code:code,max:MAX,me:me,
   onPeers:function(f){cb=f;push();},onEnd:function(){},
   presence:function(o){mine=o;},
   leave:function(){if(!alive)return;alive=false;clearInterval(tick);var s=J({t:'end'});for(var k in cl){try{cl[k].ch&&cl[k].ch.send(s);}catch(e){}}setTimeout(function(){for(var k in cl)drop(k);},300);S.close();}};
  return R;
 });}
 /* friend: connects to the host's id; resolves when the host says hi, rejects nf / full / timeout / net */
 function join(code){return sigOpen(PFX+'c-'+rid()).then(function(S){return new Promise(function(res,rej){
  var hostId=PFX+code,pc=new RTCPeerConnection({iceServers:ICE}),ch=pc.createDataChannel('z'),pend=[],settled=false,me=null,cb=null,endF=null,R=null,gone=false;
  var to=setTimeout(function(){fail('timeout');},20000);
  function fail(r){if(settled)return;settled=true;clearTimeout(to);try{ch.close();}catch(e){}try{pc.close();}catch(e){}S.close();rej(r);}
  function ended(why){if(gone)return;gone=true;try{pc.close();}catch(e){}if(R&&R._end)try{R._end(why);}catch(e){}}
  pc.onicecandidate=function(e){if(e.candidate)S.send({type:'CANDIDATE',dst:hostId,payload:{candidate:cand(e.candidate),type:'data'}});};
  S.on=function(m){if(m.src!==hostId)return;
   if(m.type==='EXPIRE')fail('nf');
   else if(m.type==='ANSWER'&&m.payload)pc.setRemoteDescription(m.payload.sdp).then(function(){pend.forEach(function(k){pc.addIceCandidate(k).catch(function(){});});pend=null;}).catch(function(){fail('net');});
   else if(m.type==='CANDIDATE'&&m.payload){if(pend)pend.push(m.payload.candidate);else pc.addIceCandidate(m.payload.candidate).catch(function(){});}};
  ch.onmessage=function(ev){var x=P(ev.data);if(!x)return;
   if(x.t==='full'){fail('full');return;}
   if(x.t==='hi'&&!settled){settled=true;clearTimeout(to);me=x.you;S.close();
    R={net:1,isHost:false,code:code,max:x.max||MAX,me:me,_end:null,
     onPeers:function(f){cb=f;},onEnd:function(f){R._end=f;},
     presence:function(o){if(ch.readyState==='open')try{ch.send(J({t:'p',d:o}));}catch(e){}},
     leave:function(){gone=true;try{ch.send(J({t:'bye'}));}catch(e){}setTimeout(function(){try{ch.close();}catch(e){}try{pc.close();}catch(e){}},150);}};
    res(R);return;}
   if(x.t==='peers'&&cb)try{cb(list2peers(x.l,me));}catch(e){}
   if(x.t==='end')ended('host');};
  ch.onclose=function(){if(settled)ended('lost');else fail('net');};
  pc.onconnectionstatechange=function(){if(pc.connectionState==='failed'){if(settled)ended('lost');else fail('net');}};
  pc.createOffer().then(function(o){return pc.setLocalDescription(o);}).then(function(){S.send({type:'OFFER',dst:hostId,payload:{sdp:pc.localDescription,type:'data',connectionId:'dc_'+rid()}});}).catch(function(){fail('net');});
 });});}
 return {host:host,join:join,MAX:MAX,ok:function(){return !!(window.RTCPeerConnection&&window.WebSocket);}};
})();
