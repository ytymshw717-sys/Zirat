import shutil,sys,time
from playwright.sync_api import sync_playwright
F=sys.argv[1];SP='/tmp/claude-0/-home-claude/b0ae6ea6-7673-5629-85ca-afcd48e28043/scratchpad/'
U='http://127.0.0.1:9912/'+F+'?v=39'
res=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
def act(pg,a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(400)
with sync_playwright() as p:
    def open_(D,url=U):
        c=p.chromium.launch_persistent_context(D,args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'],viewport={'width':390,'height':844});c.add_init_script(script="window.__skipIntro=1;");pg=c.new_page();pg.goto(url);pg.wait_for_timeout(3000);return c,pg
    A=SP+'pA';B=SP+'pB';shutil.rmtree(A,ignore_errors=True);shutil.rmtree(B,ignore_errors=True)
    # 1) autosave: a change that no game action saved survives an abrupt browser close
    c,pg=open_(A);pg.evaluate("__arena().sv.gold=777;__arena().sv.dm=55;__arena().sv.nm='דני'");pg.wait_for_timeout(4800);c.close()
    c,pg=open_(A);ok('autosave: progress survives an abrupt browser close',pg.evaluate("__arena().sv.gold")==777 and pg.evaluate("__arena().sv.dm")==55,str(pg.evaluate("__arena().sv.gold")))
    # 2) transfer link from browser A to a fresh browser B
    act(pg,'prof');ok('profile has transfer section','העבר התקדמות' in pg.inner_text('#ov'))
    act(pg,'xfer');link=pg.evaluate("(document.getElementById('xferTxt')||{}).value||''")
    ok('transfer link created (points to the game + #save-)',link.startswith('http://127.0.0.1:9912/') and '#save-' in link,link[:70])
    ok('profile window still fits the phone width',pg.evaluate("document.getElementById('ov').scrollWidth<=document.getElementById('ov').clientWidth+1"))
    pg.screenshot(path='/home/claude/t3/xfer_profile.png');c.close()
    c,pg=open_(B,link);pg.wait_for_timeout(1500)
    ok('fresh browser B: asks to load the progress (shows 777 coins)','טען התקדמות' in pg.inner_text('#ov') and '777' in pg.inner_text('#ov'),pg.inner_text('#ov')[:80])
    pg.screenshot(path='/home/claude/t3/xfer_ask.png')
    act(pg,'xferok');pg.wait_for_timeout(3500)
    ok('after loading: browser B has the progress',pg.evaluate("__arena().sv.gold")==777 and pg.evaluate("__arena().sv.nm")=='דני',str(pg.evaluate("__arena().sv.gold")))
    ok('link hash cleared after loading',pg.evaluate("location.hash")=='')
    c.close()
    c,pg=open_(B);ok('browser B keeps it after reopening',pg.evaluate("__arena().sv.gold")==777);c.close()
    # 3) cancel and broken link
    shutil.rmtree(B,ignore_errors=True);c,pg=open_(B,link);pg.wait_for_timeout(1500);act(pg,'xferno');ok('cancel keeps browser B progress unchanged',pg.evaluate("__arena().sv.gold")==100);c.close()
    shutil.rmtree(B,ignore_errors=True);c,pg=open_(B,U+'#save-%%%garbage');pg.wait_for_timeout(1500);ok('broken transfer link → clear message, no crash','לא תקין' in pg.inner_text('#ov'));c.close()
    print('SUMMARY %d/%d'%(sum(res),len(res)))
