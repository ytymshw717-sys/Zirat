import subprocess,time,os,sys
from playwright.sync_api import sync_playwright
F=sys.argv[1];BASE='http://127.0.0.1:9911/'+F
INIT=open('/home/claude/net/mock_sa.js').read()+";window.__SIG='ws://127.0.0.1:9911/peerjs';"
srv=subprocess.Popen(['node','/home/claude/net/sig.js','9911','/home/claude'],env=dict(os.environ,KILLFIRST='1'),stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(1.5)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    def page(url):
        c=b.new_context(viewport={'width':390,'height':844});c.add_init_script(script=INIT);pg=c.new_page();pg.goto(url);pg.wait_for_timeout(3500);return pg
    H=page(BASE)
    for a in ('online','onew'):H.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);H.wait_for_timeout(300)
    H.wait_for_timeout(2500);code=H.evaluate("__net().ocode")
    Fr=page(BASE+'#room-'+code);t0=time.time();ok=False
    while time.time()-t0<34:
        if Fr.evaluate("!!__net().rm"):ok=True;break
        Fr.wait_for_timeout(500)
    print(F,'friend whose server link drops right after OFFER joined:',ok,'(%.0fs)'%(time.time()-t0))
    print('  friend log:',Fr.evaluate("(window.__NL||[]).join(' | ')")[:400])
srv.terminate()
