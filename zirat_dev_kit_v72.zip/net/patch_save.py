import sys
p=sys.argv[1];s=open(p).read()
def rep(a,b):
    global s
    assert s.count(a)==1,(s.count(a),a[:90]);s=s.replace(a,b)
# 1) autosave (only when something changed) + ask the browser to keep the data
rep("function save(){try{sv.ui={s:sel.slice(),m:selMode,mp:selMap,d:dfi};}catch(e){}try{localStorage.setItem(SAVE,JSON.stringify(sv));}catch(e){}}",
"""var svLast='';
var svHold=false;
function save(){if(svHold)return;try{sv.ui={s:sel.slice(),m:selMode,mp:selMap,d:dfi};}catch(e){}try{var j=JSON.stringify(sv);localStorage.setItem(SAVE,j);svLast=j;}catch(e){}}
setInterval(function(){if(svHold)return;try{sv.ui={s:sel.slice(),m:selMode,mp:selMap,d:dfi};var j=JSON.stringify(sv);if(j!==svLast){localStorage.setItem(SAVE,j);svLast=j;}}catch(e){}},4000);
try{if(navigator.storage&&navigator.storage.persist)navigator.storage.persist().catch(function(){});}catch(e){}""")
# 2) transfer link in the profile window
rep("<div class='glass' style='text-align:start;font-size:13px;line-height:1.7'>⭐ רמת שחקן: <b>${lvl}</b>",
"<div class='glass' style='font-size:13px;line-height:1.6'>📲 <b>העבר התקדמות לדפדפן אחר</b><br><small>כל דפדפן שומר התקדמות משלו. צור קישור ופתח אותו בדפדפן השני.</small><br><button class='c' style='width:auto;padding:0 12px;margin-top:4px' data-a='xfer'>🔗 צור קישור העברה</button><div id='xferBox'></div></div><div class='glass' style='text-align:start;font-size:13px;line-height:1.7'>⭐ רמת שחקן: <b>${lvl}</b>")
rep("function profile(msg){","""function b64e(t){return btoa(unescape(encodeURIComponent(t))).replace(/\\+/g,'-').replace(/\\//g,'_').replace(/=+$/,'');}
function b64d(t){t=t.replace(/-/g,'+').replace(/_/g,'/');while(t.length%4)t+='=';return decodeURIComponent(escape(atob(t)));}
function xferLink(){save();var base=inClaude()&&GAME_URL?GAME_URL+'?v='+NETVER:(/^https?:$/.test(location.protocol)?location.origin+location.pathname:(GAME_URL||location.href.split('#')[0].split('?')[0]));return base+'#save-'+b64e(localStorage.getItem(SAVE)||JSON.stringify(sv));}
function xferShow(){var bx=document.getElementById('xferBox');if(!bx)return;var lk;try{lk=xferLink();}catch(e){bx.innerHTML='<small>לא הצלחתי ליצור קישור</small>';return;}
 bx.innerHTML="<textarea id='xferTxt' readonly style='width:100%;height:64px;margin-top:6px;font-size:10px;direction:ltr;border-radius:8px;border:0;padding:4px;color:#111'>"+esc(lk)+"</textarea><button class='c' style='width:auto;padding:0 12px;margin-top:4px' data-a='xfcp'>📋 העתק</button>"+(navigator.share?" <button class='c' style='width:auto;padding:0 12px;margin-top:4px' data-a='xfsh'>📤 שתף</button>":"")+"<br><small>שלח את הקישור לעצמך (למשל בוואטסאפ) ופתח אותו בדפדפן השני.</small>";}
function xferCopy(){var t=document.getElementById('xferTxt');if(!t)return;var v=t.value,ok=function(){var bx=document.getElementById('xferBox');if(bx&&!/הועתק/.test(bx.innerHTML))bx.insertAdjacentHTML('beforeend','<small> ✅ הועתק</small>');};try{if(navigator.clipboard&&navigator.clipboard.writeText){navigator.clipboard.writeText(v).then(ok,function(){t.select();try{document.execCommand('copy');ok();}catch(e){}});return;}}catch(e){}t.focus();t.select();try{document.execCommand('copy');ok();}catch(e){}}
var xferIn=null;try{var xm=/^#save-([A-Za-z0-9_-]+)$/.exec(location.hash||'');if(xm){var xo=JSON.parse(b64d(xm[1]));if(xo&&typeof xo==='object'&&typeof xo.gold==='number'&&Array.isArray(xo.owned))xferIn=xo;else xferIn='bad';}else if(/^#save/.test(location.hash||''))xferIn='bad';}catch(e){xferIn='bad';}
function xferAsk(){if(!xferIn)return;var o=xferIn;
 if(o==='bad'){xferIn=null;try{history.replaceState(null,'',location.href.split('#')[0]);}catch(e){}showOv("<h1>📲 העברת התקדמות</h1><small>⚠️ קישור ההעברה לא תקין. צור קישור חדש בדפדפן השני ונסה שוב.</small><button class='c' style='width:auto;padding:0 14px' data-a='menu'>◀ חזרה</button>");return;}
 var tt=0;for(var k in (o.tr||{}))tt+=+o.tr[k]||0;
 showOv("<h1>📲 העברת התקדמות</h1><div class='glass' style='font-size:14px;line-height:1.8'>נמצאה התקדמות של <b>"+esc(String(o.nm||'שחקן'))+"</b><br>⭐ רמה "+(Math.floor((+o.xp||0)/120)+1)+" · 🪙 "+(+o.gold||0)+" · 💎 "+(+o.dm||0)+" · 🏆 "+tt+" · 🦸 "+o.owned.length+" גיבורים</div><small>ההתקדמות שבדפדפן הזה תוחלף בזו.</small><button class='big' data-a='xferok'>✅ טען התקדמות</button><button class='c' style='width:auto;padding:0 14px' data-a='xferno'>ביטול</button>");}
function xferNo(){xferIn=null;try{history.replaceState(null,'',location.href.split('#')[0]);}catch(e){}menu();}
if(xferIn)setTimeout(function(){whenMenu(xferAsk);},0);
function xferApply(){if(!xferIn||xferIn==='bad')return;svHold=true;try{localStorage.setItem(SAVE,JSON.stringify(xferIn));}catch(e){}var u=location.href.split('#')[0];xferIn=null;try{history.replaceState(null,'',u);}catch(e){}location.replace(u);}
function profile(msg){""")
# 3) actions
rep('a[0]==="prof")profile()','a[0]==="prof")profile();else if(a[0]==="xfer")xferShow();else if(a[0]==="xfcp")xferCopy();else if(a[0]==="xfsh"){try{navigator.share({title:"זירת גיבורים — העברת התקדמות",url:xferLink()}).catch(function(){});}catch(e){}}else if(a[0]==="xferok")xferApply();else if(a[0]==="xferno")xferNo()')
open(p,'w').write(s)
print('patched')
