// Minimal PeerJS-protocol signalling server (test only): OPEN / ID-TAKEN / forward with src / EXPIRE after 5s / HEARTBEAT / LEAVE
const http=require('http'),crypto=require('crypto'),url=require('url'),fs=require('fs'),path=require('path');
const PORT=+process.argv[2]||9911,ROOT=process.argv[3]||'/home/claude';
const clients=new Map(),queue=[],killed=new Set();
function frame(str){const b=Buffer.from(str);let h;if(b.length<126){h=Buffer.from([0x81,b.length]);}else if(b.length<65536){h=Buffer.alloc(4);h[0]=0x81;h[1]=126;h.writeUInt16BE(b.length,2);}else{h=Buffer.alloc(10);h[0]=0x81;h[1]=127;h.writeBigUInt64BE(BigInt(b.length),2);}return Buffer.concat([h,b]);}
function send(sock,o){try{sock.write(frame(JSON.stringify(o)));}catch(e){}}
function deliver(m){const d=clients.get(m.dst);if(d){send(d.sock,m);return true;}return false;}
setInterval(()=>{const now=Date.now();for(let i=queue.length-1;i>=0;i--){const q=queue[i];if(deliver(q.m)){queue.splice(i,1);continue;}if(now-q.t>5000){queue.splice(i,1);const s=clients.get(q.m.src);if(s)send(s.sock,{type:'EXPIRE',src:q.m.dst,dst:q.m.src});}}},500);
const srv=http.createServer((req,res)=>{let p=decodeURIComponent(url.parse(req.url).pathname);if(p==='/')p='/arena3_new.html';const f=path.join(ROOT,p);if(!f.startsWith(ROOT)||!fs.existsSync(f)){res.writeHead(404);res.end();return;}res.writeHead(200,{'content-type':f.endsWith('.html')?'text/html; charset=utf-8':'application/octet-stream'});fs.createReadStream(f).pipe(res);});
srv.on('upgrade',(req,sock)=>{const q=url.parse(req.url,true).query,id=q.id;const key=req.headers['sec-websocket-key'];
 const acc=crypto.createHash('sha1').update(key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').digest('base64');
 sock.write('HTTP/1.1 101 Switching Protocols\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Accept: '+acc+'\r\n\r\n');
 const tok=q.token;
 if(!id||!tok){send(sock,{type:'ERROR',payload:{msg:'bad params'}});setTimeout(()=>sock.end(),50);return;}
 const prev=clients.get(id);
 if(prev&&prev.tok!==tok){send(sock,{type:'ID-TAKEN',payload:{msg:'ID is taken'}});setTimeout(()=>sock.end(),50);return;}
 if(prev){prev.sock=sock;}else{clients.set(id,{sock,tok});send(sock,{type:'OPEN'});}let buf=Buffer.alloc(0);
 sock.on('data',d=>{buf=Buffer.concat([buf,d]);for(;;){if(buf.length<2)return;const op=buf[0]&15;let len=buf[1]&127,off=2;if(len===126){if(buf.length<4)return;len=buf.readUInt16BE(2);off=4;}else if(len===127){if(buf.length<10)return;len=Number(buf.readBigUInt64BE(2));off=10;}
  if(buf.length<off+4+len)return;const mask=buf.slice(off,off+4),pl=Buffer.alloc(len);for(let i=0;i<len;i++)pl[i]=buf[off+4+i]^mask[i%4];buf=buf.slice(off+4+len);
  if(op===8){sock.end();return;}if(op!==1)continue;let m;try{m=JSON.parse(pl.toString());}catch(e){continue;}
  if(m.type==='HEARTBEAT')continue;m.src=id;if(m.type==='LEAVE'){if(m.dst)deliver(m);continue;}
  if(!m.dst)continue;
  if(process.env.KILLFIRST&&m.type==='OFFER'&&/-c-/.test(id)&&!killed.has(id)){killed.add(id);sock.destroy();return;}
  if(!deliver(m))queue.push({m,t:Date.now()});}});
 const bye=()=>{if(process.env.KEEP)return;const c=clients.get(id);if(c&&c.sock===sock)clients.delete(id);};sock.on('close',bye);sock.on('error',bye);});
srv.on('request',(req,res)=>{});
srv.listen(PORT,'127.0.0.1',()=>console.log('sig+http on',PORT));
