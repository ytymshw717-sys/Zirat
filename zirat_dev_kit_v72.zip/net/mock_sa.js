window.__snd={osc:0,buf:0};
(function(){var A=window.AudioContext||window.webkitAudioContext;if(A){var po=A.prototype.createOscillator,pb=A.prototype.createBufferSource;A.prototype.createOscillator=function(){window.__snd.osc++;return po.apply(this,arguments);};A.prototype.createBufferSource=function(){window.__snd.buf++;return pb.apply(this,arguments);};}})();
window.__pres=[];

window.__skipIntro=1;
