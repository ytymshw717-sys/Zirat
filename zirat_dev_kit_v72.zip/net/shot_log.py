from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:9911/arena3_new.html'
INIT=open('/home/claude/net/mock_sa.js').read()+";window.__SIG='ws://127.0.0.1:9911/peerjs';"
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    def page(url):
        c=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2);c.add_init_script(script=INIT);pg=c.new_page();pg.goto(url);pg.wait_for_timeout(3500);return pg
    H=page(BASE)
    for a in ('online','onew'):H.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);H.wait_for_timeout(300)
    H.wait_for_timeout(2500);code=H.evaluate("__net().ocode");F=page(BASE+'#room-'+code);F.wait_for_timeout(4000);H.wait_for_timeout(1000)
    H.screenshot(path='/home/claude/t3/log_host.png',full_page=True);F.screenshot(path='/home/claude/t3/log_friend.png')
    print(H.evaluate("document.getElementById('ov').scrollWidth<=innerWidth"),F.evaluate("document.getElementById('ov').scrollWidth<=innerWidth"))
