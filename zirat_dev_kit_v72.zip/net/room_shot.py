# landscape screenshot of the online screen on the site: before and inside a room
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:9911/arena3_new.html'
INIT=open('/home/claude/net/mock_sa.js').read()+";window.__SIG='ws://127.0.0.1:9911/peerjs';window.__NETMAX=3;"
def act(pg,a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True,device_scale_factor=2);c.add_init_script(script=INIT)
    H=c.new_page();E=[];H.on('pageerror',lambda e:E.append(str(e)));H.goto(BASE);H.wait_for_timeout(3500)
    act(H,'online');H.wait_for_timeout(800);H.screenshot(path='/home/claude/t3/is/room0.png')
    act(H,'onew')
    for i in range(60):
        if 'קוד החדר' in H.evaluate("document.getElementById('ov').innerText"):break
        H.wait_for_timeout(250)
    link=H.evaluate("document.getElementById('roomLink').textContent")
    c2=b.new_context(viewport={'width':390,'height':844});c2.add_init_script(script=INIT);F=c2.new_page();F.goto(link);F.wait_for_timeout(9000)
    H.wait_for_timeout(1500);H.screenshot(path='/home/claude/t3/is/room1.png')
    print('players', H.evaluate("(document.getElementById('roomN')||{}).textContent"),'errors',E[:3])
