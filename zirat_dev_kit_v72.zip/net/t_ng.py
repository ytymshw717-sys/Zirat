# shared online match: the host's game is the real one, friends steer their hero and see the same world
import sys
from playwright.sync_api import sync_playwright
BASE='http://127.0.0.1:9911/arena3_new.html'
MOCK=open('/home/claude/net/mock_sa.js').read()
INIT=MOCK+";window.__SIG='ws://127.0.0.1:9911/peerjs';window.__NETMAX=4;"
res=[];errs=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
def act(pg,a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(120)
def ovt(pg):return pg.evaluate("document.getElementById('ov').innerText")
def until(pg,js,t=20,step=250):
    for i in range(int(t*1000/step)):
        try:
            v=pg.evaluate(js)
            if v:return v
        except Exception as e:pass
        pg.wait_for_timeout(step)
    return None
SAVE='{"owned":[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19],"gold":500,"dm":60,"xp":5000,"lv":{"5":3,"0":3}}'
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    def page(url,tag,extra=''):
        c=b.new_context(viewport={'width':760,'height':360},has_touch=True,is_mobile=True,device_scale_factor=1)
        c.add_init_script(script=INIT+extra+';try{localStorage.setItem("heroes_arena_save",JSON.stringify(%s))}catch(e){}'%SAVE)
        pg=c.new_page();pg.on('pageerror',lambda e:errs.append(tag+':'+str(e)));pg.on('console',lambda m:errs.append(tag+' console:'+m.text) if m.type=='error' else None)
        pg.goto(url);pg.wait_for_timeout(3500);return pg
    for variant in ('direct','relay'):
        tag=variant
        H=page(BASE,'host-'+tag)
        act(H,'online');act(H,'onew')
        until(H,"!!(__net().rm&&__net().rm.isHost)",15)
        code=H.evaluate("__net().ocode");link=H.evaluate("__net().link(__net().ocode)")
        F=page(link,'friend-'+tag,';window.__NODIRECT=1;window.__NETRELAY=1;' if variant=='relay' else '')
        ok(tag+': friend joined the room',until(F,"!!(__net().rm&&!__net().rm.isHost)",30))
        if variant=='relay':ok(tag+': friend is on the backup (relay) path',F.evaluate("__net().rm.relayed()"))
        act(F,'menu');act(F,'pk:0:5');act(F,'menu')
        ok(tag+': host knows the friend hero from the lobby',until(H,"__net().opeers.some(function(q){return q.presence&&q.presence.h===5})",10))
        act(H,'menu');act(H,'mode:survive')
        ok(tag+': host starts → friend is pulled into the same match',until(F,"__net().NG.cli===1&&__arena().state==='play'",10))
        ok(tag+': host world has the friend as a real player (hero 5)',H.evaluate("(function(A){return A.ps.length===2&&!!A.ps[1].net&&A.ps[1].ch.idx===5})(__arena())"))
        ok(tag+': same map on both',H.evaluate("__arena().wi")==F.evaluate("__arena().wi"),'%s %s'%(H.evaluate("__arena().wi"),F.evaluate("__arena().wi")))
        ne=until(H,"__arena().enemies.length",25)
        until(F,"__arena().enemies.length",10);F.wait_for_timeout(800)
        he=H.evaluate("__arena().enemies.length");fe=F.evaluate("__arena().enemies.length")
        ok(tag+': friend sees the host enemies',fe>0 and abs(he-fe)<=2,'host %s friend %s'%(he,fe))
        # positions of a host enemy vs friend copy
        d=F.evaluate("(function(){var A=__arena();return A.enemies.map(function(e){return [Math.round(e.x),Math.round(e.y),e.t]})})()")
        hd=H.evaluate("(function(){var A=__arena();return A.enemies.map(function(e){return [Math.round(e.x),Math.round(e.y),e.t]})})()")
        close=sum(1 for a in d if any(abs(a[0]-q[0])<60 and abs(a[1]-q[1])<60 and a[2]==q[2] for q in hd))
        ok(tag+': enemy positions match (within lag)',d and close>=len(d)-1,'%d/%d'%(close,len(d)))
        H.evaluate("(function(){var A=__arena();A.ps.forEach(function(p){p.hp=p.mhp=5000;});A.enemies.forEach(function(e){e.stun=999;e.cd=999;});})()")
        x0=F.evaluate("__arena().ps[0].x");hx0=H.evaluate("__arena().ps[1].x")
        F.keyboard.down('KeyD');F.wait_for_timeout(4000);F.keyboard.up('KeyD');F.wait_for_timeout(1500)
        x1=F.evaluate("__arena().ps[0].x");hx1=H.evaluate("__arena().ps[1].x")
        ok(tag+': friend moves on own screen',x1-x0>25,'%s -> %s'%(x0,x1))
        ok(tag+': host sees the friend move to the same spot',abs(hx1-x1)<25 and hx1-hx0>25,'friend %s host %s'%(x1,hx1))
        # friend attacks an enemy placed next to them on the host
        hp0=H.evaluate("(function(){var A=__arena(),p=A.ps[1],e=A.enemies[0];e.x=p.x+45;e.y=p.y;e.hp=e.maxhp=400;e.stun=999;A.enemies.slice(1).forEach(function(q){q.x=40;q.y=40;});p.fx=1;p.fy=0;return e.hp;})()")
        F.wait_for_timeout(600)
        for k in range(6):
            F.evaluate("__arena().ps[0].fx=1;__arena().ps[0].fy=0");F.keyboard.down('Space');F.wait_for_timeout(120);F.keyboard.up('Space');F.wait_for_timeout(450)
        hp1=H.evaluate("__arena().enemies.length?__arena().enemies[0].hp:0")
        ok(tag+': friend attack damages the host enemy',hp1<hp0,'%s -> %s'%(hp0,hp1))
        ok(tag+': friend sees shots / effects from the host',until(F,"__arena().shots.length>0||__arena().parts.length>0",5) is not None)
        H.evaluate("__arena().ps[1].hp=1234")
        ok(tag+': friend health comes from the host',until(F,"Math.round(__arena().ps[0].hp)===1234",6))
        H.evaluate("(function(){var p=__arena().ps[1];p.x=120;p.y=140;})()")
        ok(tag+': host teleports the friend (respawn) → friend jumps there',until(F,"Math.abs(__arena().ps[0].x-120)<30&&Math.abs(__arena().ps[0].y-140)<30",6),str(F.evaluate("[__arena().ps[0].x,__arena().ps[0].y]")))
        F.wait_for_timeout(800)
        fx0=F.evaluate("__arena().ps[0].x");H.evaluate("__arena().ps[1].kx=700")
        ok(tag+': knockback / dash from the host moves the friend',until(F,"__arena().ps[0].x>%f+35"%fx0,6),str(F.evaluate("__arena().ps[0].x")))
        act(H,'pz') if False else H.evaluate("document.getElementById('pz').click()")
        ok(tag+': host pause → friend told',until(F,"(document.getElementById('ngWait')||{}).textContent||''",6))
        act(H,'res')
        ok(tag+': host resume → message gone',until(F,"!document.getElementById('ngWait')",6))
        ok(tag+': friend draws the host label',F.evaluate("__net().NG.hn!==undefined"))
        # friend leaves mid match
        F.evaluate("document.getElementById('pz').click()");act(F,'menu')
        ok(tag+': friend leaves → host drops the player',until(H,"__arena().ps.length===1",8))
        # stage with victory
        act(H,'menu');act(H,'stage:0')
        ok(tag+': second match → friend pulled again',until(F,"__net().NG.cli===1&&__arena().state==='play'",10))
        for k in range(120):
            st=H.evaluate("(function(){var A=__arena();A.ps.forEach(function(p){p.hp=p.mhp;});A.enemies.forEach(function(e){e.hp=0;});return A.state;})()")
            if st=='over':break
            if st=='shop':act(H,'next')
            H.wait_for_timeout(250)
        ok(tag+': host wins',st=='over')
        ok(tag+': friend gets the victory screen too',until(F,"__arena().state==='over'&&!!document.querySelector('#ov .vsW')",8))
        ok(tag+': shared match flags cleared',F.evaluate("__net().NG.on")==0 and H.evaluate("__net().NG.on")==0)
        # ---- one against the other ----
        act(F,'menu');act(H,'menu');H.wait_for_timeout(400)
        H.evaluate("(function(){var b=document.createElement('button');b.dataset.a='mode:pvp';document.getElementById('ov').appendChild(b);b.click();})()")
        ok(tag+': versus: friend pulled in on the other side',until(F,"__net().NG.cli===1&&__net().NG.side===1&&__arena().state==='play'",10))
        me=F.evaluate("__net().rm.me")
        ok(tag+': versus: host has the friend as the rival hero',until(H,"__arena().enemies.some(function(e){return e.net===%r})"%me,6))
        ok(tag+': versus: no bots in a 1 v 1',H.evaluate("__arena().tb.length")==0 and H.evaluate("__arena().enemies.length")==1)
        ok(tag+': versus: friend sees the host as the enemy, self as the player',until(F,"__arena().ps.length===1&&__arena().enemies.some(function(e){return e.t==='hero'})&&__arena().ps[0].hp>0",8))
        F.wait_for_timeout(800)
        def rv(js):return H.evaluate("(function(){var e=__arena().enemies.filter(function(e){return e.net===%r})[0];return e?(%s):null})()"%(me,js))
        fx0=F.evaluate("__arena().ps[0].x");F.keyboard.down('KeyA');F.wait_for_timeout(3000);F.keyboard.up('KeyA');F.wait_for_timeout(1500)
        fx1=F.evaluate("__arena().ps[0].x");hx=rv("e.x")
        ok(tag+': versus: friend moves, host sees the rival there',hx is not None and abs(hx-fx1)<25 and abs(fx1-fx0)>15,'friend %s->%s host %s'%(fx0,fx1,hx))
        H.evaluate("(function(){var A=__arena(),p=A.ps[0],e=A.enemies.filter(function(e){return e.net===%r})[0];p.hp=p.mhp=3000;p.inv=0;p.sh=0;p.x=e.x+40;p.y=e.y;e.inv=0;})()"%me)
        hp0=H.evaluate("__arena().ps[0].hp");F.wait_for_timeout(500)
        for k in range(6):
            F.keyboard.down('Space');F.wait_for_timeout(120);F.keyboard.up('Space');F.wait_for_timeout(500)
            H.evaluate("(function(){var A=__arena(),p=A.ps[0],e=A.enemies.filter(function(e){return e.net===%r})[0];if(e){p.x=e.x+40;p.y=e.y;p.inv=0;}})()"%me)
        hp1=H.evaluate("__arena().ps[0].hp")
        ok(tag+': versus: friend hurts the host',hp1<hp0,'%s -> %s'%(hp0,hp1))
        e0=rv("e.hp");H.evaluate("(function(){var A=__arena(),p=A.ps[0],e=A.enemies.filter(function(e){return e.net===%r})[0];e.inv=0;e.hp=e.maxhp=50;p.x=e.x+40;p.y=e.y;p.cd=0;})()"%me)
        for k in range(4):
            H.keyboard.down('Space');H.wait_for_timeout(120);H.keyboard.up('Space');H.wait_for_timeout(400)
        e1=rv("e.hp")
        ok(tag+': versus: host hurts the friend',e1 is not None and e1<50,'%s'%e1)
        ok(tag+': versus: friend health follows',until(F,"__arena().ps[0].hp<50&&__arena().ps[0].hp>0",6),str(F.evaluate("__arena().ps[0].hp")))
        H.evaluate("(function(){var e=__arena().enemies.filter(function(e){return e.net===%r})[0];e.hp=0;})()"%me)
        ok(tag+': versus: knock-out → friend is down and told',until(F,"__arena().ps[0].hp<=0",6))
        ok(tag+': versus: score counts for the host side (friend sees 0 - 1)',until(F,"__arena().tko[0]===0&&__arena().tko[1]===1",6),str(F.evaluate("__arena().tko")))
        ok(tag+': versus: friend comes back after the respawn',until(F,"__arena().ps[0].hp>0",40))
        H.evaluate("__arena().tko[0]=5")
        ok(tag+': versus: host side wins → friend gets the lose screen',until(F,"__arena().state==='over'&&!!document.querySelector('#ov .lsP')",10))
        ok(tag+': versus: host gets the win screen',until(H,"__arena().state==='over'&&!!document.querySelector('#ov .vsP')",6))
        # 3v3 with a friend: one bot ally less
        act(F,'menu');act(H,'menu');act(H,'mode:team')
        until(F,"__net().NG.cli===1",10);H.wait_for_timeout(1500)
        al=H.evaluate("__arena().tb.filter(function(b){return !b.tm}).length")
        ok(tag+': 3v3 with a friend → 2 players + 1 bot ally',al==1 and H.evaluate("__arena().ps.length")==2,'allies %s'%al)
        ok(tag+': friend sees the bots',until(F,"__arena().tb.length>=1",6))
        if variant=='direct':
            act(F,'menu');act(H,'menu');act(H,'mode:survive')
            until(F,"__net().NG.cli===1",10);until(H,"__arena().enemies.length",20);F.wait_for_timeout(1000)
            F.evaluate("window.__netKill&&window.__netKill()")
            ok(tag+': direct link breaks mid-game → friend switches to the backup path',until(F,"__net().rm&&__net().rm.relayed()",8))
            q0=F.evaluate("__net().NG.lq");F.wait_for_timeout(4000)
            ok(tag+': game keeps flowing after the switch (no disconnect)',F.evaluate("__net().NG.lq")>q0 and F.evaluate("__net().NG.cli")==1 and H.evaluate("__arena().ps.length")==2,'%s -> %s'%(q0,F.evaluate("__net().NG.lq")))
            F.keyboard.down('KeyD');F.wait_for_timeout(2500);F.keyboard.up('KeyD');F.wait_for_timeout(1500)
            ok(tag+': friend still steers on the backup path',abs(H.evaluate("__arena().ps[1].x")-F.evaluate("__arena().ps[0].x"))<30)
        F.screenshot(path='/home/claude/shots/ng_%s_friend.png'%tag);H.screenshot(path='/home/claude/shots/ng_%s_host.png'%tag)
        act(H,'menu')
        ok(tag+': host quits → friend told and back to the online screen',until(F,"__net().NG.on===0&&__arena().state==='menu'",8))
        if variant=='direct':
            act(H,'online');H.wait_for_timeout(300);act(H,'menu');act(H,'mode:survive');until(F,"__net().NG.cli===1",10)
            H.evaluate("(function(){var b=document.createElement('button');b.dataset.a='ol';document.getElementById('ov').appendChild(b);b.click();})()")
            ok(tag+': host closes the room mid-match → friend leaves the match with a message',until(F,"__net().NG.on===0&&__arena().state==='menu'&&document.getElementById('ov').innerText.indexOf('נותק')+document.getElementById('ov').innerText.indexOf('סגר')>-2",30),F.evaluate("document.getElementById('ov').innerText.slice(0,120)"))
        H.context.close();F.context.close()
    # host away while the friend opens the link
    F=page(BASE+'#room-wait77','late',';window.__NETWAIT=40000;')
    ok('friend waits for an away host (clear message)',until(F,"document.getElementById('ov').innerText.indexOf('מחכה שיחזור')>=0",15))
    H=page(BASE,'late-host');act(H,'online');H.evaluate("__net().host('wait77')")
    ok('host comes back → friend joins automatically',until(F,"!!(__net().rm&&!__net().rm.isHost)",30))
    ok('no JS errors',not errs,str(errs[:6]))
    print('SUMMARY %d/%d'%(sum(res),len(res)))
