import subprocess,time,sys
from playwright.sync_api import sync_playwright
F=sys.argv[1];INIT=open('/home/claude/net/mock_sa.js').read()+";window.__SIG='ws://127.0.0.1:9913/peerjs';"
http=subprocess.Popen(['python3','-m','http.server','9914','--bind','127.0.0.1'],cwd='/home/claude',stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(1)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    sig=subprocess.Popen(['node','/home/claude/net/sig.js','9913','/home/claude'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL);time.sleep(1.5)
    c=b.new_context(viewport={'width':390,'height':844});c.add_init_script(script=INIT);H=c.new_page();H.goto('http://127.0.0.1:9914/'+F);H.wait_for_timeout(3500)
    for a in ('online','onew'):H.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);H.wait_for_timeout(300)
    H.wait_for_timeout(2500);code=H.evaluate("__net().ocode")
    sig.terminate();sig.wait()          # room server briefly unreachable…
    c2=b.new_context(viewport={'width':390,'height':844});c2.add_init_script(script=INIT);Fr=c2.new_page();Fr.goto('http://127.0.0.1:9914/'+F+'#room-'+code)
    time.sleep(4.5);sig=subprocess.Popen(['node','/home/claude/net/sig.js','9913','/home/claude'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)   # …and back
    t0=time.time();ok=False
    while time.time()-t0<40:
        if Fr.evaluate("!!__net().rm"):ok=True;break
        Fr.wait_for_timeout(500)
    print(F,'friend joins after the server was briefly unreachable:',ok,'| friend screen:',Fr.evaluate("document.getElementById('ov').innerText.split('\\n').slice(-4).join(' / ')")[:120])
    sig.terminate()
http.terminate()
