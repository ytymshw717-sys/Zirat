# online smoothness: both heroes walk in circles; we record, every frame, how each screen draws the OTHER hero.
# usage: python3 net/t_smooth.py [jitter 0/1] [seconds] [3d 0/1]
# jitter=1: messages are held and released in bursts (like phone wifi), both ways.
import sys, json, math
from playwright.sync_api import sync_playwright
JIT = int(sys.argv[1]) if len(sys.argv) > 1 else 1
SEC = float(sys.argv[2]) if len(sys.argv) > 2 else 20
G3 = int(sys.argv[3]) if len(sys.argv) > 3 else 0
CPU = float(sys.argv[4]) if len(sys.argv) > 4 else 1
BASE = 'http://127.0.0.1:9911/arena3_new.html'
MOCK = open('/home/claude/net/mock_sa.js').read()
INIT = MOCK + ";window.__SIG='ws://127.0.0.1:9911/peerjs';window.__NETMAX=4;"
# bursty network: each data-channel message waits until the next 'release', releases come every 30-260 ms
JITJS = """
(function(){var Q=[],busy=false;var o=RTCDataChannel.prototype.send;
 function rel(){busy=false;var q=Q;Q=[];q.forEach(function(m){try{if(m[0].readyState==='open')o.call(m[0],m[1]);}catch(e){}});}
 RTCDataChannel.prototype.send=function(d){if(!window.__JIT)return o.call(this,d);Q.push([this,d]);if(!busy){busy=true;setTimeout(rel,30+Math.random()*230);}};})();
"""
# per-frame recorder + a bot that walks a circle (radius 90, ~1 turn / 4 s)
REC = """
window.__rec=[];window.__T0=0;
window.__bot0=function(p){if(!window.__WALK)return null;var t=performance.now()/1000*1.6;return {x:Math.cos(t),y:Math.sin(t),a:false,s:false,u:false,g:false};};
(function f(){try{if(window.__RECON){var A=__arena(),N=__net().NG,o=null;
 if(N.host){o=A.ps[1];}else if(N.cli){o=A.ps.filter(function(p){return p!==A.ps[0]})[0];}
 var me=A.ps[0];window.__rec.push([performance.now(),o?o.x:null,o?o.y:null,me?me.x:null,me?me.y:null,N.host&&o?(o.tpN|0):0,N.host&&o&&N.pl[o.net]?(N.pl[o.net].tp|0):0]);}}catch(e){}
 requestAnimationFrame(f);})();
"""
SAVE = '{"owned":[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19],"gold":500,"dm":60,"xp":5000,"lv":{"5":3,"0":3}}'
errs = []
def act(pg, a): pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')" % a); pg.wait_for_timeout(120)
def until(pg, js, t=20, step=250):
    for i in range(int(t * 1000 / step)):
        try:
            v = pg.evaluate(js)
            if v: return v
        except Exception: pass
        pg.wait_for_timeout(step)
    return None

def stats(rec, col_x, col_y, label):
    # rec rows: t, ox, oy ... ; analyse the drawn path of the other hero
    pts = [(r[0], r[col_x], r[col_y]) for r in rec if r[col_x] is not None]
    if len(pts) < 10: return {'label': label, 'n': len(pts)}
    jumps = 0; rev = 0; still = 0; maxj = 0; frames = len(pts) - 1; dts = []
    stillrun = 0; maxstill = 0
    prev = None
    for i in range(1, len(pts)):
        dt = pts[i][0] - pts[i-1][0]; dts.append(dt)
        dx = pts[i][1] - pts[i-1][1]; dy = pts[i][2] - pts[i-1][2]; d = math.hypot(dx, dy)
        maxj = max(maxj, d)
        if d > 25: jumps += 1
        if d < 0.01:
            stillrun += dt; maxstill = max(maxstill, stillrun); still += 1
        else: stillrun = 0
        if prev and d > 2 and prev[2] > 2 and (dx * prev[0] + dy * prev[1]) < -0.3 * d * prev[2]: rev += 1
        if d > 0.01: prev = (dx, dy, d)
    dts.sort()
    return {'label': label, 'frames': frames, 'fps': round(1000 * frames / (pts[-1][0] - pts[0][0]), 1),
            'frame_ms_p50': round(dts[len(dts)//2]), 'frame_ms_p95': round(dts[int(len(dts)*.95)]),
            'jumps>25px': jumps, 'max_jump_px': round(maxj), 'back_and_forth': rev,
            'still_frames%': round(100 * still / frames), 'longest_freeze_ms': round(maxstill)}

with sync_playwright() as p:
    args = ['--use-angle=swiftshader', '--enable-unsafe-swiftshader'] if G3 else ['--disable-3d-apis']
    b = p.chromium.launch(args=args)
    def page(url, tag, extra=''):
        c = b.new_context(viewport={'width': 760, 'height': 360}, has_touch=True, is_mobile=True, device_scale_factor=1)
        c.add_init_script(script=INIT + JITJS + REC + extra + ';try{localStorage.setItem("heroes_arena_save",JSON.stringify(%s))}catch(e){}' % SAVE)
        pg = c.new_page(); pg.on('pageerror', lambda e: errs.append(tag + ':' + str(e)))
        if CPU > 1: c.new_cdp_session(pg).send('Emulation.setCPUThrottlingRate', {'rate': CPU})
        pg.goto(url); pg.wait_for_timeout(3500 * min(CPU, 3)); return pg
    H = page(BASE, 'host')
    act(H, 'online'); act(H, 'onew')
    until(H, "!!(__net().rm&&__net().rm.isHost)", 15)
    link = H.evaluate("__net().link(__net().ocode)")
    F = page(link, 'friend')
    print('joined', bool(until(F, "!!(__net().rm&&!__net().rm.isHost)", 30)), 'relay' if F.evaluate("__net().rm&&__net().rm.relayed()") else 'direct', flush=True)
    act(F, 'menu'); act(H, 'menu'); act(H, 'mode:survive')
    print('in match', bool(until(F, "__net().NG.cli===1&&__arena().state==='play'", 15)), flush=True)
    # no fighting: immortal heroes, frozen far-away enemies, so only the network moves things
    H.evaluate("(function(){var A=__arena();A.ps.forEach(function(p){p.hp=p.mhp=99999;});})()")
    H.evaluate("setInterval(function(){try{__arena().enemies.forEach(function(e){e.x=30;e.y=30;e.stun=99;e.cd=99;});__arena().ps.forEach(function(p){p.hp=99999;})}catch(e){}},200)")
    for pg in (H, F): pg.evaluate("window.__JIT=%d;window.__WALK=1;" % JIT)
    H.wait_for_timeout(1500)
    for pg in (H, F): pg.evaluate("window.__rec=[];window.__RECON=1;")
    H.wait_for_timeout(int(SEC * 1000))
    rh = H.evaluate("window.__rec"); rf = F.evaluate("window.__rec")
    sh = stats(rh, 1, 2, 'HOST screen: friend hero'); sf = stats(rf, 1, 2, 'FRIEND screen: host hero')
    so = stats(rf, 3, 4, 'FRIEND screen: own hero'); print(json.dumps(stats(rh, 3, 4, 'HOST screen: own hero')))
    tpst = sum(1 for r in rh if r[5] > r[6])
    print(json.dumps(sh)); print(json.dumps(sf)); print(json.dumps(so))
    print('host frames where friend input is ignored (tpN>tp):', tpst, 'of', len(rh), ' final tpN/tp', rh[-1][5] if rh else '', rh[-1][6] if rh else '')
    def ok(n, c, i=''): print(('PASS ' if c else 'FAIL ') + n, i, flush=True); return c
    r = [ok('host sees the friend walk smoothly (no freeze, no jump)', sh.get('longest_freeze_ms', 9e9) < 250 and sh.get('max_jump_px', 99) < 40, str(sh.get('longest_freeze_ms')) + 'ms ' + str(sh.get('max_jump_px')) + 'px'),
         ok('friend sees the host walk smoothly', sf.get('longest_freeze_ms', 9e9) < 250 and sf.get('max_jump_px', 99) < 40, str(sf.get('longest_freeze_ms')) + 'ms ' + str(sf.get('max_jump_px')) + 'px'),
         ok('friend is never pulled back on own screen', so.get('back_and_forth', 9) == 0 and so.get('max_jump_px', 99) < 30),
         ok('host never ignores the friend (false teleport)', tpst == 0, str(tpst)),
         ok('no JS errors', not errs, str(errs[:3]))]
    print('SUMMARY %d/%d' % (sum(r), len(r)))
    b.close()
