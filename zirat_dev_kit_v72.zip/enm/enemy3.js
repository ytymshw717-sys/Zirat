/* sculpted enemies (player's Tripo models): vertex-coloured meshes, rigid body with procedural walk / wind-up / lunge / hit flash */
var EGG={},EGT={grunt:['robot',3.6],tank:['robot',3.4],fast:['warrior',4.3],archer:['warrior',4.1],boss:['demon',4.0]};
function egGeo(k){if(EGG[k])return EGG[k];var m=EGLB[k],bs=atob(m.d),u8=new Uint8Array(bs.length);for(var i=0;i<bs.length;i++)u8[i]=bs.charCodeAt(i);
 var nv=m.nv,nf=m.nf,q=new Uint16Array(u8.buffer,0,nv*3),ix=new Uint16Array(u8.buffer.slice(nv*6,nv*6+nf*6)),vc=u8.subarray(nv*6+nf*6,nv*6+nf*6+nv*3),P=new Float32Array(nv*3),C=new Float32Array(nv*3);
 for(i=0;i<nv;i++)for(var c=0;c<3;c++){P[i*3+c]=m.mn[c]+q[i*3+c]/65535*(m.mx[c]-m.mn[c]);C[i*3+c]=Math.min(1,vc[i*3+c]/255*1.08);}
 var g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(P,3));g.setAttribute('color',new THREE.BufferAttribute(C,3));g.setIndex(new THREE.BufferAttribute(ix,1));g.computeVertexNormals();g.computeBoundingSphere();EGG[k]=g;return g;}
function egMat(){var mt=new THREE.MeshToonMaterial({color:'#ffffff',vertexColors:true,gradientMap:toonGrad(),side:THREE.DoubleSide});
 mt.onBeforeCompile=function(sh){sh.fragmentShader=sh.fragmentShader.replace('vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;','vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;\noutgoingLight=mix(outgoingLight,diffuseColor.rgb*1.06+totalEmissiveRadiance,0.42);');try{rimHook(sh);}catch(e){}};
 mt.customProgramCacheKey=function(){return 'egFlat';};return mt;}
function r3mon(en,TT){
 var ty=EGT[en.t];if(!ty)return null;var e=R3.ents.get(en);
 if(!e){var k=ty[0],hk=ty[1];if(en.t==='boss'){if(en.bv==null){en.bv=R3.bossN=((R3.bossN||0)+1)%2;}if(en.bv===1){k='dragon';hk=3.3;}}
  if(!EGLB[k])return null;
  var grp=new THREE.Group(),pv=new THREE.Group(),mt=egMat(),mesh=new THREE.Mesh(egGeo(k),mt);mesh.castShadow=true;pv.add(mesh);grp.add(pv);
  if(en.t==='fast')mt.color.set('#ffd9bf');else if(en.t==='tank')mt.color.set('#ddd0ff');
  var wr=new THREE.Mesh(R3.T.flat,r3mat('#fde047',true,.85));wr.rotation.x=-Math.PI/2;wr.position.y=.04;grp.add(wr);
  R3.sc.add(grp);e={g:grp,pv:pv,mesh:mesh,bm:mt,wr:wr,blob:1,egl:1,k:k,hk:hk,age:0,face:null,ph:0};R3.ents.set(en,e);
  R3.nSpawn=(R3.nSpawn||0)+1;var sx=r3x(en.x),sz=r3z(en.y),sc0=en.t==='boss'?2:1;r3fx('ring',sx,.08,sz,{c:en.t==='boss'?'#f43f5e':'#c084fc',life:.45,s0:.2*sc0,s1:1.3*sc0,op:.8});if(!R3.low)for(var q=0;q<3;q++){var a0=q/3*6.283;r3fx('puff',sx+Math.cos(a0)*.2,.12,sz+Math.sin(a0)*.2,{c:'#d8b4fe',life:.5,vx:Math.cos(a0)*.7,vz:Math.sin(a0)*.7,vy:.4,s0:.12,s1:.4*sc0,op:.5});}}
 e.seen=R3.frameNo;return e;}
function r3monPose(e,en,TT,g,t){
 var x=r3x(en.x),z=r3z(en.y),H=en.r*R3U*e.hk,dt=Math.min(.05,Math.max(0,t-(e.lt||t)));e.lt=t;e.age+=dt;
 if(e.px==null){e.px=x;e.pz=z;e.sp=0;}
 var dd=Math.hypot(x-e.px,z-e.pz);if(dd>2)dd=0;e.px=x;e.pz=z;
 e.sp+=((dt>0?dd/dt:0)-e.sp)*Math.min(1,dt*10);e.ph+=dd/Math.max(.3,H)*7;
 var mv=Math.min(1,e.sp/(.5*Math.max(.5,H)));
 var near=null,bd=1e9;g.ps.forEach(function(p){if(p.hp<=0)return;var d=Math.hypot(p.x-en.x,p.y-en.y);if(d<bd){bd=d;near=p;}});
 var want=near?Math.atan2(near.x-en.x,near.y-en.y):(e.face||0);if(e.face==null)e.face=want;
 var df=want-e.face;df=((df+Math.PI)%(2*Math.PI)+2*Math.PI)%(2*Math.PI)-Math.PI;e.face+=df*(1-Math.exp(-10*dt));
 var pop=Math.min(1,e.age/.35),sp=pop<1?(1-Math.pow(1-pop,3))*(1+.15*Math.sin(pop*Math.PI)):1;
 var wind=en.state==='wind',wk=wind?Math.max(0,Math.min(1,1-en.wind/(TT.wind||.5))):0;
 if(e.wasWind&&!wind)e.lunge=1;e.wasWind=wind;e.lunge=Math.max(0,(e.lunge||0)-dt*4);
 var fl0=en.flash>0;if(fl0&&!e.fw)e.hit=1;e.fw=fl0;e.hit=Math.max(0,(e.hit||0)-dt*5);var hk=e.hit*e.hit,br=(1-mv)*Math.sin(t*3+en.x*.1);
 var hov=e.k==='dragon'?H*.12+Math.sin(t*2.2+en.x*.05)*.07:0;
 e.g.position.set(x,0,z);e.g.rotation.y=e.face;e.g.visible=!en.hid;
 e.pv.position.y=hov+Math.abs(Math.sin(e.ph))*.05*H*mv;
 e.pv.rotation.z=Math.sin(e.ph)*.07*mv+(e.k==='dragon'?Math.sin(t*1.3)*.05:0);
 e.pv.rotation.x=.1*mv-.28*wk+.38*e.lunge-.34*hk;e.pv.position.z=-.14*H*hk;
 var s=H*sp*(1+.06*wk);e.mesh.scale.set(s*(1+.08*hk),s*(1-.04*Math.abs(Math.cos(e.ph))*mv)*(1-.12*hk)*(1+.025*br),s*(1+.08*hk));
 var f=en.flash>0;e.bm.emissive.setRGB(f?.85:wk*.3,f?.85:wk*.2,f?.85:0);
 e.wr.visible=wind;if(wind){e.wr.scale.setScalar((en.r+(TT.reach||20)*.6+(en.wind||0)*8)*R3U);e.wr.material=r3mat('#fde047',true,Math.round(Math.min(.95,.45+.55*wk)*10)/10);}
}
/* defeated: white flash, squash-and-vanish, a ring, sparks and dust */
function r3death(e){R3.nDeath=(R3.nDeath||0)+1;var p=e.g.position,col=e.k==='dragon'?'#ff7a1a':e.k==='demon'?'#c084fc':e.k==='warrior'?'#f87171':'#fde047';
 r3fx('ring',p.x,.08,p.z,{c:'#ffffff',life:.35,s0:.2,s1:1.6,op:.8});r3fx('glow',p.x,.8,p.z,{c:col,life:.25,s0:1.6,s1:.4,op:1});
 for(var q=0;q<(R3.low?3:8);q++){var a=q/8*6.283+Math.random()*.5,sp=2+Math.random()*2;r3fx('spark',p.x,.6,p.z,{c:q%2?col:'#ffffff',life:.42,vx:Math.cos(a)*sp,vz:Math.sin(a)*sp,vy:2+Math.random()*2.5,g:11,s0:.1,s1:.03,op:1});}
 if(!R3.low)for(var j=0;j<4;j++){var b=j/4*6.283;r3fx('puff',p.x+Math.cos(b)*.25,.15,p.z+Math.sin(b)*.25,{life:.55,vx:Math.cos(b)*.8,vz:Math.sin(b)*.8,vy:.5,s0:.15,s1:.45,op:.6});}}
function r3dying(e,t){if(!e.dieT){e.dieT=t;e.ds=e.mesh.scale.x;e.dsy=e.mesh.scale.y;e.wr.visible=false;try{r3death(e);}catch(er){}}
 var p=(t-e.dieT)/.26;if(p>=1)return false;var k=1-p;e.mesh.scale.set(e.ds*(1+.3*p)*k,e.dsy*k*(1-.4*p),e.ds*(1+.3*p)*k);e.pv.rotation.y+=.25;e.pv.position.y+=.02;e.bm.emissive.setRGB(k,k,k);return true;}
