import re
p='/home/claude/g3/g3.js';s=open(p).read()
blk='/*GARDEN-START*/\n'+open('/home/claude/enm/garden3.js').read()+'/*GARDEN-END*/\n'
if '/*GARDEN-START*/' in s: s=re.sub(r'/\*GARDEN-START\*/.*?/\*GARDEN-END\*/\n',lambda m:blk,s,flags=re.S)
else: i=s.index('function r3world(g){');s=s[:i]+blk+s[i:]
th="{sky:'#06141f',fog:[24,55],hs:'#99f6e4',hg:'#042f2e',hi:.5,sc:'#ccfbf1',si:.55,out:'#042f2e',wall:'#0f766e',top:'#22d3ee',topGlow:1}\n];"
if "garden:1" not in s:
    assert s.count(th)==1;s=s.replace(th,"{sky:'#06141f',fog:[24,55],hs:'#99f6e4',hg:'#042f2e',hi:.5,sc:'#ccfbf1',si:.55,out:'#042f2e',wall:'#0f766e',top:'#22d3ee',topGlow:1},\n {sky:'#a6d8ff',fog:[34,70],hs:'#fff1e0',hg:'#4d7c3a',hi:.68,sc:'#ffe1b5',si:.8,out:'#4e8a3a',wall:'#8d8780',top:'#bdb5a8',garden:1}\n];")
ob=" else{put(T.sph,LM('#78716c'),r*1.05,r*.85,r*1.0,x,.6,z);}\n return grp;"
if "K==='stone'" not in s:
    assert s.count(ob)==1
    s=s.replace(ob," else if(K==='stone'){var ico=T.ico||(T.ico=new THREE.IcosahedronGeometry(1,1)),sm=LM('#7c7f86'),sm2=LM('#a3a8b0'),gm=LM('#4f8f3a'),gm2=LM('#6cb04a');put(ico,sm,r*1.0,r*.72,r*.92,x,.48,z,0,i*.7,0);put(ico,sm2,r*.55,r*.4,r*.5,x-r*.3,.78,z+r*.22,0,i,0);put(ico,sm,r*.42,r*.3,r*.4,x+r*.62,.2,z+r*.35,0,i*1.3,0);\n  for(var q=0;q<10;q++){var a=q/10*6.283+i;put(T.cone,q%2?gm:gm2,.12,.3+.08*(q%3),.12,x+Math.cos(a)*r*1.02,.12,z+Math.sin(a)*r*.95,Math.sin(a)*.4,0,-Math.cos(a)*.4,false);}}\n"+ob)
i=s.index('function r3world(g){');j=s.index('\n}\n',i)
body=s[i:j];w="wall(0,-7.05,24.6,.6,.7);wall(0,7.05,24.6,.4,.25);wall(-12.3,0,.6,14.7,.5);wall(12.3,0,.6,14.7,.5);"
if 'r3garden(' not in body:
    assert body.count(w)==1
    body=body.replace(w,"if(th.garden){var gt=r3garden(wg,own,T);if(gt){out.material=new THREE.MeshLambertMaterial({map:gt});own.m.push(out.material);}}else{"+w+"}")
    s=s[:i]+body+s[j:]
open(p,'w').write(s);print('ok',len(s))
