/* hero projectiles with their own look (arrow, fireball, lightning bolt, energy orb, shuriken, bullet, bomb, potion, sound wave, boomerang)
   + a glowing trail behind every shot, a muzzle flash when it is fired and a burst where it lands */
var SHW={shuriken:'star',bow:'arrow',staff:'orb',laser:'bolt',orb:'orb',shotgun:'bullet',bomb:'bomb',fire:'fire',flask:'flask',mic:'wave',guitar:'wave',boomerang:'boom'};
var TRC={arrow:'#dbeafe',fire:'#ff8a2a',bolt:'#5ad1ff',orb:'#c084fc',star:'#e2e8f0',bullet:'#ffd166',bomb:'#9ca3af',flask:'#34d399',wave:'#f472b6',boom:'#fbbf24',axe:'#f87171',rbolt:'#ff4d6d',breath:'#ff6a1f',eorb:'#ef4444',dot:'#fde047'};
function r3glowTex(){if(R3.glowTex)return R3.glowTex;var c=document.createElement('canvas');c.width=c.height=64;var x=c.getContext('2d'),g=x.createRadialGradient(32,32,1,32,32,32);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.35,'rgba(255,255,255,.55)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,64,64);R3.glowTex=new THREE.CanvasTexture(c);return R3.glowTex;}
function r3glow(col,s){var m=new THREE.SpriteMaterial({map:r3glowTex(),color:col,transparent:true,depthWrite:false,depthTest:false,blending:THREE.AdditiveBlending});var sp=new THREE.Sprite(m);sp.scale.set(s,s,1);sp.renderOrder=5;return sp;}
/* trail: a soft streak, bright at the shot and fading behind it (two crossed planes so it reads from any camera angle) */
function r3trailTex(){if(R3.trTex)return R3.trTex;var c=document.createElement('canvas');c.width=16;c.height=64;var x=c.getContext('2d'),im=x.createImageData(16,64);
 for(var y=0;y<64;y++)for(var i=0;i<16;i++){var along=Math.pow(y/63,1.6),across=Math.max(0,1-Math.abs(i-7.5)/8),a=along*Math.pow(across,1.3),o=(y*16+i)*4;im.data[o]=im.data[o+1]=im.data[o+2]=255;im.data[o+3]=Math.round(255*a);}
 x.putImageData(im,0,0);R3.trTex=new THREE.CanvasTexture(c);return R3.trTex;}
function r3trailGeo(){var T=R3.T;if(T.trail)return T.trail;var g=new THREE.PlaneGeometry(1,1);g.rotateX(-Math.PI/2);g.translate(0,0,-.5);T.trail=g;return g;}
function r3trailMat(col){R3.trMats=R3.trMats||{};return R3.trMats[col]||(R3.trMats[col]=new THREE.MeshBasicMaterial({map:r3trailTex(),color:col,transparent:true,opacity:.85,depthWrite:false,blending:THREE.AdditiveBlending,side:THREE.DoubleSide}));}
function r3trail(col){var tg=new THREE.Group(),a=new THREE.Mesh(r3trailGeo(),r3trailMat(col));a.rotation.z=.35;tg.add(a);tg.userData.trail=1;return tg;}
function r3shotBody(k){var T=R3.T,g=new THREE.Group(),M=function(c,b){return r3mat(c,b!==false);};
 if(k==='arrow'){var sh=new THREE.Mesh(T.cyl,r3mat('#8b5a2b'));sh.scale.set(.025,.62,.025);sh.rotation.x=Math.PI/2;g.add(sh);var hd=new THREE.Mesh(T.cone,M('#e5e7eb'));hd.scale.set(.06,.16,.06);hd.rotation.x=Math.PI/2;hd.position.z=.36;g.add(hd);
  [-1,1].forEach(function(s){var f=new THREE.Mesh(T.box,M('#22c55e'));f.scale.set(.1,.01,.12);f.position.set(s*.04,0,-.28);f.rotation.z=s*.6;g.add(f);});var tip=r3glow('#e0f2fe',.3);tip.position.z=.4;g.add(tip);}
 else if(k==='fire'){var c=new THREE.Mesh(T.sph,M('#fff3b0'));c.scale.setScalar(.11);g.add(c);var o=new THREE.Mesh(T.sph,M('#fb923c'));o.scale.set(.17,.17,.24);o.position.z=-.04;o.material=r3mat('#f97316',true,.75);g.add(o);g.add(r3glow('#ff7a1a',.9));g.userData.flick=1;g.userData.ember=1;}
 else if(k==='bolt'){var b=new THREE.Mesh(T.cyl,M('#e0faff'));b.scale.set(.035,.75,.035);b.rotation.x=Math.PI/2;g.add(b);var b2=new THREE.Mesh(T.cyl,r3mat('#38bdf8',true,.6));b2.scale.set(.08,.8,.08);b2.rotation.x=Math.PI/2;g.add(b2);
  for(var i=0;i<3;i++){var z=new THREE.Mesh(T.box,M('#a5f3fc'));z.scale.set(.03,.03,.22);z.position.set((i%2?1:-1)*.06,0,-.15+i*.18);z.rotation.y=(i%2?1:-1)*.8;g.add(z);}g.add(r3glow('#38bdf8',.8));g.userData.zap=1;}
 else if(k==='orb'){var c2=new THREE.Mesh(T.sph,M('#ffffff'));c2.scale.setScalar(.08);g.add(c2);var o2=new THREE.Mesh(T.sph,r3mat('#a855f7',true,.7));o2.scale.setScalar(.16);g.add(o2);g.userData.tint=o2;g.add(r3glow('#c084fc',.85));g.userData.pulse=1;}
 else if(k==='star'){var mt=M('#cbd5e1',false),dk=M('#475569',false);for(var j=0;j<4;j++){var bl=new THREE.Mesh(T.cone,mt);bl.scale.set(.06,.2,.02);bl.rotation.z=j*Math.PI/2;bl.position.set(Math.sin(j*Math.PI/2)*-.1,Math.cos(j*Math.PI/2)*.1,0);var hold=new THREE.Group();hold.add(bl);g.add(hold);}
  var hub=new THREE.Mesh(T.cyl,dk);hub.scale.set(.05,.03,.05);hub.rotation.x=Math.PI/2;g.add(hub);g.add(r3glow('#e2e8f0',.35));g.userData.spinFlat=1;}
 else if(k==='bullet'){var bu=new THREE.Mesh(T.sph,M('#fff1b8'));bu.scale.set(.055,.055,.11);g.add(bu);}
 else if(k==='bomb'){var bo=new THREE.Mesh(T.sph,r3mat('#1f2937'));bo.scale.setScalar(.15);g.add(bo);var fu=new THREE.Mesh(T.cyl,r3mat('#a16207'));fu.scale.set(.02,.1,.02);fu.position.y=.17;g.add(fu);var sk=r3glow('#fde047',.35);sk.position.y=.24;g.add(sk);g.userData.tumble=1;g.userData.spark=sk;}
 else if(k==='flask'){var fl=new THREE.Mesh(T.sph,r3mat('#34d399',true,.85));fl.scale.set(.12,.12,.12);g.add(fl);var nk=new THREE.Mesh(T.cyl,r3mat('#e2e8f0',true,.9));nk.scale.set(.04,.1,.04);nk.position.y=.14;g.add(nk);var ck=new THREE.Mesh(T.cyl,r3mat('#92400e'));ck.scale.set(.045,.04,.045);ck.position.y=.2;g.add(ck);g.add(r3glow('#34d399',.5));g.userData.tumble=1;}
 else if(k==='wave'){for(var w=0;w<3;w++){var ar=new THREE.Mesh(T.arc,r3mat('#f472b6',true,.9-w*.25));ar.scale.setScalar(.18+w*.07);ar.rotation.set(Math.PI/2,0,Math.PI/2-1);ar.position.z=-w*.08;g.add(ar);g.userData['ring'+w]=ar;}g.add(r3glow('#f9a8d4',.5));g.userData.wave=1;}
 else if(k==='boom'){var wd=r3mat('#d97706'),wl=r3mat('#fbbf24');var a1=new THREE.Mesh(T.box,wd);a1.scale.set(.32,.03,.08);a1.position.x=.12;a1.rotation.y=.5;g.add(a1);var a2=new THREE.Mesh(T.box,wl);a2.scale.set(.32,.03,.08);a2.position.x=-.12;a2.rotation.y=-.5;g.add(a2);g.userData.spin=1;}
 else if(k==='axe'){var hd2=new THREE.Mesh(T.cyl,r3mat('#5b3a29'));hd2.scale.set(.025,.42,.025);g.add(hd2);var bl2=new THREE.Mesh(T.box,r3mat('#cbd5e1'));bl2.scale.set(.2,.16,.03);bl2.position.set(.08,.15,0);g.add(bl2);g.add(r3glow('#ef4444',.45));g.userData.axe=1;}
 else if(k==='rbolt'){var rb=new THREE.Mesh(T.cyl,M('#ffe4e6'));rb.scale.set(.04,.6,.04);rb.rotation.x=Math.PI/2;g.add(rb);var rb2=new THREE.Mesh(T.cyl,r3mat('#ef4444',true,.6));rb2.scale.set(.09,.66,.09);rb2.rotation.x=Math.PI/2;g.add(rb2);g.add(r3glow('#f43f5e',.7));}
 else if(k==='breath'){var bc=new THREE.Mesh(T.sph,M('#fff7cc'));bc.scale.setScalar(.12);g.add(bc);var bo2=new THREE.Mesh(T.sph,r3mat('#f97316',true,.7));bo2.scale.set(.22,.22,.3);g.add(bo2);g.add(r3glow('#ff5a1f',1.2));g.userData.flick=1;g.userData.ember=1;}
 else if(k==='eorb'){var ec=new THREE.Mesh(T.sph,r3mat('#fecaca',true));ec.scale.setScalar(.07);g.add(ec);var eo=new THREE.Mesh(T.sph,r3mat('#ef4444',true,.7));eo.scale.setScalar(.13);g.add(eo);g.add(r3glow('#ef4444',.6));g.userData.pulse=1;}
 else{var d=new THREE.Mesh(T.sph,M('#fde047'));d.scale.setScalar(.13);g.add(d);g.add(r3glow('#fde047',.6));}
 return g;}
function r3shotMake(k){var g=new THREE.Group(),body=r3shotBody(k),tr=r3trail(TRC[k]||'#fde047');g.add(tr);g.add(body);g.userData=body.userData;g.userData.body=body;g.userData.tr=tr;g.traverse(function(o){o.castShadow=false;});return g;}
/* where a shot ends: a coloured burst on a hit, a small puff when it just runs out */
function r3impact(x,z,col,big){
 if(big){r3fx('ring',x,.1,z,{c:col,life:.24,s0:.1,s1:.75,op:.9});r3fx('glow',x,.7,z,{c:col,life:.16,s0:1,s1:.3,op:1});
  for(var q=0;q<(R3.low?2:5);q++){var a=Math.random()*6.283,sp=1.5+Math.random()*2.5;r3fx('spark',x,.7,z,{c:col,life:.3,vx:Math.cos(a)*sp,vz:Math.sin(a)*sp,vy:1.5+Math.random()*2,g:10,s0:.08,s1:.02,op:1});}}
 else r3fx('glow',x,.7,z,{c:col,life:.18,s0:.55,s1:.15,op:.75});}
function r3shotTrack(map,list,t,near,colOf){
 var fr=R3.frameNo,fl=0;list.forEach(function(s){var r=map.get(s);if(!r){r={c:colOf(s)};map.set(s,r);if(fl<2&&!(s.o&&s.o.mzT>t-.06)){fl++;if(s.o)s.o.mzT=t;r3fx('glow',r3x(s.x),.75,r3z(s.y),{c:r.c,life:.1,s0:.75,s1:.2,op:1});}}r.x=s.x;r.y=s.y;r.f=fr;});
 var gone=[];map.forEach(function(r,s){if(r.f!==fr)gone.push(s);});
 if(gone.length>12){gone.forEach(function(s){map.delete(s);});return;}
 gone.forEach(function(s,i){var r=map.get(s);map.delete(s);if(i<4)r3impact(r3x(r.x),r3z(r.y),r.c,near(r.x,r.y));});}
function r3shots(g,t){
 var dt=Math.min(.05,Math.max(0,t-(R3.shLt||t)));R3.shLt=t;
 var pools={};function take(k){var p=pools[k]||(pools[k]=r3pool('sh_'+k,function(){return r3shotMake(k);}));return r3take(p);}
 function pose(m,s,k,sc,yy){var u=m.userData,b=u.body,vx=s.vx||0,vy=s.vy||0,sp=Math.hypot(vx,vy)*R3U;
  m.position.set(r3x(s.x),yy,r3z(s.y));m.rotation.set(0,Math.atan2(vx,vy),0);m.scale.setScalar(1);
  b.scale.setScalar(sc);b.rotation.set(0,0,0);
  if(u.spin)b.rotation.y=t*22;if(u.spinFlat){b.rotation.x=-Math.PI/2;b.rotation.z=t*25;}if(u.tumble)b.rotation.x=t*9;
  if(u.flick)b.scale.setScalar(sc*(1+Math.sin(t*40+s.x)*.12));if(u.pulse)b.scale.setScalar(sc*(1+Math.sin(t*18)*.1));
  if(u.spark)u.spark.scale.setScalar(.3+Math.random()*.15);
  var L=s.ret?.45:Math.max(.35,Math.min(1.7,sp*.075)),W=Math.min(.42,.13*sc+(u.ember?.08:0));u.tr.scale.set(W,1,L);u.tr.visible=sp>.5;
  if(u.ember&&!R3.low&&R3.fx&&R3.fx.length<40&&Math.random()<dt*11){var hx=m.position.x,hz=m.position.z;r3fx('spark',hx+(Math.random()-.5)*.12,yy,hz+(Math.random()-.5)*.12,{c:Math.random()<.5?'#ffb347':'#ff6a1f',life:.3,vx:-vx*R3U*.15,vz:-vy*R3U*.15,vy:.9,g:-1,s0:.06,s1:.01,op:1});}}
 g.shots.forEach(function(s){var w=s.o&&s.o.ch?s.o.ch.wp:null,k=SHW[w]||'dot';if(s.ret)k='boom';
  var m=take(k),u=m.userData,sc=1.5*Math.max(.7,Math.min(1.6,(s.r||5)/5));pose(m,s,k,sc,.7);
  if(u.zap)u.body.children.forEach(function(c,i){if(i>1&&i<5)c.position.x=(Math.random()-.5)*.14;});
  if(u.tint&&s.col){u.tint.material=r3mat(s.col,true,.7);u.tr.children.forEach(function(c){c.material=r3trailMat(s.col);});}
  if(u.wave)for(var i=0;i<3;i++){var r=u['ring'+i];r.scale.setScalar((.18+i*.07)*(1+((t*3+i*.3)%1)*.35));}});
 for(var k in pools)r3end(pools[k]);
 ['arrow','fire','bolt','orb','star','bullet','bomb','flask','wave','boom','dot'].forEach(function(k){if(!pools[k]&&R3.pools['sh_'+k]){var p=r3pool('sh_'+k);r3end(p);}});
 var EK={axe:'axe',laser:'rbolt',fire:'fire',breath:'breath'},ep={};
 g.eshots.forEach(function(s){var k=EK[s.k]||'eorb',p=ep[k]||(ep[k]=r3pool('sh_e'+k,function(){return r3shotMake(k);})),m=r3take(p);
  var sc2=(k==='breath'?1.6:k==='fire'?1.5:1.3)*(1+Math.sin(t*16)*.08);pose(m,s,k,sc2,.75);if(m.userData.axe)m.userData.body.rotation.x=t*16;});
 ['axe','rbolt','fire','breath','eorb'].forEach(function(k){var p=ep[k]||(R3.pools['sh_e'+k]?r3pool('sh_e'+k):null);if(p)r3end(p);});
 // muzzle flash when a shot appears, burst where it ends
 R3.shM=R3.shM||new Map();R3.eshM=R3.eshM||new Map();
 r3shotTrack(R3.shM,g.shots,t,function(x,y){return g.enemies.some(function(e){return Math.hypot(e.x-x,e.y-y)<e.r+16;})||(g.structs||[]).some(function(e){return e.hp>0&&Math.hypot(e.x-x,e.y-y)<e.r+16;});},function(s){var w=s.o&&s.o.ch?s.o.ch.wp:null,k=s.ret?'boom':SHW[w]||'dot';return k==='orb'&&s.col?s.col:TRC[k]||'#fde047';});
 r3shotTrack(R3.eshM,g.eshots,t,function(x,y){return g.ps.some(function(p){return p.hp>0&&Math.hypot(p.x-x,p.y-y)<(p.r||14)+14;});},function(s){return TRC[EK[s.k]||'eorb'];});
}
