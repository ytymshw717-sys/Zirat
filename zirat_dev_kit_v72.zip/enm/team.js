/* ===== 3 נגד 3: you (+ local friends) and hero bots vs 3 hero bots. Knock-outs score; everyone respawns after 3s and heals when out of combat; first to 10 or the most after 2:30 wins ===== */
var tbots=[],tko=[0,0],tTime=0,tSlots=[],TEAMKO=10,TEAMT=150,tSudden=false;
T.hero={r:14,hp:10,sp:150,col:'#ef4444',dmg:10,wind:.3,reach:30,pts:40};
function tPos(tm,i){var n=Math.max(0,Math.min(2,i));return {x:W/2+(n-1)*86,y:tm?78:H-78};}
function tPick(n,ex){var pool=[];for(var i=0;i<CH.length;i++)if(ex.indexOf(i)<0)pool.push(i);for(var k=pool.length-1;k>0;k--){var j=Math.floor(Math.random()*(k+1)),t=pool[k];pool[k]=pool[j];pool[j]=t;}return pool.slice(0,n);}
function tCh(h){var c=skinnedK(h,Math.random()<.3?1+Math.floor(Math.random()*3):0);c.idx=h;return c;}
function mkAlly(h,i){var ch=tCh(h),q=tPos(0,i);return {i:9+i,bot:1,tm:0,ch:ch,x:q.x,y:q.y,r:14,hp:ch.hp,mhp:ch.hp,lm:1,sup:0,uh:false,gh:false,gads:0,cubes:0,fx:0,fy:-1,dir:1,inv:1.5,cd:.6,atk:0,kx:0,ky:0,walk:0,spcd:0,spin:0,sph:false,bS:0,bD:0,sh:0,flash:0,rt:0,sf:1,sfT:0,lh:-9,la:-9,slot:i};}
function mkRival(h,i){var ch=tCh(h),q=tPos(1,i),m=DF[dfi]?DF[dfi][1]:1,hp=Math.max(6,Math.round(ch.hp/10*m));return {t:'hero',ch:ch,tm:1,bot:1,x:q.x,y:q.y,r:14,hp:hp,maxhp:hp,mhp:hp,state:'chase',wind:0,cd:1,stun:0,kx:0,ky:0,flash:0,dir:1,walk:0,speed:ch.sp*.82,fx:0,fy:1,atk:0,inv:1.5,sup:0,spcd:7+Math.random()*5,sf:1,sfT:0,lh:-9,mw:0,slot:i};}
function teamInit(){tko=[0,0];tTime=0;TEAMKO=10;tSudden=false;tbots=[];
 if(typeof NG!=='undefined'&&NG.vs&&NG.vsB){var nA=ps.length,B=NG.vsB,nB=B.length,xv=ps.map(function(p){return p.ch.idx;}).concat(B.map(function(b){return b.h;})),a2=tPick(Math.max(0,nB-nA),xv);xv=xv.concat(a2);var r2=tPick(Math.max(0,nA-nB),xv);
  ps.forEach(function(p,i){var q=tPos(0,i);p.x=q.x;p.y=q.y;p.fx=0;p.fy=-1;p.lh=-9;p.la=-9;p.rt=0;});a2.forEach(function(h,i){tbots.push(mkAlly(h,nA+i));});
  tSlots=B.map(function(b){return {h:b.h,k:b.k,net:b.peer,nm:b.nm,lm:b.lm,e:null,rt:.05};}).concat(r2.map(function(h,i){return {h:h,e:null,rt:.8+i*.25};}));
  TEAMKO=5;bannerText='⚔️ קרב אונליין · '+TEAMKO+' הפלות מנצחות!';banner=2.4;return;}
var nP=Math.min(3,ps.length||np),ex=ps.length?ps.map(function(p){return p.ch.idx;}):sel.slice(0,np),al=tPick(Math.max(0,3-nP),ex);ex=ex.concat(al);var rv=tPick(3,ex);
 ps.forEach(function(p,i){var q=tPos(0,i);p.x=q.x;p.y=q.y;p.fx=0;p.fy=-1;p.lh=-9;p.la=-9;p.rt=0;});
 al.forEach(function(h,i){tbots.push(mkAlly(h,nP+i));});
 tSlots=rv.map(function(h,i){return {h:h,e:null,rt:.8+i*.25};});
 bannerText='👥 3 נגד 3 · '+TEAMKO+' הפלות מנצחות!';banner=2.2;}
function tFoes(tm){if(tm===1){var o=ps.filter(function(p){return p.hp>0;});tbots.forEach(function(b){if(b.hp>0)o.push(b);});return o;}return enemies.filter(function(e){return e.hp>0&&e.t==='hero';});}
function tVisible(tg,from){return !(tg.inBush&&!(tg.rev>0)&&Math.hypot(tg.x-from.x,tg.y-from.y)>75);}
/* steering: keep the right distance for the weapon, strafe to dodge, slide around rocks, back off when low */
function tSteer(b,tg,td,dt,sp,noKb){var ranged=!!b.ch.kind,pref=ranged?Math.max(70,b.ch.rng*.72):0,vx=0,vy=0;
 b.sfT-=dt;if(b.sfT<=0){b.sfT=.9+Math.random()*1.2;b.sf=Math.random()<.5?-1:1;}
 var low=b.hp/(b.mhp||b.maxhp||1)<.3;
 if(b.dg&&b.dg.t>0){b.dg.t-=dt;vx=b.dg.x;vy=b.dg.y;}
 else if(b.goal){var gx=b.goal.x-b.x,gy=b.goal.y-b.y,gl=Math.hypot(gx,gy);if(gl>(b.goal.r||8)){vx=gx/gl;vy=gy/gl;if(tg&&td<(b.ch.rng||60)+60){vx+=-gy/gl*b.sf*.3;vy+=gx/gl*b.sf*.3;}}}
 else if(tg){var dx=(tg.x-b.x)/(td||1),dy=(tg.y-b.y)/(td||1);
  if(low&&td<190){if(b.ffa||b.cov){var cv=hCover(b,tg);vx=cv?(cv.x-b.x)/(Math.hypot(cv.x-b.x,cv.y-b.y)||1):-dx;vy=cv?(cv.y-b.y)/(Math.hypot(cv.x-b.x,cv.y-b.y)||1):-dy;}else{var by=b.tm?60:H-60;vx=-dx*.7;vy=(by-b.y>0?1:-1)*.7;}}
  else if(td>pref+18){vx=dx;vy=dy;}else if(ranged&&td<pref-28){vx=-dx*.8;vy=-dy*.8;}
  var st=ranged?.75:.35;if(!(low&&td<190)){vx+=-dy*b.sf*st;vy+=dx*b.sf*st;}}
 else{var cy=H/2+(b.tm?-60:60);vx=(W/2-b.x)/120;vy=(cy-b.y)/120;}
 var l=Math.hypot(vx,vy);if(l<.05)return false;vx/=l;vy/=l;
 for(var k=0;k<obs.length;k++){var o=obs[k];if(o.k==='void')continue;var ox=o.x-b.x,oy=o.y-b.y,ahead=ox*vx+oy*vy;if(ahead>0&&ahead<o.r+30){var side=Math.abs(ox*vy-oy*vx);if(side<o.r+b.r){var s=(ox*vy-oy*vx)>0?1:-1;var nx=vx*Math.cos(1.2*s)-vy*Math.sin(1.2*s),ny=vx*Math.sin(1.2*s)+vy*Math.cos(1.2*s);vx=nx;vy=ny;break;}}}
 if(noKb){b.x+=vx*sp*dt;b.y+=vy*sp*dt;}else{b.x+=vx*sp*dt+b.kx*dt;b.y+=vy*sp*dt+b.ky*dt;var fr=Math.max(0,1-9*dt);b.kx*=fr;b.ky*=fr;}
 b.x=Math.max(b.r,Math.min(W-b.r,b.x));b.y=Math.max(b.r,Math.min(H-b.r,b.y));pushOut(b);b.walk+=dt*14;
 if(!(b.atk>0)&&!(tg&&td<(b.ch.rng||60)+40)){b.fx=vx;b.fy=vy;}if(Math.abs(b.fx)>.05)b.dir=b.fx<0?-1:1;return true;}
function tRegen(o,dt,hpKey){var mx=o.mhp||o.maxhp;if(o.hp>0&&o.hp<mx&&tTime-(o.lh||-9)>3&&tTime-(o.la||-9)>2.5)o.hp=Math.min(mx,o.hp+mx*.13*dt);}
/* hero bot on the player's side: uses the same attack code as the player */
function allyTick(b,dt){
 if(b.hp<=0){b.rt-=dt;if(b.rt<=0){var q=tPos(0,b.slot);b.x=q.x;b.y=q.y;b.hp=b.mhp;b.inv=2;b.kx=b.ky=0;float(b.x,b.y-30,'חזר לקרב!','#93c5fd');}return;}
 ['inv','cd','atk','spcd','spin','bS','bD','sh','flash'].forEach(function(k){if(b[k]>0)b[k]-=dt;});
 var fo=tFoes(0),tg=null,td=1e9,bs=1e9;fo.forEach(function(e){if(e.hid)return;var d=Math.hypot(e.x-b.x,e.y-b.y),sc=d-(1-hHp(e))*100-(e===b.tgO?40:0);if(sc<bs){bs=sc;td=d;tg=e;}});b.tgO=tg;
 hDodge(b,dt);tSteer(b,tg,td,dt,b.ch.sp*.85);
 var reach=b.ch.kind?b.ch.rng+12:b.ch.rng+(tg?tg.r:14)+4;
 if(tg&&td<=reach&&b.cd<=0){var s0=snd;snd=false;try{doAttack(b);}finally{snd=s0;}b.la=tTime;b.cd*=1.15+Math.random()*.2;}
 if((b.sup||0)>=100&&tg&&td<150){b.sup=0;fxe({k:'sup',x:b.x,y:b.y,su:'nova',h:b.ch.idx,fx:b.fx,fy:b.fy});var s1=snd;snd=false;try{nova(b,115,3,.5);}finally{snd=s1;}}
 tRegen(b,dt);}
function botHurt(b,dmg,fx,fy){if(b.hp<=0||b.inv>0||b.sh>0||state!=='play')return;b.hp=Math.max(0,b.hp-dmg);b.flash=.14;b.lh=tTime;var dx=b.x-fx,dy=b.y-fy,d=Math.hypot(dx,dy)||1;b.kx=dx/d*200;b.ky=dy/d*200;
 if(b.hp<=0){burst(b.x,b.y,b.ch.col,12);b.rt=3;tko[1]++;float(b.x,b.y-30,'💀 '+b.ch.nk,'#f87171');}}
/* hero bot on the other team (lives in the enemies list, so every attack, special and super of the player hits it) */
function heroBot(e,dt){if(e.net){ngRival(e,dt);return;}
 if(e.cd>0)e.cd-=dt;if(e.atk>0)e.atk-=dt;if(e.inv>0)e.inv-=dt;if(e.spcd>0)e.spcd-=dt;if(e.flash>0)e.lh=tTime;
 if(e.stun>0){e.stun-=dt;return;}
 if(e.ffa){e.inBush=!!inBush(e);e.vx=(e.x-(e.ox==null?e.x:e.ox))/Math.max(dt,.001);e.vy=(e.y-(e.oy==null?e.y:e.oy))/Math.max(dt,.001);e.ox=e.x;e.oy=e.y;}
 var tg=hPick(e,hFoes(e)),td=tg?Math.hypot(tg.x-e.x,tg.y-e.y):1e9,ranged=!!e.ch.kind;
 hDodge(e,dt);hPlan(e,tg,td,dt);
 if(e.mw>0){e.mw-=dt;if(e.mw<=0)tMelee(e);}else tSteer(e,tg,td,dt,e.speed,true);
 if(tg&&e.cd<=0){var dx=tg.x-e.x,dy=tg.y-e.y,d=td||1;
  if(ranged&&td<=e.ch.rng+10){if(e.ch.kind==='bomb'||hLos(e.x,e.y,tg.x,tg.y)){e.fx=dx/d;e.fy=dy/d;tFire(e,tg);e.cd=e.ch.cd*1.7+Math.random()*.25;e.atk=.18;e.la=tTime;e.amb=0;}else{e.sfT=Math.min(e.sfT,.15);}}
  else if(!ranged&&td<=e.ch.rng+tg.r+6){e.fx=dx/d;e.fy=dy/d;e.mw=.2;e.cd=e.ch.cd*1.6+.15;e.la=tTime;e.amb=0;}}
 if(e.spcd<=0&&tg&&hSuperNow(e,tg,td)){e.spcd=11+Math.random()*6;e.spW=0;tSuper(e);}
 tRegen(e,dt);}
/* ===== v69: smarter hero bots (dodge, cover, ambush, focus fire, line of sight, timed supers) + free-for-all ===== */
function hFoes(e){if(!e.ffa)return tFoes(1);var o=ps.filter(function(p){return p.hp>0;});enemies.forEach(function(x){if(x!==e&&x.t==='hero'&&x.hp>0)o.push(x);});return o;}
function hLos(ax,ay,bx,by){for(var k=0;k<obs.length;k++){var o=obs[k];if(o.k==='void')continue;if(segD(ax,ay,bx,by,o.x,o.y)<o.r*.8)return false;}return true;}
function hHp(o){return o.hp/(o.mhp||o.maxhp||1);}
/* who to fight: close, weak, already engaged, and (in teams) the one a team-mate is on */
function hPick(e,fo){var best=null,bs=1e9,keep=e.tgO,lim=e.ffa?(tTime<10?190:fo.length<=3?1e9:360):420;fo.forEach(function(p){if(!tVisible(p,e))return;var d=Math.hypot(p.x-e.x,p.y-e.y);if(d>lim)return;
  var sc=d-(1-hHp(p))*120-(p===keep?45:0);if(!e.ffa)enemies.forEach(function(m){if(m!==e&&m.t==='hero'&&m.tgO===p)sc-=30;});if(!hLos(e.x,e.y,p.x,p.y)&&e.ch.kind!=='bomb')sc+=60;if(sc<bs){bs=sc;best=p;}});e.tgO=best;return best;}
/* incoming projectile -> side-step (reaction gets better with difficulty) */
function hDodge(e,dt){e.tth=(e.tth||0)-dt;if(e.tth>0)return;e.tth=.12;if(e.dg&&e.dg.t>0)return;
 var L=e.tm===0?eshots:(e.ffa?shots.concat(eshots):shots),best=null,bt=.6;
 for(var i=0;i<L.length;i++){var s=L[i];if(s.o===e||s.lob)continue;var rx=e.x-s.x,ry=e.y-s.y,vv=s.vx*s.vx+s.vy*s.vy;if(vv<100)continue;var t=(rx*s.vx+ry*s.vy)/vv;if(t<0||t>bt)continue;var cx=s.x+s.vx*t-e.x,cy=s.y+s.vy*t-e.y;if(Math.hypot(cx,cy)<e.r+(s.r||4)+8){bt=t;best=[s,cx,cy];}}
 if(!best)return;var q=.3+.15*(typeof dfi==='number'?dfi:1);if(Math.random()>q)return;
 var s=best[0],v=Math.hypot(s.vx,s.vy)||1,px=-s.vy/v,py=s.vx/v;if(px*best[1]+py*best[2]>0){px=-px;py=-py;}e.dg={x:px,y:py,t:.26};}
/* where to go: inside the gas, to a power cube, into a bush to ambush or to heal, else roam */
function hPlan(e,tg,td,dt){e.goal=null;var low=hHp(e)<.35;
 if(mode==='show'&&gas){var gd=Math.hypot(e.x-gas.x,e.y-gas.y);if(gd>gas.r-38){e.goal={x:gas.x,y:gas.y,r:20};return;}}
 if(e.ffa&&(!tg||td>200)){var cb=null,cd=230;drops.forEach(function(d){if(d.k!=='cube'||d.got)return;if(mode==='show'&&gas&&Math.hypot(d.x-gas.x,d.y-gas.y)>gas.r-30)return;var dd=Math.hypot(d.x-e.x,d.y-e.y);if(dd<cd){cd=dd;cb=d;}});if(cb){e.goal={x:cb.x,y:cb.y,r:4};return;}}
 if(low&&(!tg||td>150)){var bu=hBushNear(e,240,tg);if(bu){e.goal={x:bu.x,y:bu.y,r:bu.r*.4};return;}}
 if(!tg){if(e.amb==null)e.amb=Math.random()<.5?1:0;
  if(e.amb){var b2=hBushNear(e,200,null);if(b2){e.goal={x:b2.x,y:b2.y,r:b2.r*.45};return;}}
  if(e.ffa&&(tTime>25||hFoes(e).length<=3)){var fo2=hFoes(e),nf=null,nd=1e9;fo2.forEach(function(p){var d=Math.hypot(p.x-e.x,p.y-e.y);if(d<nd){nd=d;nf=p;}});if(nf){e.goal={x:nf.x,y:nf.y,r:(e.ch.kind?e.ch.rng*.7:20)};return;}}
  if(e.ffa){e.rT=(e.rT||0)-dt;if(!e.roam||e.rT<=0||Math.hypot(e.roam.x-e.x,e.roam.y-e.y)<24){var g=mode==='show'&&gas?gas:{x:W/2,y:H/2,r:Math.min(W,H)/2};var a=Math.random()*6.283,r=Math.random()*Math.max(30,(g.r||200)-60);e.roam={x:Math.max(30,Math.min(W-30,g.x+Math.cos(a)*r)),y:Math.max(30,Math.min(H-30,g.y+Math.sin(a)*r)),r:16};e.rT=4+Math.random()*3;}e.goal=e.roam;}}}
function hBushNear(e,maxD,away){var best=null,bd=maxD;for(var i=0;i<bushes.length;i++){var b=bushes[i],d=Math.hypot(b.x-e.x,b.y-e.y);if(away&&Math.hypot(b.x-away.x,b.y-away.y)<d)continue;if(mode==='show'&&gas&&Math.hypot(b.x-gas.x,b.y-gas.y)>gas.r-30)continue;if(d<bd){bd=d;best=b;}}return best;}
function hCover(e,tg){var b=hBushNear(e,260,tg);if(b)return b;var best=null,bd=220;for(var k=0;k<obs.length;k++){var o=obs[k];if(o.k==='void')continue;var dx=o.x-tg.x,dy=o.y-tg.y,l=Math.hypot(dx,dy)||1,cx=o.x+dx/l*(o.r+e.r+6),cy=o.y+dy/l*(o.r+e.r+6),d=Math.hypot(cx-e.x,cy-e.y);if(d<bd&&Math.hypot(tg.x-e.x,tg.y-e.y)<Math.hypot(tg.x-cx,tg.y-cy)+120){bd=d;best={x:cx,y:cy};}}return best;}
/* supers when they count: two foes close, a weak target in reach, or saving yourself */
function hSuperNow(e,tg,td){var R=e.ch.kind?Math.min(260,e.ch.rng+40):130,n=0;hFoes(e).forEach(function(p){if(Math.hypot(p.x-e.x,p.y-e.y)<R)n++;});
 return n>=2||(hHp(tg)<.45&&td<R)||(hHp(e)<.3&&td<120)||(e.spW=(e.spW||0)+.016)>6;}
/* free-for-all damage between rival heroes (player-scale damage -> enemy-scale hp) */
function ffaHurt(t,dmg,sx,sy,src){if(t.hp<=0||t.inv>0||state!=='play')return;var d=Math.max(.3,dmg/13);t.hp-=d;t.flash=.15;t.lh=tTime;var dx=t.x-sx,dy=t.y-sy,l=Math.hypot(dx,dy)||1;t.kx=dx/l*160;t.ky=dy/l*160;t.stun=Math.max(t.stun||0,.05);t.tgO=src&&src.hp>0?src:t.tgO;
 if(t.hp<=0){t.hp=0;t._kb=src;burst(t.x,t.y,t.ch.col,12);ffaDrop(t);float(t.x,t.y-30,'💀 '+(t.ch.nk||''),'#fca5a5');if(src&&src.ch&&src.t==='hero'){src.kills=(src.kills||0)+1;}}}
function ffaDrop(t){var n=1+Math.min(3,t.cubes||0);for(var i=0;i<n;i++){var a=Math.random()*6.283;drops.push({x:t.x+Math.cos(a)*14*i,y:t.y+Math.sin(a)*14*i,k:'cube',t:0});}}
function hHitAny(p,dm,e){if(p.t==='hero')ffaHurt(p,dm,e.x,e.y,e);else tHit(p,dm,e.x,e.y);}
function tDmg(e){var m=e.net?1:(DF[dfi]?DF[dfi][2]:1);return Math.max(3,Math.round(e.ch.dmg*(e.ch.kind&&!MELK[e.ch.kind]?8:11)*(.7+.3*m)*(1+.12*(e.cubes||0))));}
function tHit(o,dmg,sx,sy){if(o.bot)botHurt(o,dmg,sx,sy);else hurt(o,dmg,sx,sy);}
function tMelee(e){var R=e.ch.rng+6,dm=tDmg(e);e.atk=.18;fxe({k:'melee',x:e.x,y:e.y,fx:e.fx,fy:e.fy,r:e.ch.rng,h:e.ch.idx});
 hFoes(e).forEach(function(p){var dx=p.x-e.x,dy=p.y-e.y,d=Math.hypot(dx,dy)||1;if(d<=R+p.r&&(d<p.r+e.r+6||(dx*e.fx+dy*e.fy)/d>.25)){hHitAny(p,dm,e);fxe({k:'mhit',x:p.x,y:p.y,h:e.ch.idx});}});}
function tFire(e,tg){var ch=e.ch,k=ch.kind,dm=tDmg(e),lead=DF[dfi]&&dfi>=2?.18:0,ax=tg.x+(tg.vx||0)*lead,ay=tg.y+(tg.vy||0)*lead,a=Math.atan2(ay-e.y,ax-e.x)+(Math.random()-.5)*.14,dd=Math.hypot(tg.x-e.x,tg.y-e.y);
 if(k==='spread')dm=Math.max(2,Math.round(dm/(ch.pel||3)*1.6));else if(k==='twin')dm=Math.max(2,Math.round(dm*.6));else if(k==='burst')dm=Math.max(2,Math.round(dm*.45));
 var n0=eshots.length;heroShoot(e,a,dm,dd,'e');for(var i=n0;i<eshots.length;i++)if(eshots[i].boom)eshots[i].r=7;}
function tSuper(e){fxe({k:'sup',x:e.x,y:e.y,su:'nova',h:e.ch.idx,fx:e.fx,fy:e.fy});var dm=Math.round(tDmg(e)*1.6);
 if(e.ch.kind){for(var q=0;q<10;q++){var an=q/10*6.283;eshots.push({x:e.x,y:e.y,vx:Math.cos(an)*320,vy:Math.sin(an)*320,life:.85,dmg:dm,o:e,r:5,big:1});}}
 else hFoes(e).forEach(function(p){if(Math.hypot(p.x-e.x,p.y-e.y)<=115+p.r)hHitAny(p,dm+6,e);});}
function eBoom(s){if(s.bd)return;s.bd=1;if(s.pool&&acid.length<8)acid.push({x:s.x,y:s.y,r:s.boom,t:2,tk:.2,d:Math.max(1,Math.round((s.dmg||3)*.3)),o:s.o,side:'e'});fxe({k:'boom',x:s.x,y:s.y,r:s.boom,h:s.o&&s.o.ch?s.o.ch.idx:-1});shake=Math.max(shake,.1);
 ps.forEach(function(p){if(p.hp>0&&Math.hypot(p.x-s.x,p.y-s.y)<=s.boom+p.r)hurt(p,s.dmg,s.x,s.y);});tbots.forEach(function(b){if(b.hp>0&&Math.hypot(b.x-s.x,b.y-s.y)<=s.boom+b.r)botHurt(b,s.dmg,s.x,s.y);});
 if(s.o&&s.o.ffa)enemies.forEach(function(x){if(x!==s.o&&x.t==='hero'&&x.hp>0&&Math.hypot(x.x-s.x,x.y-s.y)<=s.boom+x.r)ffaHurt(x,s.dmg,s.x,s.y,s.o);});}
/* player knocked out in team mode: back in 3 seconds instead of game over */
function teamDown(p){p.rt=3;tko[1]++;bannerText='💀 הופלת! חוזר בעוד 3…';banner=1.6;}
function teamTick(dt){tTime+=dt;
 ps.forEach(function(p,i){if(p.hp<=0&&p.rt>0){p.rt-=dt;if(p.rt<=0){var q=tPos(0,i);p.x=q.x;p.y=q.y;p.hp=p.mhp;p.inv=2;p.kx=p.ky=0;float(p.x,p.y-30,'חזרת לקרב!','#86efac');}}if(p.hp>0)tRegen(p,dt);p.vx=(p.x-(p.ox==null?p.x:p.ox))/Math.max(dt,.001);p.vy=(p.y-(p.oy==null?p.y:p.oy))/Math.max(dt,.001);p.ox=p.x;p.oy=p.y;});
 tbots.forEach(function(b){allyTick(b,dt);b.vx=(b.x-(b.ox==null?b.x:b.ox))/Math.max(dt,.001);b.vy=(b.y-(b.oy==null?b.y:b.oy))/Math.max(dt,.001);b.ox=b.x;b.oy=b.y;});
 // keep allies from stacking on the player
 var tm=ps.filter(function(p){return p.hp>0;}).concat(tbots.filter(function(b){return b.hp>0;}));for(var a=0;a<tm.length;a++)for(var c=a+1;c<tm.length;c++){var A=tm[a],B=tm[c],ex=B.x-A.x,ey=B.y-A.y,ed=Math.hypot(ex,ey),mn=A.r+B.r;if(ed<mn&&ed>.001){var pu=(mn-ed)/2;ex/=ed;ey/=ed;if(A.bot){A.x-=ex*pu;A.y-=ey*pu;}if(B.bot){B.x+=ex*pu;B.y+=ey*pu;}}}
 tSlots.forEach(function(s,i){if(s.e&&(s.e.hp<=0||enemies.indexOf(s.e)<0)){s.e=null;s.rt=3;tko[0]++;beep(780,.18,'triangle',.06,1200);}
  if(!s.e){s.rt-=dt;if(s.rt<=0){s.e=mkRival(s.h,i);if(s.net)ngRivalMake(s.e,s);enemies.push(s.e);}}});
 var lim=TEAMKO;if(tko[0]>=lim&&tko[0]>tko[1]){victory();return;}if(tko[1]>=lim&&tko[1]>tko[0]){gameOver();return;}
 if(tTime>=TEAMT){if(tko[0]>tko[1])victory();else if(tko[1]>tko[0])gameOver();else if(!tSudden){tSudden=true;TEAMKO=tko[0]+1;bannerText='⚡ הארכה! ההפלה הבאה מנצחת';banner=2;}}}
function teamText(){var s=Math.max(0,Math.ceil(TEAMT-tTime)),mm=Math.floor(s/60),ss=s%60;return '👥 אתם '+tko[0]+' · יריבים '+tko[1]+' · '+(tSudden?'הארכה!':mm+':'+(ss<10?'0':'')+ss);}
