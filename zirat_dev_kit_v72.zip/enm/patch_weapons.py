# v58 stage 2: every hero gets its own weapon (range, shape, behaviour), weapon-shaped aim indicator, auto-aim target marker.
# Applies once to arena3_stage.html and enm/team.js (asserts every anchor exists exactly once).
import re
P = '/home/claude/arena3_stage.html'
s = open(P).read()

def rep(old, new, cnt=1, src=None):
    global s
    t = s if src is None else src
    n = t.count(old)
    assert n == cnt, (n, old[:90])
    t = t.replace(old, new)
    if src is None:
        s = t
    return t

# ---------- 1. weapon table (after the last heroes get their lines) ----------
rep("CH.forEach(function(c,i){c.ln=LN[i];});",
"""CH.forEach(function(c,i){c.ln=LN[i];});
/* every hero has a weapon of its own: range, shape and behaviour (v58). Long, mid and short range are mixed; only three heroes fight up close */
var WPN={0:{kind:'twin',rng:185,cd:.3,dmg:.8},1:{kind:'wave',rng:115,cd:.55,dmg:1.5},2:{kind:'chain',rng:210,cd:.55,dmg:1.1},3:{kind:'bounce',rng:230,cd:.45,dmg:1.2},4:{kind:'pierce',rng:300,cd:.7,dmg:1.5,pr:3},
 5:{kind:'homing',rng:220,cd:.4,dmg:1.1},6:{kind:'shot',rng:280,cd:.5,dmg:1.15},7:{kind:'spread',rng:140,cd:.7,dmg:.85,pel:5},8:{kind:'bomb',rng:230,cd:.95,dmg:2,br:55},9:{kind:'flame',rng:110,cd:.12,dmg:.4},
 10:{kind:'lunge',rng:95,cd:.5,dmg:1.3},11:{kind:'bomb',rng:200,cd:.75,dmg:1.1,br:42,pool:1},12:{kind:'slam',rng:85,cd:.8,dmg:2.2},13:{kind:'spread',rng:175,cd:.5,dmg:.55,pel:5},14:{kind:'sine',rng:210,cd:.3,dmg:.7},
 15:{kind:'boom',rng:230,cd:.55,dmg:1.3},16:{kind:'sonic',rng:180,cd:.55,dmg:1},17:{kind:'burst',rng:230,cd:.6,dmg:.6},18:{kind:'venom',rng:140,cd:.32,dmg:.6},19:{kind:'axe',rng:160,cd:.75,dmg:2}};
CH.forEach(function(c,i){var w=WPN[i];if(w)Object.assign(c,w);});
Object.assign(KD,{wave:'גל חרב רחב שעובר דרך אויבים',chain:'ברק שקופץ לעוד 2 אויבים',bounce:'קליע שנתקע בקירות ומקפץ',lunge:'זינוק קדימה עם שריטה',slam:'מכת אדמה שמהממת',sine:'רוח מתפתלת שעוברת דרך אויבים',sonic:'גל קול שהולך ומתרחב',burst:'צרור של 3 קרני אור',venom:'יריקת ארס שמרעילה',axe:'גרזן מסתובב שעובר דרך אויבים',boom:'בומרנג שחוזר'});
KD.bomb='פצצה שעפה מעל קירות';""")

# ---------- 2. shared projectile builder + special attacks ----------
rep("function fire(pl){",
r"""var MELK={wave:1,lunge:1,slam:1},pq=[],acid=[];
/* the projectiles of one attack, for a hero or a hero bot. a = angle, dm = damage per hit, aimD = throw distance for lobbed bombs */
function wShots(o,a,dm,aimD){var ch=o.ch,k=ch.kind,R=ch.rng,L=[];
 function sh(an,sp,r,ex,life){var s={x:o.x+Math.cos(an)*14,y:o.y+Math.sin(an)*14,vx:Math.cos(an)*sp,vy:Math.sin(an)*sp,life:life||R/sp,dmg:dm,r:r,boom:0,o:o};if(ex)for(var q in ex)s[q]=ex[q];L.push(s);return s;}
 switch(k){
  case 'shot':sh(a,520,4,{col:'#86efac'});break;
  case 'spread':var pn=ch.pel||3,gp=pn>4?.15:.22;for(var i=0;i<pn;i++)sh(a+(i-(pn-1)/2)*gp,idxSp(ch),4,{col:'#fcd34d'});break;
  case 'bomb':var dd=Math.max(40,Math.min(R,aimD||R));sh(a,250,7,{boom:ch.br||52,lob:1,pool:ch.pool?1:0,col:'#334155'},Math.max(.15,dd/250));break;
  case 'boom':var b=sh(a,400,5,{pierce:1,ret:1,col:'#fbbf24'},R/400*2);b.rl=b.life/2;break;
  case 'twin':sh(a-.08,480,3,{col:'#e5e7eb'});sh(a+.08,480,3,{col:'#e5e7eb'});break;
  case 'pierce':sh(a,620,ch.pr||5,{pierce:1,col:ch.wc||'#67e8f9'});break;
  case 'homing':sh(a,270,5,{hom:1,col:'#a3e635'});break;
  case 'flame':sh(a+(Math.random()-.5)*.35,260,5+Math.random()*3,{col:Math.random()<.5?'#f97316':'#fde047'});break;
  case 'wave':sh(a,330,14,{pierce:1,col:'#93c5fd'});break;
  case 'chain':sh(a,560,5,{chain:2,col:'#c084fc'});break;
  case 'bounce':sh(a,470,4,{bnc:2,col:'#fbbf24'});break;
  case 'sine':sh(a,300,6,{pierce:1,sin:1,col:'#bae6fd'});break;
  case 'sonic':sh(a,300,6,{pierce:1,grow:22,col:'#e879f9'});break;
  case 'burst':sh(a,580,4,{col:'#fde047'});break;
  case 'venom':sh(a,470,4,{poi:1,col:'#a3e635'});break;
  case 'axe':sh(a,320,9,{pierce:1,spin:1,col:'#f97316'});break;
  default:sh(a,430,4,{col:'#ffffff'});}
 return L;}
function idxSp(ch){return ch.pel>4?320:380;}
/* projectile extras that both sides use: wavy path, growing waves, bouncing off the arena walls */
function projFx(s,dt){
 if(s.sin){s.st=(s.st||0)+dt;var sp=Math.hypot(s.vx,s.vy)||1,nx=-s.vy/sp,ny=s.vx/sp,d=(Math.sin(s.st*11)-Math.sin((s.st-dt)*11))*18;s.x+=nx*d;s.y+=ny*d;}
 if(s.grow&&s.r<s.grow)s.r=Math.min(s.grow,s.r+dt*42);
 if(s.bnc>0){if(s.x<4||s.x>W-4){s.vx=-s.vx;s.x=Math.max(4,Math.min(W-4,s.x));s.bnc--;s.hit=[];s.px=s.x;s.py=s.y;}if(s.y<4||s.y>H-4){s.vy=-s.vy;s.y=Math.max(4,Math.min(H-4,s.y));s.bnc--;s.hit=[];s.px=s.x;s.py=s.y;}}}
function bounceOff(s,ob){var dx=s.x-ob.x,dy=s.y-ob.y,d=Math.hypot(dx,dy)||1,nx=dx/d,ny=dy/d,vn=s.vx*nx+s.vy*ny;if(vn<0){s.vx-=2*vn*nx;s.vy-=2*vn*ny;}s.x=ob.x+nx*(ob.r+(s.r||4)*.5+1);s.y=ob.y+ny*(ob.r+(s.r||4)*.5+1);s.px=s.x;s.py=s.y;s.bnc--;s.hit=[];fxe({k:'phit',x:s.x,y:s.y,h:s.o&&s.o.ch?s.o.ch.idx:-1});}
/* lightning jumps from the first enemy it hits to up to 2 more nearby */
function chainZap(s,e){var hit=[e],cur=e,n=s.chain||0;while(n-->0){var nb=null,nd=125;enemies.forEach(function(q){if(q.hp<=0||hit.indexOf(q)>=0)return;var d=Math.hypot(q.x-cur.x,q.y-cur.y);if(d<nd){nd=d;nb=q;}});if(!nb)break;bolts.push({x1:cur.x,y1:cur.y,x2:nb.x,y2:nb.y,t:.3,ch:1});var l=nd||1;hitEnemy(nb,s.dmg*.7,(nb.x-cur.x)/l,(nb.y-cur.y)/l,120,s.o);hit.push(nb);cur=nb;}}
/* close-range moves: a lunge with claws, and a ground slam that stuns. side 'p' = player team hits enemies, 'e' = rival bots hit the player team */
function aoeHit(o,x,y,R,dm,side,kb,stun){
 if(side==='p'){enemies.forEach(function(e){if(e.hp<=0)return;var dx=e.x-x,dy=e.y-y,d=Math.hypot(dx,dy);if(d<=R+e.r){var l=d||1;hitEnemy(e,dm,dx/l,dy/l,kb,o);if(stun)e.stun=Math.max(e.stun||0,stun);fxe({k:'mhit',x:e.x,y:e.y,h:o.ch.idx});}});structs.forEach(function(t){if(t.hp>0&&Math.hypot(t.x-x,t.y-y)<=R+t.r)hitStruct(t,dm,o);});brkNear(x,y,R,null,null,dm);}
 else tFoes(1).forEach(function(p){if(Math.hypot(p.x-x,p.y-y)<=R+p.r){tHit(p,dm,o.x,o.y);fxe({k:'mhit',x:p.x,y:p.y,h:o.ch.idx});}});}
function doLunge(o,a,dm,side){var c=Math.cos(a),n=Math.sin(a);o.kx=c*640;o.ky=n*640;o.inv=Math.max(o.inv||0,.18);fxe({k:'melee',x:o.x+c*30,y:o.y+n*30,fx:c,fy:n,r:70,h:o.ch.idx});
 var hx=o.x+c*48,hy=o.y+n*48;aoeHit(o,hx,hy,40,dm,side,300,0);}
function doSlam(o,a,dm,side){var c=Math.cos(a),n=Math.sin(a),x=o.x+c*42,y=o.y+n*42;fxe({k:'boom',x:x,y:y,r:50,h:o.ch.idx});fxe({k:'melee',x:o.x,y:o.y,fx:c,fy:n,r:o.ch.rng,h:o.ch.idx});shake=Math.max(shake,.14);aoeHit(o,x,y,50,dm,side,240,side==='p'?.45:0);}
/* fire one attack for any hero (player, ally bot or rival bot) */
function heroShoot(o,a,dm,aimD,side){var k=o.ch.kind;
 if(k==='lunge'){doLunge(o,a,dm,side);return;}if(k==='slam'){doSlam(o,a,dm,side);return;}
 var L=wShots(o,a,dm,aimD),arr=side==='p'?shots:eshots;
 if(k==='burst'){arr.push(L[0]);for(var j=1;j<3;j++)pq.push({t:j*.08,o:o,a:a,dm:dm,side:side});return;}
 L.forEach(function(q){arr.push(q);});}
function pqTick(dt){for(var i=pq.length-1;i>=0;i--){var q=pq[i];q.t-=dt;if(q.t>0)continue;pq.splice(i,1);if(state!=='play'||!q.o||q.o.hp<=0)continue;var L=wShots(q.o,q.a,q.dm);(q.side==='p'?shots:eshots).push(L[0]);}
 for(var j=acid.length-1;j>=0;j--){var A=acid[j];A.t-=dt;A.tk-=dt;if(A.t<=0){acid.splice(j,1);continue;}if(A.tk>0)continue;A.tk=.4;fxe({k:'phit',x:A.x+(Math.random()-.5)*A.r,y:A.y+(Math.random()-.5)*A.r*.6,h:11});
  if(A.side==='p')enemies.forEach(function(e){if(e.hp>0&&Math.hypot(e.x-A.x,e.y-A.y)<=A.r+e.r)hitEnemy(e,A.d,0,0,0,A.o);});else tFoes(1).forEach(function(p){if(Math.hypot(p.x-A.x,p.y-A.y)<=A.r+p.r)tHit(p,A.d,A.x,A.y);});}
 enemies.forEach(function(e){if(!(e.poi>0)||e.hp<=0)return;e.poi-=dt;e.poT=(e.poT||0)-dt;if(e.poT<=0){e.poT=.5;hitEnemy(e,e.poD||.2,0,0,0,e.poO);burst(e.x,e.y,'#a3e635',2);}});}
function fire(pl){
 var ch=pl.ch,dm=ch.dmg*(pl.bD>0?1.6:1)*UP.dmg*pl.lm,a=Math.atan2(pl.fy,pl.fx),k=ch.kind;heroShoot(pl,a,dm,pl.aimD,'p');
 if(k==='lunge'||k==='slam'){noise(.12,k==='slam'?300:1400,.08);return;}
 var SN={shot:[620,.09,'triangle',.05,380],spread:[160,.14,'triangle',.07,80],bomb:[260,.15,'sine',.06,180],boom:[500,.1,'sine',.05,300],twin:[900,.06,'triangle',.04,500],pierce:[760,.12,'sine',.05,300],homing:[400,.12,'sine',.05,700],wave:[300,.12,'sawtooth',.04,160],chain:[1200,.1,'square',.03,400],bounce:[700,.07,'square',.04,900],sine:[500,.14,'sine',.04,900],sonic:[180,.16,'sawtooth',.05,420],burst:[980,.05,'triangle',.04,700],venom:[420,.08,'sine',.05,240],axe:[220,.12,'triangle',.06,140]}[k];
 if(k==='flame')noise(.05,900,.03);else if(SN)beep(SN[0],SN[1],SN[2],SN[3],SN[4]);
}
function fireOld(pl){""")

# ---------- 3. manual aim: bombs land where you aim (drag distance) ----------
rep("pl.aimD=near?nd:ch.rng;", "pl.aimD=near?nd:ch.rng;if(pl.aimO>0)pl.aimD=ch.rng*Math.max(.2,Math.min(1,pl.aimP==null?1:pl.aimP));")

# ---------- 4. player shots: lobbed, bouncing, wavy, growing, chain, poison ----------
rep("s.px=s.x;s.py=s.y;s.life-=dt;s.x+=s.vx*dt;s.y+=s.vy*dt;\n", "s.px=s.x;s.py=s.y;s.life-=dt;s.x+=s.vx*dt;s.y+=s.vy*dt;projFx(s,dt);\n")
rep("for(var i=0;i<enemies.length&&!s.dead;i++){var e=enemies[i];if(e.hp<=0)continue;\n   if(segD(s.px,s.py,s.x,s.y,e.x,e.y)<e.r+s.r){",
    "for(var i=0;i<enemies.length&&!s.dead&&!s.lob;i++){var e=enemies[i];if(e.hp<=0)continue;\n   if(segD(s.px,s.py,s.x,s.y,e.x,e.y)<e.r+s.r){")
rep("if(s.boom)explode(s);else{var d=Math.hypot(s.vx,s.vy)||1;hitEnemy(e,s.dmg,s.vx/d,s.vy/d,160,s.o);}}}",
    "if(s.boom)explode(s);else{var d=Math.hypot(s.vx,s.vy)||1;hitEnemy(e,s.dmg,s.vx/d,s.vy/d,160,s.o);if(s.chain)chainZap(s,e);if(s.poi){e.poi=1.6;e.poD=s.dmg*.3;e.poO=s.o;}}}}")
rep("shots.forEach(function(s){if(s.dead)return;for(var j=0;j<obs.length;j++){var ob=obs[j];if(ob.k==='void')continue;if(segD(s.px==null?s.x:s.px,s.py==null?s.y:s.py,s.x,s.y,ob.x,ob.y)<ob.r+s.r*.5){",
    "shots.forEach(function(s){if(s.dead||s.lob)return;for(var j=0;j<obs.length;j++){var ob=obs[j];if(ob.k==='void')continue;if(segD(s.px==null?s.x:s.px,s.py==null?s.y:s.py,s.x,s.y,ob.x,ob.y)<ob.r+s.r*.5){if(s.bnc>0&&!ob.br){bounceOff(s,ob);break;}")
# acid pool where a flask lands
rep("function explode(s){fxe({k:'boom',x:s.x,y:s.y,r:s.boom||40,h:s.o&&s.o.ch?s.o.ch.idx:-1});",
    "function explode(s){if(s.pool&&acid.length<8)acid.push({x:s.x,y:s.y,r:s.boom||40,t:2,tk:.2,d:(s.dmg||1)*.35,o:s.o,side:'p'});fxe({k:'boom',x:s.x,y:s.y,r:s.boom||40,h:s.o&&s.o.ch?s.o.ch.idx:-1});")

# ---------- 5. rival shots (eshots): same behaviours ----------
old_e = s[s.index(" eshots.forEach(function(s){var ox=s.x,oy=s.y;"):]
old_e = old_e[:old_e.index("\n eshots=eshots.filter(")]
new_e = r""" eshots.forEach(function(s){var ox=s.x,oy=s.y;s.life-=dt;s.x+=s.vx*dt;s.y+=s.vy*dt;projFx(s,dt);if(s.ret&&!s.rd&&s.life<=s.rl){s.vx=-s.vx;s.vy=-s.vy;s.rd=1;s.hit=[];}var rr=4+(s.r||0)*.4;
  if(!s.lob){var vs=ps.concat(tbots);for(var i=0;i<vs.length;i++){var p=vs[i];if(p.hp>0&&segD(ox,oy,s.x,s.y,p.x,p.y)<p.r+rr){if(s.pierce){s.hit=s.hit||[];if(s.hit.indexOf(p)>=0)continue;s.hit.push(p);if(p.bot)botHurt(p,s.dmg,s.x-s.vx,s.y-s.vy);else hurt(p,s.dmg,s.x-s.vx,s.y-s.vy);continue;}if(s.boom)eBoom(s);else if(p.bot)botHurt(p,s.dmg,s.x-s.vx,s.y-s.vy);else hurt(p,s.dmg,s.x-s.vx,s.y-s.vy);s.life=0;break;}}
   if(s.life>0&&s.o&&s.o.ch&&!s.pierce)for(var k=0;k<obs.length;k++){var ob=obs[k];if(ob.k==='void')continue;if(segD(ox,oy,s.x,s.y,ob.x,ob.y)<ob.r+(s.r||4)*.5){if(s.bnc>0){bounceOff(s,ob);break;}s.life=0;break;}}}
  if(s.life<=0&&s.boom)eBoom(s);});"""
s = s.replace(old_e, new_e)
rep("eshots=eshots.filter(function(s){return s.life>0&&s.x>-10&&s.x<W+10&&s.y>-10&&s.y<H+10;});",
    "eshots=eshots.filter(function(s){return s.life>0&&s.x>-10&&s.x<W+10&&s.y>-10&&s.y<H+10;});pqTick(dt);")

# ---------- 6. 2D drawing: acid pools and chain lightning ----------
rep("function drawDrops(){", "function drawDrops(){acid.forEach(function(A){ctx.fillStyle='rgba(52,211,153,'+(.22+.12*Math.sin(Date.now()/150))+')';ctx.beginPath();ctx.ellipse(A.x,A.y,A.r,A.r*.6,0,0,6.3);ctx.fill();});")

open(P, 'w').write(s)

# ---------- 7. team.js: rival hero bots use the same weapons ----------
TP = '/home/claude/enm/team.js'
t = open(TP).read()
a = t.index("function tFire(e,tg){")
b = t.index("function tSuper(e){")
t = t[:a] + r"""function tFire(e,tg){var ch=e.ch,k=ch.kind,dm=tDmg(e),lead=DF[dfi]&&dfi>=2?.18:0,ax=tg.x+(tg.vx||0)*lead,ay=tg.y+(tg.vy||0)*lead,a=Math.atan2(ay-e.y,ax-e.x)+(Math.random()-.5)*.14,dd=Math.hypot(tg.x-e.x,tg.y-e.y);
 if(k==='spread')dm=Math.max(2,Math.round(dm/(ch.pel||3)*1.6));else if(k==='twin')dm=Math.max(2,Math.round(dm*.6));else if(k==='burst')dm=Math.max(2,Math.round(dm*.45));
 var n0=eshots.length;heroShoot(e,a,dm,dd,'e');for(var i=n0;i<eshots.length;i++)if(eshots[i].boom)eshots[i].r=7;}
""" + t[b:]
t = t.replace("function tDmg(e){var m=e.net?1:(DF[dfi]?DF[dfi][2]:1);return Math.max(3,Math.round(e.ch.dmg*(e.ch.kind?8:11)*(.7+.3*m)));}",
              "function tDmg(e){var m=e.net?1:(DF[dfi]?DF[dfi][2]:1);return Math.max(3,Math.round(e.ch.dmg*(e.ch.kind&&!MELK[e.ch.kind]?8:11)*(.7+.3*m)));}")
assert "MELK[e.ch.kind]" in t
open(TP, 'w').write(t)
print('ok')
