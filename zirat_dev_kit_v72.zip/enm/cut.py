# remove the demon's diorama base: drop triangles below the feet and the props around them
import sys, numpy as np
W=sys.argv[1].rstrip('/')+'/'; yc=float(sys.argv[2]); rc=float(sys.argv[3]); yr=float(sys.argv[4])
P=np.load(W+'raw_pos.npy');I=np.load(W+'hi_idx.npy').reshape(-1,3);U=np.load(W+'hi_uv.npy')
C=P[I].mean(1);r=np.hypot(C[:,0],C[:,2])
keep=(C[:,1]>=yc)&~((r>rc)&(C[:,1]<yr))
I2=I[keep];used=np.unique(I2);remap=-np.ones(len(P),np.int64);remap[used]=np.arange(len(used))
P2=P[used].copy();P2[:,1]-=P2[:,1].min();np.save(W+'cut_pos.npy',P2);np.save(W+'cut_uv.npy',U[used]);np.save(W+'cut_idx.npy',remap[I2].astype(np.uint32))
print('kept',keep.sum(),'of',len(I),'bbox',P2.min(0),P2.max(0))
c=(P2.max(0)+P2.min(0))/2;Q=(P2-c);Q=Q/(P2.max(0)-P2.min(0)).max()*.95
Q.astype(np.float32).tofile(W+'hi_pos.bin');U[used].astype(np.float32).tofile(W+'hi_uv.bin');remap[I2].astype(np.uint32).tofile(W+'hi_idx.bin')
