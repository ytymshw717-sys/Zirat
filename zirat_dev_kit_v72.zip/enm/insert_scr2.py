# insert the 5 screen images (hub, online, settings, pass, profile) as base64 webp constants between markers
import base64,re,sys
F='/home/claude/arena3_stage.html'
s=open(F,encoding='utf-8').read()
names={'HUBIMG':'hub','ONLIMG':'onl','CFGIMG':'cfg','PASIMG':'pas','PRFIMG':'prf'}
js='/*SCR2-IMG-START*/'+''.join("var %s='data:image/webp;base64,%s';"%(v,base64.b64encode(open('/home/claude/scr2/%s.webp'%k,'rb').read()).decode()) for v,k in names.items())+'/*SCR2-IMG-END*/\n'
if '/*SCR2-IMG-START*/' in s:
    s=re.sub(r'/\*SCR2-IMG-START\*/.*?/\*SCR2-IMG-END\*/\n',lambda m:js,s,flags=re.S)
else:
    i=s.index("var VICIMG=")
    s=s[:i]+js+s[i:]
open(F,'w',encoding='utf-8').write(s)
print('ok',len(js))
