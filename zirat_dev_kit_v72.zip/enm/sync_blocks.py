# copies enm/team.js and enm/netgame.js into arena3_stage.html between their markers (run before t3/emb_stage.sh builds)
s=open('/home/claude/arena3_stage.html').read()
for m,f in (('NETG','enm/netgame.js'),('TEAM','enm/team.js')):
    a=s.index('/*%s-START*/'%m)+len('/*%s-START*/'%m);b=s.index('/*%s-END*/'%m)
    src=open('/home/claude/'+f).read()
    old=s[a:b];new=old[:len(old)-len(old.lstrip())]+src.strip()+old[len(old.rstrip()):]
    s=s[:a]+new+s[b:]
open('/home/claude/arena3_stage.html','w').write(s)
# enm/combat3.js -> g3/g3.js between /*SHOTS-START*/ and /*SHOTS-END*/
g=open('/home/claude/g3/g3.js').read();c=open('/home/claude/enm/combat3.js').read()
a=g.index('/*SHOTS-START*/')+len('/*SHOTS-START*/');b=g.index('/*SHOTS-END*/');old=g[a:b]
g=g[:a]+old[:len(old)-len(old.lstrip())]+c.strip()+old[len(old.rstrip()):]+g[b:]
open('/home/claude/g3/g3.js','w').write(g)
