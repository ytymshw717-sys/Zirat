/* temple-garden arena dressing (player's mockup): stone wall with posts, stone lanterns, cherry trees, bushes, banners, torii gate, grass around.
   Everything static is merged per colour so it costs only a handful of draw calls. */
function r3garden(wg,own,T,v){
 var B={},ico=T.ico||(T.ico=new THREE.IcosahedronGeometry(1,1)),cone4=T.cone4||(T.cone4=new THREE.ConeGeometry(1,1,4)),M4=new THREE.Matrix4(),Q=new THREE.Quaternion(),E=new THREE.Euler(),S=new THREE.Vector3(),P=new THREE.Vector3();
 function part(geo,col,basic,sx,sy,sz,x,y,z,rx,ry,rz,shadow){var k=col+(basic?'b':'l')+(shadow?'s':'');var b=B[k]||(B[k]={col:col,basic:basic,shadow:shadow,list:[]});
  E.set(rx||0,ry||0,rz||0);Q.setFromEuler(E);S.set(sx,sy,sz);P.set(x,y,z);M4.compose(P,Q,S);var g=geo.index?geo.toNonIndexed():geo.clone();g.applyMatrix4(M4);b.list.push(g);}
 function flush(){for(var k in B){var b=B[k],n=0;b.list.forEach(function(g){n+=g.attributes.position.count;});var pos=new Float32Array(n*3),nor=new Float32Array(n*3),o=0;
   b.list.forEach(function(g){pos.set(g.attributes.position.array,o*3);if(g.attributes.normal)nor.set(g.attributes.normal.array,o*3);o+=g.attributes.position.count;g.dispose();});
   var G=new THREE.BufferGeometry();G.setAttribute('position',new THREE.BufferAttribute(pos,3));G.setAttribute('normal',new THREE.BufferAttribute(nor,3));own.g.push(G);
   var m=b.basic?new THREE.MeshBasicMaterial({color:b.col}):new THREE.MeshLambertMaterial({color:b.col});own.m.push(m);var me=new THREE.Mesh(G,m);me.castShadow=!!b.shadow;me.receiveShadow=!b.basic;wg.add(me);}}
 var sd=31;function rnd(){sd=(sd*16807)%2147483647;return sd/2147483647;}
 // stone wall around the arena with square posts and caps
 var WC=v===2?'#6b7186':'#8d8780',WT=v===2?'#9aa0b6':'#bdb5a8';
 function wallRun(x0,z0,x1,z1,h){var dx=x1-x0,dz=z1-z0,L=Math.hypot(dx,dz),ry=Math.atan2(dx,dz);
  part(T.box,WC,0,.55,h,L,(x0+x1)/2,h/2,(z0+z1)/2,0,ry,0,1);part(T.box,WT,0,.68,.1,L+.1,(x0+x1)/2,h+.05,(z0+z1)/2,0,ry,0,0);
  var n=Math.max(1,Math.round(L/3.2));for(var i=0;i<=n;i++){var t=i/n,px=x0+dx*t,pz=z0+dz*t;part(T.box,WC,0,.62,h+.32,.62,px,(h+.32)/2,pz,0,ry,0,1);part(T.box,WT,0,.76,.12,.76,px,h+.38,pz,0,ry,0,0);if(v===2)lantern(px,pz,.42,h+.44);}}
 // stone lanterns (toro) with a warm glowing window
 var glow=null;try{var gc=document.createElement('canvas');gc.width=gc.height=64;var gx=gc.getContext('2d'),gr=gx.createRadialGradient(32,32,2,32,32,32);gr.addColorStop(0,'rgba(255,214,140,.95)');gr.addColorStop(.4,'rgba(255,170,80,.35)');gr.addColorStop(1,'rgba(255,150,60,0)');gx.fillStyle=gr;gx.fillRect(0,0,64,64);glow=new THREE.CanvasTexture(gc);own.t.push(glow);}catch(e){}
 function lantern(x,z,s,yb){var L=v===2?'#7d8296':'#8a8580',D='#55525a';yb=yb||0;var y0=yb;part(T.box,L,0,.8*s,.18*s,.8*s,x,y0+.09*s,z,0,0,0,1);part(T.cyl,L,0,.16*s,1.0*s,.16*s,x,y0+.68*s,z,0,0,0,1);part(T.box,L,0,.7*s,.12*s,.7*s,x,y0+1.24*s,z,0,0,0,1);
  part(T.box,'#ffd27a',1,.42*s,.42*s,.42*s,x,y0+1.51*s,z,0,0,0,0);[[-1,-1],[1,-1],[-1,1],[1,1]].forEach(function(q){part(T.box,D,0,.08*s,.46*s,.08*s,x+q[0]*.21*s,y0+1.51*s,z+q[1]*.21*s,0,0,0,0);});
  part(cone4,D,0,.62*s,.38*s,.62*s,x,y0+1.92*s,z,0,Math.PI/4,0,1);part(T.sph,D,0,.09*s,.09*s,.09*s,x,y0+2.16*s,z,0,0,0,0);
  if(glow&&!yb){var sm=new THREE.SpriteMaterial({map:glow,color:'#ffffff',transparent:true,depthWrite:false,blending:THREE.AdditiveBlending});own.m.push(sm);var sp=new THREE.Sprite(sm);sp.position.set(x,y0+1.51*s,z);sp.scale.set(2.2*s,2.2*s,1);wg.add(sp);}}
 [[-13.1,-6.4],[13.1,-6.4],[-13.1,0],[13.1,0],[-13.1,6.3],[13.1,6.3],[-6.5,-7.9],[6.5,-7.9]].forEach(function(q){lantern(q[0],q[1],1);});
 if(v===2){ /* rounded stone balustrade (lotus arena): straight runs + corner arcs, a lantern on every post */
  var RR=3.5,X=12.3,Z=7.05,pts=[];
  function arc(cx,cz,a0){for(var q=0;q<=6;q++){var a=a0+q/6*Math.PI/2;pts.push([cx+Math.cos(a)*RR,cz+Math.sin(a)*RR]);}}
  arc(X-RR,Z-RR,0);arc(-X+RR,Z-RR,Math.PI/2);arc(-X+RR,-Z+RR,Math.PI);arc(X-RR,-Z+RR,Math.PI*1.5);pts.push(pts[0]);
  for(var q2=0;q2<pts.length-1;q2++){var a=pts[q2],b=pts[q2+1],hz=(a[1]+b[1])/2<-6?.75:(a[1]+b[1])/2>6?.32:.55,L=Math.hypot(b[0]-a[0],b[1]-a[1]);
   if(L<.05)continue;var ry=Math.atan2(b[0]-a[0],b[1]-a[1]),mx=(a[0]+b[0])/2,mz=(a[1]+b[1])/2;
   part(T.box,WC,0,.5,hz,L+.08,mx,hz/2,mz,0,ry,0,1);part(T.box,WT,0,.62,.1,L+.14,mx,hz+.05,mz,0,ry,0,0);
   if(L>2.4){var nn=Math.round(L/3);for(var r2=1;r2<nn;r2++){var tt=r2/nn,px=a[0]+(b[0]-a[0])*tt,pz=a[1]+(b[1]-a[1])*tt;part(T.box,WC,0,.6,hz+.3,.6,px,(hz+.3)/2,pz,0,ry,0,1);part(T.box,WT,0,.74,.12,.74,px,hz+.36,pz,0,ry,0,0);lantern(px,pz,.42,hz+.42);}}}
  [[X-RR*.3,Z-RR*.3],[-X+RR*.3,Z-RR*.3],[-X+RR*.3,-Z+RR*.3],[X-RR*.3,-Z+RR*.3]].forEach(function(c){var hz=c[1]<0?.75:.32;part(T.box,WC,0,.66,hz+.34,.66,c[0],(hz+.34)/2,c[1],0,Math.PI/4,0,1);part(T.box,WT,0,.8,.12,.8,c[0],hz+.4,c[1],0,Math.PI/4,0,0);lantern(c[0],c[1],.48,hz+.46);});
  /* grass + bushes fill the cut-off corners */
  [[X,Z],[-X,Z],[-X,-Z],[X,-Z]].forEach(function(c){for(var q3=0;q3<5;q3++){var s3=.45+rnd()*.3;part(ico,['#3f7f34','#4f9a3c','#5fae47'][q3%3],0,s3,s3*.7,s3,c[0]-Math.sign(c[0])*(.3+rnd()*.9),s3*.4,c[1]-Math.sign(c[1])*(.3+rnd()*.9),0,rnd()*3,0,0);}});
 }else{ wallRun(-12.3,-7.05,12.3,-7.05,.7);wallRun(-12.3,7.05,12.3,7.05,.3);wallRun(-12.3,-7.05,-12.3,7.05,.55);wallRun(12.3,-7.05,12.3,7.05,.55);}
 /* far backdrop: mountains, temple and sky from the garden painting, seen above the arena */
 try{if(typeof MENUIMG!=='undefined'){var im=new Image();var bt=new THREE.Texture(im);im.onload=function(){bt.needsUpdate=true;};im.src=MENUIMG;bt.repeat.set(1,.56);bt.offset.set(0,.44);own.t.push(bt);
  var bmt=new THREE.MeshBasicMaterial({map:bt,fog:false});own.m.push(bmt);var bg2=new THREE.PlaneGeometry(58,27);own.g.push(bg2);var bp=new THREE.Mesh(bg2,bmt);bp.position.set(0,12.2,-13.6);wg.add(bp);}}catch(e){}
 // cherry trees: bent trunk, pink blossom clusters
 var PK=['#f7a8cb','#f28dbd','#fbc3dc'],TR='#5b3a2b';
 function tree(x,z,s,ry){var lean=(rnd()-.5)*.35;part(T.cyl,TR,0,.22*s,1.6*s,.22*s,x,.8*s,z,0,0,lean,1);var tx=x-Math.sin(lean)*1.4*s,ty=1.55*s;
  part(T.cyl,TR,0,.14*s,1.2*s,.14*s,tx+.25*s,ty+.45*s,z,0,0,-.55,1);part(T.cyl,TR,0,.13*s,1.1*s,.13*s,tx-.3*s,ty+.4*s,z+.1*s,.2,0,.6,1);
  for(var i=0;i<9;i++){var a=i/9*6.283+ry,rr=(i%3?.95:.4)*s,yy=ty+1.05*s+(i%3?0:.45*s)+rnd()*.25*s;part(ico,PK[i%3],0,(.75+rnd()*.35)*s,(.6+rnd()*.25)*s,(.75+rnd()*.35)*s,tx+Math.cos(a)*rr,yy,z+Math.sin(a)*rr*.85,0,rnd()*3,0,0);}}
 [[-15.2,-8.6,1.25],[-15.6,-3.2,1.1],[-15.1,2.4,1.2],[-15.7,7.6,1.15],[15.3,-8.4,1.2],[15.6,-2.8,1.15],[15.2,2.8,1.1],[15.6,7.8,1.2],[-9.5,-10.2,1.35],[9.8,-10.4,1.35],[-3.5,-11.6,1.2],[4.2,-11.8,1.25]].forEach(function(q){tree(q[0],q[1],q[2],rnd()*6);});
 // bushes along the outside of the wall
 var GR=['#3f7f34','#4f9a3c','#5fae47'];
 for(var i=0;i<34;i++){var side=i%4,u=rnd(),x,z;if(side===0){x=-13.4-rnd()*.9;z=-7+u*14;}else if(side===1){x=13.4+rnd()*.9;z=-7+u*14;}else if(side===2){x=-12+u*24;z=-8.1-rnd()*.7;}else{x=-12+u*24;z=7.9+rnd()*.5;}
  var s=.45+rnd()*.35;part(ico,GR[i%3],0,s,s*.75,s,x,s*.45,z,0,rnd()*3,0,0);if(rnd()<.5)part(ico,GR[(i+1)%3],0,s*.7,s*.55,s*.7,x+s*.6,s*.3,z+s*.2,0,0,0,0);
  if(rnd()<.35)part(T.sph,'#f9a8d4',1,.09,.09,.09,x+(rnd()-.5)*s,s*.85,z+(rnd()-.5)*s,0,0,0,0);}
 // red banners with a gold disc, facing the arena
 function banner(x,z,ry){part(T.cyl,'#3b2a20',0,.07,2.6,.07,x,1.3,z,0,0,0,1);part(T.box,'#3b2a20',0,1.1,.07,.07,x,2.5,z,0,ry,0,0);
  part(T.box,'#c9a227',0,1.0,1.72,.05,x,1.62,z,0,ry,0,1);part(T.box,'#b3202a',0,.9,1.6,.07,x,1.62,z,0,ry,0,1);part(T.cyl,'#e8c25a',0,.26,.08,.26,x+Math.sin(ry)*.05,1.72,z+Math.cos(ry)*.05,Math.PI/2,ry,0,0);}
 banner(-13.6,-3.4,Math.PI/2);banner(-13.6,3.4,Math.PI/2);banner(13.6,-3.4,-Math.PI/2);banner(13.6,3.4,-Math.PI/2);
 // torii gate behind the far wall
 var RD='#c0392b',DK='#2a2526';part(T.cyl,RD,0,.24,3.4,.24,-2.4,1.7,-9.4,0,0,0,1);part(T.cyl,RD,0,.24,3.4,.24,2.4,1.7,-9.4,0,0,0,1);
 part(T.box,RD,0,5.6,.28,.36,0,2.75,-9.4,0,0,0,1);part(T.box,DK,0,6.8,.3,.5,0,3.45,-9.4,0,0,0,1);part(T.box,RD,0,6.4,.22,.42,0,3.25,-9.4,0,0,0,0);part(T.box,DK,0,.3,.7,.2,0,3.05,-9.4,0,0,0,0);
 flush();
 // grass around the arena (textured ground)
 try{var c=document.createElement('canvas');c.width=c.height=128;var x2=c.getContext('2d');x2.fillStyle='#4e8a3a';x2.fillRect(0,0,128,128);
  for(i=0;i<420;i++){x2.fillStyle=['#5c9a44','#447a33','#66a84c','#3e6f2e'][i%4];x2.fillRect(rnd()*128,rnd()*128,2,3+rnd()*3);}
  for(i=0;i<14;i++){x2.fillStyle=['#f9a8d4','#ffffff','#fde68a'][i%3];x2.beginPath();x2.arc(rnd()*128,rnd()*128,1.6,0,6.3);x2.fill();}
  var tx=new THREE.CanvasTexture(c);tx.wrapS=tx.wrapT=THREE.RepeatWrapping;tx.repeat.set(36,36);own.t.push(tx);return tx;}catch(e){return null;}
}
