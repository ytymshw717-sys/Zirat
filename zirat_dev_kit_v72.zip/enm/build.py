# enemy GLB -> compact vertex-coloured mesh for the game (front +z, feet at y=0, height 1)
import sys, json, base64, struct, subprocess, numpy as np
from PIL import Image
from scipy.spatial import cKDTree
from scipy.sparse import coo_matrix
from scipy.sparse.csgraph import connected_components
SP='/tmp/claude-0/-home-claude/b0ae6ea6-7673-5629-85ca-afcd48e28043/scratchpad/'
n=sys.argv[1]; target=int(sys.argv[2]); rot=float(sys.argv[3]) if len(sys.argv)>3 else 0; mincomp=int(sys.argv[4]) if len(sys.argv)>4 else 60
W='/home/claude/enm/'+n+'/'
import os
if os.path.exists(W+'cut_pos.npy'): P=np.load(W+'cut_pos.npy');U=np.load(W+'cut_uv.npy');I=np.load(W+'cut_idx.npy').reshape(-1,3).astype(np.int64)
else: P=np.load(W+'raw_pos.npy');U=np.load(W+'hi_uv.npy');I=np.load(W+'hi_idx.npy').reshape(-1,3).astype(np.int64)
P=P.astype(np.float64)
if rot:
    a=np.radians(rot);c,s=np.cos(a),np.sin(a);x,z=P[:,0].copy(),P[:,2].copy();P[:,0]=x*c+z*s;P[:,2]=-x*s+z*c
# weld duplicated seam vertices (needed for connectivity and for the simplifier)
key=np.round(P*2e5).astype(np.int64);_,wid=np.unique(key,axis=0,return_inverse=True);wid=wid.ravel();Pw=np.zeros((wid.max()+1,3));Pw[wid]=P;Iw=wid[I]
# drop tiny floating pieces (debris, chains)
nv=len(Pw);A=coo_matrix((np.ones(len(Iw)*3),(np.repeat(Iw[:,0],3),Iw.ravel())),shape=(nv,nv))
nc,lab=connected_components(A,directed=False);fl=lab[Iw[:,0]];cnt=np.bincount(fl,minlength=nc);keepf=cnt[fl]>=mincomp
print(n,'components',nc,'dropped tris',(~keepf).sum())
I=I[keepf];Iw=Iw[keepf]
P[:,1]-=P[I.ravel(),1].min();H=P[I.ravel(),1].max();P/=H
low=P[I.ravel()];lo=low[low[:,1]<.25];cx,cz=np.median(lo[:,0]),np.median(lo[:,2]);P[:,0]-=cx;P[:,2]-=cz
# texture samples on the hi-res surface (centroid + 3 inner points per triangle)
tex=np.asarray(Image.open(W+'tex.jpg').convert('RGB'),np.float32);TH,TW=tex.shape[:2]
fn=np.cross(P[I[:,1]]-P[I[:,0]],P[I[:,2]]-P[I[:,0]]);ar=np.linalg.norm(fn,axis=1)+1e-12;fn/=ar[:,None]
S=[];C=[];N=[]
for b in [(1/3,1/3,1/3),(.6,.2,.2),(.2,.6,.2),(.2,.2,.6)]:
    p=P[I[:,0]]*b[0]+P[I[:,1]]*b[1]+P[I[:,2]]*b[2];uv=U[I[:,0]]*b[0]+U[I[:,1]]*b[1]+U[I[:,2]]*b[2]
    px=np.clip((uv[:,0]%1)*TW,0,TW-1).astype(int);py=np.clip((uv[:,1]%1)*TH,0,TH-1).astype(int)
    S.append(p);C.append(tex[py,px]);N.append(fn)
S=np.concatenate(S);C=np.concatenate(C);N=np.concatenate(N)
# decimate (position-only quadric simplifier)
Pw=np.zeros((wid.max()+1,3));Pw[wid]=P
used=np.unique(Iw);rm=-np.ones(len(Pw),np.int64);rm[used]=np.arange(len(used));Vh=Pw[used];Fh=rm[Iw]
with open(SP+'eq_in.bin','wb') as f:f.write(struct.pack('<ii',len(Vh),len(Fh)));f.write(Vh.astype(np.float32).tobytes());f.write(Fh.astype(np.int32).tobytes())
subprocess.run(['/home/claude/glb/qsimp',SP+'eq_in.bin',SP+'eq_out.bin',str(target)],check=True,stdout=subprocess.DEVNULL)
d=open(SP+'eq_out.bin','rb').read();v2,f2=struct.unpack('<ii',d[:8]);V=np.frombuffer(d,np.float32,v2*3,8).reshape(-1,3).astype(np.float64);F=np.frombuffer(d,np.int32,f2*3,8+v2*12).reshape(-1,3).astype(np.int64)
# vertex normals of the low mesh
fl2=np.cross(V[F[:,1]]-V[F[:,0]],V[F[:,2]]-V[F[:,0]]);VN=np.zeros_like(V)
for k in range(3):np.add.at(VN,F[:,k],fl2)
VN/=np.linalg.norm(VN,axis=1)[:,None]+1e-12
# vertex colour = average of nearby surface samples facing the same way
el=np.linalg.norm(V[F[:,0]]-V[F[:,1]],axis=1).mean()
kd=cKDTree(S);dist,idx=kd.query(V,k=24)
w=np.exp(-(dist/(el*.7+1e-9))**2)*np.clip((N[idx]*VN[:,None,:]).sum(2),0,1)**2
w[w.sum(1)<1e-6]=np.exp(-(dist[w.sum(1)<1e-6]/(el+1e-9))**2)
col=(C[idx]*w[:,:,None]).sum(1)/(w.sum(1)[:,None]+1e-9)
mn=V.min(0);mx=V.max(0);q=np.round((V-mn)/(mx-mn)*65535).astype(np.uint16)
blob=q.tobytes()+F.astype(np.uint16).tobytes()+np.clip(col,0,255).astype(np.uint8).tobytes()
meta={'nv':len(V),'nf':len(F),'mn':[round(x,5) for x in mn],'mx':[round(x,5) for x in mx],'d':base64.b64encode(blob).decode()}
json.dump(meta,open(W+'enemy.json','w'))
print(n,'verts',len(V),'tris',len(F),'b64 KB',len(meta['d'])//1024,'bbox',mn.round(3),mx.round(3))
# preview bins for rviews (vertex colours -> tiny texture strip per vertex is overkill: write colored ply-ish npy)
np.save(W+'low_V.npy',V);np.save(W+'low_F.npy',F);np.save(W+'low_C.npy',col)
