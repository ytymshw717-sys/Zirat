/* ===== 3D loot box opening (the player's own box model): drops in, glows in its rarity colour, charges, bursts open and spits the rewards out one by one ===== */
var BXS=null;
var BXT=[{c:'#94a3b8',g:'#e2e8f0',s:.8},{c:'#3b82f6',g:'#93c5fd',s:.93},{c:'#a855f7',g:'#e9d5ff',s:1.06},{c:'#f59e0b',g:'#fde68a',s:1.2}];
function bxTex(){var c=document.createElement('canvas');c.width=c.height=128;var x=c.getContext('2d'),g=x.createRadialGradient(64,64,2,64,64,64);g.addColorStop(0,'rgba(255,255,255,1)');g.addColorStop(.25,'rgba(255,255,255,.55)');g.addColorStop(.6,'rgba(255,255,255,.12)');g.addColorStop(1,'rgba(255,255,255,0)');x.fillStyle=g;x.fillRect(0,0,128,128);return new THREE.CanvasTexture(c);}
function bxInit(){
 var dp=window.devicePixelRatio||1,r=new THREE.WebGLRenderer({antialias:dp<2,alpha:true,powerPreference:'high-performance'});r.debug.checkShaderErrors=false;r.setPixelRatio(Math.min(dp,1.5));r.setClearColor(0x000000,0);
 var c=r.domElement;c.style.cssText='position:absolute;left:0;top:0;width:100%;height:100%;display:block;pointer-events:none';
 var sc=new THREE.Scene(),cam=new THREE.PerspectiveCamera(32,1,.1,60);
 sc.add(new THREE.HemisphereLight('#e0e7ff','#312e81',.85));var key=new THREE.DirectionalLight('#ffffff',.95);key.position.set(2.5,4,3.5);sc.add(key);var rim=new THREE.DirectionalLight('#c7d2fe',.8);rim.position.set(-3,2.5,-3);sc.add(rim);
 var pl=new THREE.PointLight('#ffffff',0,7,1.4);pl.position.set(0,1.1,1.4);sc.add(pl);
 var tex=bxTex(),T={box:new THREE.BoxGeometry(1,1,1),oct:new THREE.OctahedronGeometry(1),disc:new THREE.CircleGeometry(1,40)};
 var hold=new THREE.Group();sc.add(hold);
 var mt=egMat();mt.side=THREE.FrontSide;var box=new THREE.Mesh(egGeo('box'),mt);box.rotation.y=Math.PI/2;var pv=new THREE.Group();pv.add(box);hold.add(pv);
 var glow=new THREE.Sprite(new THREE.SpriteMaterial({map:tex,color:'#ffffff',transparent:true,depthWrite:false}));glow.position.set(0,.55,-.9);sc.add(glow);
 // light rays fanning out behind the box
 var N=18,pos=[];for(var i=0;i<N;i++){var a=i/N*6.283,w=.09;pos.push(0,0,0,Math.cos(a-w)*6,Math.sin(a-w)*6,0,Math.cos(a+w)*6,Math.sin(a+w)*6,0);}
 var rg=new THREE.BufferGeometry();rg.setAttribute('position',new THREE.Float32BufferAttribute(pos,3));var rm=new THREE.MeshBasicMaterial({color:'#ffffff',transparent:true,opacity:.22,depthWrite:false,side:THREE.DoubleSide});
 var rays=new THREE.Mesh(rg,rm);rays.position.set(0,.55,-1.6);sc.add(rays);
 var sh=new THREE.Mesh(T.disc,new THREE.MeshBasicMaterial({color:'#000000',transparent:true,opacity:.35,depthWrite:false}));sh.rotation.x=-Math.PI/2;sh.position.y=.005;sc.add(sh);
 var ring=new THREE.Mesh(new THREE.RingGeometry(.92,1,48),new THREE.MeshBasicMaterial({color:'#ffffff',transparent:true,opacity:.8,depthWrite:false,side:THREE.DoubleSide}));ring.rotation.x=-Math.PI/2;ring.position.y=.02;sc.add(ring);
 var im=new THREE.InstancedMesh(T.oct,new THREE.MeshBasicMaterial({color:'#ffffff'}),90);im.frustumCulled=false;var cc=new THREE.Color(1,1,1);for(i=0;i<90;i++)im.setColorAt(i,cc);im.count=0;sc.add(im);
 BXS={r:r,c:c,sc:sc,cam:cam,hold:hold,pv:pv,box:box,mt:mt,glow:glow,rays:rays,rm:rm,sh:sh,ring:ring,pl:pl,im:im,P:[],st:'off',t0:0,raf:0,el:null,w:0,h:0,tier:0,hero:0,spin:.3,flash:0,M:new THREE.Matrix4(),Q:new THREE.Quaternion(),V:new THREE.Vector3(),S:new THREE.Vector3(),E:new THREE.Euler(),C:new THREE.Color()};}
var BXG={},BXH=[[null,null,null],[.56,.63,.6],[.86,.75,.78],[.13,.985,.13]];
function bxGeo(t){if(BXG[t])return BXG[t];var g0=egGeo('box');if(!t){}var g=g0.clone(),ca=g.getAttribute('color'),C=new THREE.Color(),h={},tg=BXH[t]||BXH[0];
 for(var i=0;i<ca.count;i++){C.setRGB(ca.getX(i),ca.getY(i),ca.getZ(i));C.getHSL(h);if(h.s<.3&&h.l<.92){}else{
  var red=h.h>=.88||h.h<.04,blue=h.h>=.45&&h.h<=.78,lite=blue&&h.l>=.75;
  if(t===0){if(red)C.setHSL(.6,h.s*.12,Math.min(.85,h.l+.12));else if(blue)C.setHSL(.6,h.s*(lite?.15:.22),h.l*(lite?1:1.05));}
  else if(red)C.setHSL(tg[0],Math.min(1,h.s*.95),Math.min(.8,h.l+(t===3?.12:.06)));
  else if(lite)C.setHSL(tg[2],h.s*(t===1?1:.75),h.l);
  else if(blue)C.setHSL(tg[1],Math.min(1,h.s*(t===3?1:1)),t===3?h.l*.9:h.l);}
  ca.setXYZ(i,C.r,C.g,C.b);}
 ca.needsUpdate=true;BXG[t]=g;return g;}
function bxSet(tier){var B=BXS,k=BXT[tier]||BXT[0];B.tier=tier;B.k=k;B.glow.material.color.set(k.c);B.rm.color.set(k.g);B.rm.userData.c=k.g;B.ring.material.color.set(k.c);B.pl.color.set(k.g);B.mt.color.set('#ffffff');try{B.box.geometry=bxGeo(tier|0);}catch(e){}}
function bxParts(n,col,sp,up){var B=BXS;for(var i=0;i<n&&B.P.length<90;i++){var a=Math.random()*6.283,s=sp*(.5+Math.random()),c=new THREE.Color(Math.random()<.35?'#ffffff':col);B.P.push({x:0,y:.6,z:.2,vx:Math.cos(a)*s,vy:(up||3)+Math.random()*3,vz:Math.sin(a)*s*.6+.8,t:0,life:.7+Math.random()*.5,s:.05+Math.random()*.06,c:c,rx:Math.random()*6});}}
function bxLoop(now){var B=BXS;if(!B||B.st==='off'){if(B)B.raf=0;return;}
 if(!B.el||!document.body.contains(B.el)){B.st='off';B.raf=0;try{B.c.remove();}catch(e){}return;}
 B.raf=requestAnimationFrame(bxLoop);if(document.hidden)return;
 var t=(now-B.t0)/1000,dt=Math.min(.05,Math.max(0,(now-(B.lt||now))/1000));B.lt=now;
 var w=B.el.clientWidth|0,h=B.el.clientHeight|0;if(w<10||h<10)return;
 if(w!==B.w||h!==B.h){B.w=w;B.h=h;B.r.setSize(w,h,false);B.cam.aspect=w/h;var d=Math.max(4.4,3.1/B.cam.aspect*1.9);B.cam.position.set(0,1.45,d);B.cam.lookAt(0,.62,0);B.cam.fov=32;B.cam.updateProjectionMatrix();}
 var k=B.k,s=k.s,y=0,sq=1,rz=0,ry=Math.sin(t*.7)*.25,sc=s,tt=t-(B.ts||0);
 if(B.st==='drop'){var p=Math.min(1,t/.75);var b=p<.6?1-Math.pow(p/.6,2):Math.abs(Math.sin((p-.6)/.4*Math.PI))*.18*(1-p);y=b*3.2;sq=p>.55&&p<.8?1-Math.sin((p-.55)/.25*Math.PI)*.22:1;if(p>=1){B.st='idle';B.ts=t;}if(p>.55&&!B.landed){B.landed=1;bxParts(10,'#cbd5e1',2.2,1.2);}}
 else if(B.st==='idle'){y=Math.abs(Math.sin(t*2.2))*.05;var wig=(tt%2.6)>2.2?Math.sin(tt*40)*.08:0;rz=wig;sq=1-.03*Math.abs(Math.cos(t*2.2));}
 else if(B.st==='charge'){var q=Math.min(1,tt/.5);rz=Math.sin(tt*60)*.12*q;sc=s*(1+.1*q);B.pl.intensity=q*2.5;y=.04*q;if(q>=1){B.st='burst';B.ts=t;B.flash=1;B.pl.intensity=7;bxParts(70,k.c,3.4,3.5);if(navigator.vibrate){try{navigator.vibrate(40);}catch(e){}}}}
 else if(B.st==='burst'){var q2=Math.min(1,tt/.55);y=Math.sin(q2*Math.PI)*.55;sq=q2<.25?1+.25*Math.sin(q2/.25*Math.PI):1;sc=s*(1-.38*q2);if(q2>=1){B.st='spit';B.ts=t;}}
 else if(B.st==='spit'){sc=s*.55;var q3=Math.max(0,1-tt/.35);y=Math.sin(Math.min(1,tt/.35)*Math.PI)*.35*(B.hop||0);sq=1+.15*q3*(B.hop||0);}
 var low=B.st==='spit'||B.st==='burst'&&tt>.3;B.hold.position.set(0,(low?-.42:0)+y,low?.3:0);B.pv.scale.set(sc*(2-sq),sc*sq,sc*(2-sq));B.pv.rotation.set(0,ry,rz);
 B.flash=Math.max(0,B.flash-dt*2.2);if(B.st!=='charge'&&B.st!=='burst')B.pl.intensity=Math.max(B.hero?2.2+Math.sin(t*16)*1.4:0,B.pl.intensity-dt*6);
 var gp=1+.08*Math.sin(t*3)+B.flash*2.2+(B.hero?.35+.25*Math.sin(t*14):0);B.glow.scale.set(3.6*s*gp,3.6*s*gp,1);B.glow.material.opacity=Math.min(1,.5+B.flash*.5);
 B.spin+=((B.hero?2.4:B.st==='burst'?1.6:.35)-B.spin)*Math.min(1,dt*3);B.rays.rotation.z+=B.spin*dt;B.rm.opacity=(B.hero?.4+.14*Math.sin(t*18):.26)+B.flash*.3;if(B.hero)B.rm.color.setHSL((t*.35)%1,.95,.65);else if(B.rm.userData.c)B.rm.color.set(B.rm.userData.c);
 B.mt.emissive.setRGB(B.flash*.8+(B.st==='charge'?.25:0),B.flash*.8+(B.st==='charge'?.2:0),B.flash*.8);
 B.ring.scale.setScalar(.9*s*(1+.06*Math.sin(t*4))+B.flash*1.4);B.ring.material.opacity=.55+.3*Math.sin(t*4)+B.flash*.4;B.sh.scale.setScalar(.75*s/(1+y*.6));
 var n=0;for(var i=B.P.length-1;i>=0;i--){var P=B.P[i];P.t+=dt;if(P.t>=P.life){B.P.splice(i,1);continue;}P.vy-=7*dt;P.x+=P.vx*dt;P.y+=P.vy*dt;P.z+=P.vz*dt;if(P.y<.02){P.y=.02;P.vy*=-.3;P.vx*=.6;}var f=1-P.t/P.life;
  B.V.set(P.x,P.y+B.hold.position.y*.3,P.z);B.E.set(P.rx+P.t*9,P.t*7,0);B.Q.setFromEuler(B.E);B.S.setScalar(P.s*(.4+f));B.M.compose(B.V,B.Q,B.S);B.im.setMatrixAt(n,B.M);B.C.copy(P.c).multiplyScalar(.75+.25*f);B.im.setColorAt(n,B.C);n++;}
 B.im.count=n;B.im.instanceMatrix.needsUpdate=true;if(B.im.instanceColor)B.im.instanceColor.needsUpdate=true;
 B.r.render(B.sc,B.cam);}
/* build the renderer, all four rarity colourings and the shaders while the player sits in the menu, so the first box opens without a hitch */
function bxWarm(){if(!ready3()||typeof EGLB==='undefined'||!EGLB.box)return false;try{if(!BXS)bxInit();var B=BXS;for(var t=3;t>=0;t--)bxGeo(t);bxSet(0);B.r.setSize(64,64,false);B.cam.aspect=1;B.cam.updateProjectionMatrix();B.r.compile(B.sc,B.cam);B.r.render(B.sc,B.cam);B.w=0;B.h=0;return true;}catch(e){return false;}}
function bxShow(el,tier){if(!ready3()||typeof EGLB==='undefined'||!EGLB.box)return false;try{if(!BXS)bxInit();bxSet(tier|0);var B=BXS;B.el=el;el.appendChild(B.c);B.w=0;B.st='drop';B.landed=0;B.hero=0;B.flash=0;B.P.length=0;B.t0=performance.now();B.ts=0;B.lt=0;B.hold.position.set(0,3,0);if(!B.raf)B.raf=requestAnimationFrame(bxLoop);return true;}catch(e){return false;}}
function bxOpen(){var B=BXS;if(!B||B.st==='off')return;if(B.st==='drop'||B.st==='idle'){B.st='charge';B.ts=(performance.now()-B.t0)/1000;}}
function bxSpit(hero){var B=BXS;if(!B||B.st==='off')return;B.hero=hero?1:0;B.hop=hero?1.6:1;B.st='spit';B.ts=(performance.now()-B.t0)/1000;B.flash=hero?1:.35;bxParts(hero?40:14,hero?'#fde047':B.k.c,hero?3:2,3);}
function bxEnd(){var B=BXS;if(!B)return;B.st='off';try{B.c.remove();}catch(e){}}
