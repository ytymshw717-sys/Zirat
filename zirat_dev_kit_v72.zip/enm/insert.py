import json,re
p='/home/claude/g3/g3.js';s=open(p).read()
D={k:json.load(open('/home/claude/enm/%s/enemy.json'%k)) for k in ['robot','warrior','demon','dragon','box']}
blk='/*EGLB-START*/\nvar EGLB='+json.dumps(D,separators=(',',':'))+';\n'+open('/home/claude/enm/enemy3.js').read()+open('/home/claude/enm/box3.js').read()+'/*EGLB-END*/\n'
if '/*EGLB-START*/' in s: s=re.sub(r'/\*EGLB-START\*/.*?/\*EGLB-END\*/\n',lambda m:blk,s,flags=re.S)
else:
    i=s.index('function r3frame(g){');s=s[:i]+blk+s[i:]
old="var TT=g.T[en.t]||{col:'#ef4444',reach:20,wind:.5},e=r3blob(en,TT)"
new="var TT=g.T[en.t]||{col:'#ef4444',reach:20,wind:.5};if(typeof EGLB!=='undefined'){var me=r3mon(en,TT);if(me){r3monPose(me,en,TT,g,t);return;}}var e=r3blob(en,TT)"
if old in s: s=s.replace(old,new);print('hooked')
else: print('hook already present' if new in s else 'HOOK NOT FOUND')
open(p,'w').write(s);print('size',len(s))
