import json,base64,io,re
from PIL import Image
m=json.load(open('/home/claude/glb/cowboy_meta.json'))
K=1.3;XC=.02;YMIN=m['mn'][1]
def H(x,y,z):return [round((x)*K,4),round((y-YMIN)*K+.01,4),round(z*K,4)]
J={'hip':H(.185,-.30,-.013),'knee':H(.185,-.62,-.01),'sh':H(.33,.10,-.07),'el':H(.36,-.17,-.07),'hd':H(.385,-.44,0.0),'nk':H(0,.20,0.0),'tor':H(0,-.22,.02)}
m['j']=J;m['k']=K;m['xc']=XC
bf=io.BytesIO();Image.open('/home/claude/glb/atlas1k.png').save(bf,'WEBP',quality=88,method=6)
m['tex']='data:image/webp;base64,'+base64.b64encode(bf.getvalue()).decode()
m['d']=open('/home/claude/glb/cowboy_blob.b64').read()
line='var GLBC='+json.dumps(m,separators=(',',':'))+';'
p='/home/claude/g3/g3.js';s=open(p).read()
i=s.index('var GLBC=');j=s.index('\n',i)
s=s[:i]+line+s[j:];open(p,'w').write(s);print('ok',len(line))
