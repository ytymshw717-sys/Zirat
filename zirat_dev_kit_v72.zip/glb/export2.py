# skin weights + compact blob for one hero.  usage: python3 export2.py WORKDIR   (reads WORKDIR/params.json)
import sys, json, base64, io, numpy as np
from PIL import Image
W = sys.argv[1].rstrip('/') + '/'
Pm = json.load(open(W + 'params.json'))
Z = np.load(W + 'model.npz'); V = Z['V']; F = Z['F']; seen = Z['seen']; best = Z['best']; VC = Z['VC']
PR = json.load(open(W + 'prm.json'))
NV = len(V)
XC = Pm['xc']; x = V[:, 0] + XC; y = V[:, 1]; z = V[:, 2]; ax = np.abs(x)
def ss(a, b, t):
    t = np.clip((t - a) / (b - a), 0, 1); return t * t * (3 - 2 * t)
A = Pm['arm']; Hd = Pm['head']
head = np.where(ax < Hd['ax'], ss(Hd['y0'], Hd['y1'], y), (y > Hd['yo']) * 1.0)
xa = A['xa']; za = A['za']; dax = np.hypot(ax - xa, z - za)
armA = np.where(y > A['ys'], ss(A['d0'], A['d1'], ax) * (1 - ss(A['t0'], A['t1'], y)),
        np.where(y > A['yb'], 1 - ss(A['r0'], A['r1'], dax), np.where(y > A['yh'], (ax > A['xh']) * 1.0, 0.0)))
for bx in Pm.get('rigid', []):   # boxes forced onto the torso (props on the back, pouches ...)
    m = (x > bx[0]) & (x < bx[1]) & (y > bx[2]) & (y < bx[3]) & (z > bx[4]) & (z < bx[5])
    armA = np.where(m, 0, armA); head = np.where(m, 0, head)
fore = ss(A['e0'], A['e1'], y)
L = Pm['leg']
legA = np.where(armA > 0, 0, ss(L['y0'], L['y1'], y)) * (1 - head)
shin = ss(L['k0'], L['k1'], y)
rest = (1 - head) * (1 - armA) * (1 - legA)
tors = rest * ss(Pm['body'][0], Pm['body'][1], y); bodyw = rest - tors
side = ss(-.04, .04, x); sideA = (x > 0) * 1.0
Wt = np.zeros((NV, 11))
Wt[:, 0] = bodyw; Wt[:, 1] = tors; Wt[:, 2] = head * (1 - armA)
Wt[:, 3] = legA * (1 - shin) * (1 - side); Wt[:, 4] = legA * shin * (1 - side); Wt[:, 5] = legA * (1 - shin) * side; Wt[:, 6] = legA * shin * side
Wt[:, 7] = armA * (1 - fore) * (1 - sideA); Wt[:, 8] = armA * fore * (1 - sideA); Wt[:, 9] = armA * (1 - fore) * sideA; Wt[:, 10] = armA * fore * sideA
Wt = Wt / Wt.sum(1, keepdims=True)
dom = Wt.argmax(1); isArm = np.isin(dom, [7, 8, 9, 10])
fa = isArm[F]; cy = V[F][:, :, 1].mean(1); cut = (fa.any(1) & ~fa.all(1)) & (cy < Pm['cut'])
keep = ~cut; F = F[keep]; seen = seen[keep]; best = best[keep]; NF = len(F)
print('cut tris', cut.sum(), 'dominant counts', np.bincount(dom, minlength=11))
np.save(W + 'skin_dom.npy', dom)
o = np.argsort(-Wt, 1)[:, :4]; ww = np.take_along_axis(Wt, o, 1); ww /= ww.sum(1, keepdims=True)
wq = np.round(ww * 255).astype(int); wq[:, 0] += 255 - wq.sum(1)
mn = V.min(0); mx = V.max(0); q = np.round((V - mn) / (mx - mn) * 65535).astype(np.uint16)
fv = np.where(seen, best, 9).astype(np.uint8)
vc = np.clip(np.round(VC), 0, 255).astype(np.uint8)
blob = b''.join([q.tobytes(), F.astype(np.uint16).tobytes(), fv.tobytes(), vc.tobytes(), o.astype(np.uint8).tobytes(), wq.astype(np.uint8).tobytes()])
K = Pm['k']; YMIN = mn[1]
def H(p): return [round(p[0] * K, 4), round((p[1] - YMIN) * K + .01, 4), round(p[2] * K, 4)]
J = {k: H(v) for k, v in Pm['joints'].items()}
bf = io.BytesIO(); Image.open(W + 'atlas1k.png').save(bf, 'WEBP', quality=88, method=6)
meta = {'nv': NV, 'nf': NF, 'mn': mn.round(6).tolist(), 'mx': mx.round(6).tolist(), 'f': PR['f'], 'b': PR['b'], 'cf': PR['cf'], 'cb': PR['cb'],
        'j': J, 'k': K, 'xc': XC, 'bm': Pm['bm'], 'un': 9, 'aw': PR['aw'], 's': PR.get('s'), 'cs': PR.get('cs'), 'tex': 'data:image/webp;base64,' + base64.b64encode(bf.getvalue()).decode(), 'd': base64.b64encode(blob).decode()}
json.dump(meta, open(W + 'meta_full.json', 'w'), separators=(',', ':'))
print('blob', len(blob), 'tex', len(bf.getvalue()), 'joints', J)
