import sys,json,numpy as np,subprocess;sys.path.insert(0,'/home/claude/glb')
from glbio import load
W=sys.argv[1].rstrip('/')+'/'
V,F=load(W+'white_mesh.glb');d=np.load(W+'skin_dom.npy')
pal=np.array([[.5,.5,.5],[1,.8,.2],[1,.3,.3],[.2,.5,1],[.1,.2,.6],[.2,1,.4],[.1,.5,.2],[1,.5,1],[.6,.1,.6],[.3,1,1],[.1,.5,.5]])
C=pal[d][F].reshape(-1,3);UV=np.zeros((len(F)*3,2))+.999
json.dump({'v':V.ravel().tolist(),'f':F.ravel().tolist(),'uv':UV.ravel().tolist(),'c':C.ravel().tolist()},open(W+'seg.json','w'))
subprocess.run(['python3','/home/claude/glb/shot.py',W+'seg.json',W+'seg.png','[0,90,180,270]','{"atlas":"white.png"}'],check=True,capture_output=True)
