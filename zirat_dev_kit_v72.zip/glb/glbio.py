import json,struct,numpy as np
def load(p):
    b=open(p,'rb').read();o=12;ch=[]
    while o<len(b):
        cl,ct=struct.unpack('<II',b[o:o+8]);ch.append(b[o+8:o+8+cl]);o+=8+cl
    J=json.loads(ch[0]);B=ch[1]
    def acc(i):
        a=J['accessors'][i];bv=J['bufferViews'][a['bufferView']];off=bv.get('byteOffset',0)+a.get('byteOffset',0)
        dt={5126:np.float32,5125:np.uint32,5123:np.uint16,5121:np.uint8}[a['componentType']]
        n={'SCALAR':1,'VEC2':2,'VEC3':3,'VEC4':4}[a['type']]
        return np.frombuffer(B,dtype=dt,count=a['count']*n,offset=off).reshape(-1,n) if n>1 else np.frombuffer(B,dtype=dt,count=a['count'],offset=off)
    pr=J['meshes'][0]['primitives'][0]
    V=acc(pr['attributes']['POSITION']).astype(np.float64);F=acc(pr['indices']).reshape(-1,3).astype(np.int64)
    return V,F

def save(p,V,F):
    import json,struct
    V=np.asarray(V,np.float32);F=np.asarray(F,np.uint32)
    ib=F.tobytes();vb=V.tobytes();pad=lambda b:b+b'\x00'*((4-len(b)%4)%4)
    ib=pad(ib);B=ib+vb
    J={'asset':{'version':'2.0'},'scene':0,'scenes':[{'nodes':[0]}],'nodes':[{'mesh':0}],
       'meshes':[{'primitives':[{'attributes':{'POSITION':1},'indices':0,'mode':4}]}],
       'buffers':[{'byteLength':len(B)}],
       'bufferViews':[{'buffer':0,'byteOffset':0,'byteLength':F.nbytes},{'buffer':0,'byteOffset':len(ib),'byteLength':len(vb)}],
       'accessors':[{'bufferView':0,'componentType':5125,'count':int(F.size),'type':'SCALAR'},
                    {'bufferView':1,'componentType':5126,'count':int(len(V)),'type':'VEC3','min':V.min(0).tolist(),'max':V.max(0).tolist()}]}
    js=json.dumps(J).encode();js=js+b' '*((4-len(js)%4)%4)
    out=struct.pack('<III',0x46546C67,2,12+8+len(js)+8+len(B))+struct.pack('<II',len(js),0x4E4F534A)+js+struct.pack('<II',len(B),0x004E4942)+B
    open(p,'wb').write(out)
def simplify(src,dst,target):
    import subprocess,struct
    V,F=load(src)
    with open('/tmp/claude-0/-home-claude/b0ae6ea6-7673-5629-85ca-afcd48e28043/scratchpad/qs_in.bin','wb') as f:
        f.write(struct.pack('<ii',len(V),len(F)));f.write(V.astype(np.float32).tobytes());f.write(F.astype(np.int32).tobytes())
    subprocess.run(['/home/claude/glb/qsimp','/tmp/claude-0/-home-claude/b0ae6ea6-7673-5629-85ca-afcd48e28043/scratchpad/qs_in.bin','/tmp/claude-0/-home-claude/b0ae6ea6-7673-5629-85ca-afcd48e28043/scratchpad/qs_out.bin',str(target)],check=True)
    d=open('/tmp/claude-0/-home-claude/b0ae6ea6-7673-5629-85ca-afcd48e28043/scratchpad/qs_out.bin','rb').read();nv,nf=struct.unpack('<ii',d[:8])
    V2=np.frombuffer(d,np.float32,nv*3,8).reshape(-1,3);F2=np.frombuffer(d,np.int32,nf*3,8+nv*12).reshape(-1,3)
    save(dst,V2,F2);return V2,F2

def taubin(V,F,iters=8,lam=.5,mu=-.53):
    from scipy.sparse import coo_matrix
    V=np.array(V,np.float64);n=len(V)
    e=np.concatenate([F[:,[0,1]],F[:,[1,2]],F[:,[2,0]]]);e=np.concatenate([e,e[:,::-1]])
    A=coo_matrix((np.ones(len(e)),(e[:,0],e[:,1])),shape=(n,n)).tocsr();A.data[:]=1
    d=np.array(A.sum(1)).ravel();d[d==0]=1
    for i in range(iters):
        for f in(lam,mu):V=V+f*((A@V)/d[:,None]-V)
    return V
