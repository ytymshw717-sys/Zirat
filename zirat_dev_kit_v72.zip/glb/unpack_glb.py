# Tripo / gltfpack GLB (plain or EXT_meshopt_compression) -> hi_pos.npy, hi_uv.npy, hi_idx.npy, tex.jpg in WORKDIR (raw frame, no transform)
import sys, json, struct, subprocess, numpy as np
W = sys.argv[1].rstrip('/') + '/'; SP = '/tmp/claude-0/-home-claude/b0ae6ea6-7673-5629-85ca-afcd48e28043/scratchpad/'
b = open(W + 'src.glb', 'rb').read(); o = 12; ch = []
while o < len(b):
    cl, ct = struct.unpack('<II', b[o:o + 8]); ch.append(b[o + 8:o + 8 + cl]); o += 8 + cl
J = json.loads(ch[0]); B = ch[1]
cache = {}
def view(i):
    if i in cache: return cache[i]
    v = J['bufferViews'][i]; e = v.get('extensions', {}).get('EXT_meshopt_compression')
    if not e:
        r = B[v.get('byteOffset', 0):v.get('byteOffset', 0) + v['byteLength']]
    else:
        src = B[e.get('byteOffset', 0):e.get('byteOffset', 0) + e['byteLength']]; open(SP + 'mo_in.bin', 'wb').write(src)
        if e['mode'] == 'ATTRIBUTES': subprocess.run(['/home/claude/glb/mdec', 'vtx', SP + 'mo_in.bin', SP + 'mo_out.bin', str(e['count']), str(e['byteStride'])], check=True)
        elif e['mode'] == 'TRIANGLES': subprocess.run(['/home/claude/glb/mdec', 'tri', SP + 'mo_in.bin', SP + 'mo_out.bin', str(e['count'])], check=True)
        else: raise SystemExit('unsupported mode ' + e['mode'])
        r = open(SP + 'mo_out.bin', 'rb').read()
        if e['mode'] == 'TRIANGLES' and e['byteStride'] == 2: r = np.frombuffer(r, np.uint32).astype(np.uint16).tobytes()
        f = e.get('filter', 'NONE')
        if f == 'EXPONENTIAL':
            a = np.frombuffer(r, np.int32); ex = a >> 24; m = (a << 8) >> 8
            r = (m.astype(np.float64) * np.power(2.0, ex.astype(np.float64))).astype(np.float32).tobytes()
        elif f != 'NONE': print('note: filter', f, 'left undecoded (view', i, ')')
    cache[i] = r; return r
def acc(i):
    a = J['accessors'][i]; v = J['bufferViews'][a['bufferView']]; raw = view(a['bufferView'])
    dt = {5126: np.float32, 5125: np.uint32, 5123: np.uint16, 5121: np.uint8, 5120: np.int8, 5122: np.int16}[a['componentType']]
    n = {'SCALAR': 1, 'VEC2': 2, 'VEC3': 3, 'VEC4': 4}[a['type']]; isz = np.dtype(dt).itemsize
    st = v.get('byteStride', n * isz); off = a.get('byteOffset', 0)
    arr = np.frombuffer(raw, np.uint8)[off:off + st * a['count']].reshape(a['count'], st)[:, :n * isz].copy().view(dt).reshape(a['count'], n)
    return arr if n > 1 else arr.ravel()
p = J['meshes'][0]['primitives'][0]
P = acc(p['attributes']['POSITION']).astype(np.float32); U = acc(p['attributes']['TEXCOORD_0']).astype(np.float32); I = acc(p['indices']).astype(np.uint32).reshape(-1, 3)
mt = J['materials'][p['material']]; ti = mt['pbrMetallicRoughness']['baseColorTexture']['index']; im = J['images'][J['textures'][ti]['source']]
open(W + 'tex.jpg', 'wb').write(view(im['bufferView']))
print('pos', P.shape, P.min(0), P.max(0), 'uv', U.min(0), U.max(0), 'idx', I.shape, I.max(), 'mime', im.get('mimeType'))
np.save(W + 'raw_pos.npy', P); np.save(W + 'hi_uv.npy', U); np.save(W + 'hi_idx.npy', I)
