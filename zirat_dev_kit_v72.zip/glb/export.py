import sys,json,base64,numpy as np
sys.path.insert(0,'/home/claude/glb')
from PIL import Image
Z=np.load('model.npz');V=Z['V'].copy();F=Z['F'];seen=Z['seen'];VC=Z['VC']
best=np.load('paint.npz')['best'];PRM=json.load(open('prm.json'))
NV,NF=len(V),len(F)
XC=0.02
x=V[:,0]+XC;y=V[:,1];z=V[:,2];ax=np.abs(x)
def ss(a,b,t):
    t=np.clip((t-a)/(b-a),0,1);return t*t*(3-2*t)
# bones: 0 body,1 torso,2 head,3 legL,4 kneeL,5 legR,6 kneeR,7 armL,8 foreL,9 armR,10 foreR   (L = -x side)
W=np.zeros((NV,11))
head=np.where(ax<.3,ss(.17,.26,y),(y>.3)*1.0)
# arm membership
pouch=(x>.1)&(x<.3)&(y<-.11)&(y>-.3)&(z>.04)
xa=np.where(y>-.2,.355,.355+(-.2-y)*.08);za=np.where(y>-.2,-.08,-.08+(-.2-y)*.2)
dax=np.hypot(ax-xa,z-za)
armA=np.where(y>-.12,ss(.22,.30,ax)*(1-ss(.13,.21,y)),np.where(y>-.17,1-ss(.115,.145,dax),np.where(y>-.33,(dax<.13)*1.0,(ax>.26)*1.0)))
armA=np.where((y<-.56)|pouch,0,armA)
armA=np.where((y<-.33)&(ax<=.26),0,armA)
fore=ss(-.13,-.21,y)
legA=np.where(armA>0,0,ss(-.2,-.36,y))*(1-head)
shin=ss(-.56,-.68,y)
rest=(1-head)*(1-armA)*(1-legA)
tors=rest*ss(-.25,-.1,y);bodyw=rest-tors
side=ss(-.04,.04,x)   # 0 -> L(-x), 1 -> R(+x)
sideA=(x>0)*1.0
W[:,0]=bodyw;W[:,1]=tors;W[:,2]=head*(1-armA)
W[:,3]=legA*(1-shin)*(1-side);W[:,4]=legA*shin*(1-side);W[:,5]=legA*(1-shin)*side;W[:,6]=legA*shin*side
W[:,7]=armA*(1-fore)*(1-sideA);W[:,8]=armA*fore*(1-sideA);W[:,9]=armA*(1-fore)*sideA;W[:,10]=armA*fore*sideA
W=W/W.sum(1,keepdims=True)
dom=W.argmax(1);isArm=np.isin(dom,[7,8,9,10])
fa=isArm[F];cy=V[F][:,:,1].mean(1);cut=(fa.any(1)&~fa.all(1))&(cy<-.17)
keep=~cut;print('cut tris',cut.sum())
F=F[keep];seen=seen[keep];best=best[keep];NF=len(F)
o=np.argsort(-W,1)[:,:4];ww=np.take_along_axis(W,o,1);ww/=ww.sum(1,keepdims=True)
wq=np.round(ww*255).astype(int);wq[:,0]+=255-wq.sum(1)
print('bones per vertex>1:',(ww[:,1]>.01).mean(),'counts',np.bincount(o[:,0],minlength=11))
np.save('skin_dom.npy',o[:,0])
# quantize positions
mn=V.min(0);mx=V.max(0);q=np.round((V-mn)/(mx-mn)*65535).astype(np.uint16)
fv=np.where(seen,best,2).astype(np.uint8)
vc=np.clip(np.round(VC),0,255).astype(np.uint8)
blob=b''.join([q.tobytes(),F.astype(np.uint16).tobytes(),fv.tobytes(),vc.tobytes(),o.astype(np.uint8).tobytes(),wq.astype(np.uint8).tobytes()])
meta={'nv':NV,'nf':NF,'mn':mn.round(6).tolist(),'mx':mx.round(6).tolist(),'f':PRM['front'],'b':PRM['back'],'crop':[272,32,480,960]}
open('cowboy_blob.b64','w').write(base64.b64encode(blob).decode())
json.dump(meta,open('cowboy_meta.json','w'))
print('blob',len(blob),'b64',len(base64.b64encode(blob)))
