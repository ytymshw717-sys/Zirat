# green-screen character image(s) -> front_rgba.png / back_rgba.png (1024 canvas, figure ~1000 px tall)
# usage: prep_img.py WORKDIR SHEET.png            (front | back side by side)
#        prep_img.py WORKDIR FRONT.png BACK.png   (two separate images)
import sys
from PIL import Image
import numpy as np
from scipy import ndimage
W = sys.argv[1].rstrip('/') + '/'
def key(path):
    a = np.array(Image.open(path).convert('RGB')).astype(float); R, G, B = a[..., 0], a[..., 1], a[..., 2]
    gr = G - np.maximum(R, B)
    al = ndimage.median_filter(np.clip(1 - (gr - 35) / (110 - 35), 0, 1), 3)
    mx = np.maximum(R, B); G2 = np.where(G > mx, mx + (G - mx) * 0.15, G)
    return np.dstack([R, G2, B]), al
def place(rgb, al, name, H=1000):
    l2, _ = ndimage.label(al > .5); s2 = ndimage.sum(al > .5, l2, range(1, l2.max() + 1)); k = np.argmax(s2) + 1
    al = al * ndimage.binary_dilation(l2 == k, iterations=3)
    ys, xs = np.where(al > .5); bx = (xs.min(), ys.min(), xs.max() + 1, ys.max() + 1)
    sub = rgb[bx[1]:bx[3], bx[0]:bx[2]]; al = al[bx[1]:bx[3], bx[0]:bx[2]]
    h, w = al.shape; S = H / h; nw, nh = int(round(w * S)), int(round(h * S))
    t = Image.fromarray(np.dstack([sub, al * 255]).clip(0, 255).astype(np.uint8), 'RGBA').resize((nw, nh), Image.LANCZOS)
    c = Image.new('RGBA', (1024, 1024), (0, 0, 0, 0)); c.paste(t, ((1024 - nw) // 2, (1024 - nh) // 2), t)
    c.save(W + name + '_rgba.png'); print(name, w, h, '->', nw, nh)
    wb = Image.new('RGB', (1024, 1024), 'white'); wb.paste(c, (0, 0), c); wb.save(W + name + '_white.png')
if len(sys.argv) == 3:
    rgb, al = key(sys.argv[2]); X = rgb.shape[1] // 2
    place(rgb[:, :X], al[:, :X], 'front'); place(rgb[:, X:], al[:, X:], 'back')
else:
    for path, n in [(sys.argv[2], 'front'), (sys.argv[3], 'back')]:
        rgb, al = key(path); place(rgb, al, n)
