import sys,base64
from playwright.sync_api import sync_playwright
D=sys.argv[1].rstrip('/')+'/';rel='/'+D.replace('/home/claude/','')
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader']);pg=b.new_page(viewport={'width':1024,'height':1024})
    E=[];pg.on('pageerror',lambda e:E.append(str(e)));pg.on('console',lambda m:E.append(m.text) if m.type=='error' else None)
    pg.goto('http://127.0.0.1:9920/glb/rviews.html');pg.evaluate("(d)=>setup(d)",rel)
    for n,v in [('front',(0,0,1)),('back',(0,0,-1)),('side',(1,0,0)),('sideR',(-1,0,0))]:
        u=pg.evaluate("(v)=>shot(v[0],v[1],v[2])",list(v));open(D+n+'_rgba.png','wb').write(base64.b64decode(u.split(',')[1]))
    print('E',E[:3])
