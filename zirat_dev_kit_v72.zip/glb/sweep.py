import sys,json,subprocess,re,itertools
W=sys.argv[1];base=json.load(open('/home/claude/%s/params.json'%W));orig=dict(base)
grid=json.loads(sys.argv[2])
keys=list(grid);res=[]
for vals in itertools.product(*[grid[k] for k in keys]):
    p=dict(orig);p.update(dict(zip(keys,vals)));json.dump(p,open('/home/claude/%s/params.json'%W,'w'))
    subprocess.run(['python3','/home/claude/glb/export4.py',W],capture_output=True)
    out=subprocess.run(['python3','/home/claude/glb/sim.py',W],capture_output=True,text=True).stdout
    d=eval(re.search(r"\(%\): (\{.*?\})",out).group(1));avg=sum(v[0] for v in d.values())/len(d);p99=sum(v[1] for v in d.values())/len(d)
    res.append((round(avg,2),round(p99,2),dict(zip(keys,vals))));print(res[-1],flush=True)
json.dump(orig,open('/home/claude/%s/params.json'%W,'w'))
print('BEST',sorted(res,key=lambda r:r[0])[:3])
