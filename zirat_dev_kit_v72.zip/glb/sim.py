# skinning stress test: pose the sculpted hero with the game's poses (after joint limits) in numpy and measure triangle stretch
# usage: sim.py WORKDIR [--fix]   prints per-pose stretch stats; writes stretch.npy (worst ratio per face)
import sys, json, base64, numpy as np
W = sys.argv[1].rstrip('/') + '/'
m = json.load(open(W + 'meta_full.json'))
bs = base64.b64decode(m['d']); nv, nf = m['nv'], m['nf']; o = 0
q = np.frombuffer(bs, np.uint16, nv * 3, 0).reshape(-1, 3); o = nv * 6
F = np.frombuffer(bs, np.uint16, nf * 3, o).reshape(-1, 3).astype(int); o += nf * 6
if m.get('pa') or m.get('v2'): o += nv * 3 + nv * 4
else: o += nf + nv * 3
SI = np.frombuffer(bs, np.uint8, nv * 4, o).reshape(-1, 4).astype(int); o += nv * 4
SW = np.frombuffer(bs, np.uint8, nv * 4, o).reshape(-1, 4) / 255.
mn, mx, K = np.array(m['mn']), np.array(m['mx']), m['k']
V = mn + q / 65535 * (mx - mn); P = np.stack([(V[:, 0] + m['xc']) * K, (V[:, 1] - mn[1]) * K + .01, V[:, 2] * K], 1)
J = m['j']
def g(k, s=1): return np.array([J[k][0] * s, J[k][1], J[k][2]])
shR = np.array(J['shR']) if 'shR' in J else g('sh'); shL = np.array(J['shL']) if 'shL' in J else g('sh', -1)
elR = np.array(J['elR']) if 'elR' in J else g('el'); elL = np.array(J['elL']) if 'elL' in J else g('el', -1)
piv = [np.zeros(3), g('tor'), g('nk'), g('hip', -1), np.array([-J['hip'][0], J['knee'][1], J['knee'][2]]), g('hip'), np.array([J['hip'][0], J['knee'][1], J['knee'][2]]), shL, elL, shR, elR]
par = [-1, 0, 1, 0, 3, 0, 5, 1, 7, 1, 9]
def R(e):
    x, y, z = e; cx, sx, cy, sy, cz, sz = np.cos(x), np.sin(x), np.cos(y), np.sin(y), np.cos(z), np.sin(z)
    Rx = np.array([[1, 0, 0], [0, cx, -sx], [0, sx, cx]]); Ry = np.array([[cy, 0, sy], [0, 1, 0], [-sy, 0, cy]]); Rz = np.array([[cz, -sz, 0], [sz, cz, 0], [0, 0, 1]])
    return Rx @ Ry @ Rz   # three.js 'XYZ'
AM = float(m.get('am', 1))
def soft(x, a): return -a - (-a - x) * .35 if x < -a else (a + (x - a) * .35 if x > a else x)
def limit(r):
    for i in (7, 9): x, y, z = r[i]; x *= AM; z *= AM; r[i] = [np.clip(soft(x, 1.15), -1.5, .8), np.clip(y, -.3, .3), np.clip(soft(z, .4), -.55, .55)]
    for i in (8, 10): r[i] = [np.clip(r[i][0] * AM, -1.45, .1), 0, np.clip(r[i][2], -.2, .2)]
    for i in (3, 5): r[i] = [np.clip(soft(r[i][0], .75), -1.05, .95), 0, np.clip(r[i][2], -.25, .25)]
    for i in (4, 6): r[i] = [np.clip(r[i][0], 0, 1.15), 0, 0]
    r[1] = [np.clip(r[1][0], -.35, .35), np.clip(r[1][1], -.5, .5), r[1][2]]; return r
def pose(d):
    r = [[0, 0, 0] for _ in range(11)]; r[8] = [-.35, 0, 0]; r[10] = [-.35, 0, 0]; r[7] = [0, 0, .12]; r[9] = [0, 0, -.12]
    for k, v in d.items(): r[k] = list(v)
    return limit(r)
POSES = {'guard': pose({7: (-1.25, 0, -.35), 9: (-1.35, 0, .35), 3: (0, 0, -.18), 5: (0, 0, .18), 1: (.15, 0, 0)}),
         'victory': pose({7: (-2.8, 0, .45), 9: (-2.8, 0, -.45)}),
         'kick': pose({5: (-1.6, 0, 0), 6: (1.5, 0, 0), 3: (.15, 0, 0), 1: (-.22, 0, 0), 7: (0, 0, .72), 9: (0, 0, -.72)}),
         'slash': pose({9: (-2.36, 0, -.2), 1: (0, .35, 0), 3: (-.26, 0, 0), 5: (.22, 0, 0)}),
         'walk': pose({3: (.85, 0, 0), 5: (-.85, 0, 0), 4: (.12, 0, 0), 6: (1.17, 0, 0), 7: (-.7, 0, .17), 9: (.7, 0, -.17), 8: (-1.2, 0, 0), 10: (-1.2, 0, 0), 1: (.16, 0, 0)}),
         'cast': pose({7: (-2, 0, -.4), 9: (-2, 0, .4), 1: (-.15, 0, 0)}),
         'shoot': pose({9: (-1.55, 0, -.12), 7: (-1.1, 0, -.3), 10: (0, 0, 0), 1: (0, -.15, 0)})}
def skin(rots):
    Mw = [None] * 11
    for i in range(11):
        Rl = R(rots[i]); T = np.eye(4); T[:3, :3] = Rl; T[:3, 3] = piv[i] - Rl @ piv[i]   # rotation about the bind pivot
        Mw[i] = T if par[i] < 0 else Mw[par[i]] @ T
    out = np.zeros_like(P)
    for k in range(4):
        idx = SI[:, k]; w = SW[:, k]
        M = np.stack([Mw[i] for i in range(11)])[idx]
        out += w[:, None] * (np.einsum('nij,nj->ni', M[:, :3, :3], P) + M[:, :3, 3])
    return out
def edges(X):
    a, b, c = X[F[:, 0]], X[F[:, 1]], X[F[:, 2]]
    return np.stack([np.linalg.norm(a - b, axis=1), np.linalg.norm(b - c, axis=1), np.linalg.norm(c - a, axis=1)], 1)
E0 = edges(P) + 1e-5; worst = np.ones(nf); rep = {}
for n, r in POSES.items():
    ratio = (edges(skin(r)) / E0).max(1); worst = np.maximum(worst, ratio)
    rep[n] = (round(float((ratio > 1.8).mean() * 100), 2), round(float(np.percentile(ratio, 99.9)), 2))
np.save(W + 'stretch.npy', worst)
bad = worst > 1.8; dom = SI[:, 0]
print(W, 'faces >1.8x (%):', rep, '| worst-face bones:', np.bincount(dom[F[bad, 0]], minlength=11).tolist() if bad.any() else [])
