import sys,json,base64
from playwright.sync_api import sync_playwright
data=sys.argv[1];out=sys.argv[2];ang=sys.argv[3] if len(sys.argv)>3 else '[0,90,180,270]';opt=json.loads(sys.argv[4]) if len(sys.argv)>4 else {}
atl=opt.pop('atlas','atlas.png')
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader']);pg=b.new_page(viewport={'width':1200,'height':600})
    E=[];pg.on('pageerror',lambda e:E.append(str(e)));pg.on('console',lambda m:E.append(m.text) if m.type=='error' else None)
    pg.goto('file:///home/claude/glb/view.html');D=open(data).read()
    B64=base64.b64encode(open('/home/claude/glb/'+atl,'rb').read()).decode()
    pg.evaluate("(b)=>new Promise(r=>{var i=document.getElementById('atl');i.onload=r;i.src='data:image/png;base64,'+b})",B64)
    opt['ang']=json.loads(ang)
    pg.evaluate("([d,o])=>render(JSON.parse(d),o)",[D,opt]);pg.wait_for_timeout(300)
    pg.screenshot(path=out);print('err',E[:3])
