# rebuild the GLBM block in g3.js from the per-hero meta files
import json
HEROES={0:'/home/claude/hb/m8/meta_full.json',1:'/home/claude/p1/meta_full.json',2:'/home/claude/n4/meta_full.json',4:'/home/claude/n0/meta_full.json',5:'/home/claude/n3/meta_full.json',6:'/home/claude/n1/meta_full.json',7:'/home/claude/n2/meta_full.json',9:'/home/claude/n5/meta_full.json',10:'/home/claude/hb/m4/meta_full.json',11:'/home/claude/hb/m9/meta_full.json',12:'/home/claude/hb/m6/meta_full.json',13:'/home/claude/hb/m3/meta_full.json',14:'/home/claude/hb/m2/meta_full.json',15:'/home/claude/hb/m0/meta_full.json',16:'/home/claude/hb/m7/meta_full.json',17:'/home/claude/hb/m10/meta_full.json',18:'/home/claude/hb/m5/meta_full.json',19:'/home/claude/hb/m1/meta_full.json'}
parts=[]
for k,p in HEROES.items():parts.append('%d:%s'%(k,open(p).read().strip()))
blk='/* original sculpted hero models: 3D meshes generated from the player\'s own character sheets, painted from the sheet views */\nvar GLBM={'+',\n'.join(parts)+'};\n'+open('/home/claude/glb/glbfn3.js').read()
p='/home/claude/g3/g3.js';s=open(p).read()
a=s.index('/* original ');b=s.index('var T0={};')
s=s[:a]+blk+s[b:]
s=s.replace("if(ch.idx===7&&!(ch.skn>0)&&typeof GLBC!=='undefined'){try{glbCow(V,T);}catch(e){}}","if(typeof GLBM!=='undefined'&&GLBM[ch.idx]&&!(ch.skn>0)){try{glbHero(V,T,ch.idx);}catch(e){}}")
s=s.replace("wait:function(){return !!(GLBI&&!GLBI.done);}","wait:function(){return glbWait();}")
open(p,'w').write(s);print('heroes',list(HEROES),'size',len(blk))
