# estimate rig params (joints + skin regions) for a standing character mesh in the canonical frame
# usage: autoparams.py WORKDIR [json overrides]
import sys, json, numpy as np
sys.path.insert(0, '/home/claude/glb')
from glbio import load
from PIL import Image, ImageDraw
W = sys.argv[1].rstrip('/') + '/'; OV = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}
V, F = load(W + 'white_mesh.glb'); P = V[F]
RES = 400
def silh(ax):
    im = Image.new('L', (RES, RES * 2), 0); d = ImageDraw.Draw(im)
    U = (P[..., ax] + 1) * RES / 2; Y = (1 - P[..., 1]) * RES
    for t in range(len(F)): d.polygon([(U[t, 0], Y[t, 0]), (U[t, 1], Y[t, 1]), (U[t, 2], Y[t, 2])], fill=255)
    return np.array(im) > 127
S = silh(0)
def row(y):
    r = S[int(np.clip((1 - y) * RES, 0, 2 * RES - 1))]
    idx = np.where(np.diff(np.concatenate([[0], r.astype(int), [0]])) != 0)[0].reshape(-1, 2)
    return [(a * 2 / RES - 1, b * 2 / RES - 1) for a, b in idx]
ys = np.arange(-.98, .95, .01)
# legs: follow the two leg segments up from the feet until they merge
def legsegs(y):
    return [s for s in row(y) if s[1] > -.45 and s[0] < .45]
crotch = None
for y in ys:
    sg = legsegs(y); L = [s for s in sg if s[1] <= .02]; R = [s for s in sg if s[0] >= -.02]
    if y > -.75 and not (L and R and max(s[1] for s in L) < min(s[0] for s in R)):
        crotch = y - .01; break
if crotch is None: crotch = -.45
sg = legsegs(crotch - .12); xl = np.mean([abs((s[0] + s[1]) / 2) for s in sg if abs((s[0] + s[1]) / 2) > .03] or [.17])
# torso half-width just above the crotch (arms excluded = central segment)
def central(y):
    for s in row(y):
        if s[0] <= 0 <= s[1]: return s
    return None
# arms: rows above the crotch where an outer segment is separate from the central one
armrows = []
for y in ys:
    if y < crotch - .15 or y > .5: continue
    c = central(y); sg = row(y)
    if c is None: continue
    outer = [s for s in sg if s[0] > c[1] or s[1] < c[0]]
    if outer: armrows.append((y, c, outer))
if armrows:
    yh_lo = min(a[0] for a in armrows); armpit = max(a[0] for a in armrows if a[0] < .3)
    cpit = central(armpit - .03) or (-.3, .3); torso_hw = max(abs(cpit[0]), abs(cpit[1]))
    outs = [s for a in armrows for s in a[2]]
    arm_out = max(max(abs(s[0]), abs(s[1])) for s in outs)
else:
    yh_lo, armpit, torso_hw, arm_out = crotch - .05, crotch + .4, .28, .45
c_ap = central(armpit + .08) or (-.35, .35); sh_x = min(max(abs(c_ap[0]), abs(c_ap[1])) - .05, torso_hw + .06)
# neck: narrowest central width between the armpit and the head
best = (9, armpit + .12)
for y in ys:
    if armpit + .04 < y < .45:
        c = central(y)
        if c and c[1] - c[0] < best[0]: best = (c[1] - c[0], y)
neck = best[1]
top = max(V[:, 1])
sh_y = min(armpit + .07, neck - .03)
hand_y = yh_lo + .07
el_y = (sh_y + hand_y) / 2
zc = lambda m: float(np.median(V[m, 2])) if m.sum() else 0.0
x, y, z = V[:, 0], V[:, 1], V[:, 2]
zt = zc((abs(x) < .15) & (abs(y - (crotch + .2)) < .05)); zh = zc((abs(x - xl) < .1) & (abs(y - crotch) < .05))
zs = zc((abs(abs(x) - sh_x) < .08) & (abs(y - sh_y) < .05)); zhand = zc((abs(x) > torso_hw) & (abs(y - hand_y) < .06))
xh = (torso_hw + .02)
P_ = {"xc": 0.0, "k": 1.3, "fl": 0.45, "nowp": 1,
      "head": {"ax": 0.75, "y0": round(neck - .03, 3), "y1": round(neck + .05, 3), "yo": round(neck + .07, 3)},
      "arm": {"ys": round(armpit, 3), "d0": round(torso_hw - .03, 3), "d1": round(torso_hw + .04, 3), "t0": round(sh_y - .01, 3), "t1": round(sh_y + .07, 3),
              "yb": round(armpit, 3), "xa": .4, "za": 0.0, "xs": 0.0, "zs": 0.0, "yk": round(armpit, 3), "r0": .12, "r1": .15,
              "yh": round(yh_lo - .03, 3), "xh": round(xh, 3), "e0": round(el_y + .04, 3), "e1": round(el_y - .05, 3)},
      "bindR": [], "rigid": [],
      "leg": {"y0": round(crotch + .06, 3), "y1": round(crotch - .05, 3), "k0": round((crotch - 1) / 2 + .05, 3), "k1": round((crotch - 1) / 2 - .05, 3)},
      "body": [round(crotch - .02, 3), round(crotch + .12, 3)],
      "cut": round(armpit - .06, 3),
      "joints": {"hip": [round(xl, 3), round(crotch + .03, 3), round(zh, 3)], "knee": [round(xl, 3), round((crotch - 1) / 2, 3), round(zh, 3)],
                 "sh": [round(sh_x, 3), round(sh_y, 3), round(zs, 3)], "el": [round((sh_x + arm_out) / 2 - .02, 3), round(el_y, 3), round(zs, 3)],
                 "hd": [round(arm_out - .06, 3), round(hand_y, 3), round(zhand, 3)], "nk": [0, round(neck, 3), round(zt, 3)], "tor": [0, round(crotch + .06, 3), round(zt, 3)]},
      "bm": [round((top - neck) * .5 * 1.3, 3), 0.08, round((top - neck) * .5 * 1.3 * .95, 3)]}
def deep(a, b):
    for k, v in b.items():
        if isinstance(v, dict) and isinstance(a.get(k), dict): deep(a[k], v)
        else: a[k] = v
deep(P_, OV)
json.dump(P_, open(W + 'params.json', 'w'), indent=0)
print(json.dumps({'crotch': round(crotch, 3), 'armpit': round(armpit, 3), 'hands': round(yh_lo, 3), 'neck': round(neck, 3), 'torso_hw': round(torso_hw, 3), 'arm_out': round(arm_out, 3), 'xl': round(xl, 3)}))
