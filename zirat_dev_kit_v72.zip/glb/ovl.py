import sys,json,numpy as np
sys.path.insert(0,'/home/claude/glb')
exec(open('project.py').read().split("PRM={n:fit")[0])
PRM=json.load(open('prm.json'))
out=[]
for n in['front','back','sideL']:
    imn,uf,df,dr=VIEWS[n];S=sil(PRM[n],uf,1024);A=IMG[imn].copy()
    E=S^ndimage.binary_erosion(S,iterations=2)
    rgb=A[...,:3]*(A[...,3:]/255)+np.array([60,60,60])*(1-A[...,3:]/255);rgb[E]=[0,255,0]
    out.append(Image.fromarray(rgb.astype(np.uint8)).resize((512,512)))
s=Image.new('RGB',(1536,512));[s.paste(o,(i*512,0)) for i,o in enumerate(out)];s.save('ovl.png')
