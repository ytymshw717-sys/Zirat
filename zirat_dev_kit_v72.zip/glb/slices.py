import sys,numpy as np;sys.path.insert(0,'/home/claude/glb')
from glbio import load
from scipy import ndimage
W=sys.argv[1].rstrip('/')+'/';side=float(sys.argv[2]) if len(sys.argv)>2 else 1
V,F=load(W+'white_mesh.glb');x,y,z=V[:,0]*side,V[:,1],V[:,2]
# densify: sample triangle points
P=V[F];r=np.random.RandomState(0).rand(len(F),6,2);r=np.where(r.sum(2,keepdims=True)>1,1-r,r)
S=(P[:,None,0]+r[...,0:1]*(P[:,None,1]-P[:,None,0])+r[...,1:2]*(P[:,None,2]-P[:,None,0])).reshape(-1,3);S[:,0]*=side
S=np.concatenate([S,np.stack([x,y,z],1)])
cs=.022
for yc in np.arange(.5,-.8,-.05):
    m=(np.abs(S[:,1]-yc)<.012)&(S[:,0]>-.02);s=S[m]
    if not len(s):continue
    gx=((s[:,0]+.02)/cs).astype(int);gz=((s[:,2]+.8)/cs).astype(int);G=np.zeros((gx.max()+2,gz.max()+2),bool);G[gx,gz]=1
    G=ndimage.binary_closing(G,iterations=1)|G
    lab,n=ndimage.label(G,structure=np.ones((3,3)));out=[]
    for k in range(1,n+1):
        mm=lab[gx,gz]==k
        if mm.sum()<4:continue
        out.append('x[%.2f,%.2f] z[%.2f,%.2f] n%d'%(s[mm,0].min(),s[mm,0].max(),s[mm,2].min(),s[mm,2].max(),mm.sum()))
    print('%.2f | '%yc+' || '.join(out))
