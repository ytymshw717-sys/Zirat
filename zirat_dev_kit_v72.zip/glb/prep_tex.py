# textured hi-res model -> canonical frame (faces +z, feet at y=-1, height 1.96), bins for rendering, welded raw.glb for decimation
# usage: prep_tex.py WORKDIR FACE   (FACE = axis the model looks along in its own file: +x, -x, +z, -z)
import sys, numpy as np
sys.path.insert(0, '/home/claude/glb')
from glbio import save
W = sys.argv[1].rstrip('/') + '/'; face = sys.argv[2] if len(sys.argv) > 2 else '+z'
P = np.load(W + 'raw_pos.npy').astype(np.float64); U = np.load(W + 'hi_uv.npy'); I = np.load(W + 'hi_idx.npy').astype(np.int64)
x, y, z = P[:, 0], P[:, 1], P[:, 2]
T = {'+z': np.stack([x, y, z], 1), '-z': np.stack([-x, y, -z], 1), '+x': np.stack([-z, y, x], 1), '-x': np.stack([z, y, -x], 1)}[face]
s = 1.96 / (T[:, 1].max() - T[:, 1].min()); T = T * s; T[:, 1] += -1 - T[:, 1].min()
if len(sys.argv) > 3 and sys.argv[3] == 'mirror': T[:, 0] *= -1; I = I[:, [0, 2, 1]]   # put a held weapon into the game's right hand
np.save(W + 'hi_pos.npy', T.astype(np.float32))
T.astype('<f4').tofile(W + 'hi_pos.bin'); U.astype('<f4').tofile(W + 'hi_uv.bin'); I.astype('<u4').tofile(W + 'hi_idx.bin')
key = np.round(T * 1e5).astype(np.int64); u, inv = np.unique(key, axis=0, return_inverse=True); inv = inv.ravel()
Vw = np.zeros((len(u), 3)); np.add.at(Vw, inv, T); Vw /= np.bincount(inv)[:, None]
Fw = inv[I]; g = (Fw[:, 0] != Fw[:, 1]) & (Fw[:, 1] != Fw[:, 2]) & (Fw[:, 0] != Fw[:, 2]); Fw = Fw[g]
save(W + 'raw.glb', Vw, Fw); print('welded', len(T), '->', len(Vw), 'faces', len(Fw), 'bbox', Vw.min(0).round(3), Vw.max(0).round(3))
