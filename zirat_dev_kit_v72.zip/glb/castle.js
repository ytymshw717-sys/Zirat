/* hero window backdrop: painted castle courtyard (sky, towers, banners, stone floor), soft-focus like a photo background */
var CBG=null;
function castleBg(){if(CBG)return CBG;try{
 var W=540,H=420,c=document.createElement('canvas');c.width=W;c.height=H;var x=c.getContext('2d');
 function R(a,b){return a+Math.random()*(b-a);}
 var g=x.createLinearGradient(0,0,0,H*.62);g.addColorStop(0,'#3f8fe6');g.addColorStop(.55,'#8cc7ff');g.addColorStop(1,'#ffe7bf');x.fillStyle=g;x.fillRect(0,0,W,H);
 var s=x.createRadialGradient(W*.78,H*.18,4,W*.78,H*.18,W*.45);s.addColorStop(0,'rgba(255,248,225,.95)');s.addColorStop(.25,'rgba(255,236,190,.45)');s.addColorStop(1,'rgba(255,236,190,0)');x.fillStyle=s;x.fillRect(0,0,W,H);
 function cloud(cx,cy,k){x.fillStyle='rgba(255,255,255,.85)';for(var i=0;i<7;i++){x.beginPath();x.ellipse(cx+(i-3)*16*k,cy+Math.sin(i*1.7)*5*k,R(18,28)*k,R(11,16)*k,0,0,6.3);x.fill();}}
 cloud(W*.22,H*.12,1.1);cloud(W*.62,H*.08,.8);cloud(W*.9,H*.27,.7);cloud(W*.08,H*.3,.6);
 function stone(t){var v=Math.round(255-t*90);return 'rgb('+v+','+Math.round(v*.93)+','+Math.round(v*.84)+')';}
 function tower(cx,top,w,base,t,flag){x.fillStyle=stone(t);x.fillRect(cx-w/2,top,w,base-top);var mw=w/5;for(var i=0;i<5;i+=2)x.fillRect(cx-w/2+i*mw,top-mw*.9,mw,mw);
  x.fillStyle='rgba(0,0,0,'+(.08+t*.12)+')';x.fillRect(cx+w*.18,top,w*.32,base-top);
  x.fillStyle='rgba(40,25,15,'+(.35+t*.2)+')';for(var j=0;j<3;j++){x.fillRect(cx-w*.08,top+(base-top)*(.2+j*.25),w*.16,(base-top)*.09);}
  if(flag){x.strokeStyle=stone(t+.4);x.lineWidth=2;x.beginPath();x.moveTo(cx,top-mw);x.lineTo(cx,top-mw-26);x.stroke();x.fillStyle='#d62b2b';x.beginPath();x.moveTo(cx,top-mw-26);x.quadraticCurveTo(cx+14,top-mw-24,cx+24,top-mw-20);x.quadraticCurveTo(cx+12,top-mw-16,cx,top-mw-14);x.fill();}}
 // far castle
 x.fillStyle=stone(.35);x.fillRect(W*.3,H*.4,W*.42,H*.25);for(var i=0;i<14;i+=2)x.fillRect(W*.3+i*W*.03,H*.4-8,W*.03,8);
 tower(W*.33,H*.22,46,H*.66,.38,1);tower(W*.55,H*.17,54,H*.66,.42,1);tower(W*.74,H*.27,40,H*.66,.36,1);
 x.fillStyle='rgba(170,200,235,.25)';x.fillRect(0,H*.15,W,H*.55);
 // near walls framing the courtyard
 function wall(x0,x1,top,t){x.fillStyle=stone(t);x.fillRect(x0,top,x1-x0,H-top);var mw=(x1-x0)/9;for(var i=0;i<9;i+=2)x.fillRect(x0+i*mw,top-mw*.8,mw,mw*.8);
  x.strokeStyle='rgba(60,40,25,.25)';x.lineWidth=1;for(var y=top+10;y<H;y+=14){x.beginPath();x.moveTo(x0,y);x.lineTo(x1,y);x.stroke();for(var bx=x0+((y/14|0)%2)*12;bx<x1;bx+=24){x.beginPath();x.moveTo(bx,y);x.lineTo(bx,y+14);x.stroke();}}}
 wall(-10,W*.2,H*.18,.62);wall(W*.86,W+10,H*.24,.66);
 tower(W*.06,H*.04,74,H,.68,1);tower(W*.95,H*.1,64,H,.72,0);
 // hanging banners with a simple gold crown mark
 function banner(bx,by,bw,bh){x.fillStyle='#b91c1c';x.beginPath();x.moveTo(bx,by);x.lineTo(bx+bw,by);x.lineTo(bx+bw,by+bh);x.lineTo(bx+bw/2,by+bh-bw*.35);x.lineTo(bx,by+bh);x.closePath();x.fill();
  x.strokeStyle='#f5c542';x.lineWidth=2.5;x.stroke();x.fillStyle='#f5c542';var cx=bx+bw/2,cy=by+bh*.4,k=bw*.28;x.beginPath();x.moveTo(cx-k,cy+k*.6);x.lineTo(cx-k,cy-k*.4);x.lineTo(cx-k*.5,cy+k*.05);x.lineTo(cx,cy-k*.6);x.lineTo(cx+k*.5,cy+k*.05);x.lineTo(cx+k,cy-k*.4);x.lineTo(cx+k,cy+k*.6);x.closePath();x.fill();}
 banner(W*.11,H*.3,34,96);banner(W*.865,H*.36,30,86);
 // stone courtyard floor with warm light
 var fy=H*.66,fg=x.createLinearGradient(0,fy,0,H);fg.addColorStop(0,'#b79c7c');fg.addColorStop(1,'#7c624a');x.fillStyle=fg;x.fillRect(0,fy,W,H-fy);
 x.strokeStyle='rgba(60,40,25,.35)';x.lineWidth=1.2;for(var r=0;r<7;r++){var y=fy+Math.pow(r/7,1.6)*(H-fy);x.beginPath();x.moveTo(0,y);x.lineTo(W,y);x.stroke();}
 for(var q=-12;q<=12;q++){x.beginPath();x.moveTo(W/2+q*20,fy);x.lineTo(W/2+q*90,H);x.stroke();}
 var lg=x.createRadialGradient(W*.5,H*.86,10,W*.5,H*.86,W*.5);lg.addColorStop(0,'rgba(255,214,150,.45)');lg.addColorStop(1,'rgba(255,214,150,0)');x.fillStyle=lg;x.fillRect(0,fy,W,H-fy);
 // soft bokeh + vignette
 for(var b=0;b<16;b++){var bx2=R(0,W),by2=R(0,H*.7),br=R(4,12);var bg=x.createRadialGradient(bx2,by2,0,bx2,by2,br);bg.addColorStop(0,'rgba(255,240,200,.55)');bg.addColorStop(1,'rgba(255,240,200,0)');x.fillStyle=bg;x.beginPath();x.arc(bx2,by2,br,0,6.3);x.fill();}
 var vg=x.createRadialGradient(W/2,H*.55,H*.3,W/2,H*.55,W*.75);vg.addColorStop(0,'rgba(0,0,0,0)');vg.addColorStop(1,'rgba(10,15,35,.45)');x.fillStyle=vg;x.fillRect(0,0,W,H);
 CBG=c.toDataURL('image/jpeg',.86);}catch(e){CBG='';}return CBG;}
function castleStage(el){try{if(!el||el.querySelector('.hvBg'))return;var u=castleBg();if(!u)return;
 if(!document.getElementById('hvBgCss')){var st=document.createElement('style');st.id='hvBgCss';st.textContent='#ov .hvStage.castle{background:#6aa8e8}#ov .hvStage.castle .hvRays{display:none}#ov .hvBg{position:absolute;inset:-10px;background-size:cover;background-position:center 62%;filter:blur(1.6px) saturate(1.08);z-index:0;pointer-events:none}#ov .hvBg:after{content:"";position:absolute;inset:0;background:linear-gradient(to bottom,rgba(0,0,0,0) 55%,rgba(20,14,8,.28))}';document.head.appendChild(st);}
 var d=document.createElement('div');d.className='hvBg';d.style.backgroundImage='url('+u+')';el.insertBefore(d,el.firstChild);el.classList.add('castle');}catch(e){}}
