import sys,json,numpy as np
sys.path.insert(0,'/home/claude/glb')
from glbio import load
from PIL import Image, ImageDraw
from scipy import ndimage, optimize
V,F=load('white_mesh.glb')
P=V[F];FN=np.cross(P[:,1]-P[:,0],P[:,2]-P[:,0]);FA=np.linalg.norm(FN,axis=1)/2;FN/= (np.linalg.norm(FN,axis=1)[:,None]+1e-12)
FC=P.mean(1)
IMG={n:np.array(Image.open(n+'_rgba.png')).astype(float) for n in['front','side','back']}
# view: (image, u-func, depth-func, dir)
VIEWS={
 'front':('front',lambda X:X[...,0],lambda X:X[...,2],np.array([0,0,1.])),
 'back':('back',lambda X:-X[...,0],lambda X:-X[...,2],np.array([0,0,-1.])),
 'sideL':('side',lambda X:-X[...,2],lambda X:X[...,0],np.array([1.,0,0])),
 'sideR':('sideM',lambda X:X[...,2],lambda X:-X[...,0],np.array([-1.,0,0])),
}
IMG['sideM']=IMG['side'][:,::-1].copy()
def sil(prm,uf,res=256):
    sx,sy,cx,cy=prm;k=res/1024
    im=Image.new('L',(res,res),0);d=ImageDraw.Draw(im)
    U=(cx+sx*uf(P))*k;Y=(cy-sy*P[...,1])*k
    for t in range(len(F)):d.polygon([(U[t,0],Y[t,0]),(U[t,1],Y[t,1]),(U[t,2],Y[t,2])],fill=255)
    return np.array(im)>127
def fit(name):
    imn,uf,df,dr=VIEWS[name];A=IMG[imn][...,3]>128
    ys,xs=np.where(A);u=uf(V);
    sx=(xs.max()-xs.min())/(u.max()-u.min());sy=(ys.max()-ys.min())/(V[:,1].max()-V[:,1].min())
    cx=xs.min()-sx*u.min();cy=ys.min()+sy*V[:,1].max()
    p0=np.array([sx,sy,cx,cy]);As=np.array(Image.fromarray(A.astype(np.uint8)*255).resize((256,256)))>127
    def loss(p):
        S=sil(p,uf);return -(S&As).sum()/((S|As).sum()+1)
    best=(loss(p0),p0)
    for it in range(3):
        for i,st in enumerate([4,4,3,3]):
            for dlt in(-st,st,-st/2,st/2):
                q=best[1].copy();q[i]+=dlt*(1 if i>1 else 1.0);l=loss(q)
                if l<best[0]:best=(l,q)
    print(name,'IoU0',-loss(p0),'IoU',-best[0],best[1].round(2))
    return best[1]
PRM={n:fit(n) for n in ['front','back','sideL']}
p=PRM['sideL'].copy();p[2]=1024-p[2];PRM['sideR']=p  # mirrored image: u'=1024-u, uf flips sign
json.dump({k:list(map(float,v)) for k,v in PRM.items()},open('prm.json','w'))
