var GLBI={},GLBT={},GLBG={};
function glbImg(id){var I=GLBI[id];if(!I&&GLBM[id]){I=GLBI[id]=new Image();I.onload=function(){I.done=1;if(GLBT[id])GLBT[id].needsUpdate=true;};I.onerror=function(){I.done=1;I.bad=1;};I.src=GLBM[id].tex;}return I;}
try{for(var gk in GLBM)glbImg(gk);}catch(e){}
function glbWait(){for(var k in GLBI)if(!GLBI[k].done)return true;return false;}
function glbTex(id){var t=GLBT[id];if(!t){var I=glbImg(id);t=GLBT[id]=new THREE.Texture(I);t.anisotropy=8;if(I.done&&!I.bad)t.needsUpdate=true;}return t;}
/* indexed, skinned geometry: bind-pose position + normal, fallback colour, per-view visibility */
function glbGeo(id){if(GLBG[id])return GLBG[id];
 var m=GLBM[id],bs=atob(m.d),u8=new Uint8Array(bs.length);for(var i=0;i<bs.length;i++)u8[i]=bs.charCodeAt(i);
 var nv=m.nv,nf=m.nf,o=0,q=new Uint16Array(u8.buffer,0,nv*3);o=nv*6;var ix=new Uint16Array(u8.buffer.slice(o,o+nf*6));o+=nf*6;
 var vc=u8.subarray(o,o+nv*3);o+=nv*3;var pv=u8.subarray(o,o+nv*4);o+=nv*4;var si=u8.subarray(o,o+nv*4);o+=nv*4;var sw=u8.subarray(o,o+nv*4);
 var mn=m.mn,mx=m.mx,K=m.k,y0=mn[1],hp=new Float32Array(nv*3),C=new Float32Array(nv*3),PV=new Float32Array(nv*4),SI=new Uint16Array(nv*4),SW=new Float32Array(nv*4);
 for(i=0;i<nv;i++){for(var c=0;c<3;c++){var v=mn[c]+q[i*3+c]/65535*(mx[c]-mn[c]);hp[i*3+c]=c===0?(v+m.xc)*K:c===1?(v-y0)*K+.01:v*K;C[i*3+c]=vc[i*3+c]/255;}
  for(c=0;c<4;c++){PV[i*4+c]=pv[i*4+c]/255;SI[i*4+c]=si[i*4+c];SW[i*4+c]=sw[i*4+c]/255;}}
 var g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(hp,3));g.setIndex(new THREE.BufferAttribute(ix,1));g.computeVertexNormals();
 g.setAttribute('pcol',new THREE.BufferAttribute(C,3));g.setAttribute('pvis',new THREE.BufferAttribute(PV,4));
 g.setAttribute('skinIndex',new THREE.Uint16BufferAttribute(SI,4));g.setAttribute('skinWeight',new THREE.BufferAttribute(SW,4));g.computeBoundingSphere();g.computeBoundingBox();
 GLBG[id]=g;return g;}
/* linear maps from bind-pose position to atlas uv for each painted view */
function glbMaps(m){var K=m.k,AW=m.aw||1024,AH=m.ah||1024,y0=m.mn[1],CL=m.cells;
 function mk(pr,cr,cl,sg,off){if(!pr||!cr||!cl)return new THREE.Vector4(0,0,0,0);var sx=pr[0],sy=pr[1],cx=pr[2],cy=pr[3],fx=cl[2]/cr[2],fy=cl[3]/cr[3],C0=cy-sy*y0+sy*.01/K;
  return new THREE.Vector4(sg*sx/K*fx/AW,(cl[0]+(cx+off*sx-cr[0])*fx)/AW,sy/K*fy/AH,1-(cl[1]+(C0-cr[1])*fy)/AH);}
 var sL=mk(m.s,m.cs,CL.side,-1,0);return {f:mk(m.f,m.cf,CL.front,1,-m.xc),b:mk(m.b,m.cb,CL.back,-1,m.xc),s:sL,r:m.r?mk(m.r,m.cr,CL.sideR,1,0):sL};}
function glbMat(id){
 var m=GLBM[id],M=glbMaps(m),tx=glbTex(id);
 var mt=new THREE.MeshToonMaterial({color:'#ffffff',gradientMap:toonGrad(),skinning:true,side:THREE.DoubleSide});
 mt.onBeforeCompile=function(sh){
  sh.uniforms.pMap={value:tx};sh.uniforms.uF={value:M.f};sh.uniforms.uB={value:M.b};sh.uniforms.uS={value:M.s};sh.uniforms.uR={value:M.r};sh.uniforms.uFlat={value:m.fl!=null?m.fl:.82};
  sh.vertexShader='attribute vec3 pcol;attribute vec4 pvis;varying vec3 vPC;varying vec4 vPV;varying vec3 vBP;varying vec3 vBN;\n'+sh.vertexShader.replace('#include <begin_vertex>','#include <begin_vertex>\nvPC=pcol;vPV=pvis;vBP=position;vBN=normal;');
  sh.fragmentShader='uniform sampler2D pMap;uniform vec4 uF;uniform vec4 uB;uniform vec4 uS;uniform vec4 uR;uniform float uFlat;varying vec3 vPC;varying vec4 vPV;varying vec3 vBP;varying vec3 vBN;\n'+sh.fragmentShader
   .replace('#include <color_fragment>','#include <color_fragment>\n{vec3 bn=normalize(vBN);float wf=vPV.x*pow(max(bn.z,0.0),2.0),wb=vPV.y*pow(max(-bn.z,0.0),2.0),wl=vPV.z*pow(max(bn.x,0.0),2.0)*0.85,wr=vPV.w*pow(max(-bn.x,0.0),2.0)*0.85,wt=wf+wb+wl+wr;vec3 pc=vPC;'
    +'if(wt>0.0005){vec3 tc=vec3(0.0);if(wf>0.002)tc+=wf*texture2D(pMap,vec2(uF.x*vBP.x+uF.y,uF.z*vBP.y+uF.w)).rgb;if(wb>0.002)tc+=wb*texture2D(pMap,vec2(uB.x*vBP.x+uB.y,uB.z*vBP.y+uB.w)).rgb;if(wl>0.002)tc+=wl*texture2D(pMap,vec2(uS.x*vBP.z+uS.y,uS.z*vBP.y+uS.w)).rgb;if(wr>0.002)tc+=wr*texture2D(pMap,vec2(uR.x*vBP.z+uR.y,uR.z*vBP.y+uR.w)).rgb;tc/=max(wt,0.0001);pc=mix(vPC,tc,smoothstep(0.0,0.08,wt));}diffuseColor.rgb*=pc;}')
   .replace('vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;','vec3 outgoingLight = reflectedLight.directDiffuse + reflectedLight.indirectDiffuse + totalEmissiveRadiance;\noutgoingLight=mix(outgoingLight,diffuseColor.rgb*1.04+totalEmissiveRadiance,uFlat);');
  rimHook(sh);mt.userData.sh=sh;};
 mt.customProgramCacheKey=function(){return 'glbProj';};
 return mt;}
/* swap a hero's primitive body for its sculpted mesh, skinned to the same joint groups so every animation keeps working */
function glbHero(V,T,id){
 var I=glbImg(id);if(!I||I.bad)return false;
 var m=GLBM[id],G=glbGeo(id),J=m.j,bm=m.bm||[.4,.09,.47];
 var mt=glbMat(id);
 var keep=new Set();V.wp.traverse(function(o){keep.add(o);});var rm=[];V.g.traverse(function(o){if(o.isMesh&&o!==V.ring&&!keep.has(o))rm.push(o);});
 V.torso.position.set(0,J.tor[1],J.tor[2]);
 V.legs.forEach(function(p,i){var s=i?1:-1;p.position.set(s*J.hip[0],J.hip[1],J.hip[2]);if(V.knee&&V.knee[i])V.knee[i].position.set(0,J.knee[1]-J.hip[1],J.knee[2]-J.hip[2]);});
 V.arms.forEach(function(p,i){var s=i?1:-1;if(J.shR){var S=i?J.shR:J.shL,E=i?J.elR:J.elL;p.position.set(S[0],S[1]-J.tor[1],S[2]-J.tor[2]);if(V.fore&&V.fore[i])V.fore[i].position.set(E[0]-S[0],E[1]-S[1],E[2]-S[2]);return;}p.position.set(s*J.sh[0],J.sh[1]-J.tor[1],J.sh[2]-J.tor[2]);if(V.fore&&V.fore[i])V.fore[i].position.set(s*(J.el[0]-J.sh[0]),J.el[1]-J.sh[1],J.el[2]-J.sh[2]);});
 V.head.position.set(0,J.nk[1]-J.tor[1],J.nk[2]-J.tor[2]);
 V.head.scale.set(1,1,1);
 if(J.hdR)V.wp.position.set(J.hdR[0]-J.elR[0],J.hdR[1]-J.elR[1],J.hdR[2]-J.elR[2]+.04);else V.wp.position.set(J.hd[0]-J.el[0],J.hd[1]-J.el[1],J.hd[2]-J.el[2]+.04);
 var sm=new THREE.SkinnedMesh(G,mt);sm.castShadow=true;sm.frustumCulled=false;sm.userData.glb=1;V.g.add(sm);
 V.g.updateMatrixWorld(true);
 sm.bind(new THREE.Skeleton([V.body,V.torso,V.head,V.legs[0],V.knee[0],V.legs[1],V.knee[1],V.arms[0],V.fore[0],V.arms[1],V.fore[1]]));
 rm.forEach(function(o){if(o.parent)o.parent.remove(o);});
 var hc=new THREE.Object3D();hc.position.set(0,bm[0],bm[1]);hc.scale.setScalar(bm[2]);V.head.add(hc);V.head.children.unshift(V.head.children.pop());
 if(m.nowp)V.wp.traverse(function(o){if(o.isMesh)o.visible=false;});
 V.mats=[mt,V.ring.material];V.face=null;V.glb=sm;V.am=+GLBM[id].am||1;
 return true;}
