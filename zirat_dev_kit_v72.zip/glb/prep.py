from PIL import Image, ImageDraw
import numpy as np
from scipy import ndimage
O='/mnt/user-data/outputs/'
def pouch(im,x0,y0,x1,y1):
    S=4;W,H=im.size;lay=Image.new('RGBA',(W*S,H*S),(0,0,0,0));d=ImageDraw.Draw(lay)
    d.rounded_rectangle([x0*S,y0*S,x1*S,y1*S],radius=14*S,fill=(30,44,104,255))
    d.rounded_rectangle([(x0+5)*S,(y0+4)*S,(x1-5)*S,(y0+24)*S],radius=9*S,fill=(42,60,132,255))
    d.rounded_rectangle([(x0+9)*S,(y0+7)*S,(x1-26)*S,(y0+12)*S],radius=3*S,fill=(78,100,178,255))
    cx=(x0+x1)/2;d.ellipse([(cx-4.5)*S,(y0+18)*S,(cx+4.5)*S,(y0+27)*S],fill=(214,180,60,255))
    d.rounded_rectangle([(x0+4)*S,(y1-12)*S,(x1-4)*S,(y1-3)*S],radius=5*S,fill=(22,32,80,255))
    lay=lay.resize((W,H),Image.LANCZOS);return Image.alpha_composite(im,lay)
def cut(im):
    a=np.array(im).astype(int);R,G,B=a[...,0],a[...,1],a[...,2]
    bg=(B>120)&(B-R>70)&(B-G>40)
    lab,n=ndimage.label(bg);sz=ndimage.sum(bg,lab,range(1,n+1))
    m=np.isin(lab,[i+1 for i,s in enumerate(sz) if s>=3])
    al=1-ndimage.gaussian_filter(m.astype(float),.7);al[m]=0
    # decontaminate blue fringe: pull edge colours toward interior
    rgba=np.dstack([a,(al*255)]).clip(0,255).astype(np.uint8)
    return Image.fromarray(rgba,'RGBA')
pouch(cut(Image.open(O+'cowboy_front.png').convert('RGB')),559,563,626,628).save('front_rgba.png')
pouch(cut(Image.open(O+'cowboy_side.png').convert('RGB')),428,567,493,627).save('side_rgba.png')
cut(Image.open(O+'cowboy_back.png').convert('RGB')).save('back_rgba.png')
for n in['front','side','back']:
    A=np.array(Image.open(n+'_rgba.png'))[...,3];ys,xs=np.where(A>128);print(n,xs.min(),xs.max(),ys.min(),ys.max())
