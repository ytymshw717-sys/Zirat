# paint a generated mesh from character images (front/back[/side] planar projection + harmonic fill)
# usage: python3 pipe.py WORKDIR   (needs white_mesh.glb, front_rgba.png, back_rgba.png; optional side_rgba.png + sidemask.json)
import sys, os, json, numpy as np
sys.path.insert(0, '/home/claude/glb')
from glbio import load
from PIL import Image, ImageDraw
from scipy import ndimage
from scipy.sparse import coo_matrix
W = sys.argv[1].rstrip('/') + '/'
V, F = load(W + 'white_mesh.glb')
P = V[F]; FN = np.cross(P[:, 1] - P[:, 0], P[:, 2] - P[:, 0]); FN /= (np.linalg.norm(FN, axis=1)[:, None] + 1e-12)
FC = P.mean(1); NV, NF = len(V), len(F)
IMG = {n: np.array(Image.open(W + n + '_rgba.png').convert('RGBA')).astype(float) for n in ['front', 'back']}
VIEWS = {'front': (lambda X: X[..., 0], lambda X: X[..., 2], np.array([0, 0, 1.])),
         'back': (lambda X: -X[..., 0], lambda X: -X[..., 2], np.array([0, 0, -1.]))}
IMK = {'front': 'front', 'back': 'back'}
names = ['front', 'back']
SIDE = os.path.exists(W + 'side_rgba.png') and not os.environ.get('NOSIDE')
if SIDE:
    sd = np.array(Image.open(W + 'side_rgba.png').convert('RGBA')).astype(float)
    mk = json.load(open(W + 'sidemask.json')) if os.path.exists(W + 'sidemask.json') else {}
    for b in mk.get('both', []): sd[b[1]:b[3], b[0]:b[2], 3] = 0
    sm = sd[:, ::-1].copy()
    for b in mk.get('mirror', []): sm[b[1]:b[3], 1024 - b[2]:1024 - b[0], 3] = 0
    IMG['side'] = sd; IMG['sideM'] = sm
    VIEWS['sideL'] = (lambda X: -X[..., 2], lambda X: X[..., 0], np.array([1., 0, 0]))
    VIEWS['sideR'] = (lambda X: X[..., 2], lambda X: -X[..., 0], np.array([-1., 0, 0]))
    IMK['sideL'] = 'side'; IMK['sideR'] = 'sideM'; names += ['sideL', 'sideR']
SIDER = SIDE and os.path.exists(W + 'sideR_rgba.png')   # a real right-side view (rendered from a textured model)
if SIDER: IMG['sideR'] = np.array(Image.open(W + 'sideR_rgba.png').convert('RGBA')).astype(float); IMK['sideR'] = 'sideR'

def sil(prm, uf, res=256):
    sx, sy, cx, cy = prm; k = res / 1024
    im = Image.new('L', (res, res), 0); d = ImageDraw.Draw(im)
    U = (cx + sx * uf(P)) * k; Y = (cy - sy * P[..., 1]) * k
    for t in range(NF): d.polygon([(U[t, 0], Y[t, 0]), (U[t, 1], Y[t, 1]), (U[t, 2], Y[t, 2])], fill=255)
    return np.array(im) > 127

def fit(name):
    uf = VIEWS[name][0]; A = IMG[IMK[name]][..., 3] > 128
    ys, xs = np.where(A); u = uf(V)
    sx = (xs.max() - xs.min()) / (u.max() - u.min()); sy = (ys.max() - ys.min()) / (V[:, 1].max() - V[:, 1].min())
    cx = xs.min() - sx * u.min(); cy = ys.min() + sy * V[:, 1].max()
    p0 = np.array([sx, sy, cx, cy]); As = np.array(Image.fromarray(A.astype(np.uint8) * 255).resize((256, 256))) > 127
    def loss(p):
        S = sil(p, uf); return -(S & As).sum() / ((S | As).sum() + 1)
    best = (loss(p0), p0)
    for it in range(3):
        for i, st in enumerate([4, 4, 3, 3]):
            for dl in (-st, st, -st / 2, st / 2):
                q = best[1].copy(); q[i] += dl; l = loss(q)
                if l < best[0]: best = (l, q)
    print(name, 'IoU0 %.3f IoU %.3f' % (-loss(p0), -best[0]), best[1].round(2))
    return best[1]

PRM = {n: fit(n) for n in ['front', 'back'] + (['sideL'] if SIDE else []) + (['sideR'] if SIDER else [])}
if SIDE and not SIDER: p = PRM['sideL'].copy(); p[2] = 1024 - p[2]; PRM['sideR'] = p
def pix(n, X):
    sx, sy, cx, cy = PRM[n]; return cx + sx * VIEWS[n][0](X), cy - sy * X[..., 1]
def samp(n, X):   # image key + pixel coords in the un-mirrored source image
    U, Y = pix(n, X)
    if n == 'sideR' and not SIDER: return 'side', 1024 - U, Y
    return IMK[n], U, Y

VIS = {}
for n in names:
    uf, df, dr = VIEWS[n]; U, Y = pix(n, P); D = df(FC); order = np.argsort(D)
    im = Image.new('I', (1024, 1024), -1); d = ImageDraw.Draw(im)
    for t in order: d.polygon([(U[t, 0], Y[t, 0]), (U[t, 1], Y[t, 1]), (U[t, 2], Y[t, 2])], fill=int(t))
    ib = np.array(im); cnt = np.bincount(ib[ib >= 0].ravel(), minlength=NF)
    area = np.abs((U[:, 1] - U[:, 0]) * (Y[:, 2] - Y[:, 0]) - (U[:, 2] - U[:, 0]) * (Y[:, 1] - Y[:, 0])) / 2
    vis = np.where(area > .5, np.clip(cnt / np.maximum(area, 1e-6), 0, 1), 0.)
    cu = np.clip(U.mean(1).astype(int), 0, 1023); cyy = np.clip(Y.mean(1).astype(int), 0, 1023)
    vis = np.maximum(vis, (ib[cyy, cu] == np.arange(NF)) * 1.0)
    al = IMG[IMK[n]][..., 3][cyy, cu] / 255
    VIS[n] = (vis, al, np.maximum(0, FN @ dr))
FT = float(os.environ.get('FT', '.3'))
WV = {'front': 1.0, 'back': 1.0, 'sideL': float(os.environ.get('SW', '.9')), 'sideR': float(os.environ.get('SW', '.9'))}
score = np.stack([np.maximum(VIS[n][0], .05) * (VIS[n][1] > .5) * (VIS[n][2] > FT) * (VIS[n][2] + .02) * WV[n] for n in names], 1)
if SIDE:   # side image only where it lines up well (optional y-range from env SY0)
    sy0 = float(os.environ.get('SY0', '-9')); sft = float(os.environ.get('SFT', '.3'))
    for i, n in enumerate(names):
        if n.startswith('side'): score[:, i] *= ((FC[:, 1] > sy0) | (FC[:, 1] < float(os.environ.get('SY1', '-9')))) * (VIS[n][2] > sft)
best = score.argmax(1); seen = score.max(1) > .02
print('seen %.2f' % seen.mean(), [(n, int(((best == i) & seen).sum())) for i, n in enumerate(names)])
PAD = {}
for k in ['front', 'back'] + (['side'] if SIDE else []) + (['sideR'] if SIDER else []):
    A = IMG[k]; m = ndimage.binary_dilation(A[..., 3] < 128, iterations=4)
    idx = ndimage.distance_transform_edt(m, return_distances=False, return_indices=True); PAD[k] = A[..., :3][idx[0], idx[1]]
acc = np.zeros((NV, 3)); cnt = np.zeros(NV)
for i, n in enumerate(names):
    sel = np.where(seen & (best == i))[0]
    if not len(sel): continue
    vi = F[sel].ravel(); k, U, Yp = samp(n, V[vi])
    c = PAD[k][np.clip(Yp.astype(int), 0, 1023), np.clip(U.astype(int), 0, 1023)]
    np.add.at(acc, vi, c); np.add.at(cnt, vi, 1)
fixed = cnt > 0; VC = np.zeros((NV, 3)); VC[fixed] = acc[fixed] / cnt[fixed, None]
e = np.concatenate([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]]); e = np.concatenate([e, e[:, ::-1]])
Aj = coo_matrix((np.ones(len(e)), (e[:, 0], e[:, 1])), shape=(NV, NV)).tocsr(); Aj.data[:] = 1; deg = np.array(Aj.sum(1)).ravel()
free = ~fixed; VC[free] = VC[fixed].mean(0)
for it in range(1500): VC[free] = (Aj @ VC)[free] / deg[free, None]
if os.path.exists(W + 'hi_pos.npy'):   # exact colours from the textured source model (nearest surface points)
    from scipy.spatial import cKDTree
    HP = np.load(W + 'hi_pos.npy'); HU = np.load(W + 'hi_uv.npy'); TX = np.array(Image.open(W + 'tex.jpg').convert('RGB')).astype(float)
    d, ii = cKDTree(HP).query(V, k=12); w = 1 / (d + 1e-4); uv = HU[ii]
    th, tw = TX.shape[:2]; c = TX[np.clip((uv[..., 1] * th).astype(int), 0, th - 1), np.clip((uv[..., 0] * tw).astype(int), 0, tw - 1)]
    VC = (c * w[..., None]).sum(1) / w.sum(1)[:, None]; print('exact vertex colours from textured model')
# atlas: big front cell (most visible), smaller back / side cells; light sharpening for crisp detail
from PIL import ImageFilter
AW, AH = 1024, (2048 if SIDER else 1536)
CELLS = {'front': [0, 0, 640, 1280], 'back': [640, 0, 384, 768], 'side': [640, 768, 384, 768], 'sideR': [0, 1280, 384, 768]}
CROP = {}
for k in PAD:
    ys, xs = np.where(IMG[k][..., 3] > 128); cw = int(max(xs.max() - xs.min() + 30, (ys.max() - ys.min() + 30) / 2)); cw += cw % 2
    cxm = (xs.min() + xs.max()) // 2; cym = (ys.min() + ys.max()) // 2
    CROP[k] = [int(cxm - cw // 2), int(cym - cw), cw, 2 * cw]
atlas = np.zeros((AH, AW, 3), np.uint8)
for k in PAD:
    X0, Y0, CW, CH = CROP[k]; cx0, cy0, cw0, ch0 = CELLS[k]
    pd = PAD[k].clip(0, 255).astype(np.uint8); ix = np.clip(np.arange(-1024, 2048), 0, 1023)
    big = pd[ix][:, ix]
    crop = Image.fromarray(big).crop((X0 + 1024, Y0 + 1024, X0 + 1024 + CW, Y0 + 1024 + CH)).resize((cw0, ch0), Image.LANCZOS)
    crop = crop.filter(ImageFilter.UnsharpMask(radius=1.4, percent=70, threshold=2))
    atlas[cy0:cy0 + ch0, cx0:cx0 + cw0] = np.array(crop)
Image.fromarray(atlas).save(W + 'atlas1k.png')
UV = np.zeros((NF, 3, 2))
VCOL = np.ones((NF, 3, 3)) * 255; VCOL[~seen] = VC[F[~seen]]
json.dump({'v': V.round(5).ravel().tolist(), 'f': F.ravel().tolist(), 'uv': UV.round(5).ravel().tolist(), 'c': ((VCOL / 255) ** 2.2).round(4).ravel().tolist()}, open(W + 'tex.json', 'w'))
out = {'f': list(map(float, PRM['front'])), 'b': list(map(float, PRM['back'])), 'cf': CROP['front'], 'cb': CROP['back'], 'aw': AW, 'ah': AH, 'cells': CELLS}
if SIDE: out['s'] = list(map(float, PRM['sideL'])); out['cs'] = CROP['side']
if SIDER: out['r'] = list(map(float, PRM['sideR'])); out['cr'] = CROP['sideR']
json.dump(out, open(W + 'prm.json', 'w'))
# per-vertex visibility per view (front, back, sideL, sideR) for the in-shader blended projection
PV = np.zeros((NV, 4))
for i, n in enumerate(['front', 'back', 'sideL', 'sideR']):
    if n not in VIS: continue
    fvis = ((VIS[n][0] > .5) & (VIS[n][1] > .5)).astype(float)
    acc = np.zeros(NV); cn = np.zeros(NV); np.add.at(acc, F.ravel(), np.repeat(fvis, 3)); np.add.at(cn, F.ravel(), 1)
    k, U, Y = samp(n, V); am = ndimage.binary_dilation(IMG[k][..., 3] > 128, iterations=5)
    inside = am[np.clip(Y.astype(int), 0, 1023), np.clip(U.astype(int), 0, 1023)]
    pv = acc / np.maximum(cn, 1) * inside
    if n.startswith('side'):
        sy0 = float(os.environ.get('SY0', '-9')); sy1 = float(os.environ.get('SY1', '-9'))
        pv *= ((V[:, 1] > sy0) | (V[:, 1] < sy1))
    PV[:, i] = pv
print('vertex vis mean', PV.mean(0).round(2))
np.savez(W + 'model.npz', V=V, F=F, seen=seen, best=best, VC=VC, PV=PV)
print('ok', CROP)
