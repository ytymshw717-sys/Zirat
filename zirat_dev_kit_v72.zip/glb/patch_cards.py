p='/home/claude/arena3_new.html';s=open(p).read()
def rep(a,b,n=1):
    global s
    assert s.count(a)==n,(s.count(a),a[:80]);s=s.replace(a,b)
# picker: every card opens the hero screen (select from there)
rep("data-a='${own?'pk:'+i+':'+j:'hi:'+j}'><img src='${prevB(j,sk,64,R[1])}' width='52' height='52'>","data-a='hp:${i}:${j}'><img src='${prevB(j,sk,64,R[1])}' width='52' height='52'>")
rep("<small>לחץ על גיבור לבחירה · 🔒 נפתח בחנות או מתיבות</small>","<small>לחץ על גיבור לפרטים ולבחירה · 🔒 נפתח בחנות או מתיבות</small>")
# hero screen: remember where it was opened from
rep("function hinfo(idx,msg,pk){\n state='menu';","var hvFrom=null;\nfunction hinfo(idx,msg,pk){\n state='menu';function HA(j){return hvFrom!=null?'hp:'+hvFrom+':'+j:'hi:'+j;}")
rep("<button class='c' data-a='hi:${(idx+CH.length-1)%CH.length}' aria-label='הקודם'>▶</button>","<button class='c' data-a='${HA((idx+CH.length-1)%CH.length)}' aria-label='הקודם'>▶</button>")
rep("<button class='c' data-a='hi:${(idx+1)%CH.length}' aria-label='הבא'>◀</button></div>`;","<button class='c' data-a='${HA((idx+1)%CH.length)}' aria-label='הבא'>◀</button></div>`;\n if(hvFrom!=null&&own)h+=`<button class='c hvPick' data-a='pk:${hvFrom}:${idx}' style='width:auto;padding:0 22px;margin:2px auto 4px;background:linear-gradient(#4ade80,#16a34a);color:#fff;font-weight:900'>${sel[hvFrom]===idx?'✅ נבחר · חזרה לתפריט':'✅ בחר את '+c.nk}</button>`;")
rep("h+=`<button class='hvH${i===idx?' on':''}' data-a='hi:${i}'","h+=`<button class='hvH${i===idx?' on':''}' data-a='${HA(i)}'")
rep("h+=`</div><button class='c' style='width:auto;padding:0 14px' data-a='menu'>◀ חזרה</button></div>`;\n showOv(h);","h+=`</div><button class='c' style='width:auto;padding:0 14px' data-a='${hvFrom!=null?'pick:'+hvFrom:'menu'}'>◀ חזרה</button></div>`;\n showOv(h);")
rep('a[0]==="hi")hinfo(+a[1]);','a[0]==="hi"){hvFrom=null;hinfo(+a[1]);}else if(a[0]==="hp"){hvFrom=+a[1];hinfo(+a[2]);}')
# heroes list: the whole card (picture + name) opens the hero screen
rep("<div class='r' style='width:100%'><button class='c' style='width:auto;height:auto;padding:0;background:none' data-a='hi:${i}'><img src='${prevB(i,sv.sk[i]||0,56,R[1])}' width='44' height='44'></button><span style='flex:1;text-align:start;font-size:12px'><b style='color:${R[1]}'>${c.nk} <small>${c.n}</small></b> · ${R[0]}${own?' · רמה '+(lv+1)+' · 🏆'+(sv.tr[i]||0):''}<br>${c.w} · ⭐ ${c.sn}</span>`;",
"<div class='r' style='width:100%'><button class='c' style='width:auto;height:auto;padding:0;background:none' data-a='hi:${i}'><img src='${prevB(i,sv.sk[i]||0,56,R[1])}' width='44' height='44'></button><button class='hrow' data-a='hi:${i}' style='flex:1;text-align:start;font-size:12px;background:none;border:0;color:inherit;font-family:inherit;padding:2px 0;cursor:pointer;line-height:1.35'><b style='color:${R[1]}'>${c.nk} <small>${c.n}</small></b> · ${R[0]}${own?' · רמה '+(lv+1)+' · 🏆'+(sv.tr[i]||0):''}<br>${c.w} · ⭐ ${c.sn}</button>`;")
open(p,'w').write(s);print('patched')
