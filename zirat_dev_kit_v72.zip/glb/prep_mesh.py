# raw generated mesh -> light game mesh: decimate + Taubin smoothing.  usage: prep_mesh.py WORKDIR [target_tris] [smooth_iters]
import sys;sys.path.insert(0,'/home/claude/glb')
from glbio import load,save,simplify,taubin
W=sys.argv[1].rstrip('/')+'/';T=int(sys.argv[2]) if len(sys.argv)>2 else 12000;S=int(sys.argv[3]) if len(sys.argv)>3 else 6
V,F=simplify(W+'raw.glb',W+'_dec.glb',T)
V2=taubin(V,F,S);save(W+'white_mesh.glb',V2,F);print('mesh',V2.shape,F.shape)
