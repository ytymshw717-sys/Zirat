/* quadric edge-collapse mesh simplifier (iterative threshold variant)
   usage: qsimp in.bin out.bin target_faces [aggressiveness]
   bin format: int32 nv, int32 nf, float32 v[nv*3], int32 f[nf*3] */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <math.h>

typedef struct { double x, y, z; } vec3;
static vec3 v3(double x, double y, double z) { vec3 r = {x, y, z}; return r; }
static vec3 sub(vec3 a, vec3 b) { return v3(a.x - b.x, a.y - b.y, a.z - b.z); }
static vec3 add(vec3 a, vec3 b) { return v3(a.x + b.x, a.y + b.y, a.z + b.z); }
static vec3 mul(vec3 a, double s) { return v3(a.x * s, a.y * s, a.z * s); }
static double dot(vec3 a, vec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static vec3 cross(vec3 a, vec3 b) { return v3(a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x); }
static vec3 norm(vec3 a) { double l = sqrt(dot(a, a)); return l > 0 ? mul(a, 1.0 / l) : a; }

typedef struct { double m[10]; } SM;
static SM sm_plane(double a, double b, double c, double d) {
  SM s; s.m[0] = a * a; s.m[1] = a * b; s.m[2] = a * c; s.m[3] = a * d; s.m[4] = b * b;
  s.m[5] = b * c; s.m[6] = b * d; s.m[7] = c * c; s.m[8] = c * d; s.m[9] = d * d; return s;
}
static SM sm_add(SM a, SM b) { SM r; for (int i = 0; i < 10; i++) r.m[i] = a.m[i] + b.m[i]; return r; }
static double sm_det(const SM *q, int a11, int a12, int a13, int a21, int a22, int a23, int a31, int a32, int a33) {
  const double *m = q->m;
  return m[a11] * m[a22] * m[a33] + m[a13] * m[a21] * m[a32] + m[a12] * m[a23] * m[a31]
       - m[a13] * m[a22] * m[a31] - m[a11] * m[a23] * m[a32] - m[a12] * m[a21] * m[a33];
}

typedef struct { int v[3]; double err[4]; int deleted, dirty; vec3 n; } Tri;
typedef struct { vec3 p; int tstart, tcount; SM q; int border; } Vert;
typedef struct { int tid, tvertex; } Ref;

static Tri *T; static int nT;
static Vert *Vv; static int nV;
static Ref *R; static int nR, capR;

static void ref_push(Ref r) {
  if (nR >= capR) { capR = capR ? capR * 2 : 1024; R = realloc(R, sizeof(Ref) * capR); }
  R[nR++] = r;
}

static double vertex_error(const SM *q, double x, double y, double z) {
  const double *m = q->m;
  return m[0] * x * x + 2 * m[1] * x * y + 2 * m[2] * x * z + 2 * m[3] * x + m[4] * y * y
       + 2 * m[5] * y * z + 2 * m[6] * y + m[7] * z * z + 2 * m[8] * z + m[9];
}

static double calculate_error(int i1, int i2, vec3 *pr) {
  SM q = sm_add(Vv[i1].q, Vv[i2].q);
  int border = Vv[i1].border & Vv[i2].border;
  double err = 0, det = sm_det(&q, 0, 1, 2, 1, 4, 5, 2, 5, 7);
  if (det != 0 && !border) {
    pr->x = -1 / det * sm_det(&q, 1, 2, 3, 4, 5, 6, 5, 7, 8);
    pr->y = 1 / det * sm_det(&q, 0, 2, 3, 1, 5, 6, 2, 7, 8);
    pr->z = -1 / det * sm_det(&q, 0, 1, 3, 1, 4, 6, 2, 5, 8);
    err = vertex_error(&q, pr->x, pr->y, pr->z);
  } else {
    vec3 p1 = Vv[i1].p, p2 = Vv[i2].p, p3 = mul(add(p1, p2), .5);
    double e1 = vertex_error(&q, p1.x, p1.y, p1.z), e2 = vertex_error(&q, p2.x, p2.y, p2.z), e3 = vertex_error(&q, p3.x, p3.y, p3.z);
    err = fmin(e1, fmin(e2, e3));
    if (err == e1) *pr = p1; if (err == e2) *pr = p2; if (err == e3) *pr = p3;
  }
  return err;
}

static int flipped(vec3 p, int i1, Vert *v0, int *del) {
  for (int k = 0; k < v0->tcount; k++) {
    Tri *t = &T[R[v0->tstart + k].tid];
    if (t->deleted) continue;
    int s = R[v0->tstart + k].tvertex, id1 = t->v[(s + 1) % 3], id2 = t->v[(s + 2) % 3];
    if (id1 == i1 || id2 == i1) { del[k] = 1; continue; }
    vec3 d1 = norm(sub(Vv[id1].p, p)), d2 = norm(sub(Vv[id2].p, p));
    if (fabs(dot(d1, d2)) > 0.999) return 1;
    vec3 n = norm(cross(d1, d2));
    del[k] = 0;
    if (dot(n, t->n) < 0.2) return 1;
  }
  return 0;
}

static void update_triangles(int i0, Vert *v, int *del, int *deleted_triangles) {
  vec3 p;
  for (int k = 0; k < v->tcount; k++) {
    Ref r = R[v->tstart + k]; Tri *t = &T[r.tid];
    if (t->deleted) continue;
    if (del[k]) { t->deleted = 1; (*deleted_triangles)++; continue; }
    t->v[r.tvertex] = i0; t->dirty = 1;
    t->err[0] = calculate_error(t->v[0], t->v[1], &p);
    t->err[1] = calculate_error(t->v[1], t->v[2], &p);
    t->err[2] = calculate_error(t->v[2], t->v[0], &p);
    t->err[3] = fmin(t->err[0], fmin(t->err[1], t->err[2]));
    ref_push(r);
  }
}

static void update_mesh(int iteration) {
  if (iteration > 0) { int dst = 0; for (int i = 0; i < nT; i++) if (!T[i].deleted) T[dst++] = T[i]; nT = dst; }
  for (int i = 0; i < nV; i++) { Vv[i].tstart = 0; Vv[i].tcount = 0; }
  for (int i = 0; i < nT; i++) for (int j = 0; j < 3; j++) Vv[T[i].v[j]].tcount++;
  int ts = 0; for (int i = 0; i < nV; i++) { Vv[i].tstart = ts; ts += Vv[i].tcount; Vv[i].tcount = 0; }
  nR = 0; if (capR < nT * 3) { capR = nT * 3 + 16; R = realloc(R, sizeof(Ref) * capR); } nR = nT * 3;
  for (int i = 0; i < nT; i++) for (int j = 0; j < 3; j++) { Vert *v = &Vv[T[i].v[j]]; R[v->tstart + v->tcount].tid = i; R[v->tstart + v->tcount].tvertex = j; v->tcount++; }
  if (iteration == 0) {
    int *vcount = malloc(sizeof(int) * 64), *vids = malloc(sizeof(int) * 64), cap = 64;
    for (int i = 0; i < nV; i++) Vv[i].border = 0;
    for (int i = 0; i < nV; i++) {
      Vert *v = &Vv[i]; int n = 0;
      for (int j = 0; j < v->tcount; j++) {
        Tri *t = &T[R[v->tstart + j].tid];
        for (int k = 0; k < 3; k++) {
          int id = t->v[k], ofs = 0;
          while (ofs < n) { if (vids[ofs] == id) break; ofs++; }
          if (ofs == n) { if (n >= cap) { cap *= 2; vcount = realloc(vcount, sizeof(int) * cap); vids = realloc(vids, sizeof(int) * cap); } vcount[n] = 1; vids[n] = id; n++; }
          else vcount[ofs]++;
        }
      }
      for (int j = 0; j < n; j++) if (vcount[j] == 1) Vv[vids[j]].border = 1;
    }
    free(vcount); free(vids);
    for (int i = 0; i < nV; i++) memset(&Vv[i].q, 0, sizeof(SM));
    for (int i = 0; i < nT; i++) {
      Tri *t = &T[i]; vec3 p0 = Vv[t->v[0]].p, p1 = Vv[t->v[1]].p, p2 = Vv[t->v[2]].p;
      vec3 n = norm(cross(sub(p1, p0), sub(p2, p0))); t->n = n;
      for (int j = 0; j < 3; j++) Vv[t->v[j]].q = sm_add(Vv[t->v[j]].q, sm_plane(n.x, n.y, n.z, -dot(n, p0)));
    }
    vec3 p;
    for (int i = 0; i < nT; i++) {
      Tri *t = &T[i];
      for (int j = 0; j < 3; j++) t->err[j] = calculate_error(t->v[j], t->v[(j + 1) % 3], &p);
      t->err[3] = fmin(t->err[0], fmin(t->err[1], t->err[2]));
    }
  }
}

static void compact_mesh(void) {
  int dst = 0;
  for (int i = 0; i < nV; i++) Vv[i].tcount = 0;
  for (int i = 0; i < nT; i++) if (!T[i].deleted) { T[dst++] = T[i]; for (int j = 0; j < 3; j++) Vv[T[i].v[j]].tcount = 1; }
  nT = dst; dst = 0;
  for (int i = 0; i < nV; i++) if (Vv[i].tcount) { Vv[i].tstart = dst; Vv[dst].p = Vv[i].p; dst++; }
  for (int i = 0; i < nT; i++) for (int j = 0; j < 3; j++) T[i].v[j] = Vv[T[i].v[j]].tstart;
  nV = dst;
}

int main(int argc, char **argv) {
  if (argc < 4) { fprintf(stderr, "usage\n"); return 1; }
  FILE *f = fopen(argv[1], "rb"); int nv, nf;
  if (!f || fread(&nv, 4, 1, f) != 1 || fread(&nf, 4, 1, f) != 1) { fprintf(stderr, "read error\n"); return 1; }
  float *fv = malloc(4 * nv * 3); int *ff = malloc(4 * nf * 3);
  if (fread(fv, 4, nv * 3, f) != (size_t)nv * 3 || fread(ff, 4, nf * 3, f) != (size_t)nf * 3) { fprintf(stderr, "read error2\n"); return 1; }
  fclose(f);
  nV = nv; nT = nf; Vv = calloc(nV, sizeof(Vert)); T = calloc(nT, sizeof(Tri));
  for (int i = 0; i < nV; i++) Vv[i].p = v3(fv[i * 3], fv[i * 3 + 1], fv[i * 3 + 2]);
  for (int i = 0; i < nT; i++) for (int j = 0; j < 3; j++) T[i].v[j] = ff[i * 3 + j];
  int target = atoi(argv[3]); double agg = argc > 4 ? atof(argv[4]) : 7;
  int deleted_triangles = 0, tri_count = nT;
  int *del0 = NULL, *del1 = NULL, cap0 = 0, cap1 = 0;
  for (int iteration = 0; iteration < 100; iteration++) {
    if (tri_count - deleted_triangles <= target) break;
    if (iteration % 5 == 0) update_mesh(iteration);
    for (int i = 0; i < nT; i++) T[i].dirty = 0;
    double threshold = 0.000000001 * pow((double)(iteration + 3), agg);
    for (int i = 0; i < nT; i++) {
      Tri *t = &T[i];
      if (t->err[3] > threshold || t->deleted || t->dirty) continue;
      for (int j = 0; j < 3; j++) if (t->err[j] < threshold) {
        int i0 = t->v[j], i1 = t->v[(j + 1) % 3]; Vert *v0 = &Vv[i0], *v1 = &Vv[i1];
        if (v0->border != v1->border) continue;
        vec3 p; calculate_error(i0, i1, &p);
        if (v0->tcount > cap0) { cap0 = v0->tcount * 2; del0 = realloc(del0, sizeof(int) * cap0); }
        if (v1->tcount > cap1) { cap1 = v1->tcount * 2; del1 = realloc(del1, sizeof(int) * cap1); }
        if (flipped(p, i1, v0, del0)) continue;
        if (flipped(p, i0, v1, del1)) continue;
        v0->p = p; v0->q = sm_add(v1->q, v0->q);
        int tstart = nR;
        update_triangles(i0, v0, del0, &deleted_triangles);
        update_triangles(i0, v1, del1, &deleted_triangles);
        v0 = &Vv[i0]; v1 = &Vv[i1];
        int tcount = nR - tstart;
        if (tcount <= v0->tcount) { if (tcount) memmove(&R[v0->tstart], &R[tstart], sizeof(Ref) * tcount); }
        else v0->tstart = tstart;
        v0->tcount = tcount;
        break;
      }
      if (tri_count - deleted_triangles <= target) break;
    }
  }
  compact_mesh();
  FILE *o = fopen(argv[2], "wb");
  fwrite(&nV, 4, 1, o); fwrite(&nT, 4, 1, o);
  for (int i = 0; i < nV; i++) { float q[3] = {(float)Vv[i].p.x, (float)Vv[i].p.y, (float)Vv[i].p.z}; fwrite(q, 4, 3, o); }
  for (int i = 0; i < nT; i++) fwrite(T[i].v, 4, 3, o);
  fclose(o);
  fprintf(stderr, "done: %d verts, %d tris\n", nV, nT);
  return 0;
}
