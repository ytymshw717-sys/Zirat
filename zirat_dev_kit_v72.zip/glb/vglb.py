import sys,json,subprocess,time
from playwright.sync_api import sync_playwright
url=sys.argv[1];out=sys.argv[2];opt=json.loads(sys.argv[3]) if len(sys.argv)>3 else {}
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader']);pg=b.new_page(viewport={'width':1600,'height':800})
    E=[];pg.on('pageerror',lambda e:E.append(str(e)));pg.on('console',lambda m:E.append(m.text) if m.type=='error' else None)
    pg.goto('http://127.0.0.1:9920/glb/vglb.html');r=pg.evaluate("([u,o])=>view(u,o)",[url,opt]);pg.wait_for_timeout(500)
    pg.screenshot(path=out);print(r,'E',E[:3])
