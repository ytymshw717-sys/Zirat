# skin weights + compact blob for one hero.  usage: python3 export2.py WORKDIR   (reads WORKDIR/params.json)
import sys, json, base64, io, numpy as np
from PIL import Image
W = sys.argv[1].rstrip('/') + '/'
Pm = json.load(open(W + 'params.json'))
Z = np.load(W + 'model.npz'); V = Z['V']; F = Z['F']; seen = Z['seen']; best = Z['best']; VC = Z['VC']; PV = Z['PV']
PR = json.load(open(W + 'prm.json'))
NV = len(V)
XC = Pm.get('xc', 0); x = V[:, 0] + XC; y = V[:, 1]; z = V[:, 2]; ax = np.abs(x)
def ss(a, b, t):
    t = np.clip((t - a) / (b - a), 0, 1); return t * t * (3 - 2 * t)
J0 = Pm['joints']
def G(k, sgn=1):
    v = J0.get(k)
    return np.array([v[0] * sgn, v[1], v[2]], float)
hipR = G('hip'); hipL = G('hip', -1); knR = G('knee'); knL = G('knee', -1)
shR = np.array(J0['shR'] if 'shR' in J0 else J0['sh'], float); elR = np.array(J0['elR'] if 'elR' in J0 else J0['el'], float); hdR = np.array(J0['hdR'] if 'hdR' in J0 else J0['hd'], float)
shL = np.array(J0['shL'] if 'shL' in J0 else [-J0['sh'][0]] + J0['sh'][1:], float); elL = np.array(J0['elL'] if 'elL' in J0 else [-J0['el'][0]] + J0['el'][1:], float); hdL = np.array(J0['hdL'] if 'hdL' in J0 else [-J0['hd'][0]] + J0['hd'][1:], float)
nk = G('nk'); tor = G('tor'); top = V[:, 1].max(); cr = Pm.get('crotch', tor[1] - .06)
def ext(a, b, k): return b + (b - a) / (np.linalg.norm(b - a) + 1e-9) * k
SEG = [(np.array([0, cr - .04, tor[2]]), np.array([0, tor[1] + .08, tor[2]])),          # 0 body (pelvis)
       (np.array([0, tor[1] + .08, tor[2]]), nk),                                         # 1 torso
       (nk + [0, .05, 0], np.array([0, top - .05, nk[2]])),                               # 2 head
       (hipL, knL), (knL, np.array([knL[0], -.98, knL[2]])),                              # 3,4 left leg
       (hipR, knR), (knR, np.array([knR[0], -.98, knR[2]])),                              # 5,6 right leg
       (shL, elL), (elL, ext(elL, hdL, Pm.get('handExt', .13))),                           # 7,8 left arm
       (shR, elR), (elR, ext(elR, hdR, Pm.get('handExt', .13)))]                           # 9,10 right arm
def dseg(p, a, b):
    ab = b - a; t = np.clip(((p - a) @ ab) / (ab @ ab + 1e-12), 0, 1); return np.linalg.norm(p - (a + t[:, None] * ab), axis=1)
Pv = np.stack([x, y, z], 1); D = np.stack([dseg(Pv, a, b) for a, b in SEG], 1)
D[:, 2] *= Pm.get('headBias', 1.0)
Wt = 1 / np.power(D + .015, Pm.get('envPow', 7))
Wt[y < nk[1] - Pm.get('headLow', .03), 2] *= .03
# torso half-width per height: the connected cross-section around x=0 (arms hanging beside the body are separate pieces)
from scipy import ndimage as _nd
def torso_hw():
    Pt = V[F]; rr = np.random.RandomState(0).rand(len(F), 5, 2); rr = np.where(rr.sum(2, keepdims=True) > 1, 1 - rr, rr)
    S = (Pt[:, None, 0] + rr[..., 0:1] * (Pt[:, None, 1] - Pt[:, None, 0]) + rr[..., 1:2] * (Pt[:, None, 2] - Pt[:, None, 0])).reshape(-1, 3); S = np.concatenate([S, V])
    bins = np.arange(-1.0, 1.0, .02); hw = np.full(len(bins), np.nan); cs = .02
    for i, yc in enumerate(bins):
        sl = S[np.abs(S[:, 1] - yc) < .011]
        if len(sl) < 10: continue
        gx = ((sl[:, 0] + 1) / cs).astype(int); gz = ((sl[:, 2] + 1) / cs).astype(int); G = np.zeros((gx.max() + 2, gz.max() + 2), bool); G[gx, gz] = 1
        G = _nd.binary_closing(G, iterations=1) | G; lab, n = _nd.label(G, structure=np.ones((3, 3)))
        c0 = int(1 / cs); col = lab[c0] if c0 < lab.shape[0] else np.zeros(1); ids = set(col[col > 0].tolist())
        if not ids: continue
        m = np.isin(lab[gx, gz], list(ids)); hw[i] = np.abs(sl[m, 0]).max()
    return bins, hw
HB, HW = torso_hw()
yi = np.clip(((y + 1.0) / .02).round().astype(int), 0, len(HB) - 1); hwv = HW[yi]
shy = min(shR[1], shL[1]); low = (y < shy - Pm.get('shBand', .08)) & ~np.isnan(hwv) & (y > cr - .1)
inside = low & (ax < hwv - .012); outside = low & (ax > hwv + .015) & (np.minimum(D[:, 8], D[:, 10]) < Pm.get('armR', .13) + .02) | low & (ax > hwv + .015) & (np.minimum(D[:, 7], D[:, 9]) < Pm.get('armR', .13))
Wt[inside, 7:11] *= .002            # the body's own side never follows the arm
Wt[outside, 0:3] *= .002            # the arm (outside the body) never sticks to the body
print('torso-side locks', int(inside.sum()), 'arm locks', int(outside.sum()))
Wt[y > nk[1] + .06, 3:] *= .02
far = (np.minimum(D[:, 7], D[:, 9]) > Pm.get('armR', .13)) & (np.minimum(D[:, 8], D[:, 10]) > Pm.get('armR', .13) + Pm.get('handR', .1)); Wt[far, 7:11] = 0   # arms only near the arm bones (no coat/holster stretching)
Wt[far & (Wt.sum(1) < 1e-9), 1] = 1   # above the neck: no limbs (except held props below)
Wt[y > cr + .06, 3:7] = 0          # legs only below the hips
for bx in Pm.get('rigid', []):     # boxes forced onto the torso/body (capes, packs ...): [x0,x1,y0,y1,z0,z1,(bone)]
    m = (x > bx[0]) & (x < bx[1]) & (y > bx[2]) & (y < bx[3]) & (z > bx[4]) & (z < bx[5]); bn = int(bx[6]) if len(bx) > 6 else 1
    Wt[m] = 0; Wt[m, bn] = 1
for bx in Pm.get('noArm', []):    # regions that never follow the arms (legs beside a hanging hand): [x0,x1,y0,y1]
    m = (x > bx[0]) & (x < bx[1]) & (y > bx[2]) & (y < bx[3]); Wt[m, 7:11] = 0; z0 = m & (Wt.sum(1) < 1e-9); Wt[z0, 0] = 1
for bx in Pm.get('bindR', []):     # held props ride on the right forearm
    m = (x > bx[0]) & (x < bx[1]) & (y > bx[2]) & (y < bx[3]) & (z > bx[4] + bx[5] * y); Wt[m] = 0; Wt[m, 10] = 1
for bx in Pm.get('bindL', []):
    m = (x > bx[0]) & (x < bx[1]) & (y > bx[2]) & (y < bx[3]) & (z > bx[4] + bx[5] * y); Wt[m] = 0; Wt[m, 8] = 1
Wt = Wt / Wt.sum(1, keepdims=True)
from scipy.sparse import coo_matrix
e = np.concatenate([F[:, [0, 1]], F[:, [1, 2]], F[:, [2, 0]]]); e = np.concatenate([e, e[:, ::-1]])
Aj = coo_matrix((np.ones(len(e)), (e[:, 0], e[:, 1])), shape=(NV, NV)).tocsr(); Aj.data[:] = 1; deg = np.maximum(np.array(Aj.sum(1)).ravel(), 1)
for it in range(Pm.get('smooth', 2)): Wt = .5 * Wt + .5 * (Aj @ Wt) / deg[:, None]
Wt = Wt / Wt.sum(1, keepdims=True)
dom = Wt.argmax(1); isArm = np.isin(dom, [7, 8, 9, 10])
cut = np.zeros(len(F), bool)
if Pm.get('cutArmLeg'):   # a hand resting on the thigh: drop the faces that weld the arm to the leg
    dA = np.isin(dom[F], [7, 8, 9, 10]); dL = np.isin(dom[F], [3, 4, 5, 6]); cut = dA.any(1) & dL.any(1)
    if Pm.get('cutArmLeg') > 1: cut |= np.isin(dom[F], [8, 10]).any(1) & np.isin(dom[F], [0]).any(1); print('arm-leg bridge faces cut', int(cut.sum()))
if Pm.get('cutArmTorso'):   # a hanging arm pressed against a bulky jacket: drop the faces that weld the lower arm/hand to the torso
    sd = Pm.get('cutArmTorso'); bones = [8] if sd == 'L' else [10] if sd == 'R' else [8, 10]
    c2 = np.isin(dom[F], bones).any(1) & np.isin(dom[F], [1]).any(1); cut |= c2; print('arm-torso bridge faces cut', int(c2.sum()))
keep = ~cut; F = F[keep]; seen = seen[keep]; best = best[keep]; NF = len(F)
print('cut tris', cut.sum(), 'dominant counts', np.bincount(dom, minlength=11))
np.save(W + 'skin_dom.npy', dom)
o = np.argsort(-Wt, 1)[:, :4]; ww = np.take_along_axis(Wt, o, 1); ww /= ww.sum(1, keepdims=True)
wq = np.round(ww * 255).astype(int); wq[:, 0] += 255 - wq.sum(1)
mn = V.min(0); mx = V.max(0); q = np.round((V - mn) / (mx - mn) * 65535).astype(np.uint16)
fv = np.where(seen, best, 9).astype(np.uint8)
vc = np.clip(np.round(VC), 0, 255).astype(np.uint8)
pv = np.clip(np.round(PV * 255), 0, 255).astype(np.uint8)
blob = b''.join([q.tobytes(), F.astype(np.uint16).tobytes(), vc.tobytes(), pv.tobytes(), o.astype(np.uint8).tobytes(), wq.astype(np.uint8).tobytes()])
K = Pm['k']; YMIN = mn[1]
def H(p): return [round(p[0] * K, 4), round((p[1] - YMIN) * K + .01, 4), round(p[2] * K, 4)]
J = {k: H(v) for k, v in Pm['joints'].items()}
bf = io.BytesIO(); Image.open(W + 'atlas1k.png').save(bf, 'WEBP', quality=Pm.get('q', 82), method=6)
meta = {'nv': NV, 'nf': NF, 'mn': mn.round(6).tolist(), 'mx': mx.round(6).tolist(), 'f': PR['f'], 'b': PR['b'], 'cf': PR['cf'], 'cb': PR['cb'],
        'j': J, 'k': K, 'xc': XC, 'bm': Pm['bm'], 'v2': 1, 'aw': PR['aw'], 'ah': PR['ah'], 'cells': PR['cells'], 's': PR.get('s'), 'cs': PR.get('cs'), 'r': PR.get('r'), 'cr': PR.get('cr'), 'fl': Pm.get('fl', .82), 'nowp': Pm.get('nowp', 0), 'pa': 1, 'am': Pm.get('am', 1), 'tex': 'data:image/webp;base64,' + base64.b64encode(bf.getvalue()).decode(), 'd': base64.b64encode(blob).decode()}
json.dump(meta, open(W + 'meta_full.json', 'w'), separators=(',', ':'))
print('blob', len(blob), 'tex', len(bf.getvalue()))
