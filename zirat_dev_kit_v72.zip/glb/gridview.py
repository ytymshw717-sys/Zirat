import sys
from PIL import Image, ImageDraw, ImageFont
W=sys.argv[1].rstrip('/')+'/';out=sys.argv[2]
f=ImageFont.truetype('/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf',13)
ims=[]
for n,lab in [('front','x'),('side','z')]:
    im=Image.open(W+n+'_rgba.png').convert('RGBA');bg=Image.new('RGBA',im.size,(40,40,60,255));bg.alpha_composite(im);d=ImageDraw.Draw(bg)
    hh=1.96/2*1024/1000
    def px(v):return 512+v/hh*512
    def py(v):return 512-(v+0.02)/hh*512
    for k in range(-10,11):
        v=k/10;c=(255,255,0,120) if k%5==0 else (255,255,255,50)
        d.line([(px(v),0),(px(v),1024)],fill=c,width=1);d.line([(0,py(v)),(1024,py(v))],fill=c,width=1)
        d.text((px(v)+2,2),'%.1f'%v,fill=(255,255,0,255),font=f);d.text((2,py(v)-14),'%.1f'%v,fill=(255,255,0,255),font=f)
    d.text((900,1000),n+' ('+lab+')',fill=(255,255,255,255),font=f)
    ims.append(bg.convert('RGB'))
s=Image.new('RGB',(2048,1024));s.paste(ims[0],(0,0));s.paste(ims[1],(1024,0));s.resize((1400,700)).save(out)
