import sys,json,numpy as np
sys.path.insert(0,'/home/claude/glb')
sys.argv=sys.argv[:1];exec(open('paint.py').read().split("# --- visibility")[0])
Z=np.load('paint.npz');best=Z['best'];seen=Z['seen'];C=Z['col']
names=list(VIEWS)
X0,Y0,CW,CH=272,32,480,960;AW,AH=2048,1024
CELL={'front':0,'sideL':512,'sideR':512,'back':1024}
for k in['front','back','side']:
    A=IMG[k];m=ndimage.binary_dilation(A[...,3]<128,iterations=4);idx=ndimage.distance_transform_edt(m,return_distances=False,return_indices=True);IMG[k+'_pad']=A[...,:3][idx[0],idx[1]]
atlas=np.zeros((AH,AW,3),np.uint8)
for k,x in[('front',0),('side',512),('back',1024)]:
    crop=Image.fromarray(IMG[k+'_pad'].astype(np.uint8)).crop((X0,Y0,X0+CW,Y0+CH)).resize((512,1024),Image.LANCZOS)
    atlas[:,x:x+512]=np.array(crop)
# unseen faces: smooth per-vertex colours (harmonic fill from seen-face samples), uv -> white cell
atlas[0:16,2032:2048]=255
UV=np.zeros((NF,3,2));UV[:,:,0]=2040/AW;UV[:,:,1]=1-8/AH
acc=np.zeros((NV,3));cnt=np.zeros(NV)
for i,n in enumerate(names):
    sel=np.where(seen&(best==i))[0]
    if not len(sel):continue
    vi=F[sel].ravel();U,Yp=pix(n,V[vi]);im=IMG[VIEWS[n][0] if VIEWS[n][0]!='sideM' else 'side'][...,:3] if False else None
    src=IMG[{'front':'front','back':'back'}[n]+'_pad']
    c=src[np.clip(Yp.astype(int),0,1023),np.clip(U.astype(int),0,1023)]
    np.add.at(acc,vi,c);np.add.at(cnt,vi,1)
fixed=cnt>0;VC=np.zeros((NV,3));VC[fixed]=acc[fixed]/cnt[fixed,None]
from scipy.sparse import coo_matrix
e=np.concatenate([F[:,[0,1]],F[:,[1,2]],F[:,[2,0]]]);e=np.concatenate([e,e[:,::-1]])
Aj=coo_matrix((np.ones(len(e)),(e[:,0],e[:,1])),shape=(NV,NV)).tocsr();Aj.data[:]=1;deg=np.array(Aj.sum(1)).ravel()
free=~fixed;VC[free]=VC[fixed].mean(0)
for it in range(1500):
    VC[free]=(Aj@VC)[free]/deg[free,None]
print('fixed verts',fixed.sum(),'free',free.sum())
VCOL=np.ones((NF,3,3))*255
VCOL[~seen]=VC[F[~seen]]
for i,n in enumerate(names):
    sel=np.where(seen&(best==i))[0];U,Yp=pix(n,P[sel])
    if n=='sideR':U=1024-U
    ax=CELL[n]+(U-X0)*512/CW;ay=(Yp-Y0)*1024/CH
    UV[sel,:,0]=ax/AW;UV[sel,:,1]=1-ay/AH
Image.fromarray(atlas).save('atlas.png')
json.dump({'v':V.round(5).ravel().tolist(),'f':F.ravel().tolist(),'uv':UV.round(5).ravel().tolist(),'c':((VCOL/255)**2.2).round(4).ravel().tolist()},open('tex.json','w'))
np.savez('model.npz',V=V,F=F,UV=UV,VCOL=VCOL,seen=seen,VC=VC)
print('ok')
