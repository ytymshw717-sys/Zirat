var GLBI={},GLBT={},GLBG={};
function glbImg(id){var I=GLBI[id];if(!I&&GLBM[id]){I=GLBI[id]=new Image();I.onload=function(){I.done=1;if(GLBT[id])GLBT[id].needsUpdate=true;};I.onerror=function(){I.done=1;I.bad=1;};I.src=GLBM[id].tex;}return I;}
try{for(var gk in GLBM)glbImg(gk);}catch(e){}
function glbWait(){for(var k in GLBI)if(!GLBI[k].done)return true;return false;}
function glbTex(id){var t=GLBT[id];if(!t){var I=glbImg(id);t=GLBT[id]=new THREE.Texture(I);t.anisotropy=4;if(I.done&&!I.bad)t.needsUpdate=true;}return t;}
function glbGeo(id){if(GLBG[id])return GLBG[id];
 var m=GLBM[id],bs=atob(m.d),u8=new Uint8Array(bs.length);for(var i=0;i<bs.length;i++)u8[i]=bs.charCodeAt(i);
 var nv=m.nv,nf=m.nf,o=0,q=new Uint16Array(u8.buffer,0,nv*3);o=nv*6;var ix=new Uint16Array(u8.buffer,o,nf*3);o+=nf*6;
 var fv=u8.subarray(o,o+nf);o+=nf;var vc=u8.subarray(o,o+nv*3);o+=nv*3;var si=u8.subarray(o,o+nv*4);o+=nv*4;var sw=u8.subarray(o,o+nv*4);
 var mn=m.mn,mx=m.mx,K=m.k,y0=mn[1],gp=new Float32Array(nv*3),hp=new Float32Array(nv*3);
 for(i=0;i<nv;i++)for(var c=0;c<3;c++){var v=mn[c]+q[i*3+c]/65535*(mx[c]-mn[c]);gp[i*3+c]=v;hp[i*3+c]=c===0?(v+m.xc)*K:c===1?(v-y0)*K+.01:v*K;}
 var g0=new THREE.BufferGeometry();g0.setAttribute('position',new THREE.BufferAttribute(hp,3));g0.setIndex(new THREE.BufferAttribute(new Uint16Array(ix),1));g0.computeVertexNormals();var nr=g0.attributes.normal.array;
 var n3=nf*3,P=new Float32Array(n3*3),N=new Float32Array(n3*3),UV=new Float32Array(n3*2),C=new Float32Array(n3*3),SI=new Uint16Array(n3*4),SW=new Float32Array(n3*4);
 var un=m.un!=null?m.un:2,AW=m.aw||1024,VW=[[m.f,m.cf||m.crop,0],[m.b,m.cb||m.crop,1],[m.s,m.cs,2],[m.s,m.cs,2]];
 for(var f=0;f<nf;f++){var view=fv[f];for(var k=0;k<3;k++){var vi=ix[f*3+k],w=f*3+k;
   for(c=0;c<3;c++){P[w*3+c]=hp[vi*3+c];N[w*3+c]=nr[vi*3+c];}
   for(c=0;c<4;c++){SI[w*4+c]=si[vi*4+c];SW[w*4+c]=sw[vi*4+c]/255;}
   var vw=view!==un&&VW[view];
   if(vw&&vw[0]){var pr=vw[0],cr=vw[1],gx=gp[vi*3],gy=gp[vi*3+1],gz=gp[vi*3+2],px=pr[2]+pr[0]*(view===0?gx:view===1?-gx:-gz),py=pr[3]-pr[1]*gy;
    UV[w*2]=(vw[2]*512+(px-cr[0])*512/cr[2])/AW;UV[w*2+1]=1-(py-cr[1])/cr[3];C[w*3]=C[w*3+1]=C[w*3+2]=1;}
   else{UV[w*2]=12/AW;UV[w*2+1]=1-12/1024;for(c=0;c<3;c++)C[w*3+c]=vc[vi*3+c]/255;}}}
 var g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(P,3));g.setAttribute('normal',new THREE.BufferAttribute(N,3));g.setAttribute('uv',new THREE.BufferAttribute(UV,2));g.setAttribute('color',new THREE.BufferAttribute(C,3));
 g.setAttribute('skinIndex',new THREE.Uint16BufferAttribute(SI,4));g.setAttribute('skinWeight',new THREE.BufferAttribute(SW,4));g.computeBoundingSphere();g.computeBoundingBox();g0.dispose();
 GLBG[id]=g;return g;}
/* swap a hero's primitive body for its sculpted mesh, skinned to the same joint groups so every animation keeps working */
function glbHero(V,T,id){
 var I=glbImg(id);if(!I||I.bad)return false;
 var m=GLBM[id],G=glbGeo(id),J=m.j,bm=m.bm||[.4,.09,.47];
 var mt=new THREE.MeshToonMaterial({map:glbTex(id),vertexColors:true,gradientMap:toonGrad(),skinning:true,side:THREE.DoubleSide});mt.onBeforeCompile=rimHook;mt.customProgramCacheKey=function(){return 'toonRim';};
 var keep=new Set();V.wp.traverse(function(o){keep.add(o);});var rm=[];V.g.traverse(function(o){if(o.isMesh&&o!==V.ring&&!keep.has(o))rm.push(o);});
 V.torso.position.set(0,J.tor[1],J.tor[2]);
 V.legs.forEach(function(p,i){var s=i?1:-1;p.position.set(s*J.hip[0],J.hip[1],J.hip[2]);if(V.knee&&V.knee[i])V.knee[i].position.set(0,J.knee[1]-J.hip[1],J.knee[2]-J.hip[2]);});
 V.arms.forEach(function(p,i){var s=i?1:-1;p.position.set(s*J.sh[0],J.sh[1]-J.tor[1],J.sh[2]-J.tor[2]);if(V.fore&&V.fore[i])V.fore[i].position.set(s*(J.el[0]-J.sh[0]),J.el[1]-J.sh[1],J.el[2]-J.sh[2]);});
 V.head.position.set(0,J.nk[1]-J.tor[1],J.nk[2]-J.tor[2]);
 V.head.scale.set(1,1,1);
 V.wp.position.set(J.hd[0]-J.el[0],J.hd[1]-J.el[1],J.hd[2]-J.el[2]+.04);
 var sm=new THREE.SkinnedMesh(G,mt);sm.castShadow=true;sm.frustumCulled=false;sm.userData.glb=1;V.g.add(sm);
 V.g.updateMatrixWorld(true);
 sm.bind(new THREE.Skeleton([V.body,V.torso,V.head,V.legs[0],V.knee[0],V.legs[1],V.knee[1],V.arms[0],V.fore[0],V.arms[1],V.fore[1]]));
 rm.forEach(function(o){if(o.parent)o.parent.remove(o);});
 var hc=new THREE.Object3D();hc.position.set(0,bm[0],bm[1]);hc.scale.setScalar(bm[2]);V.head.add(hc);V.head.children.unshift(V.head.children.pop());
 V.mats=[mt,V.ring.material];V.face=null;V.glb=sm;
 return true;}
