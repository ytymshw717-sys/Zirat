/* meshopt (EXT_meshopt_compression) decoder: vertex codec v0 + triangle index codec v0/v1
   usage: mdec vtx IN OUT count stride      |  mdec tri IN OUT count(indices) */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static unsigned char *readall(const char *p, size_t *n) {
  FILE *f = fopen(p, "rb"); if (!f) return 0;
  fseek(f, 0, SEEK_END); *n = ftell(f); fseek(f, 0, SEEK_SET);
  unsigned char *b = malloc(*n); if (fread(b, 1, *n, f) != *n) { fclose(f); return 0; } fclose(f); return b;
}
#define GS 16
static const unsigned char *bytesGroup(const unsigned char *data, unsigned char *buf, int bl) {
  int i, j;
  if (bl == 0) { memset(buf, 0, GS); return data; }
  if (bl == 3) { memcpy(buf, data, GS); return data + GS; }
  int bits = bl == 1 ? 2 : 4, per = 8 / bits, nb = GS / per;
  const unsigned char *dv = data + nb; int k = 0;
  for (i = 0; i < nb; i++) {
    unsigned char byte = data[i];
    for (j = 0; j < per; j++) {
      unsigned char enc = byte >> (8 - bits); byte <<= bits;
      if (enc == (1 << bits) - 1) buf[k++] = *dv++; else buf[k++] = enc;
    }
  }
  return dv;
}
static const unsigned char *decBytes(const unsigned char *data, unsigned char *buf, size_t sz) {
  size_t hs = (sz / GS + 3) / 4; const unsigned char *h = data; data += hs;
  for (size_t i = 0; i < sz; i += GS) { size_t ho = i / GS; int bl = (h[ho / 4] >> ((ho % 4) * 2)) & 3; data = bytesGroup(data, buf + i, bl); }
  return data;
}
static int vtx(const unsigned char *in, size_t n, unsigned char *out, size_t count, size_t stride) {
  if ((in[0] & 0xf0) != 0xa0) return -1;
  if ((in[0] & 0x0f) != 0) return -9;
  const unsigned char *data = in + 1, *end = in + n;
  unsigned char last[256]; memcpy(last, end - stride, stride);
  size_t bs = 8192 / stride; bs &= ~(size_t)(GS - 1); if (bs > 256) bs = 256;
  unsigned char buf[256], tr[8192 + 256];
  for (size_t vo = 0; vo < count; ) {
    size_t blk = vo + bs < count ? bs : count - vo, al = (blk + GS - 1) & ~(size_t)(GS - 1);
    for (size_t k = 0; k < stride; k++) {
      data = decBytes(data, buf, al);
      unsigned char p = last[k]; size_t o = k;
      for (size_t i = 0; i < blk; i++) { unsigned char e = buf[i]; unsigned char v = (unsigned char)(((unsigned char)(0 - (e & 1)) ^ (e >> 1)) + p); tr[o] = v; p = v; o += stride; }
    }
    memcpy(out + vo * stride, tr, blk * stride); memcpy(last, tr + stride * (blk - 1), stride); vo += blk;
  }
  size_t tail = stride < 32 ? 32 : stride;
  if ((size_t)(end - data) != tail) { fprintf(stderr, "tail mismatch %ld vs %ld\n", (long)(end - data), (long)tail); return -3; }
  return 0;
}
static unsigned vbyte(const unsigned char **d) {
  unsigned char lead = *(*d)++; if (lead < 128) return lead;
  unsigned r = lead & 127, sh = 7;
  for (int i = 0; i < 4; i++) { unsigned char g = *(*d)++; r |= (unsigned)(g & 127) << sh; sh += 7; if (g < 128) break; }
  return r;
}
static unsigned dindex(const unsigned char **d, unsigned last) { unsigned v = vbyte(d); unsigned dd = (v >> 1) ^ (unsigned)(-(int)(v & 1)); return last + dd; }
unsigned char PATH[4000000];
static int tri(const unsigned char *buf, size_t n, unsigned *dst, size_t ic) {
  if ((buf[0] & 0xf0) != 0xe0) return -1;
  int version = buf[0] & 15, fecmax = version >= 1 ? 13 : 15;
  unsigned ef[16][2], vf[16]; memset(ef, 0xff, sizeof ef); memset(vf, 0xff, sizeof vf);
  unsigned eo = 0, vo = 0, next = 0, last = 0;
  const unsigned char *code = buf + 1, *data = code + ic / 3, *aux = buf + n - 16;
#define PE(a_, b_) { ef[eo][0] = (a_); ef[eo][1] = (b_); eo = (eo + 1) & 15; }
#define PV(v_, c_) { vf[vo] = (v_); vo = (vo + (c_)) & 15; }
  for (size_t i = 0; i < ic; i += 3) {
    unsigned char ct = *code++; unsigned a, b, c;
    if (ct < 0xf0) {
      int fe = ct >> 4; a = ef[(eo - 1 - fe) & 15][0]; b = ef[(eo - 1 - fe) & 15][1];
      int fec = ct & 15;
      if (fec < fecmax) {
        unsigned cf = vf[(vo - 1 - fec) & 15]; c = fec == 0 ? next : cf; int f0 = fec == 0; next += f0;
        PATH[i/3]=1; dst[i] = a; dst[i + 1] = b; dst[i + 2] = c; PV(c, f0); PE(c, b); PE(a, c);
      } else {
        c = last = (fec != 15) ? last + (fec - (fec ^ 3)) : dindex(&data, last);
        PATH[i/3]=2; dst[i] = a; dst[i + 1] = b; dst[i + 2] = c; PV(c, 1); PE(c, b); PE(a, c);
      }
    } else if (ct < 0xfe) {
      unsigned char ca = aux[ct & 15]; int feb = ca >> 4, fec = ca & 15;
      a = next++;
      unsigned bf = vf[(vo - feb) & 15]; b = feb == 0 ? next : bf; int fb0 = feb == 0; next += fb0;
      unsigned cf = vf[(vo - fec) & 15]; c = fec == 0 ? next : cf; int fc0 = fec == 0; next += fc0;
      PATH[i/3]=3; dst[i] = a; dst[i + 1] = b; dst[i + 2] = c; PV(a, 1); PV(b, fb0); PV(c, fc0); PE(b, a); PE(c, b); PE(a, c);
    } else {
      unsigned char ca = *data++; int fea = ct == 0xfe ? 0 : 15, feb = ca >> 4, fec = ca & 15;
      if (ca == 0) next = 0;
      a = fea == 0 ? next++ : 0; b = feb == 0 ? next++ : 0; c = fec == 0 ? next++ : 0;
      if (fea == 15) last = a = dindex(&data, last);
      if (feb == 15) last = b = dindex(&data, last);
      if (fec == 15) last = c = dindex(&data, last);
      PATH[i/3]=4; dst[i] = a; dst[i + 1] = b; dst[i + 2] = c; PV(a, 1); PV(b, (feb == 0) | (feb == 15)); PV(c, (fec == 0) | (fec == 15)); PE(b, a); PE(c, b); PE(a, c);
    }
  }
  if (data != aux) { fprintf(stderr, "index data end mismatch %ld\n", (long)(aux - data)); return -3; }
  return 0;
}
int main(int argc, char **argv) {
  size_t n; unsigned char *in = readall(argv[2], &n); if (!in) return 2;
  size_t count = strtoul(argv[4], 0, 10); int r; FILE *o;
  if (!strcmp(argv[1], "vtx")) {
    size_t stride = strtoul(argv[5], 0, 10); unsigned char *out = calloc(count, stride);
    r = vtx(in, n, out, count, stride); if (r) { fprintf(stderr, "vtx err %d\n", r); return 1; }
    o = fopen(argv[3], "wb"); fwrite(out, stride, count, o); fclose(o);
  } else {
    unsigned *out = calloc(count, 4); r = tri(in, n, out, count); if (r) { fprintf(stderr, "tri err %d\n", r); return 1; }
    o = fopen(argv[3], "wb"); fwrite(out, 4, count, o); fclose(o); o = fopen("/tmp/claude-0/-home-claude/b0ae6ea6-7673-5629-85ca-afcd48e28043/scratchpad/path.bin", "wb"); fwrite(PATH, 1, count / 3, o); fclose(o);
  }
  return 0;
}
