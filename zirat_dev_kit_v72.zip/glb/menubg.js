/* main menu backdrop: painted dusk garden courtyard (sky, mountains, cherry tree, temple, lanterns, wooden deck) */
var MBG=null;
function menuBg(){if(MBG!=null)return MBG;try{
 var W=1280,H=720,c=document.createElement('canvas');c.width=W;c.height=H;var x=c.getContext('2d');
 var seed=7;function R(a,b){seed=(seed*16807)%2147483647;return a+(seed/2147483647)*(b-a);}
 function lg(x0,y0,x1,y1,st){var g=x.createLinearGradient(x0,y0,x1,y1);st.forEach(function(s){g.addColorStop(s[0],s[1]);});return g;}
 function rg(cx,cy,r0,r1,st){var g=x.createRadialGradient(cx,cy,r0,cx,cy,r1);st.forEach(function(s){g.addColorStop(s[0],s[1]);});return g;}
 function glow(cx,cy,r,col,a){x.fillStyle=rg(cx,cy,0,r,[[0,'rgba('+col+','+a+')'],[1,'rgba('+col+',0)']]);x.fillRect(cx-r,cy-r,2*r,2*r);}
 var HZ=H*.6;
 // sky
 x.fillStyle=lg(0,0,0,HZ,[[0,'#24357e'],[.35,'#4d63c4'],[.68,'#a98fd6'],[.86,'#f2b49a'],[1,'#ffd7a3']]);x.fillRect(0,0,W,HZ+40);
 glow(W*.46,HZ*.78,W*.42,'255,214,160',.55);glow(W*.46,HZ*.8,W*.16,'255,240,210',.6);
 // clouds
 function cloud(cx,cy,k,a){for(var i=0;i<9;i++){var ox=(i-4)*26*k+R(-8,8)*k,oy=-Math.sin(i/8*Math.PI)*16*k+R(-4,4)*k,rr=R(20,34)*k;
   x.fillStyle=rg(cx+ox,cy+oy-rr*.3,rr*.2,rr,[[0,'rgba(255,246,250,'+a+')'],[.7,'rgba(232,214,240,'+a*.85+')'],[1,'rgba(200,180,230,0)']]);x.beginPath();x.arc(cx+ox,cy+oy,rr,0,6.3);x.fill();}}
 cloud(W*.2,H*.12,1.3,.9);cloud(W*.55,H*.07,1,.8);cloud(W*.8,H*.17,1.1,.85);cloud(W*.38,H*.25,.8,.7);cloud(W*.95,H*.32,.7,.6);cloud(W*.05,H*.3,.8,.6);
 // far mountains (two misty layers)
 function ridge(y0,amp,col,fq,ph){x.fillStyle=col;x.beginPath();x.moveTo(0,HZ+30);for(var xx=0;xx<=W;xx+=8){var y=y0-amp*(.55+.45*Math.sin(xx*fq+ph))*(.6+.4*Math.sin(xx*fq*2.3+ph*1.7));x.lineTo(xx,y);}x.lineTo(W,HZ+30);x.closePath();x.fill();}
 ridge(HZ-40,90,'rgba(140,130,200,.75)',.006,1);ridge(HZ-10,70,'rgba(96,104,170,.85)',.009,3.4);
 // rocky spire
 function spire(cx,top,w){x.fillStyle=lg(cx-w,0,cx+w,0,[[0,'#7f93a8'],[.45,'#5b6f86'],[1,'#3b4a63']]);x.beginPath();x.moveTo(cx-w,HZ);
   x.lineTo(cx-w*.7,HZ-80);x.lineTo(cx-w*.55,top+90);x.lineTo(cx-w*.35,top+30);x.lineTo(cx-w*.15,top);x.lineTo(cx+w*.1,top+20);x.lineTo(cx+w*.3,top+70);x.lineTo(cx+w*.45,top+130);x.lineTo(cx+w*.7,HZ-60);x.lineTo(cx+w,HZ);x.closePath();x.fill();
   x.strokeStyle='rgba(30,40,60,.35)';x.lineWidth=2;for(var i=0;i<7;i++){x.beginPath();var sx=cx+R(-w*.4,w*.3),sy=R(top+30,HZ-40);x.moveTo(sx,sy);x.lineTo(sx+R(-12,12),sy+R(25,60));x.stroke();}
   for(i=0;i<4;i++){var gx=cx+R(-w*.35,w*.25),gy=R(top+60,HZ-60);x.fillStyle='rgba(52,96,74,.75)';x.beginPath();x.ellipse(gx,gy,R(8,14),R(4,7),0,0,6.3);x.fill();}
   x.fillStyle=lg(0,HZ-120,0,HZ,[[0,'rgba(200,190,240,0)'],[1,'rgba(220,200,240,.7)']]);x.fillRect(cx-w,HZ-120,2*w,120);}
 spire(W*.43,H*.2,92);spire(W*.53,H*.32,60);
 // lake + distant shore
 x.fillStyle=lg(0,HZ-14,0,HZ+30,[[0,'#9fb3e8'],[1,'#6f86c9']]);x.fillRect(0,HZ-12,W*.5,40);
 x.fillStyle='rgba(255,230,200,.5)';for(var i=0;i<14;i++)x.fillRect(R(20,W*.48),R(HZ-8,HZ+22),R(20,60),2);
 // mid hills with trees
 x.fillStyle='#4f7f5f';x.beginPath();x.moveTo(0,HZ+30);for(var xx=0;xx<=W;xx+=10)x.lineTo(xx,HZ+4-18*Math.sin(xx*.012+1)-10*Math.sin(xx*.031));x.lineTo(W,HZ+30);x.fill();
 for(i=0;i<46;i++){var tx=R(0,W),ty=HZ+R(-12,10),tr=R(8,18);x.fillStyle=['#2f6b4a','#3d7d55','#2a5e45'][i%3];x.beginPath();x.arc(tx,ty,tr,0,6.3);x.fill();x.fillStyle='rgba(180,230,160,.25)';x.beginPath();x.arc(tx-tr*.3,ty-tr*.35,tr*.45,0,6.3);x.fill();}
 // wooden deck (perspective planks)
 var vx=W*.5,vy=HZ-40,fy=H*.66;
 x.fillStyle=lg(0,fy,0,H,[[0,'#6b3a2c'],[.5,'#53291f'],[1,'#3a1c16']]);x.fillRect(0,fy,W,H-fy);
 for(var k=-26;k<=26;k++){var bx=vx+k*120,bx2=vx+(k+1)*120,t0=(fy-vy)/(H-vy);x.fillStyle=['rgba(120,62,44,.35)','rgba(70,34,24,.3)','rgba(140,76,52,.25)'][(k+30)%3];x.beginPath();x.moveTo(vx+(bx-vx)*t0,fy);x.lineTo(vx+(bx2-vx)*t0,fy);x.lineTo(bx2,H);x.lineTo(bx,H);x.closePath();x.fill();x.strokeStyle='rgba(20,8,6,.55)';x.lineWidth=2;x.beginPath();x.moveTo(vx+(bx-vx)*((fy-vy)/(H-vy)),fy);x.lineTo(bx,H);x.stroke();
  x.strokeStyle='rgba(255,190,140,.12)';x.lineWidth=1.5;x.beginPath();x.moveTo(vx+(bx+4-vx)*((fy-vy)/(H-vy)),fy);x.lineTo(bx+4,H);x.stroke();}
 for(k=0;k<9;k++){var yy=fy+Math.pow(k/9,1.7)*(H-fy);x.strokeStyle='rgba(20,8,6,.35)';x.lineWidth=1.5;x.beginPath();x.moveTo(0,yy);x.lineTo(W,yy);x.stroke();}
 x.fillStyle=rg(W*.5,H*.8,10,W*.42,[[0,'rgba(255,190,130,.35)'],[1,'rgba(255,190,130,0)']]);x.fillRect(0,fy,W,H-fy);
 x.fillStyle=lg(0,fy-4,0,fy+10,[[0,'#3a1d15'],[1,'rgba(58,29,21,0)']]);x.fillRect(0,fy-4,W,14);
 // temple (right)
 function temple(){var X0=W*.66,X1=W*1.02,base=fy-2;
  x.fillStyle='#6d6a73';x.fillRect(X0-20,base-26,X1-X0+40,26);x.fillStyle='rgba(0,0,0,.25)';for(var s=0;s<4;s++)x.fillRect(X0+90+s*-8,base-26+s*6.5,150+s*16,2);
  var wallT=base-210;x.fillStyle=lg(0,wallT,0,base-26,[[0,'#3b2420'],[1,'#2a1915']]);x.fillRect(X0,wallT,X1-X0,base-26-wallT);
  for(var p=0;p<6;p++){var px=X0+8+p*(X1-X0-16)/5;x.fillStyle=lg(px-9,0,px+9,0,[[0,'#7a2a1d'],[.5,'#a5402b'],[1,'#5e1f15']]);x.fillRect(px-9,wallT-6,18,base-26-wallT+6);}
  for(p=0;p<5;p++){var wx=X0+22+p*(X1-X0-16)/5,ww=(X1-X0-16)/5-28;if(p===1||p===2)continue;x.fillStyle=lg(0,wallT+40,0,base-40,[[0,'#ffcf7a'],[1,'#ff9a3c']]);x.fillRect(wx,wallT+46,ww,base-26-wallT-70);
   x.strokeStyle='rgba(60,25,10,.8)';x.lineWidth=2;for(var g2=1;g2<4;g2++){x.beginPath();x.moveTo(wx+ww*g2/4,wallT+46);x.lineTo(wx+ww*g2/4,base-50);x.stroke();}for(g2=1;g2<4;g2++){x.beginPath();x.moveTo(wx,wallT+46+(base-26-wallT-70)*g2/4);x.lineTo(wx+ww,wallT+46+(base-26-wallT-70)*g2/4);x.stroke();}
   glow(wx+ww/2,wallT+100,90,'255,170,80',.35);}
  // hanging banner with a simple star emblem
  var bx0=X0+(X1-X0)*.3,bw=(X1-X0)*.3,by0=wallT+30;x.fillStyle=lg(bx0,0,bx0+bw,0,[[0,'#1c2453'],[.5,'#283574'],[1,'#1a2250']]);x.fillRect(bx0,by0,bw,base-60-by0);
  x.strokeStyle='#c9a24a';x.lineWidth=3;x.strokeRect(bx0+6,by0+6,bw-12,base-72-by0);var ex=bx0+bw/2,ey=by0+(base-60-by0)*.45,er=bw*.28;x.beginPath();x.arc(ex,ey,er,0,6.3);x.stroke();
  x.fillStyle='#c9a24a';x.beginPath();for(var q=0;q<10;q++){var ang=-Math.PI/2+q*Math.PI/5,rr2=q%2?er*.38:er*.82;x.lineTo(ex+Math.cos(ang)*rr2,ey+Math.sin(ang)*rr2);}x.closePath();x.fill();
  // roofs
  function roof(y,x0,x1,h,ov){x.fillStyle=lg(0,y-h,0,y,[[0,'#2e3550'],[1,'#1b2035']]);x.beginPath();x.moveTo(x0-ov,y);x.quadraticCurveTo(x0-ov*.2,y-6,x0+20,y-h);x.lineTo(x1-20,y-h);x.quadraticCurveTo(x1+ov*.2,y-6,x1+ov,y);
   x.quadraticCurveTo(x1+ov*.6,y-14,x1+ov+14,y-26);x.lineTo(x1+ov,y+8);x.lineTo(x0-ov,y+8);x.lineTo(x0-ov-14,y-26);x.quadraticCurveTo(x0-ov*.6,y-14,x0-ov,y);x.closePath();x.fill();
   x.strokeStyle='rgba(120,140,190,.35)';x.lineWidth=2;for(var t=x0+10;t<x1;t+=16){x.beginPath();x.moveTo(t,y-h+4);x.lineTo(t+(t-(x0+x1)/2)*.08,y+4);x.stroke();}
   x.fillStyle='#4a2a1c';x.fillRect(x0-ov,y+4,x1-x0+2*ov,8);}
  roof(wallT,X0,X1,60,46);x.fillStyle='#2a1915';x.fillRect(X0+50,wallT-130,X1-X0-80,80);roof(wallT-120,X0+40,X1-30,48,36);
  // paper lanterns
  [[X0-6,wallT+26],[X0+(X1-X0)*.68,wallT+26],[X0+(X1-X0)*.95,wallT+26]].forEach(function(l){glow(l[0],l[1]+24,70,'255,170,70',.5);x.strokeStyle='#2a160f';x.lineWidth=2;x.beginPath();x.moveTo(l[0],l[1]);x.lineTo(l[0],l[1]+8);x.stroke();
   x.fillStyle=lg(l[0]-14,0,l[0]+14,0,[[0,'#e8642c'],[.5,'#ffd27a'],[1,'#e8642c']]);x.beginPath();x.ellipse(l[0],l[1]+26,14,19,0,0,6.3);x.fill();x.fillStyle='#2a160f';x.fillRect(l[0]-8,l[1]+6,16,4);x.fillRect(l[0]-8,l[1]+44,16,4);});}
 temple();
 // wooden railing
 function rail(x0,x1,y){x.fillStyle='#4a2a1f';x.fillRect(x0,y-46,x1-x0,9);x.fillRect(x0,y-20,x1-x0,7);for(var p=x0;p<=x1;p+=70){x.fillStyle=lg(p,0,p+14,0,[[0,'#6a3b29'],[1,'#3e2219']]);x.fillRect(p,y-58,14,58);x.fillStyle='#7a4630';x.fillRect(p-3,y-62,20,8);}}
 rail(W*.08,W*.36,fy+2);rail(W*.6,W*.68,fy+2);
 // stone lanterns
 function toro(cx,y,s){x.fillStyle='#8a8a90';x.fillRect(cx-16*s,y-14*s,32*s,14*s);x.fillRect(cx-6*s,y-60*s,12*s,46*s);x.fillStyle='#9b9ba3';x.fillRect(cx-20*s,y-68*s,40*s,9*s);
  x.fillStyle='#ffd27a';x.fillRect(cx-13*s,y-96*s,26*s,28*s);glow(cx,y-82*s,70*s,'255,180,80',.6);x.fillStyle='#7d7d85';x.fillRect(cx-15*s,y-96*s,4*s,28*s);x.fillRect(cx+11*s,y-96*s,4*s,28*s);
  x.fillStyle='#6f6f78';x.beginPath();x.moveTo(cx-30*s,y-94*s);x.lineTo(cx,y-118*s);x.lineTo(cx+30*s,y-94*s);x.closePath();x.fill();x.fillRect(cx-4*s,y-128*s,8*s,12*s);}
 toro(W*.27,fy+8,1);toro(W*.62,fy+6,.9);
 // cherry blossom tree (left)
 function blossom(){var tx=W*.1,ty=fy+10;x.strokeStyle='#4a2a22';x.lineCap='round';
  function br(x0,y0,a,l,w,d){if(d>6||w<1.4)return;var x1=x0+Math.cos(a)*l,y1=y0+Math.sin(a)*l;x.lineWidth=w;x.strokeStyle=d<2?'#3e231c':'#5a3328';x.beginPath();x.moveTo(x0,y0);x.quadraticCurveTo((x0+x1)/2+R(-12,12),(y0+y1)/2+R(-12,12),x1,y1);x.stroke();
   br(x1,y1,a-R(.25,.55),l*R(.62,.78),w*.66,d+1);br(x1,y1,a+R(.2,.5),l*R(.6,.76),w*.66,d+1);if(d>=3){pts.push([x1,y1]);}}
  var pts=[];br(tx,ty,-1.45,150,26,0);br(tx+10,ty-120,-.7,120,14,2);
  pts.forEach(function(p){for(var i=0;i<5;i++){var cx=p[0]+R(-30,30),cy=p[1]+R(-24,18),r=R(16,30);x.fillStyle=rg(cx-r*.3,cy-r*.3,r*.15,r,[[0,'#ffd1ea'],[.55,'#f59ad0'],[1,'rgba(214,92,170,.0)']]);x.beginPath();x.arc(cx,cy,r,0,6.3);x.fill();}});
  for(var i=0;i<140;i++){var p=pts[Math.floor(R(0,pts.length))];if(!p)continue;var cx=p[0]+R(-40,40),cy=p[1]+R(-34,24),r=R(6,13);x.fillStyle=['#ffc2e3','#f7a6d6','#ee86c4','#ffe0f0'][i%4];x.globalAlpha=.85;x.beginPath();x.arc(cx,cy,r,0,6.3);x.fill();}x.globalAlpha=1;}
 blossom();
 // foreground bushes + flowers at the deck edges
 function bush(cx,cy,s){for(var i=0;i<9;i++){var ox=R(-60,60)*s,oy=R(-26,10)*s,r=R(20,34)*s;x.fillStyle=rg(cx+ox-r*.3,cy+oy-r*.4,r*.1,r,[[0,'#7fcf6a'],[.6,'#3f8f45'],[1,'#21552c']]);x.beginPath();x.arc(cx+ox,cy+oy,r,0,6.3);x.fill();}
  for(i=0;i<10;i++){x.fillStyle=['#ffd1ea','#fff3a8','#ff9ac8'][i%3];x.beginPath();x.arc(cx+R(-60,60)*s,cy+R(-30,6)*s,R(3,5)*s,0,6.3);x.fill();}}
 bush(W*.02,H*.86,1.3);bush(W*.2,H*.9,.9);bush(W*.98,H*.84,1.4);bush(W*.8,H*.93,.8);
 // falling petals
 for(i=0;i<70;i++){var px2=R(0,W),py2=R(0,H*.95),pr=R(2.5,5.5);x.save();x.translate(px2,py2);x.rotate(R(0,6.3));x.fillStyle=['rgba(255,200,230,.9)','rgba(247,166,214,.85)','rgba(255,225,240,.8)'][i%3];x.beginPath();x.ellipse(0,0,pr,pr*.55,0,0,6.3);x.fill();x.restore();}
 // light shafts + vignette
 x.globalCompositeOperation='lighter';for(i=0;i<4;i++){x.fillStyle='rgba(255,220,170,.022)';x.beginPath();var sx=W*(.3+i*.08);x.moveTo(sx,0);x.lineTo(sx+60,0);x.lineTo(sx+260,H);x.lineTo(sx+120,H);x.closePath();x.fill();}x.globalCompositeOperation='source-over';
 x.fillStyle=rg(W/2,H*.55,H*.35,W*.72,[[0,'rgba(0,0,0,0)'],[1,'rgba(12,8,30,.55)']]);x.fillRect(0,0,W,H);
 MBG=c.toDataURL('image/jpeg',.88);}catch(e){MBG='';}return MBG;}
