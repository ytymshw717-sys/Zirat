import sys,json,numpy as np
sys.path.insert(0,'/home/claude/glb')
exec(open('project.py').read().split("PRM={n:fit")[0])
PRM=json.load(open('prm.json'))
NV=len(V);NF=len(F)
def pix(n,X):
    imn,uf,df,dr=VIEWS[n];sx,sy,cx,cy=PRM[n];return cx+sx*uf(X),cy-sy*X[...,1]
# --- visibility via painter's ID buffer at 1024
VIS={};
for n in VIEWS:
    imn,uf,df,dr=VIEWS[n];U,Y=pix(n,P);D=df(FC);order=np.argsort(D)
    im=Image.new('I',(1024,1024),-1);d=ImageDraw.Draw(im)
    for t in order:d.polygon([(U[t,0],Y[t,0]),(U[t,1],Y[t,1]),(U[t,2],Y[t,2])],fill=int(t))
    ib=np.array(im);cnt=np.bincount(ib[ib>=0].ravel(),minlength=NF)
    area=np.abs((U[:,1]-U[:,0])*(Y[:,2]-Y[:,0])-(U[:,2]-U[:,0])*(Y[:,1]-Y[:,0]))/2
    vis=np.where(area>0.5,np.clip(cnt/np.maximum(area,1e-6),0,1),0.)
    # small faces: visible if any pixel; also mark tiny ones visible if centroid pixel id equals
    cu=np.clip(U.mean(1).astype(int),0,1023);cyy=np.clip(Y.mean(1).astype(int),0,1023)
    vis=np.maximum(vis,(ib[cyy,cu]==np.arange(NF))*1.0)
    # alpha at centroid in image
    A=IMG[imn][...,3];al=A[cyy,cu]/255
    VIS[n]=(vis,al,np.maximum(0,FN@dr))
names=list(VIEWS)
FT=float(sys.argv[1]) if len(sys.argv)>1 else .3
score=np.stack([np.maximum(VIS[n][0],.05)*(VIS[n][1]>.5)*(VIS[n][2]>FT)*(VIS[n][2]+.02) for n in names],1)
# prefer front/back slightly over sides (better art)
score*=np.array([1.0,1.0,0.0,0.0])
best=score.argmax(1);bs=score.max(1)
seen=bs>0.02
print('seen',seen.mean(),'per view',[(names[i],int(((best==i)&seen).sum())) for i in range(4)])
# --- padded images (fill transparent with nearest opaque colour)
PAD={}
for k in['front','back','side','sideM']:
    A=IMG[k];m=ndimage.binary_dilation(A[...,3]<128,iterations=4);idx=ndimage.distance_transform_edt(m,return_distances=False,return_indices=True)
    PAD[k]=A[...,:3][idx[0],idx[1]]
# face colours for seen faces (centroid sample) and diffusion for unseen
col=np.zeros((NF,3))
for i,n in enumerate(names):
    sel=seen&(best==i);U,Y=pix(n,FC[sel]);col[sel]=PAD[VIEWS[n][0]][np.clip(Y.astype(int),0,1023),np.clip(U.astype(int),0,1023)]
# face adjacency via shared vertices
from scipy.sparse import coo_matrix
r=np.repeat(np.arange(NF),3);c=F.ravel();M=coo_matrix((np.ones(len(r)),(r,c)),shape=(NF,NV)).tocsr();Adj=(M@M.T).tocsr()
known=seen.copy();C=col.copy()
for it in range(200):
    if known.all():break
    s=Adj@(C*known[:,None]);w=Adj@known.astype(float);new=(~known)&(w>0)
    C[new]=s[new]/w[new,None];known=known|new
print('unseen filled',(~seen).sum())
np.savez('paint.npz',best=best,seen=seen,col=C)
