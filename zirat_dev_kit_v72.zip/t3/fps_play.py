import sys
from playwright.sync_api import sync_playwright
F=sys.argv[1]
with sync_playwright() as p:
    b=p.chromium.launch()
    c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True,device_scale_factor=2)
    c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3400)
    pg.evaluate("document.querySelector('#ov [data-a=play]').click()");pg.wait_for_timeout(2500)
    n=pg.evaluate("new Promise(r=>{var n=0,t0=performance.now();function f(){n++;if(performance.now()-t0<3000)requestAnimationFrame(f);else r(n/3)}requestAnimationFrame(f)})")
    print(F,'play fps %.1f'%n,pg.evaluate("G3.r3state()"))
