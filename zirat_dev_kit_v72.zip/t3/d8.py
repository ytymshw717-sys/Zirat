from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch()
    for vp in [(390,844),(375,667),(320,568)]:
        pg=b.new_page(viewport={'width':vp[0],'height':vp[1]},is_mobile=True,has_touch=True);pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3300)
        print(vp,pg.evaluate("""(function(){var r=function(s){var e=document.querySelector(s);if(!e)return null;var q=e.getBoundingClientRect();return [Math.round(q.left),Math.round(q.top),Math.round(q.right),Math.round(q.bottom)]};return {np:r('#ov [data-a=np]'),md:r('#mdSel'),play:r('#ov [data-a=play]')}})()"""))
        pg.screenshot(path='/home/claude/t3/d8_%dx%d.png'%vp)
    b.close()
