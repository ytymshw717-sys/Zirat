# capture every screen (landscape 844x390 @1.5x) for the "screens that need a redesign" sheet
import sys, os
from playwright.sync_api import sync_playwright
F = sys.argv[1] if len(sys.argv) > 1 else 'arena3_new.html'
OUT = sys.argv[2] if len(sys.argv) > 2 else '/home/claude/t3/sheet'
os.makedirs(OUT, exist_ok=True)
SCREENS = ['pick:0', 'heroes', 'hi:0', 'shop', 'skall', 'cat:rw', 'cat:hr', 'cat:md', 'maps', 'cfg', 'prof', 'online', 'tr', 'qs', 'pass']
with sync_playwright() as p:
    b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
    c = b.new_context(viewport={'width': 844, 'height': 390}, has_touch=True, is_mobile=True, device_scale_factor=1.5)
    c.add_init_script(path='/home/claude/t/mock.js')
    c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify({owned:[0,1,3,5],gold:500,dm:60}))}catch(e){}')
    pg = c.new_page(); E = []; pg.on('pageerror', lambda e: E.append(str(e)))
    pg.goto('file:///home/claude/' + F); pg.wait_for_timeout(4000)
    def act(a):
        pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;b.style.display='none';document.getElementById('ov').appendChild(b);b.click();})('%s')" % a); pg.wait_for_timeout(700)
    for s in SCREENS:
        act('menu'); act(s); pg.wait_for_timeout(1200)
        pg.screenshot(path='%s/%s.png' % (OUT, s.replace(':', '_')))
    act('menu'); act('play'); pg.wait_for_timeout(3500)
    pg.screenshot(path=OUT + '/game.png')
    pg.evaluate("document.getElementById('pz').click()"); pg.wait_for_timeout(800); pg.screenshot(path=OUT + '/pause.png')
    pg.evaluate("document.getElementById('pz').click()"); pg.wait_for_timeout(500)
    for k in range(40):
        st = pg.evaluate("(function(){var A=__arena();A.ps.forEach(function(p){if(p.hp>0){p.hp=0.01;p.inv=0;p.sh=0;}});A.enemies.forEach(function(e){if(A.ps[0]){e.x=A.ps[0].x+6;e.y=A.ps[0].y+6;}});return A.state;})()")
        if st == 'over': break
        pg.wait_for_timeout(300)
    print('over state', st); pg.wait_for_timeout(900); pg.screenshot(path=OUT + '/over.png')
    act('menu'); act('sm:show'); act('play'); pg.wait_for_timeout(2500)
    for k in range(20):
        st = pg.evaluate("(function(){var A=__arena();A.enemies.forEach(function(e){e.hp=0;});return A.state;})()")
        if st == 'over': break
        pg.wait_for_timeout(300)
    print('victory state', st); pg.wait_for_timeout(1500); pg.screenshot(path=OUT + '/victory.png')
    print('errors', E[:3])
