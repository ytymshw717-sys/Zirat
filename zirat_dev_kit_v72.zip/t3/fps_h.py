import sys
from playwright.sync_api import sync_playwright
F=sys.argv[1];H=sys.argv[2]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True,device_scale_factor=2)
    c.add_init_script(path='/home/claude/t/mock.js');c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify({owned:[0,1,3,5,7],gold:100}))}catch(e){}')
    pg=c.new_page();pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3500)
    def act(a):pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='%s';document.getElementById('ov').appendChild(b);b.click();})()"%a);pg.wait_for_timeout(80)
    act('pk:0:'+H);pg.wait_for_timeout(500);act('menu');act('mode:survive');pg.wait_for_timeout(2500)
    n=pg.evaluate("new Promise(r=>{var n=0,t0=performance.now();function f(){n++;if(performance.now()-t0<3000)requestAnimationFrame(f);else r(n/3)}requestAnimationFrame(f)})")
    print(F,'hero',H,'fps %.1f'%n, pg.evaluate("G3.r3state()"))
