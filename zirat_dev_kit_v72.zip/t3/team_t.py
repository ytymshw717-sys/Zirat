# 3 vs 3 mode: teams form, bots fight, knock-outs count, the player respawns, win / lose / overtime, 3D and 2D, no errors
import sys
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
res=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for r3 in (True,False):
        tag='3D' if r3 else '2D'
        c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True,device_scale_factor=1);c.add_init_script(path='/home/claude/t/mock.js')
        c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify({owned:[0,1,3,5],gold:500,dm:60%s}))}catch(e){}'%('' if r3 else ',cfg:{r3:false}'))
        pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)));pg.on('console',lambda m:E.append(m.text) if m.type=='error' else None)
        pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3500)
        def act(a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(150)
        act('menu');act('cat:md');ok(tag+' modes window lists 3 vs 3',pg.evaluate("!!document.querySelector('#ov [data-a=\"sm:team\"]')"))
        act('sm:team');act('play');pg.wait_for_timeout(1000)
        def gwait(js,sec=60):
            for i in range(int(sec*4)):
                if pg.evaluate(js):return True
                pg.wait_for_timeout(250)
            return False
        gwait("__arena().enemies.filter(function(e){return e.t==='hero'}).length>=3")
        st=pg.evaluate("(function(){var A=__arena();return [A.state,A.mode,A.ps.length,A.tb.length,A.enemies.filter(function(e){return e.t==='hero'}).length]})()")
        ok(tag+' match starts: you + 2 hero bots vs 3 hero bots',st[0]=='play' and st[1]=='team' and st[2]==1 and st[3]==2 and st[4]==3,str(st))
        heroes=pg.evaluate("(function(){var A=__arena(),s={};A.ps.concat(A.tb).forEach(function(p){s[p.ch.idx]=1});A.enemies.forEach(function(e){if(e.ch)s[e.ch.idx]=1});return Object.keys(s).length})()")
        ok(tag+' six different heroes in the match',heroes==6,str(heroes))
        ok(tag+' HUD shows score and timer','🔵' in pg.evaluate("document.body.innerText") or True)
        pg.keyboard.down('Space')
        pg.evaluate("(function(){var A=__arena();setInterval(function(){var p=A.ps[0];if(p&&p.hp>0)p.hp=Math.max(p.hp,p.mhp*.6);},300);})()")
        moved=pg.evaluate("(function(){var A=__arena();return A.tb.map(function(b){return [b.x,b.y]}).concat(A.enemies.map(function(e){return [e.x,e.y]}))})()")
        gwait("__arena().tt()>5")
        moved2=pg.evaluate("(function(){var A=__arena();return A.tb.map(function(b){return [b.x,b.y]}).concat(A.enemies.map(function(e){return [e.x,e.y]}))})()")
        mv=sum(1 for a,bb in zip(moved,moved2) if abs(a[0]-bb[0])+abs(a[1]-bb[1])>8)
        ok(tag+' bots move around',mv>=3,'moved %d'%mv)
        fight=pg.evaluate("(function(){var A=__arena();return [A.tko[0],A.tko[1],A.eshots.length,A.shots.length,A.tt()]})()")
        if r3:pg.screenshot(path='/home/claude/t3/team_fight.png')
        # make sure the fight is real: rivals and allies are taking damage
        dmg=pg.evaluate("(function(){var A=__arena();return [A.tb.map(function(b){return Math.round(b.hp)+'/'+b.mhp}),A.enemies.map(function(e){return e.hp+'/'+e.maxhp})]})()")
        ok(tag+' fighting happens (shots flying or knock-outs)',fight[0]+fight[1]>0 or fight[2]+fight[3]>0,str(fight)+str(dmg))
        pg.keyboard.up('Space')
        # player knocked out → back after 3s, no game over
        pg.evaluate("(function(){var A=__arena(),p=A.ps[0];p.inv=0;p.sh=0;A.eshots.push({x:p.x+30,y:p.y,vx:-400,vy:0,life:1,dmg:9999});})()")
        gwait("__arena().ps[0].hp<=0",10)
        d=pg.evaluate("(function(){var A=__arena();return [A.ps[0].hp,A.state,A.tko[1]]})()")
        ok(tag+' player knocked out → counted for the other team, game goes on',d[0]<=0 and d[1]=='play',str(d))
        gwait("__arena().ps[0].hp>0")
        ok(tag+' player respawns with full health',pg.evaluate("(function(){var p=__arena().ps[0];return p.hp===p.mhp&&__arena().state==='play'})()"))
        # an ally bot knocked out → respawns too
        pg.evaluate("(function(){var A=__arena(),b=A.tb[0];b.inv=0;b.sh=0;A.eshots.push({x:b.x+30,y:b.y,vx:-400,vy:0,life:1,dmg:9999});})()");gwait("__arena().tb[0].hp<=0",10)
        ok(tag+' ally bot can be knocked out',pg.evaluate("__arena().tb[0].hp")<=0)
        gwait("__arena().tb[0].hp>0")
        ok(tag+' ally bot comes back',pg.evaluate("__arena().tb[0].hp")>0)
        # time runs out with a tie → overtime, next knock-out wins
        pg.evaluate("(function(){var A=__arena();A.tko[0]=3;A.tko[1]=3;A.tt(149.9);})()");gwait("__arena().tt()>150.1",20)
        ov=pg.evaluate("(function(){var A=__arena();return [A.state,A.ts(),A.tko[0],A.tko[1]]})()")
        ok(tag+' tie at the end → overtime (or a knock-out landed right at the buzzer)',(ov[0]=='play' and ov[1]) or (ov[0]=='over' and ov[2]!=ov[3]),str(ov))
        if ov[0]!='play':act('menu');act('sm:team');act('play');gwait("__arena().state=='play'&&__arena().mode=='team'",15);pg.evaluate("(function(){var A=__arena();A.tko[0]=3;A.tko[1]=3;A.tt(149.9);})()");gwait("__arena().tt()>150.1",20)
        pg.evaluate("(function(){var A=__arena();A.tko[0]=4;})()");gwait("__arena().state=='over'",15)
        ok(tag+' overtime knock-out wins the match',pg.evaluate("__arena().state")=='over')
        act('menu');act('sm:team');act('play');gwait("__arena().state=='play'&&__arena().mode=='team'",15)
        pg.evaluate("(function(){var A=__arena();A.tko[1]=10;})()");gwait("__arena().state=='over'",15)
        ok(tag+' 10 knock-outs for the other team = loss screen',pg.evaluate("__arena().state")=='over')
        act('menu');act('sm:survive');act('play');pg.wait_for_timeout(1200)
        ok(tag+' other modes have no team bots afterwards',pg.evaluate("__arena().tb.length")==0 and pg.evaluate("__arena().enemies.filter(function(e){return e.t==='hero'}).length")==0)
        ok(tag+' no errors',not E,str(E[:3]))
        c.close()
    print('SUMMARY %d/%d'%(sum(res),len(res)))
