import sys
from playwright.sync_api import sync_playwright
modes=sys.argv[1].split(',') if len(sys.argv)>1 else ['survive']
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True,device_scale_factor=2)
    c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append('con:'+m.text) if m.type=='error' else None)
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3500)
    def act(a):pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='%s';document.getElementById('ov').appendChild(b);b.click();})()"%a);pg.wait_for_timeout(60)
    for m in modes:
        act('mode:'+m);pg.wait_for_timeout(2500)
        pg.keyboard.down('KeyD');pg.keyboard.down('Space');pg.wait_for_timeout(1500);pg.keyboard.up('KeyD');pg.keyboard.up('Space')
        print(m,pg.evaluate("G3.r3state()"),pg.evaluate("__arena().state"))
        pg.screenshot(path='/home/claude/t3/r3_%s.png'%m)
        pg.keyboard.press('KeyP');pg.wait_for_timeout(100);act('menu')
    print('ERR',errs[:5])
