import sys
from playwright.sync_api import sync_playwright
from PIL import Image
idx=int(sys.argv[1]) if len(sys.argv)>1 else 7;out=sys.argv[2] if len(sys.argv)>2 else 'cmp'
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    pg=b.new_page(viewport={'width':520,'height':520});E=[];pg.on('pageerror',lambda e:E.append(str(e)))
    pg.add_init_script(path='/home/claude/t/mock.js');pg.goto('file:///home/claude/arena3_gfx.html');pg.wait_for_timeout(3500)
    u=pg.evaluate("G3.portrait(%d,0,320)"%idx)
    pg.evaluate("(function(u){document.body.innerHTML='<div style=\"width:512px;height:512px;background:radial-gradient(circle at 50% 40%,#4b8cf0,#2b63d9)\"><img src=\"'+u+'\" width=512 height=512></div>'})",u)
    pg.wait_for_timeout(300);pg.screenshot(path='/home/claude/t3/%s_ours.png'%out,clip={'x':0,'y':0,'width':512,'height':512})
    print('errors',E[:2])
ref=Image.open('/mnt/user-data/attachments/b0ae6ea6-7673-5629-85ca-afcd48e28043/27cd0fc3-image.png').convert('RGB').crop((0,495,924,1505)).resize((512,560))
ours=Image.open('/home/claude/t3/%s_ours.png'%out).convert('RGB').resize((512,512))
sh=Image.new('RGB',(1040,560),(20,20,30));sh.paste(ref,(0,0));sh.paste(ours,(528,24));sh.save('/home/claude/t3/%s.png'%out)
