import sys,json
from playwright.sync_api import sync_playwright
F='file:///home/claude/'+(sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html')
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True,device_scale_factor=3)
    c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page()
    t0=pg.evaluate("performance.now()")
    pg.goto(F);pg.wait_for_function("document.querySelector('#ov [data-a=play]')",timeout=30000)
    print('menu ready after load ms',round(pg.evaluate("performance.now()")))
    pg.wait_for_timeout(1000)
    def t(a):
        return pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='%s';document.getElementById('ov').appendChild(b);var t=performance.now();b.click();return Math.round(performance.now()-t)})()"%a)
    rows=[]
    for a in ['menu','shop','menu','cat:hr','cg:hr:heroes','menu','cg:hr:skall','menu','menu','hi:3','hi:4','menu','maps','menu','cat:md','menu','cat:rw','cg:rw:pass','menu','cg:rw:tr','menu','cg:rw:qs','menu','menu','prof','menu','cfg','q:2','menu','pick:0','menu','skins:0','menu','shop','cg:shop:online','menu','menu']:
        rows.append((a,t(a)))
    print('click->window ms (first pass):',rows)
    rows2=[(a,t(a)) for a in ['cat:hr','cg:hr:heroes','menu','cg:hr:skall','menu','menu','maps','menu']]
    print('second pass (cached):',rows2)
    # gameplay frame times 2D
    t('play');pg.wait_for_timeout(1500)
    pg.evaluate("window.__ft=[];(function f(t){window.__ft.push(t);if(window.__ft.length<240)requestAnimationFrame(f);})(performance.now())")
    pg.keyboard.down('KeyD');pg.wait_for_timeout(2500);pg.keyboard.up('KeyD');pg.keyboard.down('Space');pg.wait_for_timeout(1500);pg.keyboard.up('Space')
    ft=pg.evaluate("(function(){var a=window.__ft,d=[];for(var i=1;i<a.length;i++)d.push(a[i]-a[i-1]);d.sort(function(x,y){return x-y});return [d.length,Math.round(d[Math.floor(d.length/2)]),Math.round(d[Math.floor(d.length*.95)]),Math.round(d[d.length-1])]})()")
    print('2D game frames [n, median, p95, max] ms',ft)
    b.close()
