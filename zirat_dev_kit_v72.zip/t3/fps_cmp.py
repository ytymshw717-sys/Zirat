import sys
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for f in sys.argv[1:]:
        r=[]
        for rep in range(2):
            c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True,device_scale_factor=2)
            c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();pg.goto('file:///home/claude/'+f);pg.wait_for_timeout(5000)
            pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='mode:survive';document.getElementById('ov').appendChild(b);b.click();})()");pg.wait_for_timeout(3000)
            pg.evaluate("window.__ft=[];(function q(t){window.__ft.push(t);if(window.__ft.length<120)requestAnimationFrame(q);})(performance.now())")
            pg.keyboard.down('KeyD');pg.wait_for_timeout(6000);pg.keyboard.up('KeyD')
            r.append(pg.evaluate("(function(){var a=window.__ft,d=[];for(var i=1;i<a.length;i++)d.push(a[i]-a[i-1]);d.sort(function(x,y){return x-y});return [d.length,Math.round(d[Math.floor(d.length/2)])]})()"))
            c.close()
        print(f,r,flush=True)
