from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for (pw,ph),(lw,lh) in [((390,844),(844,390)),((390,700),(700,340)),((375,600),(600,300))]:
        c=b.new_context(viewport={'width':pw,'height':ph},is_mobile=True,has_touch=True,device_scale_factor=2);c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
        pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3500)
        out=[]
        for scr in ['menu','game']:
            if scr=='game':pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('mode:survive')");pg.wait_for_timeout(1500)
            pg.evaluate("window.scrollTo(0,40)")
            pg.set_viewport_size({'width':lw,'height':lh});pg.evaluate("window.dispatchEvent(new Event('orientationchange'))");pg.wait_for_timeout(1800)
            m=pg.evaluate("(function(){var cv=document.getElementById('cv').getBoundingClientRect(),st=document.getElementById('stage').getBoundingClientRect();return {scrollY:scrollY,bodyH:document.body.getBoundingClientRect().height|0,innerH:innerHeight,docW:document.documentElement.scrollWidth,cv:[cv.left|0,cv.top|0,cv.right|0,cv.bottom|0],fits:cv.bottom<=innerHeight+1&&cv.right<=innerWidth+1&&cv.left>=-1}})()")
            out.append((scr,m));pg.screenshot(path='/home/claude/t3/rot/R3_%dx%d_%s.png'%(lw,lh,scr))
            pg.set_viewport_size({'width':pw,'height':ph});pg.evaluate("window.dispatchEvent(new Event('orientationchange'))");pg.wait_for_timeout(1500)
            back=pg.evaluate("(function(){var cv=document.getElementById('cv').getBoundingClientRect();return {bodyH:document.body.getBoundingClientRect().height|0,innerH:innerHeight,fits:cv.right<=innerWidth+1}})()")
            out.append((scr+'-back',back))
        print('%dx%d'%(lw,lh),out,'errors',E[:2],flush=True);c.close()
