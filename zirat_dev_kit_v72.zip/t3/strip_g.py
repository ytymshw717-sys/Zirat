import sys,time
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':1280,'height':720});c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page()
    pg.goto('file:///home/claude/'+sys.argv[1]);pg.wait_for_timeout(5000)
    pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='hi:12';document.getElementById('ov').appendChild(b);b.click();})()")
    t0=time.time()
    for i in range(30):
        pg.wait_for_timeout(500)
        n=pg.evaluate("(function(){var a=document.querySelectorAll('#ov .hvH img'),k=0;for(var i=0;i<a.length;i++)if(a[i].src.indexOf('data:image/png')==0)k++;return [k,a.length]})()")
        if n[0]>=n[1]:break
    print(sys.argv[1],'loaded',n,'in %.1fs'%(time.time()-t0))
    pg.screenshot(path='/home/claude/t3/strip.png')
