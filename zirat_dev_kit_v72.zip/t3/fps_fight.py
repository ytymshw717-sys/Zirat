# fps while fighting: hero keeps shooting, enemies alive and close; compare builds
import sys
from playwright.sync_api import sync_playwright
FILES=sys.argv[1].split(',');HERO=int(sys.argv[2]) if len(sys.argv)>2 else 9;MAP=int(sys.argv[3]) if len(sys.argv)>3 else 0;REP=int(sys.argv[4]) if len(sys.argv)>4 else 2
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for r in range(REP):
        for F in FILES:
            c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True,device_scale_factor=2)
            c.add_init_script(path='/home/claude/t/mock.js')
            c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify({owned:[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19],gold:500,dm:60,g9:1}))}catch(e){}')
            pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)));pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3500)
            def act(a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(250)
            act('menu');act('pk:0:%d'%HERO);act('menu');act('mp:%d'%MAP);act('menu');act('mode:survive');pg.wait_for_timeout(2500)
            pg.evaluate("(function(){var A=__arena();A.ps[0].hp=1e6;A.ps[0].mh=1e6;})()")
            pg.keyboard.down('Space')
            pg.evaluate("(function(){var A=__arena();setInterval(function(){var p=A.ps[0];if(p){p.hp=1e6;p.cd=0;}A.enemies.forEach(function(e,j){if(Math.hypot(e.x-p.x,e.y-p.y)>220){e.x=p.x+90+((j*37)%120);e.y=p.y-60+((j*53)%120);}e.hp=Math.max(e.hp,5);});},120);})()")
            pg.wait_for_timeout(1500)
            fps=pg.evaluate("new Promise(r=>{var n=0,t0=performance.now(),mx=0,l=t0;function f(){var t=performance.now();mx=Math.max(mx,t-l);l=t;n++;if(t-t0<5000)requestAnimationFrame(f);else r([n/5,mx])}requestAnimationFrame(f)})")
            st=pg.evaluate("G3.r3state()")
            pg.keyboard.up('Space')
            print(F,'hero',HERO,'map',MAP,'fps %.1f worst frame %.0fms'%(fps[0],fps[1]),'shots',pg.evaluate("__arena().shots.length"),'calls',st.get('calls'),'low',st.get('low'),'errors',E[:2],flush=True)
            c.close()
