import sys,math,json
from playwright.sync_api import sync_playwright
F='file:///home/claude/t3/dbg.html'
THREE=open('/home/claude/mrdoob/three.js/build/three.min.js','rb').read()
res=[];errs=[]
def ok(n,c,info=''):
    res.append((n,bool(c)));print(('PASS ' if c else 'FAIL ')+n,info,flush=True)
def route(r):r.fulfill(status=200,body=THREE,headers={'content-type':'application/javascript'})
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--ignore-gpu-blocklist'])
    for vp,mob in [((390,844),True)]:
        tag='%dx%d'%vp
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=mob,is_mobile=mob,device_scale_factor=2 if mob else 1)
        c.add_init_script(path='/home/claude/t/mock.js')
        c.route('**/three.min.js',route)
        pg=c.new_page();pg.on('pageerror',lambda e:errs.append(tag+':'+str(e)));pg.on('console',lambda m:errs.append(tag+' console:'+m.text) if m.type=='error' else None)
        pg.goto(F);pg.wait_for_timeout(3300)
        ok(tag+' 3D mode in modes list',pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='cat:md';document.getElementById('ov').appendChild(b);b.click();return !!document.querySelector('[data-a=\"sm:3d\"]')})()"))
        g0=pg.evaluate("A3.sv.gold");t0=pg.evaluate("(A3.sv.tr[A3.sel()]||0)")
        pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='sm:3d';document.getElementById('ov').appendChild(b);b.click();})()");pg.wait_for_timeout(200)
        pg.evaluate("document.querySelector('#ov [data-a=play]').click()")
        pg.wait_for_function("window.__g3&&__g3.st()",timeout=20000);pg.wait_for_timeout(800)
        s=pg.evaluate("__g3.st()");ok(tag+' 3D booted, scene draws',s['calls']>=5,'calls=%d tris=%d fps=%s'%(s['calls'],s['tris'],s['fps']))
        ok(tag+' 2D state paused while in 3D',pg.evaluate("__arena().state")=='g3')
        pg.screenshot(path='/home/claude/t3/%s_start.png'%tag)
        # canvas non-blank via readPixels of screenshot variety
        pg.evaluate("__g3.freeze()")
        def st():return pg.evaluate("__g3.st()")
        def place(px,pz,ex,ez,face=None):
            pg.evaluate("__g3.set('p',{x:%f,z:%f,vx:0,vz:0,kbx:0,kbz:0,cool:0,phase:'idle',stag:0,inv:0,dashT:0});__g3.set('e',{x:%f,z:%f,vx:0,vz:0,kbx:0,kbz:0,cool:0,phase:'idle',stag:0,inv:0,dashT:0})"%(px,pz,ex,ez))
            if face is not None:pg.evaluate("__g3.set('p',{face:%f})"%face)
        # movement each direction (keyboard)
        for k,ex in [('KeyD',(1,0)),('KeyA',(-1,0)),('KeyS',(0,1)),('KeyW',(0,-1)),('ArrowRight',(1,0))]:
            pg.evaluate("__g3.manual()");place(-2,3,9,-9);a=st()['p'];pg.keyboard.down(k);pg.evaluate("__g3.step(24,1/60)");pg.keyboard.up(k);pg.evaluate("__g3.step(15,1/60)");bb=st()['p'];pg.evaluate("__g3.manual(false)")
            d=(bb['x']-a['x'],bb['z']-a['z']);l=math.hypot(*d) or 1
            want=math.atan2(ex[0],ex[1]);fd=abs((bb['face']-want+math.pi)%(2*math.pi)-math.pi)
            ok(tag+' move '+k,l>.8 and (d[0]*ex[0]+d[1]*ex[1])/l>.9,'d=(%.2f,%.2f)'%d)
            ok(tag+' body faces move dir '+k,fd<.2,'face err=%.2f'%fd)
        # smooth rotation: turn rate limited (not instant)
        place(-2,3,9,-9,0.0);pg.evaluate("__g3.manual()");pg.evaluate("__g3.move([0,-1])");pg.evaluate("__g3.step(1,1/60)")
        f1=st()['p']['face'];pg.evaluate("__g3.step(20,1/60)");f2=st()['p']['face'];pg.evaluate("__g3.move(null);__g3.manual(false)")
        ok(tag+' rotation smooth (gradual 180° turn)',0.05<abs(f1)<0.5 and abs(abs(f2)-math.pi)<.15,'1 frame=%.2f, 20 frames=%.2f'%(f1,f2))
        # diagonal & collision with wall
        pg.evaluate("__g3.manual()");place(10.5,10.5,-9,-9);pg.keyboard.down('KeyD');pg.keyboard.down('KeyS');pg.evaluate("__g3.step(40,1/60)");pg.keyboard.up('KeyD');pg.keyboard.up('KeyS')
        q=st()['p'];ok(tag+' stays inside arena walls',abs(q['x'])<=11 and abs(q['z'])<=11,'(%.2f,%.2f)'%(q['x'],q['z']))
        place(0,3,9,-9);pg.keyboard.down('KeyW');pg.evaluate("__g3.step(60,1/60)");pg.keyboard.up('KeyW');pg.evaluate("__g3.manual(false)")
        q=st()['p'];ok(tag+' blocked by central pillar',math.hypot(q['x'],q['z'])>=1.15+.6-.02,'dist=%.2f'%math.hypot(q['x'],q['z']))
        # combat: miss when out of range
        pg.evaluate("__g3.manual()")
        rng=st()['p']['rng'];ranged=st()['p']['ranged']
        place(-4,-8,(-4+rng+3),-8,math.pi/2);h0=st()['e']['hp']
        pg.evaluate("__g3.attack('p')");pg.evaluate("__g3.step(120,1/60)")
        ok(tag+' no damage when target out of range',st()['e']['hp']==h0,'hp %d->%d ranged=%s'%(h0,st()['e']['hp'],ranged))
        # miss when facing away
        place(-4,-8,-4+1.2,-8,-math.pi/2);pg.evaluate("__g3.set('p',{cool:0})");h0=st()['e']['hp']
        pg.evaluate("__g3.attack('p')");pg.evaluate("__g3.step(4,1/60)");pg.evaluate("__g3.set('p',{face:-Math.PI/2})");pg.evaluate("__g3.step(120,1/60)")
        ok(tag+' no damage when facing away',st()['e']['hp']==h0,'hp %d->%d'%(h0,st()['e']['hp']))
        # hit when in range and facing; exactly one hit per attack
        place(-4,-8,-4+1.3,-8,math.pi/2);h0=st()['e']['hp'];hits0=st()['hits']
        pg.evaluate("__g3.attack('p')");pg.evaluate("__g3.step(5,1/60)");mid=st()['e']['hp']
        pg.evaluate("__g3.step(120,1/60)");s2=st()
        ok(tag+' no damage during windup',mid==h0)
        ok(tag+' valid hit deals damage once',s2['e']['hp']<h0 and s2['hits']-hits0==1,'hp %d->%d hits+%d'%(h0,s2['e']['hp'],s2['hits']-hits0))
        ok(tag+' enemy knocked back',s2['e']['x']>-4+1.3+.1,'x=%.2f'%s2['e']['x'])
        # cooldown prevents spam
        place(-4,-8,-4+1.3,-8,math.pi/2);pg.evaluate("__g3.attack('p')");pg.evaluate("__g3.step(30,1/60)");r2=pg.evaluate("__g3.attack('p')")
        ok(tag+' cooldown blocks immediate re-attack',r2==False)
        pg.evaluate("__g3.manual(false)")
        # touch controls (mobile)
        if mob:
            cdp=c.new_cdp_session(pg)
            def tp(t,pts):cdp.send('Input.dispatchTouchEvent',{'type':t,'touchPoints':pts})
            r=pg.evaluate("(function(){var r=document.querySelector('#g3 .js3').getBoundingClientRect();return [r.left+r.width/2,r.top+r.height/2]})()")
            place(-2,3,9,-9);a=st()['p']
            tp('touchStart',[{'x':r[0],'y':r[1],'id':1}])
            for i in range(1,6):tp('touchMove',[{'x':r[0]+i*12,'y':r[1],'id':1}]);pg.wait_for_timeout(30)
            pg.wait_for_timeout(350);tp('touchEnd',[]);bb=st()['p']
            ok(tag+' joystick moves right',bb['x']-a['x']>.8,'dx=%.2f'%(bb['x']-a['x']))
            ab=pg.evaluate("(function(){var r=document.querySelector('#g3 .atk3').getBoundingClientRect();return [r.left+r.width/2,r.top+r.height/2,r.width]})()")
            ok(tag+' attack button big',ab[2]>=96,str(ab[2]))
            # multi-touch: joystick + attack simultaneously
            place(-4,-8,-4+1.3,-8,math.pi/2);h0=st()['e']['hp']
            pg.evaluate("__g3.manual()");tp('touchStart',[{'x':ab[0],'y':ab[1],'id':2}]);pg.wait_for_timeout(60);tp('touchEnd',[])
            pg.evaluate("__g3.step(40,1/60);__g3.manual(false)");ok(tag+' tap attack button hits',st()['e']['hp']<h0,'%d->%d'%(h0,st()['e']['hp']))
            # hold attack → repeated attacks
            place(-4,-8,-4+1.3,-8,math.pi/2);hits0=st()['hits']
            pg.evaluate("__g3.manual()");tp('touchStart',[{'x':ab[0],'y':ab[1],'id':3}]);pg.wait_for_timeout(50)
            for i in range(8):pg.evaluate("__g3.set('e',{x:-2.7,z:-8,kbx:0,kbz:0});__g3.step(30,1/60)")
            tp('touchEnd',[]);pg.wait_for_timeout(80);ok(tag+' attack button released after touch end',st()['hold']==False);pg.evaluate("__g3.manual(false)");ok(tag+' hold attack repeats',st()['hits']-hits0>=2,'hits+%d'%(st()['hits']-hits0))
            ok(tag+' page did not scroll',pg.evaluate("scrollX===0&&scrollY===0&&document.scrollingElement.scrollTop===0"))
        else:
            place(-4,-8,-4+1.3,-8,math.pi/2);h0=st()['e']['hp']
            pg.evaluate("__g3.manual()");pg.keyboard.down('Space');pg.evaluate("__g3.step(3,1/60)");pg.keyboard.up('Space');pg.evaluate("__g3.step(40,1/60)");ok(tag+' Space attack hits',st()['e']['hp']<h0);pg.evaluate("__g3.manual(false)")
            # dash
            pg.evaluate("__g3.manual()");place(0,6,9,-9,math.pi/2);pg.keyboard.press('ShiftLeft');pg.evaluate("__g3.step(20,1/60)");pg.evaluate("__g3.manual(false)");ok(tag+' Shift dash moves',st()['p']['x']>1.2,'x=%.2f'%st()['p']['x'])
            # pause
            pg.keyboard.press('Escape');pg.wait_for_timeout(200);ok(tag+' Esc pauses',st()['paused'])
            pg.click('#g3 [data-g3=res]');pg.wait_for_timeout(200);ok(tag+' resume',not st()['paused'])
        # AI fights back (unfreeze) and player can lose
        print('LOGPRE',len(pg.evaluate('__g3.dbg2()') or []))
        pg.evaluate("__g3.freeze(false);__g3.set('p',{hp:12});__g3.set('e',{hp:__g3.st().e.mhp});__g3.manual();__g3.step(90,1/60)");place(0,4,0,2.5)
        for i in range(40):
            pg.evaluate("__g3.step(30,1/60)")
            if st()['over']:break
        pg.evaluate("__g3.manual(false)");pg.wait_for_timeout(200)
        print('LOG',pg.evaluate('__g3.dbg2()')[-12:])
        s=st();ok(tag+' AI attacks → player loses',s['over'] and s['win']==False and s['p']['dead'])
        txt=pg.inner_text('#g3 .msg3');ok(tag+' lose screen',('הפסד' in txt),txt[:30])
        pg.screenshot(path='/home/claude/t3/%s_lose.png'%tag)
        # again → win
        pg.click('#g3 [data-g3=again]');pg.wait_for_function("window.__g3&&__g3.st()&&!__g3.st().over",timeout=20000);pg.wait_for_timeout(300)
        pg.evaluate("__g3.freeze();__g3.set('e',{hp:5})");place(-4,-8,-4+1.3,-8,math.pi/2);pg.evaluate("__g3.manual();__g3.attack('p');__g3.step(140,1/60);__g3.manual(false)");pg.wait_for_timeout(200);s=st()
        ok(tag+' win when enemy HP 0',s['win']==True and s['e']['dead'])
        pg.screenshot(path='/home/claude/t3/%s_win.png'%tag)
        g1=pg.evaluate("A3.sv.gold");t1=pg.evaluate("(A3.sv.tr[A3.sel()]||0)")
        ok(tag+' rewards saved (coins+trophies)',g1>g0 and t1>t0,'gold %d->%d tr %d->%d'%(g0,g1,t0,t1))
        saved=pg.evaluate("JSON.parse(localStorage.getItem('heroes_arena_save')).gold");ok(tag+' persisted to save',saved==g1)
        pg.click('#g3 [data-g3=exit]');pg.wait_for_timeout(400)
        ok(tag+' exit back to menu, 3D cleaned',pg.evaluate("!document.getElementById('g3')&&!window.__g3&&__arena().state==='menu'&&!!document.querySelector('#ov [data-a=play]')"))
        # old game still works after 3D
        pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='sm:survive';document.getElementById('ov').appendChild(b);b.click();})()");pg.wait_for_timeout(150);pg.evaluate("document.querySelector('#ov [data-a=play]').click()");pg.wait_for_timeout(1500)
        x0=pg.evaluate("__arena().ps[0].x");pg.keyboard.down('KeyD');pg.wait_for_timeout(400);pg.keyboard.up('KeyD')
        ok(tag+' 2D game still plays after 3D',pg.evaluate("__arena().state")=='play' and pg.evaluate("__arena().ps[0].x")>x0+20)
        # re-enter 3D many times (leaks)
        pg.keyboard.press('KeyP');pg.wait_for_timeout(100);pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='menu';document.getElementById('ov').appendChild(b);b.click();})()");pg.wait_for_timeout(200)
        for i in range(4):
            pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='sm:3d';document.getElementById('ov').appendChild(b);b.click();})()");pg.evaluate("document.querySelector('#ov [data-a=play]').click()")
            pg.wait_for_function("window.__g3&&__g3.st()",timeout=20000);pg.wait_for_timeout(200);pg.evaluate("G3.exit()");pg.wait_for_timeout(200)
        ok(tag+' 4x enter/exit, no leftover canvases',pg.evaluate("document.querySelectorAll('canvas').length")==1,str(pg.evaluate("document.querySelectorAll('canvas').length")))
        c.close()
    # failure path: CDN blocked
    c=b.new_context(viewport={'width':844,'height':390});c.add_init_script(path='/home/claude/t/mock.js')
    c.route('**/three.min.js',lambda r:r.abort());pg=c.new_page();pg.on('pageerror',lambda e:errs.append('blocked:'+str(e)))
    pg.goto(F);pg.wait_for_timeout(3300);pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='sm:3d';document.getElementById('ov').appendChild(b);b.click();})()");pg.evaluate("document.querySelector('#ov [data-a=play]').click()");pg.wait_for_timeout(1500)
    ok('no internet → 3D still works (engine built in)',pg.evaluate("!!(window.__g3&&__g3.st())"))
    pg.evaluate("G3.exit()");pg.wait_for_timeout(300);ok('exit back to menu works',pg.evaluate("__arena().state")=='menu')
    ok('no internet → menus show 3D heroes',pg.evaluate("G3.ready()"))
    c.close();b.close()
print('ERRORS',errs)
print('SUMMARY %d/%d'%(sum(1 for r in res if r[1]),len(res)))
