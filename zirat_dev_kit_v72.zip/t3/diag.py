import sys
from playwright.sync_api import sync_playwright
H=sys.argv[1];flat=sys.argv[2];out=sys.argv[3]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True,device_scale_factor=2);c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
    pg.goto('file:///home/claude/arena3_gfx.html');pg.wait_for_timeout(3500)
    pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='hi:%s';document.getElementById('ov').appendChild(b);b.click();})()"%H);pg.wait_for_timeout(1200)
    pg.evaluate("""(f)=>{var v=G3._v();var sh=v.glb.material.userData.sh;if(sh)sh.uniforms.uFlat.value=f;G3.showPlay('guard');}""",float(flat))
    pg.wait_for_timeout(400)
    bb=pg.evaluate("(function(){var r=document.getElementById('hvStage').getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height}})()")
    pg.screenshot(path=out,clip=bb);print('E',E[:2])
