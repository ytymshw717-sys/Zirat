import sys,json
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True);c.add_init_script(path='/home/claude/t/mock.js')
    pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)));pg.on('console',lambda m:E.append(m.text) if m.type=='error' else None)
    pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(2500)
    def act(a,w=300):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;b.style.display='none';document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(w)
    act('menu');act('cat:md');act('sm:show');act('play',2000)
    print(pg.evaluate("(function(){var A=__arena();return {mode:A.mode,st:A.state,heroes:A.enemies.filter(function(e){return e.t==='hero'}).length,others:A.enemies.filter(function(e){return e.t!=='hero'}).length}})()"))
    pg.evaluate("(function(){var A=__arena(),p=A.ps[0];p.hp=p.mhp=1e6;window.__bot0=function(){return {x:0,y:0,a:false}};})()")
    log=[]
    for k in range(16):
        r=pg.evaluate("""(function(){var A=__arena();A.sim(150,1/30);A=__arena();var H=A.enemies.filter(function(e){return e.t==='hero'&&e.hp>0});
          return {st:A.state,alive:H.length,cubes:H.reduce(function(s,e){return s+(e.cubes||0)},0),kills:H.reduce(function(s,e){return s+(e.kills||0)},0),drops:A.drops?A.drops.length:-1,
            dodges:H.filter(function(e){return e.dg&&e.dg.t>0}).length,inBush:H.filter(function(e){return e.inBush}).length,gas:A.gas?Math.round(A.gas.r):-1,
            php:Math.round(A.ps[0].hp),hpMin:H.length?Math.min.apply(0,H.map(function(e){return +(e.hp/e.maxhp).toFixed(2)})):0}})()""")
        log.append(r);print(k*5,'s',r)
        if r['st']!='play':break
    print('E',E[:5])
