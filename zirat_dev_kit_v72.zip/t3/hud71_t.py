# v71 battle HUD: pause-only top bar in battle, pause menu sound/camera, button states, kill feed, mini-map, portrait overlay
import sys,math
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
res=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for (w,h) in [(844,390),(390,844)]:
        tag='%dx%d'%(w,h)
        c=b.new_context(viewport={'width':w,'height':h},has_touch=True,is_mobile=True,device_scale_factor=1);c.add_init_script(path='/home/claude/t/mock.js')
        c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify({owned:[0,1,3,5],gold:500,dm:60,lv:{0:5,1:5,3:5,5:5}}))}catch(e){}')
        pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)));pg.on('console',lambda m:E.append(m.text) if m.type=='error' else None)
        pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3500)
        def act(a,t=200):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(t)
        def vis(sel):return pg.evaluate("(function(){var e=document.querySelector('%s');if(!e)return false;var r=e.getBoundingClientRect();return r.width>0&&r.height>0&&getComputedStyle(e).display!=='none'})()"%sel)
        act('menu');ok(tag+' menu: title + sound visible',vis('#top>span')and vis('#snd') and not pg.evaluate("document.body.classList.contains('inb')"))
        act('cat:md');act('sm:team');act('play',1500)
        for i in range(80):
            if pg.evaluate("(function(){var A=__arena();return A.state==='play'&&A.enemies.filter(function(e){return e.ch}).length>=3})()"):break
            pg.wait_for_timeout(250)
        pg.wait_for_timeout(800)
        pg.evaluate("(function(){var A=__arena();setInterval(function(){A.ps.concat(A.tb).forEach(function(p){if(p.hp>0&&!p.__die){p.inv=Math.max(p.inv||0,1);p.hp=Math.max(p.hp,p.mhp*.6);}});},200);})()")
        ok(tag+' battle: body.inb on',pg.evaluate("document.body.classList.contains('inb')"))
        ok(tag+' battle: only pause on top (title/score/sound/camera hidden)',vis('#pz') and not any(vis(s) for s in ['#top>span','#top .tsc','#snd','#rl','#rr']))
        pz=pg.evaluate("(function(){var r=document.getElementById('pz').getBoundingClientRect(),c=document.getElementById('cv').getBoundingClientRect();return [r.left,r.top,r.width,r.height,c.left,c.top,c.right,c.bottom]})()")
        ok(tag+' pause button 44px, on the arena corner',abs(pz[2]-44)<2 and abs(pz[3]-44)<2 and pz[0]>=0 and pz[1]>=0 and pz[1]<70,str([round(x) for x in pz]))
        # super charge ring + ready state
        pg.evaluate("__arena().ps[0].sup=50")
        for i in range(30):
            pg.wait_for_timeout(100)
            if pg.evaluate("document.getElementById('sup').style.getPropertyValue('--ch')")=='180deg':break
        st=pg.evaluate("(function(){var s=document.getElementById('sup');return [s.className,s.style.getPropertyValue('--ch'),s.style.background]})()")
        ok(tag+' super charging: ring at 180deg, no inline background',st[1]=='180deg' and 'rdy' not in st[0] and 'lk' not in st[0] and not st[2],str(st))
        pg.evaluate("__arena().ps[0].sup=100")
        for i in range(30):
            pg.wait_for_timeout(100)
            if pg.evaluate("document.getElementById('sup').classList.contains('rdy')"):break
        ok(tag+' super ready: gold class',pg.evaluate("document.getElementById('sup').classList.contains('rdy')"))
        g=pg.evaluate("(function(){var g=document.getElementById('gad');return [g.className,g.querySelector('b')?g.querySelector('b').textContent:null,__arena().ps[0].gads]})()")
        ok(tag+' gadget badge shows the count',g[1] is not None and int(g[1])==g[2] and 'lk' not in g[0],str(g))
        ok(tag+' attack keeps its name for screen readers',pg.evaluate("document.getElementById('atk').getAttribute('aria-label')")=='הכה')
        # mini-map pixels (3D: the 2D layer is clear except the HUD)
        mm=pg.evaluate("""(function(){var c=document.getElementById('cv'),x=c.getContext('2d'),d=x.getImageData(c.width-Math.round(c.width*0.06),Math.round(c.height*0.07),1,1).data,e=x.getImageData(Math.round(c.width*0.5),Math.round(c.height*0.6),1,1).data;return [d[3],e[3]]})()""")
        ok(tag+' mini-map drawn top-right (and the middle of the arena stays clear)',mm[0]>150 and mm[1]<40,str(mm))
        # kill feed: a rival hero goes down by the player's hand
        kf=pg.evaluate("""(function(){var A=__arena(),e=A.enemies.filter(function(e){return e.ch&&e.hp>0})[0];e._kb=A.ps[0];e.hp=0;return e.nm||e.ch.nk})()""");pg.wait_for_timeout(400)
        feed=pg.evaluate("__kf()")
        ok(tag+' kill feed: "you ⚔️ 💀 rival"',any(('אתה' in f and kf in f and '⚔️' in f) for f in feed),str(feed)+' '+kf)
        pg.evaluate("(function(){var A=__arena(),b=A.tb[0];b.__die=1;b.inv=0;b.sh=0;A.eshots.push({x:b.x+30,y:b.y,vx:-400,vy:0,life:1,dmg:9999});})()")
        for i in range(40):
            if pg.evaluate("__arena().tb[0].hp<=0"):break
            pg.wait_for_timeout(100)
        pg.wait_for_timeout(300)
        feed=pg.evaluate("__kf()");ok(tag+' kill feed: ally down shows too, max 3 lines',len(feed)>=2 and len(feed)<=3,str(feed)+str(pg.evaluate("__arena().tb.map(function(b){return Math.round(b.hp)+'/'+b._kfd})")))
        pg.wait_for_timeout(4200);ok(tag+' kill feed fades after ~4s',len(pg.evaluate("__kf()"))==0,str(pg.evaluate("__kf()")))
        # pause menu (v72: sound/camera live in settings, pause = resume/menu)
        pg.evaluate("document.getElementById('pz').click()");pg.wait_for_timeout(300)
        ok(tag+' pause menu: resume + menu',pg.evaluate("!!document.querySelector('#ov [data-a=res]')&&!!document.querySelector('#ov [data-a=menu]')&&__arena().state==='pause'"))
        pg.evaluate("document.querySelector('#ov [data-a=res]').click()");pg.wait_for_timeout(300)
        ok(tag+' resume → play, overlay hidden',pg.evaluate("__arena().state==='play'&&document.getElementById('ov').classList.contains('hide')"))
        if h>w:
            ok(tag+' portrait: arena starts at the top (top bar floats)',pz[5]<30,str(round(pz[5])))
            ok(tag+' portrait: page turns dark in battle',pg.evaluate("getComputedStyle(document.body).backgroundImage.indexOf('gradient')>=0"))
        pg.screenshot(path='/home/claude/ui/shots/t_%s.png'%tag)
        act('menu',400)
        ok(tag+' back to menu: top bar restored',not pg.evaluate("document.body.classList.contains('inb')") and vis('#top>span') and vis('#snd'))
        ok(tag+' no errors',not E,str(E[:3]))
        c.close()
print('SUMMARY %d/%d'%(sum(res),len(res)))
