import sys
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},device_scale_factor=2);c.add_init_script(path='/home/claude/t/mock.js')
    c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify({owned:[0,1,2,3,4,5,6,7,8,9],gold:500,dm:60}))}catch(e){}')
    pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
    pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3500)
    def act(a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(250)
    act('menu');act('pk:0:7');act('menu');act('mode:survive');pg.wait_for_timeout(2500)
    for i in range(40):
        if pg.evaluate('__arena().enemies.length')>=2:break
        pg.wait_for_timeout(250)
    pg.wait_for_timeout(800)
    n=pg.evaluate("(function(){var A=__arena(),p=A.ps[0];A.enemies.forEach(function(e,j){e.stun=99;e.cd=99;e.x=p.x+70+j*40;e.y=p.y+(j%2?50:-40);e.hp=j==0?0.01:999;});p.fx=1;p.fy=-.5;return A.enemies.length;})()")
    print('enemies',n)
    pg.evaluate("(function(){var p=__arena().ps[0];p.cd=0;})()");pg.keyboard.down('Space');pg.wait_for_timeout(50);pg.keyboard.up('Space')
    for k in range(6):
        pg.wait_for_timeout(60);pg.screenshot(path='/home/claude/t3/die%d.png'%k,clip={'x':300,'y':60,'width':400,'height':250})
        print(k,pg.evaluate("__arena().enemies.length"),pg.evaluate("__arena().state"),pg.evaluate("(function(s){return [s.fx,s.deaths,s.spawns,s.ents]})(G3.r3state())"))
    print('errors',E[:3])
