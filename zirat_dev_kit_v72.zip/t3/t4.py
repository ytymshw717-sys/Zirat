import json
from playwright.sync_api import sync_playwright
res=[];errs=[]
def ok(n,c,info=''):
    res.append((n,bool(c)));print(('PASS ' if c else 'FAIL ')+n,info,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch()
    for vp,mob in [((844,390),True),((390,844),True),((1280,720),False)]:
        tag='%dx%d'%vp
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=mob,is_mobile=mob)
        c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page()
        pg.on('pageerror',lambda e:errs.append(tag+':'+str(e)))
        pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3300)
        def act(a):pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='%s';document.getElementById('ov').appendChild(b);b.click();})()"%a);pg.wait_for_timeout(60)
        def sv(e):return pg.evaluate("(function(sv){return %s})(A3.sv)"%e)
        n=pg.evaluate("A3.CH.length")
        # rich player for full checks
        pg.evaluate("A3.sv.gold=999999;A3.sv.dm=99999")
        bad=[]
        for i in range(n):
            act('hi:%d'%i)
            t=pg.evaluate("[!!document.getElementById('hiUp'),!!document.getElementById('hiSk'),document.querySelectorAll('#hiSk img').length,document.getElementById('ov').scrollWidth<=document.getElementById('ov').clientWidth+1]")
            if not(t[0] and t[1] and t[2]==4 and t[3]):bad.append((i,t))
        ok(tag+' every hero window has upgrade + 4 skins, no sideways overflow (%d heroes)'%n,not bad,str(bad[:3]))
        # buy a not-owned hero from its window
        no=pg.evaluate("A3.CH.map(function(c,i){return i}).filter(function(i){return A3.sv.owned.indexOf(i)<0})")
        if no:
            h=no[0];act('hi:%d'%h)
            ok(tag+' not-owned hero: skins locked',pg.evaluate("[].every.call(document.querySelectorAll('#hiSk button:not(.hvSk)'),function(b){return b.dataset.a.split(':')[0]==='x'})"))
            g0=sv('sv.gold');pg.evaluate("document.querySelector('[data-a=\"hbuy2:%d\"]').click()"%h);pg.wait_for_timeout(80)
            ok(tag+' buy hero inside its window',sv('sv.owned.indexOf(%d)>=0'%h) and sv('sv.gold')<g0 and pg.evaluate("!!document.querySelector('[data-a=\"hup2:%d\"]')"%h),'stays in window')
        # upgrade all levels for hero 0 from its window
        h=0;act('hi:0');lv0=sv('sv.lv[0]||0');steps=0
        while pg.evaluate("!!document.querySelector('[data-a=\"hup2:0\"]')") and steps<12:
            g0=sv('sv.gold');l=sv('sv.lv[0]||0')
            pg.evaluate("document.querySelector('[data-a=\"hup2:0\"]').click()");pg.wait_for_timeout(60);steps+=1
            if not(sv('sv.lv[0]')==l+1 and g0-sv('sv.gold')==60*(l+1) and pg.evaluate("!!document.getElementById('hiUp')")):ok(tag+' upgrade step %d'%l,False);break
        ok(tag+' upgrade inside window to max (9)',sv('sv.lv[0]')==8 and 'מקסימלית' in pg.inner_text('#hiUp'),'from %d in %d steps'%(lv0,steps))
        # skins: buy and equip each from the window
        okk=True
        for k in [1,2,3]:
            pg.evaluate("document.querySelector('[data-a=\"sbuy2:0:%d\"]').click()"%k);pg.wait_for_timeout(60)
            if not(sv("(sv.so[0]||[]).indexOf(%d)>=0"%k) and sv('sv.sk[0]')==k and pg.evaluate("!!document.getElementById('hiSk')")):okk=False
        ok(tag+' buy 3 skins inside window, auto-equip',okk)
        pg.evaluate("document.querySelector('[data-a=\"seq2:0:0\"]').click()");pg.wait_for_timeout(60)
        ok(tag+' equip classic skin from window',sv('sv.sk[0]')==0 and '✅' in pg.inner_text('#hiSk'))
        saved=pg.evaluate("JSON.parse(localStorage.getItem('heroes_arena_save'))")
        ok(tag+' saved to storage',saved['lv']['0']==8 and 3 in saved['so']['0'] and saved['sk']['0']==0)
        # reload keeps it
        pg.reload();pg.wait_for_timeout(3300);act('hi:0')
        ok(tag+' after reload: level + skins kept',sv('sv.lv[0]')==8 and pg.evaluate("[].filter.call(document.querySelectorAll('#hiSk button'),function(b){return /^seq2/.test(b.dataset.a)}).length")==4)
        # poor player: nothing changes
        pg.evaluate("A3.sv.gold=0;A3.sv.dm=0");h1=pg.evaluate("A3.sv.owned.filter(function(i){return (A3.sv.lv[i]||0)<8})[0]")
        act('hi:%d'%h1);l=sv('sv.lv[%d]||0'%h1)
        pg.evaluate("document.querySelector('[data-a=\"hup2:%d\"]').click()"%h1);pg.wait_for_timeout(60)
        ok(tag+' no money → no upgrade, message shown',sv('sv.lv[%d]||0'%h1)==l and sv('sv.gold')==0 and 'אין מספיק' in pg.inner_text('#ov'))
        sk=pg.evaluate("(function(){var b=document.querySelector('#hiSk [data-a^=sbuy2]');return b?b.dataset.a:null})()")
        if sk:
            pg.evaluate("document.querySelector('[data-a=\"%s\"]').click()"%sk);pg.wait_for_timeout(60)
            p_=sk.split(':');ok(tag+' no money → no skin',sv("(sv.so[%s]||[]).indexOf(%s)<0"%(p_[1],p_[2])))
        # arrows navigate
        act('hi:0');pg.evaluate("document.querySelector('#ov [data-a=\"hi:1\"]').click()");pg.wait_for_timeout(60)
        ok(tag+' ▶ goes to next hero',pg.evaluate("A3.CH[1].nk") in pg.inner_text('#ov h1'))
        pg.evaluate("document.querySelector('#ov [data-a=\"hi:%d\"]').click()"%(n-1) if False else "document.querySelector('#ov [data-a=\"hi:0\"]').click()");pg.wait_for_timeout(60)
        ok(tag+' ◀ goes back',pg.evaluate("A3.CH[0].nk") in pg.inner_text('#ov h1'))
        # old windows still work
        act('heroes');ok(tag+' old heroes list still works',pg.evaluate("document.querySelectorAll('#ov [data-a^=\"hi:\"]').length")>=n)
        act('skins:0');ok(tag+' old skins window still works','סקינים' in pg.inner_text('#ov'))
        act('hi:0');pg.screenshot(path='/home/claude/t3/hi_%s.png'%tag,full_page=False)
        # buttons reachable by scrolling: back button exists
        ok(tag+' back button present',pg.evaluate("!!document.querySelector('#ov [data-a=menu]')"))
        c.close()
    b.close()
print('ERRORS',errs);print('SUMMARY %d/%d'%(sum(1 for r in res if r[1]),len(res)))
