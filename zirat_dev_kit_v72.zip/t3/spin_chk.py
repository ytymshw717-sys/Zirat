from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for vp in [(844,390),(1280,720)]:
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]});c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
        pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3500)
        pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='mode:survive';document.getElementById('ov').appendChild(b);b.click();})()");pg.wait_for_timeout(3000)
        r=[]
        for i in range(3):
            pg.evaluate("var p=__arena().ps[0];p.spcd=0;p.sup=100");pg.keyboard.down('KeyK');pg.wait_for_timeout(250);pg.keyboard.up('KeyK')
            t=0
            while t<3000 and pg.evaluate("__arena().ps[0].spcd")<=0:pg.wait_for_timeout(100);t+=100
            r.append((pg.evaluate("__arena().ps[0].spcd")>0,t,pg.evaluate("G3.r3state()&&G3.r3state().calls")))
            pg.wait_for_timeout(600)
        print(vp,'spin triggered (ok, ms after key-up, draw calls):',r,'errors',E[:2]);c.close()
