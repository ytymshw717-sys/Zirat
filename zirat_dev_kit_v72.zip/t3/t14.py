# hero cards open the hero screen (stats) — picker and heroes list
from playwright.sync_api import sync_playwright
res=[];errs=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch()
    for vp in [(844,390),(390,844)]:
        tag='%dx%d'%vp
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=True,is_mobile=True)
        c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();pg.on('pageerror',lambda e:errs.append(tag+str(e)))
        pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3300)
        def act(a):pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='%s';document.getElementById('ov').appendChild(b);b.click();})()"%a);pg.wait_for_timeout(150)
        def click(a):
            n=pg.evaluate("(function(){var b=[].filter.call(document.querySelectorAll('#ov [data-a]'),function(x){return x.dataset.a==='%s'})[0];if(!b)return 0;b.click();return 1})()"%a);pg.wait_for_timeout(200);return n
        hs=lambda:pg.evaluate("!!document.getElementById('hiSk')")
        txt=lambda:pg.evaluate("document.getElementById('ov').innerText")
        act('pick:0')
        n=pg.evaluate("document.querySelectorAll('#ov [data-a^=\"hp:0:\"]').length")
        ok(tag+' picker: every card opens the hero screen',n==20,n)
        ok(tag+' tap owned card (3) → hero screen with stats',click('hp:0:3') and hs() and 'חיים' in txt() and 'מהירות' in txt())
        ok(tag+'   select button shown',pg.evaluate("!!document.querySelector('#ov [data-a=\"pk:0:3\"]')"))
        ok(tag+'   arrows keep the picker context',pg.evaluate("[].every.call(document.querySelectorAll('#ov .hvTop [data-a]'),function(b){return b.dataset.a.indexOf('hp:0:')==0})"))
        ok(tag+'   back returns to the picker',click('pick:0') and pg.evaluate("document.querySelectorAll('#ov [data-a^=\"hp:0:\"]').length")==20)
        click('hp:0:3');ok(tag+' select from hero screen → chosen + back to menu',click('pk:0:3') and pg.evaluate("A3.sel()")==3 and not hs())
        act('pick:0');click('hp:0:2');ok(tag+' locked card → hero screen with buy, no select',hs() and not pg.evaluate("!!document.querySelector('#ov [data-a^=\"pk:\"]')") and pg.evaluate("!!document.querySelector('#ov [data-a=\"hbuy2:2\"]')"))
        act('menu');act('hi:0');ok(tag+' hero screen from menu has no select button',hs() and not pg.evaluate("!!document.querySelector('#ov .hvPick')"))
        ok(tag+'   its back goes to the menu',pg.evaluate("!!document.querySelector('#ov [data-a=\"menu\"]')"))
        act('heroes');ok(tag+' heroes list: name part of each card is clickable',pg.evaluate("document.querySelectorAll('#ov button.hrow[data-a^=\"hi:\"]').length")==20)
        ok(tag+'   tapping it opens the hero screen',pg.evaluate("document.querySelector('#ov button.hrow[data-a=\"hi:5\"]').click(),1") and (pg.wait_for_timeout(200) or True) and hs() and 'זוק' in txt())
        c.close()
    print('errors',errs[:3]);print('SUMMARY %d/%d'%(sum(res),len(res)))
