import sys
from playwright.sync_api import sync_playwright
H=sys.argv[1] if len(sys.argv)>1 else '7';out=sys.argv[2] if len(sys.argv)>2 else 'w7'
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True,device_scale_factor=2)
    c.add_init_script(path='/home/claude/t/mock.js');c.add_init_script(script='try{if(!localStorage.getItem("heroes_arena_save"))localStorage.setItem("heroes_arena_save",JSON.stringify({owned:[0,1,3,5,%s],gold:100}))}catch(e){}'%H);pg=c.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append('con:'+m.text) if m.type=='error' else None)
    pg.goto('file:///home/claude/arena3_gfx.html');pg.wait_for_timeout(3500)
    def act(a):pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='%s';document.getElementById('ov').appendChild(b);b.click();})()"%a);pg.wait_for_timeout(80)
    act('pk:0:'+H);pg.wait_for_timeout(600);act('menu');pg.wait_for_timeout(300);act('mode:survive');pg.wait_for_timeout(2500)
    pg.screenshot(path='/home/claude/t3/%s_a.png'%out)
    pg.keyboard.down('KeyD');pg.wait_for_timeout(700);pg.screenshot(path='/home/claude/t3/%s_b.png'%out)
    pg.keyboard.down('Space');pg.wait_for_timeout(250);pg.screenshot(path='/home/claude/t3/%s_c.png'%out);pg.wait_for_timeout(900);pg.keyboard.up('KeyD');pg.keyboard.up('Space')
    pg.keyboard.down('KeyS');pg.wait_for_timeout(600);pg.screenshot(path='/home/claude/t3/%s_d.png'%out);pg.keyboard.up('KeyS')
    print(pg.evaluate("G3.r3state()"),pg.evaluate("__arena().state"),'ERR',errs[:5])
