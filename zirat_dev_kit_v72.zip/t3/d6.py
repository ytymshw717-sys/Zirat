from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page();pg.on('pageerror',lambda e:print('ERR',e))
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3300)
    pg.evaluate("document.querySelector('#ov [data-a=play]').click()");pg.wait_for_timeout(1500)
    for i in range(20):
        pg.evaluate("__arena().enemies.forEach(function(e){e.hp=0.01;})");pg.keyboard.down('Space');pg.wait_for_timeout(120);pg.keyboard.up('Space')
    print(pg.evaluate("[__arena().score,__arena().state,A3.sv.best]"))
    pg.evaluate("window.dispatchEvent(new Event('pagehide'))")
    print(pg.evaluate("[__arena().score,__arena().state,A3.sv.best,JSON.parse(localStorage.getItem('heroes_arena_save')).best]"))
