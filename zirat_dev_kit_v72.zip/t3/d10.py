from playwright.sync_api import sync_playwright
THREE=open('/home/claude/mrdoob/three.js/build/three.min.js','rb').read()
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':1280,'height':720});c.add_init_script(path='/home/claude/t/mock.js')
    c.route('**/three.min.js',lambda r:r.fulfill(status=200,body=THREE,headers={'content-type':'application/javascript'}))
    pg=c.new_page();pg.on('pageerror',lambda e:print('ERR',e));pg.on('console',lambda m:print('CON',m.text))
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3300)
    pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='sm:3d';document.getElementById('ov').appendChild(b);b.click();})()")
    pg.evaluate("document.querySelector('#ov [data-a=play]').click()")
    pg.wait_for_function("window.__g3&&__g3.st()",timeout=20000)
    for i in range(5):
        pg.wait_for_timeout(600);s=pg.evaluate("__g3.st()");print(pg.evaluate('[__g3.st().p.inv,__g3.st().e.inv]'))
    pg.screenshot(path='/home/claude/t3/d9.png')
