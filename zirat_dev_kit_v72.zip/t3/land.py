import sys,json
from playwright.sync_api import sync_playwright
F='file:///home/claude/arena3_new.html'
SIZES=[(932,430),(844,390),(812,340),(740,320),(667,300)]
JS_OVER="""(function(){var vw=innerWidth,vh=innerHeight,bad=[];
 function vis(e){var r=e.getBoundingClientRect(),s=getComputedStyle(e);return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'&&+s.opacity>0.05;}
 var els=[].slice.call(document.querySelectorAll('#ov button,#ov .chip,#ov h1,#ov .hn,#ctl button,#js,#top button,#top span'));
 els.forEach(function(e){if(!vis(e))return;var r=e.getBoundingClientRect();if(r.left<-1||r.right>vw+1)bad.push('offX:'+(e.dataset.a||e.id||e.className||e.tagName)+' '+Math.round(r.left)+'-'+Math.round(r.right));});
 return {docW:document.documentElement.scrollWidth,vw:vw,ovSW:(document.getElementById('ov')||{}).scrollWidth,ovCW:(document.getElementById('ov')||{}).clientWidth,bad:bad.slice(0,6)};})()"""
JS_OVL="""(function(){function R(id){var e=document.getElementById(id);if(!e)return null;var r=e.getBoundingClientRect();return r.width?[Math.round(r.left),Math.round(r.top),Math.round(r.right),Math.round(r.bottom)]:null;}
 function hit(a,b){return a&&b&&a[0]<b[2]&&b[0]<a[2]&&a[1]<b[3]&&b[1]<a[3];}
 var js=R('js'),atk=R('atk'),spb=R('spb'),sup=R('sup'),gad=R('gad'),top=R('top'),cv=R('cv');
 var o=[];[['js','atk',js,atk],['js','spb',js,spb],['js','sup',js,sup],['atk','spb',atk,spb],['sup','gad',sup,gad],['top','sup',top,sup],['top','gad',top,gad]].forEach(function(q){if(hit(q[2],q[3]))o.push(q[0]+'x'+q[1]);});
 [['js',js],['atk',atk],['spb',spb],['sup',sup],['gad',gad]].forEach(function(q){if(q[1]&&(q[1][3]>innerHeight+1||q[1][1]<0))o.push(q[0]+' offscreen '+q[1]);});
 return {overlaps:o,cv:cv,top:top,js:js,atk:atk,sup:sup,gad:gad,spb:spb};})()"""
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for w,h in SIZES:
        c=b.new_context(viewport={'width':w,'height':h},is_mobile=True,has_touch=True,device_scale_factor=2);c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
        pg.goto(F);pg.wait_for_timeout(3500)
        def act(a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(600)
        tag='%dx%d'%(w,h);res={}
        res['menu']=pg.evaluate(JS_OVER);pg.screenshot(path='/home/claude/t3/rot/L_%s_menu.png'%tag)
        act('hi:0');pg.wait_for_timeout(800);res['hero']=pg.evaluate(JS_OVER);pg.screenshot(path='/home/claude/t3/rot/L_%s_hero.png'%tag)
        act('menu');act('shop');res['shop']=pg.evaluate(JS_OVER);pg.screenshot(path='/home/claude/t3/rot/L_%s_shop.png'%tag)
        act('menu');act('mode:survive');pg.wait_for_timeout(1500);res['game']=pg.evaluate(JS_OVL);pg.screenshot(path='/home/claude/t3/rot/L_%s_game.png'%tag)
        print(tag,json.dumps(res,ensure_ascii=False)[:900],'err',E[:2],flush=True);c.close()
