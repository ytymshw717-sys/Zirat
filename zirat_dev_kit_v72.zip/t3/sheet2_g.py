import sys
from playwright.sync_api import sync_playwright
heroes=[int(x) for x in sys.argv[1].split(',')];out=sys.argv[2]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    pg=b.new_page(viewport={'width':820,'height':205*len(heroes)+10});pg.on('pageerror',lambda e:print('ERR',e))
    pg.add_init_script(path='/home/claude/t/mock.js');pg.goto('file:///home/claude/arena3_gfx.html');pg.wait_for_timeout(4000)
    html=pg.evaluate("(function(H){var h='';H.forEach(function(i){for(var k=0;k<4;k++)h+='<img src=\"'+G3.portrait(i,k,200)+'\" width=196 height=196 style=\"background:#334155;margin:2px\">';});return h})(%s)"%heroes)
    pg.evaluate("(function(h){document.body.innerHTML='<div style=\"background:#1e293b;padding:2px;width:820px;direction:ltr\">'+h+'</div>'})",html)
    pg.wait_for_timeout(300);pg.screenshot(path=out)
