from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True,device_scale_factor=2)
    c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3600)
    pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='hi:0';document.getElementById('ov').appendChild(b);b.click();})()");pg.wait_for_timeout(1500)
    print(pg.evaluate("(function(){var r=document.getElementById('hvStage').getBoundingClientRect();return [r.left,r.top,r.width,r.height,innerHeight,document.getElementById('ov').scrollTop]})()"))
    pg.screenshot(path='/home/claude/t3/d11.png')
