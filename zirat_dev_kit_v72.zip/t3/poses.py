from playwright.sync_api import sync_playwright
P=[("-.2,0,.42","-2.05,0,-.1"),("-.1,0,.95","-1.7,0,0"),("-.35,.3,.9","-1.9,0,.3"),("0,0,1.1","-1.5,-.3,0"),("-.25,-.3,.8","-1.8,0,-.3"),("-.5,0,.7","-1.4,0,.4")]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    pg=b.new_page(viewport={'width':1200,'height':420});pg.add_init_script(path='/home/claude/t/mock.js');pg.goto('file:///home/claude/arena3_gfx.html');pg.wait_for_timeout(3500)
    h=''
    for a,w in P:
        u=pg.evaluate("""(function(){var src=G3.__pose;return null})()""")
    # render via hero window? use portrait with overridden pose through a global hook
    urls=pg.evaluate("""(function(P){var out=[];P.forEach(function(q){window.__PP=q;out.push(G3.portrait(7,0,190+out.length));});return out;})(%s)"""%str([[a,w] for a,w in P]))
    pg.evaluate("(function(U){document.body.innerHTML='<div style=\"background:#2b63d9;display:flex\">'+U.map(function(u){return '<img src=\"'+u+'\" width=200 height=200>'}).join('')+'</div>'})",urls)
    pg.wait_for_timeout(300);pg.screenshot(path='/home/claude/t3/poses.png',clip={'x':0,'y':0,'width':1200,'height':200})
