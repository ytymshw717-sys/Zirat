from playwright.sync_api import sync_playwright
res=[];errs=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch();c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True)
    c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    def act(a):pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='%s';document.getElementById('ov').appendChild(b);b.click();})()"%a);pg.wait_for_timeout(80)
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3300)
    v0=pg.evaluate("A3.sv.visits")
    h=pg.evaluate("A3.sv.owned[2]")
    act('pk:0:%d'%h);act('sm:boss');act('df:2');act('mp:3')
    pg.evaluate("A3.sv.gold=777;A3.sv.dm=55")
    pg.evaluate("window.dispatchEvent(new Event('pagehide'))")
    pg.reload();pg.wait_for_timeout(3300)
    ok('visits counted on enter',pg.evaluate("A3.sv.visits")==v0+1,'%s->%s'%(v0,pg.evaluate("A3.sv.visits")))
    ok('coins/gems kept after exit+enter',pg.evaluate("A3.sv.gold")==777 and pg.evaluate("A3.sv.dm")==55)
    ok('selected hero kept',pg.evaluate("A3.sel()")==h)
    t=pg.inner_text('#mdSel');pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='maps';document.getElementById('ov').appendChild(b);b.click();})()");pg.wait_for_timeout(80)
    ok('mode, difficulty, map kept','בוסים' in t and 'קשה' in t and pg.evaluate("!!document.querySelector('.c.sel[data-a=\"mp:3\"]')"),t.replace('\n',' '))
    # mid-match exit keeps best score
    act('sm:survive');act('play');pg.wait_for_timeout(1200)
    pg.evaluate("(function(){var A=__arena();})()")
    best0=pg.evaluate("A3.sv.best")
    pg.evaluate("__arena().ps[0].x+=0");pg.evaluate("(function(){})()")
    # raise score via game hook object (score is primitive; use kills): set through enemy kill simulation
    for i in range(30):
        pg.evaluate("(function(){var A=__arena();A.enemies.forEach(function(e){e.hp=0.01;});})()");pg.keyboard.down('Space');pg.wait_for_timeout(120);pg.keyboard.up('Space')
    sc=pg.evaluate("__arena().score")
    pg.evaluate("document.dispatchEvent(new Event('visibilitychange'))");pg.evaluate("Object.defineProperty(document,'hidden',{value:true,configurable:true});document.dispatchEvent(new Event('visibilitychange'))")
    saved=pg.evaluate("JSON.parse(localStorage.getItem('heroes_arena_save')).best")
    ok('leaving mid-match saves best score',sc==0 or saved>=sc,'score=%s saved best=%s'%(sc,saved))
    pg.reload();pg.wait_for_timeout(3300)
    ok('best score kept after re-enter',pg.evaluate("A3.sv.best")>=min(sc,saved))
    # corrupted save does not break the game
    pg.evaluate("localStorage.setItem('heroes_arena_save','{bad json')");pg.reload();pg.wait_for_timeout(3300)
    ok('corrupt save → game still opens',pg.evaluate("!!document.querySelector('#ov [data-a=play]')"))
    b.close()
print('ERRORS',errs);print('SUMMARY %d/%d'%(sum(res),len(res)))
