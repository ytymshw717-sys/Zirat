from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for q,c3 in [(2,True),(2,False),(0,True),(0,False)]:
        c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True,device_scale_factor=3)
        c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(5500)
        pg.evaluate("A3.sv.cfg.q=%d;A3.sv.cfg.c3=%s"%(q,'true' if c3 else 'false'))
        pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='q:%d';document.getElementById('ov').appendChild(b);b.click();b=document.createElement('button');b.dataset.a='menu';document.getElementById('ov').appendChild(b);b.click();b=document.createElement('button');b.dataset.a='play';document.getElementById('ov').appendChild(b);b.click();})()"%q)
        pg.wait_for_timeout(2500)
        pg.evaluate("window.__ft=[];(function f(t){window.__ft.push(t);if(window.__ft.length<120)requestAnimationFrame(f);})(performance.now())")
        pg.keyboard.down('KeyD');pg.wait_for_timeout(3000);pg.keyboard.up('KeyD')
        print('q',q,'3d',c3,pg.evaluate("(function(){var a=window.__ft,d=[];for(var i=1;i<a.length;i++)d.push(a[i]-a[i-1]);d.sort(function(x,y){return x-y});return [d.length,Math.round(d[Math.floor(d.length/2)]),Math.round(d[Math.floor(d.length*.95)])]})()"))
        c.close()
    b.close()
