import re
from playwright.sync_api import sync_playwright
res=[];errs=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
mock=open('/home/claude/t/mock.js').read().replace('window.__skipIntro=1;','')+";window.__log=[];setInterval(function(){try{window.__log.push([!!document.getElementById('introL'),!!document.querySelector('#ov [data-sp]'),!!document.querySelector('#ov [data-a=play]')]);}catch(e){}},100);"
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for vp in [(390,844),(844,390),(1280,720)]:
        tag='%dx%d'%vp;c=b.new_context(viewport={'width':vp[0],'height':vp[1]},is_mobile=vp[0]<1000,has_touch=vp[0]<1000,device_scale_factor=2)
        c.add_init_script(script=mock);pg=c.new_page();pg.on('pageerror',lambda e:errs.append(tag+str(e)))
        pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_function("!!document.getElementById('introL')",timeout=15000);pg.wait_for_timeout(1200)
        r=pg.evaluate("(function(){var d=document.getElementById('introL');if(!d)return null;var cs=getComputedStyle(d),r=d.getBoundingClientRect();return [cs.backgroundColor,getComputedStyle(d.querySelector('h1')).color,cs.position==='fixed'&&+cs.zIndex>=50&&r.width>=innerWidth-1&&r.height>=innerHeight-1,d.textContent.indexOf('זירת גיבורים')>=0]})()")
        ok(tag+' black intro with white logo covers screen',r and r[0]=='rgb(0, 0, 0)' and r[1]=='rgb(255, 255, 255)' and r[2] and r[3],str(r))
        pg.screenshot(path='/home/claude/t3/intro_%s.png'%tag)
        pg.wait_for_function("!document.getElementById('introL')&&!document.querySelector('#ov [data-sp]')&&!!document.querySelector('#ov [data-a=play]')",timeout=30000)
        pg.wait_for_timeout(300);L=pg.evaluate("window.__log")
        seq=[];[seq.append(k) for k in [('logo' if x[0] else '')+('+loading' if x[1] else '')+('+menu' if x[2] and not x[0] and not x[1] else '') for x in L] if k and (not seq or seq[-1]!=k)]
        ok(tag+' order: logo → loading screen → menu','logo' in seq[0] and any('loading' in k for k in seq) and seq[-1]=='+menu',str(seq))
        c.close()
    # tap to skip
    c=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True);c.add_init_script(script=mock);pg=c.new_page()
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_function("!!document.getElementById('introL')",timeout=15000);pg.tap('#introL');pg.wait_for_timeout(800)
    ok('tap skips intro',pg.evaluate("!document.getElementById('introL')") and 'טוען' in pg.inner_text('#ov'));c.close()
    # reduced motion
    c=b.new_context(viewport={'width':390,'height':844},reduced_motion='reduce');c.add_init_script(script=mock);pg=c.new_page()
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_function("!!document.getElementById('introL')",timeout=15000);pg.wait_for_timeout(1900);ok('reduced motion: short intro',pg.evaluate("!document.getElementById('introL')"));c.close()
    # 3D maps
    c=b.new_context(viewport={'width':844,'height':390},is_mobile=True,has_touch=True);c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();pg.on('pageerror',lambda e:errs.append('maps:'+str(e)))
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3500)
    def act(a):pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='%s';document.getElementById('ov').appendChild(b);b.click();})()"%a);pg.wait_for_timeout(60)
    act('maps');t=0
    while pg.evaluate("[].some.call(document.querySelectorAll('#ov img'),function(i){return /^data:image\\/svg/.test(i.getAttribute('src'))})") and t<60:pg.wait_for_timeout(500);t+=1
    ok('maps window: 3D previews for all 10 maps',pg.evaluate("[].filter.call(document.querySelectorAll('#ov [data-a^=\"mp:\"] img'),function(i){return i.naturalWidth===240}).length")==10)
    pg.screenshot(path='/home/claude/t3/maps3d.png')
    for wi in range(8):
        act('mp:%d'%wi);act('sm:3d');act('play')
        pg.wait_for_function("window.__g3&&__g3.st()",timeout=30000);pg.wait_for_timeout(1500)
        s=pg.evaluate("__g3.st()");ok('3D fight on map %d loads'%wi,s['calls']>10 and not s['over'],'calls=%d'%s['calls'])
        nm=pg.evaluate("A3.world(%d).n"%wi);ok('   map name shown: '+nm,nm in pg.inner_text('#g3'))
        pg.screenshot(path='/home/claude/t3/map3d_%d.png'%wi)
        # obstacle collision works on this map
        pg.evaluate("__g3.freeze();__g3.manual()")
        ok('   player stays in arena',abs(pg.evaluate("__g3.st().p.x"))<=11.5)
        pg.evaluate("G3.exit()");pg.wait_for_timeout(300)
    ok('back in menu, single canvas',pg.evaluate("__arena().state==='menu'&&document.querySelectorAll('#g3').length===0"))
    b.close()
print('ERRORS',errs);print('SUMMARY %d/%d'%(sum(res),len(res)))
