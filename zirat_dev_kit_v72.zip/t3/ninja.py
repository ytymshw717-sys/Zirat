import sys
from playwright.sync_api import sync_playwright
out=sys.argv[1] if len(sys.argv)>1 else 'ninja';H=sys.argv[2] if len(sys.argv)>2 else '0'
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True,device_scale_factor=2);c.add_init_script(path='/home/claude/t/mock.js');c.add_init_script(script='window.__H="%s";'%H);pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
    pg.goto('file:///home/claude/arena3_gfx.html');pg.wait_for_timeout(3500)
    pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='hi:'+(window.__H||'0');document.getElementById('ov').appendChild(b);b.click();})()");pg.wait_for_timeout(700)
    bb=pg.evaluate("(function(){var r=document.getElementById('hvStage').getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height}})()")
    def shot(n):pg.screenshot(path='/home/claude/t3/%s_%s.png'%(out,n),clip=bb)
    shot('front');x=bb['x']+bb['width']/2;y=bb['y']+bb['height']/2
    pg.mouse.move(x,y);pg.mouse.down();pg.mouse.move(x+130,y,steps=6);pg.mouse.up();pg.wait_for_timeout(250)
    shot('side')
    pg.mouse.move(x,y);pg.mouse.down();pg.mouse.move(x+150,y,steps=6);pg.mouse.up();pg.wait_for_timeout(250)
    shot('back')
    print('errors',E[:3])
