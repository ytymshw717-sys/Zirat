# gameplay monkey: every sculpted hero x several modes, random movement/attacks/spin/super; collect JS errors and state
import sys,random,json
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html';random.seed(3)
HEROES=[0,1,2,4,5,6,7,9];MODES=['survive','boss','siege','gems','ball','heist']
KEYS=['KeyW','KeyA','KeyS','KeyD','Space','KeyK','KeyJ','KeyE','KeyQ']
res=[];E=[]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True)
    c.add_init_script(path='/home/claude/t/mock.js');c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify({owned:[0,1,2,3,4,5,6,7,8,9],gold:500,lv:{0:4,1:4,2:4,4:4,5:4,6:4,7:4,9:4}}))}catch(e){}')
    pg=c.new_page();pg.on('pageerror',lambda e:E.append(str(e)));pg.on('console',lambda m:E.append('console: '+m.text) if m.type=='error' else None)
    pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3500)
    def act(a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;b.style.display='none';document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(100)
    for i,h in enumerate(HEROES):
        m=MODES[i%len(MODES)];n0=len(E)
        act('menu');act('pk:0:%d'%h);act('menu');act('mode:'+m);pg.wait_for_timeout(1500)
        pg.evaluate("var p=__arena().ps[0];p.sup=100;p.spcd=0")
        for k in range(14):
            ks=random.sample(KEYS,2)
            for kk in ks:pg.keyboard.down(kk)
            pg.wait_for_timeout(220)
            for kk in ks:pg.keyboard.up(kk)
        st=pg.evaluate("[__arena().state,__arena().ps[0].ch.nk,Math.round(__arena().ps[0].x),Math.round(__arena().ps[0].y)]");r3=pg.evaluate("G3.r3state()")
        res.append((h,m,st,r3 and r3['calls'],len(E)-n0))
        pg.screenshot(path='/home/claude/t3/monkey_%d.png'%h)
        pg.keyboard.press('KeyP');pg.wait_for_timeout(100)
    print(json.dumps(res,ensure_ascii=False));print('ERRORS',E[:5])
okk=not E and all(r[2][0] in ('play','shop','over') for r in res);print('states',[r[2][0] for r in res]);print(('PASS' if okk else 'FAIL')+' gameplay monkey: %d heroes x modes, JS errors %d'%(len(res),len(E)));print('SUMMARY %d/1'%(1 if okk else 0))
