# skinning stress test for every sculpted hero (numpy LBS with the game's poses + joint limits)
import subprocess,re
res=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
for d,name in [('hb/m8','שאדו'),('p1','רוק'),('n4','זאפ'),('n0','בליץ'),('n3','זוק'),('n1','ריי'),('n2','ג׳ד'),('n5','רקס'),('hb/m4','דרק'),('hb/m9','נובה'),('hb/m6','טנק'),('hb/m3','ניקי'),('hb/m2','בו'),('hb/m0','בומי'),('hb/m7','ריף'),('hb/m10','סול'),('hb/m5','ויפר'),('hb/m1','טורו')]:
    out=subprocess.run(['python3','/home/claude/glb/sim.py','/home/claude/'+d],capture_output=True,text=True).stdout
    st=eval(re.search(r"\(%\): (\{.*?\})",out).group(1))
    worst=max(v[0] for v in st.values());p999=max(v[1] for v in st.values())
    ok('%s (%s): stretched faces under every pose <3%%, 99.9th pct stretch <4x'%(name,d),worst<3 and p999<4,'worst %.2f%% p99.9 %.2fx'%(worst,p999))
print('SUMMARY %d/%d'%(sum(res),len(res)))
