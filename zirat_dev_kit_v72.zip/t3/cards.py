from playwright.sync_api import sync_playwright
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True,device_scale_factor=2)
    c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3500)
    def act(a):pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='%s';document.getElementById('ov').appendChild(b);b.click();})()"%a);pg.wait_for_timeout(60)
    PH="[].filter.call(document.querySelectorAll('#ov img'),function(i){return /^data:image\\/svg/.test(i.getAttribute('src'))}).length"
    for w in ['menu','pick:0','heroes']:
        act(w);t=0
        while pg.evaluate(PH)>0 and t<80:pg.wait_for_timeout(500);t+=1
        pg.screenshot(path='/home/claude/t3/card_%s.png'%w.replace(':','_'))
        print(w,'placeholders left',pg.evaluate(PH),'round cards',pg.evaluate("[].filter.call(document.querySelectorAll('#ov img.hc'),function(i){return getComputedStyle(i).borderRadius==='50%'}).length"))
        act('menu')
    print('ERR',errs)
