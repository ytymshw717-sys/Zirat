# capture the 5 painted screens in landscape (and outline every control to check alignment)
import sys
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
VP=(int(sys.argv[2]),int(sys.argv[3])) if len(sys.argv)>3 else (844,390)
DBG=len(sys.argv)>4 and sys.argv[4]=='dbg'
SAVE=sys.argv[5] if len(sys.argv)>5 else '{"owned":[0,1,3,5],"gold":500,"dm":60,"xp":400}'
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':VP[0],'height':VP[1]},has_touch=True,is_mobile=True,device_scale_factor=2)
    c.add_init_script(path='/home/claude/t/mock.js')
    c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify(%s))}catch(e){}'%SAVE)
    pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
    pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(4000)
    def act(a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;b.style.display='none';document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(600)
    for s in ['cat:hr','cfg','online','pass','prof']:
        act('menu');act(s);pg.wait_for_timeout(1500)
        if DBG:pg.evaluate("document.querySelectorAll('#ov .isA>*,#ov .isA button,#ov .isA input').forEach(function(e){e.style.outline='2px solid rgba(255,0,0,.9)';})")
        pg.screenshot(path='/home/claude/t3/is/%s_%dx%d%s.png'%(s.replace(':','_'),VP[0],VP[1],'_d' if DBG else ''))
    print('errors',E[:3])
