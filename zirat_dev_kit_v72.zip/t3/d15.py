from playwright.sync_api import sync_playwright
mock=open('/home/claude/t/mock.js').read().replace('window.__skipIntro=1;','')
with sync_playwright() as p:
    b=p.chromium.launch();c=b.new_context(viewport={'width':390,'height':844},is_mobile=True,device_scale_factor=2);c.add_init_script(script=mock);pg=c.new_page()
    pg.clock.install();pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_function("!!document.getElementById('introL')",timeout=20000)
    pg.wait_for_timeout(2600);pg.screenshot(path='/home/claude/t3/intro_shot.png')
