from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    pg=b.new_page(viewport={'width':520,'height':520})
    pg.add_init_script(path='/home/claude/t/mock.js');pg.goto('file:///home/claude/arena3_gfx.html');pg.wait_for_timeout(4000)
    u=pg.evaluate("G3.portrait(0,0,500)")
    pg.evaluate("(function(u){document.body.innerHTML='<img src=\"'+u+'\" style=\"background:#1d4ed8\">'})",u)
    pg.wait_for_timeout(300);pg.screenshot(path='/home/claude/t3/one.png')
