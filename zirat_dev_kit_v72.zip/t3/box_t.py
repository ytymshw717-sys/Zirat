# loot box flow: victory -> 3D box -> rewards one by one -> summary -> back to victory with the box marked as opened; home button; hero card; skip; shop / pass / 2D / portrait
import sys
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
OUT='/home/claude/shots/box'
import os;os.makedirs(OUT,exist_ok=True)
res=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
SAVE='{"owned":[0,1,2,3,4,5],"gold":900,"dm":90,"xp":5000%s}'
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for tag,vp,extra in (('3D',(844,390),''),('portrait',(390,844),''),('2D',(844,390),',"cfg":{"r3":false}')):
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=True,is_mobile=True,device_scale_factor=1);c.add_init_script(path='/home/claude/t/mock.js')
        c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify(%s))}catch(e){}'%(SAVE%extra))
        pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)));pg.on('console',lambda m:E.append(m.text) if m.type=='error' else None)
        pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3500)
        def act(a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(150)
        def tapThrough(maxn=12):
            n=0;cards=[]
            for k in range(maxn):
                if pg.evaluate("!!document.querySelector('#ov .bxSum')"):break
                pg.evaluate("(function(){var t=document.querySelector('#ov .bx3Tap');if(t)t.click();})()");pg.wait_for_timeout(1150)
                cards.append(pg.evaluate("(function(){var c=document.querySelector('#bx3Card .bxC');return c?c.className:''})()"));n+=1
            return n,cards
        # ---- victory ----
        act('menu');act('stage:0');pg.wait_for_timeout(2000)
        st=''
        for k in range(80):
            st=pg.evaluate("(function(){var A=__arena();A.ps.forEach(function(p){p.hp=p.mhp;});A.enemies.forEach(function(e){e.hp=0;});return A.state;})()")
            if st=='over':break
            if st=='shop':act('next')
            pg.wait_for_timeout(300)
        pg.wait_for_timeout(1200)
        ok(tag+' victory reached',st=='over',st)
        ok(tag+' victory has a home button and the box button',pg.evaluate("!!document.querySelector('#ov .vsHm')&&!!document.querySelector('#ov .bxbtn')"))
        pg.screenshot(path=OUT+'/%s_victory.png'%tag)
        pg.evaluate("document.querySelector('#ov .bxbtn').click()");pg.wait_for_timeout(1300)
        has3=pg.evaluate("!!document.querySelector('#bx3 canvas')");has2=pg.evaluate("!!document.querySelector('#bx3 .bx2')")
        ok(tag+' box screen shows the 3D box (or the 2D fallback)',has3 or has2,'3d=%s 2d=%s'%(has3,has2))
        pg.screenshot(path=OUT+'/%s_box_idle.png'%tag)
        nitems=pg.evaluate("window._bx.items.length")
        pg.evaluate("document.querySelector('#ov .bx3Tap').click()");pg.wait_for_timeout(500);pg.screenshot(path=OUT+'/%s_box_burst.png'%tag);pg.wait_for_timeout(900)
        first=pg.evaluate("(function(){var c=document.querySelector('#bx3Card .bxC');return c?c.className:''})()")
        ok(tag+' first reward card pops out after opening',bool(first),first)
        pg.screenshot(path=OUT+'/%s_box_item1.png'%tag)
        n,cards=tapThrough()
        ok(tag+' each reward shown one by one, then the summary',pg.evaluate("!!document.querySelector('#ov .bxSum')") and n==nitems,'items=%d taps=%d %s'%(nitems,n,cards))
        ok(tag+' summary lists every reward',pg.evaluate("document.querySelectorAll('#ov .bxCh').length")==nitems)
        pg.screenshot(path=OUT+'/%s_box_sum.png'%tag)
        pg.evaluate("document.querySelector('#ov [data-a=bxd]').click()");pg.wait_for_timeout(600)
        ok(tag+' back on victory: box button gone, "opened" plate shown',pg.evaluate("!document.querySelector('#ov .bxbtn')&&!!document.querySelector('#ov .vsDone')&&!!document.querySelector('#ov .vsHm')"))
        ok(tag+' 3D box canvas removed after closing (only the celebrating hero stays)',pg.evaluate("!document.querySelector('#ov .bx3W')&&![].some.call(document.querySelectorAll('#ov canvas'),function(c){return !c.closest('#vsHero');})"))
        pg.screenshot(path=OUT+'/%s_victory_after.png'%tag)
        pg.evaluate("document.querySelector('#ov .vsHm').click()");pg.wait_for_timeout(900)
        ok(tag+' home button returns to the main menu',pg.evaluate("__arena().state")=='menu' and pg.evaluate("!!document.querySelector('#ov [data-main]')"),pg.evaluate("__arena().state"))
        # ---- hero reward card ----
        pg.evaluate("__arena().boxAnim(['🪙 +120','🦸 גיבור חדש: נובה 🌟'],3,null)");pg.wait_for_timeout(1300)
        pg.evaluate("document.querySelector('#ov .bx3Tap').click()");pg.wait_for_timeout(1300)
        for k in range(30):
            if pg.evaluate("window._bx&&window._bx.i>=0"):break
            pg.wait_for_timeout(200)
        pg.wait_for_timeout(400);pg.evaluate("document.querySelector('#ov .bx3Tap').click()");pg.wait_for_timeout(500)
        hc=pg.evaluate("(function(){var c=document.querySelector('#bx3Card .bxC.k-hero');return c?{img:!!c.querySelector('img'),fl:!!document.querySelector('#bx3Card .bxFlash'),rays:!!document.querySelector('#bx3Card .bxRays'),t:c.textContent}:null})()")
        ok(tag+' new hero: flashing legendary card with portrait',hc and hc['fl'] and 'נובה' in hc['t'],str(hc))
        pg.wait_for_timeout(700);pg.screenshot(path=OUT+'/%s_box_hero.png'%tag)
        pg.evaluate("document.querySelector('#ov .bx3Tap').click()");pg.wait_for_timeout(700)
        pg.evaluate("document.querySelector('#ov [data-a=bxd]').click()");pg.wait_for_timeout(700)
        ok(tag+' hero box closes back to menu',pg.evaluate("__arena().state")=='menu')
        # ---- skip ----
        pg.evaluate("__arena().boxAnim(['🪙 +50','💎 +5','⚡ +1 רמה: ברזל'],1,null)");pg.wait_for_timeout(900)
        pg.evaluate("document.querySelector('#ov .bx3Skip').click()");pg.wait_for_timeout(500)
        ok(tag+' skip jumps straight to the summary',pg.evaluate("document.querySelectorAll('#ov .bxCh').length")==3)
        # rapid taps must not break the order or skip rewards
        act('bxd');pg.wait_for_timeout(300)
        pg.evaluate("__arena().boxAnim(['🪙 +50','💎 +5','⚡ +1 רמה: ברזל'],2,null)");pg.wait_for_timeout(900)
        pg.evaluate("(function(){for(var k=0;k<12;k++){var t=document.querySelector('#ov .bx3Tap');if(t)t.click();}})()");pg.wait_for_timeout(1400)
        bi=pg.evaluate("window._bx&&window._bx.i")
        ok(tag+' a burst of taps only opens the box (rewards are not skipped)',bi==0,str(bi))
        act('bxd');pg.wait_for_timeout(300)
        # ---- shop box ----
        act('shop');pg.wait_for_timeout(500);act('bx1');pg.wait_for_timeout(1300)
        ok(tag+' shop box opens the box screen',pg.evaluate("!!document.querySelector('#ov .bx3W')"))
        n,cards=tapThrough()
        ok(tag+' shop box rewards shown (no unknown items)',n>=1 and all(('k-gold' in x or 'k-gem' in x or 'k-skin' in x) for x in cards if x),str(cards))
        act('bxd');pg.wait_for_timeout(600)
        ok(tag+' shop box returns to the shop',pg.evaluate("document.getElementById('ov').textContent.indexOf('חנות')>=0"))
        act('menu');pg.wait_for_timeout(300)
        ok(tag+' no JS errors',not E,str(E[:3]))
        c.close()
    print('SUMMARY %d/%d'%(sum(res),len(res)))
