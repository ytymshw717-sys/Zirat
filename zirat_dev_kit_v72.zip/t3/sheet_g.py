from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    pg=b.new_page(viewport={'width':1000,'height':1010});pg.on('pageerror',lambda e:print('ERR',e))
    pg.add_init_script(path='/home/claude/t/mock.js');pg.goto('file:///home/claude/arena3_gfx.html');pg.wait_for_timeout(4000)
    html=pg.evaluate("(function(){var h='';for(var i=0;i<20;i++)h+='<img src=\"'+G3.portrait(i,0,200)+'\" width=196 height=196 style=\"background:#334155;margin:2px\">';return h})()")
    pg.evaluate("(function(h){document.body.innerHTML='<div style=\"background:#1e293b;padding:2px;width:1000px;direction:ltr\">'+h+'</div>'})",html)
    pg.wait_for_timeout(300);pg.screenshot(path='/home/claude/t3/sheet.png')
