from playwright.sync_api import sync_playwright
import sys
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':1400,'height':1000});c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
    pg.goto('file:///home/claude/arena3_gfx.html');pg.wait_for_timeout(4000)
    for h in sys.argv[1].split(','):
        pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='hi:%s';document.getElementById('ov').appendChild(b);b.click();})()"%h);pg.wait_for_timeout(int(sys.argv[2]) if len(sys.argv)>2 else 600)
        pg.locator('#hvStage').screenshot(path='/home/claude/t3/hand_%s.png'%h)
    print(E[:3])
