# floating joystick: touching the left part of the screen in a match places the stick under the finger; never blocks menus
import sys,math
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
res=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for vp in ((844,390),(390,844)):
        tag='%dx%d'%vp
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=True,is_mobile=True,device_scale_factor=1);c.add_init_script(path='/home/claude/t/mock.js')
        pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
        pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3500)
        def act(a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(150)
        ok(tag+' zone hidden in the menu',pg.evaluate("getComputedStyle(document.getElementById('jzone')).display")=='none')
        act('menu');act('mode:survive');pg.wait_for_timeout(1500)
        ok(tag+' zone active in a match',pg.evaluate("getComputedStyle(document.getElementById('jzone')).display")=='block')
        pg.evaluate("(function(){var A=__arena();A.ps[0].hp=A.ps[0].mhp=1e5;A.ps[0].x=480;A.ps[0].y=270;A.obs.length=0;A.enemies.forEach(function(e){e.stun=99;e.x=40;e.y=40;});__yaw(0);})()")
        jr=pg.evaluate("(function(){var r=document.getElementById('js').getBoundingClientRect();return [r.left+r.width/2,r.top+r.height/2]})()")
        tx,ty=vp[0]*0.25,vp[1]*0.55
        hit=pg.evaluate("(function(){var e=document.elementFromPoint(%f,%f);return e&&e.id})()"%(tx,ty))
        ok(tag+' touch point on the left lands on the joystick zone',hit=='jzone',str(hit))
        cdp=c.new_cdp_session(pg)
        def tp(t,x,y):cdp.send('Input.dispatchTouchEvent',{'type':t,'touchPoints':[] if t=='touchEnd' else [{'x':x,'y':y,'id':1}]})
        a=pg.evaluate("[__arena().ps[0].x,__arena().ps[0].y]")
        tp('touchStart',tx,ty);pg.wait_for_timeout(80)
        jr2=pg.evaluate("(function(){var r=document.getElementById('js').getBoundingClientRect();return [r.left+r.width/2,r.top+r.height/2]})()")
        ok(tag+' stick jumps under the finger',abs(jr2[0]-tx)<6 and abs(jr2[1]-ty)<6,'%s vs %s'%(jr2,(tx,ty)))
        for i in range(1,5):tp('touchMove',tx+i*12,ty);pg.wait_for_timeout(40)
        pg.wait_for_timeout(1500);bb=pg.evaluate("[__arena().ps[0].x,__arena().ps[0].y]")
        tp('touchEnd',0,0);pg.wait_for_timeout(1200)
        d=math.hypot(bb[0]-a[0],bb[1]-a[1])
        ok(tag+' hero moves with the floating stick',d>15,str(d))
        jr3=pg.evaluate("(function(){var r=document.getElementById('js').getBoundingClientRect();return [r.left+r.width/2,r.top+r.height/2]})()")
        ok(tag+' stick returns home after release',abs(jr3[0]-jr[0])<4 and abs(jr3[1]-jr[1])<4,'%s vs %s'%(jr3,jr))
        st=pg.evaluate("__arena().ps[0].x");pg.wait_for_timeout(600)
        ok(tag+' hero stops after release',abs(pg.evaluate("__arena().ps[0].x")-st)<3)
        pg.evaluate("document.getElementById('pz').click()");pg.wait_for_timeout(300)
        ok(tag+' paused: zone gone, menu clickable',pg.evaluate("getComputedStyle(document.getElementById('jzone')).display")=='none')
        ok(tag+' no errors',not E,str(E[:2]))
        c.close()
    print('SUMMARY %d/%d'%(sum(res),len(res)))
