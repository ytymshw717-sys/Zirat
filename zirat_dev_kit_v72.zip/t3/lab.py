from playwright.sync_api import sync_playwright
F='file:///tmp/claude-0/-home-claude/b0ae6ea6-7673-5629-85ca-afcd48e28043/scratchpad/code-lab/index.html'
with sync_playwright() as p:
    b=p.chromium.launch();c=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2);pg=c.new_page()
    errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto(F);pg.wait_for_timeout(1200)
    print('hello iframe:',pg.frame_locator('#view').locator('h1').inner_text())
    pg.click('[data-l=math]');pg.wait_for_timeout(800);print('math out:',pg.inner_text('#out'))
    pg.fill('#js','var a = 1;\nVar tv = 5+7=12;');pg.click('#run');pg.wait_for_timeout(800);print('err1:',pg.inner_text('#out'))
    pg.fill('#js','var a = 1;\nvar b = 2;\nalert(tvv);');pg.click('#run');pg.wait_for_timeout(800);print('err2:',pg.inner_text('#out'))
    pg.fill('#js','alert(“שלום”);');pg.click('#run');pg.wait_for_timeout(800);print('smartquotes:',pg.inner_text('#out'))
    pg.click('[data-l=clicker]');pg.wait_for_timeout(800);f=pg.frame_locator('#view')
    for i in range(3):f.locator('#btn').click()
    print('clicker coins:',f.locator('#coins').inner_text())
    pg.screenshot(path='/home/claude/t3/lab.png',full_page=True)
    pg.reload();pg.wait_for_timeout(800);print('restored lesson:',pg.evaluate("document.querySelector('.lesson[aria-pressed=true]').dataset.l"),'js kept:',pg.input_value('#js')[:20])
    print('overflow:',pg.evaluate("document.documentElement.scrollWidth>innerWidth"),'errs',errs)
