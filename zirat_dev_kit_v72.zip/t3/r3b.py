import math
from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True,device_scale_factor=2)
    c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3500)
    pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='mode:survive';document.getElementById('ov').appendChild(b);b.click();})()");pg.wait_for_timeout(2500)
    pg.evaluate("__arena().enemies.forEach(function(e){e.stun=99;e.cd=99;})")
    for yaw in [0,1.57,3.14,0.8]:
        pg.evaluate("__yaw(%f);var p=__arena().ps[0];p.x=480;p.y=270;__arena().obs.length=0"%yaw);pg.wait_for_timeout(600)
        a=pg.evaluate("(function(){var p=__arena().ps[0];return [p.x,p.y]})()")
        pg.keyboard.down('KeyD');pg.wait_for_timeout(500);pg.keyboard.up('KeyD');pg.wait_for_timeout(500)
        r=pg.evaluate("(function(a){var p=__arena().ps[0];var A=G3.r3proj(a[0],a[1],0),B=G3.r3proj(p.x,p.y,0);return [B[0]-A[0],B[1]-A[1]]})(%s)"%a)
        dx,dy=r;print('yaw',yaw,'screen move',round(dx),round(dy))
    pg.screenshot(path='/home/claude/t3/r3_yaw.png')
    print(errs)
