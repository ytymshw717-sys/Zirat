from playwright.sync_api import sync_playwright
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True,device_scale_factor=2)
    c.add_init_script(path='/home/claude/t/mock.js')
    pg=c.new_page();pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append('con:'+m.text) if m.type=='error' else None)
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(1200);pg.screenshot(path='/home/claude/t3/s_splash.png')
    pg.wait_for_timeout(2400)
    print('3d ready',pg.evaluate("G3.ready()"),'menu img 3d',pg.evaluate("(document.querySelector('#ov .mhero img')||{}).naturalWidth"))
    pg.screenshot(path='/home/claude/t3/s_menu.png')
    pg.evaluate("document.querySelector('#ov [data-a=play]').click()");pg.wait_for_timeout(2500)
    pg.keyboard.down('KeyD');pg.wait_for_timeout(700);pg.screenshot(path='/home/claude/t3/s_play.png');pg.keyboard.up('KeyD')
    print('state',pg.evaluate("__arena().state"),'x',pg.evaluate("__arena().ps[0].x"))
    b.close()
print('ERR',errs)
