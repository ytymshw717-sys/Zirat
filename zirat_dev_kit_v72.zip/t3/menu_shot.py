import sys
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_gfx.html';tag=sys.argv[2] if len(sys.argv)>2 else 'm'
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for vp,n in [((844,390),'land'),((390,844),'port')]:
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=True,is_mobile=True,device_scale_factor=2)
        c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
        pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(5000)
        pg.screenshot(path='/home/claude/t3/%s_%s.png'%(tag,n));print(n,E[:2],pg.evaluate("[document.getElementById('ov').className,!!document.querySelector('#mStage.live'),document.documentElement.scrollWidth,innerWidth,document.getElementById('ov').scrollHeight,innerHeight]"));c.close()
