from playwright.sync_api import sync_playwright
res=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for vp in [(844,390),(390,844)]:
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=True,is_mobile=True,device_scale_factor=2);c.add_init_script(path='/home/claude/t/mock.js')
        pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
        pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(600)
        tag='%dx%d'%vp
        ok(tag+' loading screen shows the consent line',pg.evaluate("!!document.querySelector('#ov .splLg')"))
        pg.wait_for_timeout(3500)
        def act(a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;b.style.display='none';document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(400)
        act('menu');act('cfg')
        ok(tag+' settings has a privacy button',pg.evaluate("!!document.querySelector('#ov [data-a=\"legal:cfg\"]')"))
        pg.click('#ov [data-a="legal:cfg"]');pg.wait_for_timeout(500)
        t=pg.inner_text('#ov')
        ok(tag+' privacy + terms screen opens',all(w in t for w in ['מדיניות פרטיות','תנאי שימוש','PeerJS','localStorage','GitHub']))
        pg.screenshot(path='/home/claude/t3/legal_%s.png'%tag)
        pg.click('#ov [data-a="cfg"]');pg.wait_for_timeout(400)
        ok(tag+' back returns to settings',pg.evaluate("!!document.querySelector('#ov [data-a=\"legal:cfg\"]')"))
        c.close()
    c=b.new_context(viewport={'width':844,'height':390});c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page()
    pg.goto('file:///home/claude/arena3_new.html#privacy');pg.wait_for_timeout(7000)
    ok('link with #privacy opens the policy directly','מדיניות פרטיות' in pg.inner_text('#ov'))
    print('SUMMARY %d/%d'%(sum(res),len(res)))
