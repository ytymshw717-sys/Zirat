# gallery: every ranged hero's projectile in flight + its impact, every melee hero's swing, specials and supers
import sys
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
WHICH=[int(x) for x in sys.argv[2].split(',')] if len(sys.argv)>2 else list(range(20))
OUT='/home/claude/t3/gal'
import os;os.makedirs(OUT,exist_ok=True)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},device_scale_factor=2);c.add_init_script(path='/home/claude/t/mock.js')
    c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify({owned:[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19],gold:500,dm:60,xp:5000,lv:{0:5,1:5,2:5,3:5,4:5,5:5,6:5,7:5,8:5,9:5,10:5,11:5,12:5,13:5,14:5,15:5,16:5,17:5,18:5,19:5}}))}catch(e){}')
    pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)));pg.on('console',lambda m:E.append(m.text) if m.type=='error' else None)
    pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3500)
    def act(a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(200)
    def clip(name):
        r=pg.evaluate("(function(){var p=__arena().ps[0],c=document.getElementById('cv').getBoundingClientRect();var q=G3.r3proj(p.x+90,p.y,1);return [q[0]*c.width/(360*(c.width/c.height)),q[1]*c.height/360,c.left,c.top]})()")
        x,y=r[0]+r[2],r[1]+r[3];pg.screenshot(path='%s/%s.png'%(OUT,name),clip={'x':max(0,x-210),'y':max(0,y-140),'width':420,'height':230})
    for h in WHICH:
        act('menu');act('pk:0:%d'%h);act('menu');act('mode:survive');pg.wait_for_timeout(1800)
        for i in range(30):
            if pg.evaluate('__arena().enemies.length')>=1:break
            pg.wait_for_timeout(200)
        pg.evaluate("(function(){var A=__arena(),p=A.ps[0];p.hp=1e5;A.enemies.forEach(function(e,j){e.stun=99;e.cd=99;e.rcd=99;e.x=p.x+190+j*25;e.y=p.y+(j%2?30:-20);});p.fx=1;p.fy=0;})()")
        pg.evaluate("(function(){var p=__arena().ps[0];p.cd=0;p.fx=1;p.fy=0;})()");pg.keyboard.down('Space');pg.wait_for_timeout(40);pg.keyboard.up('Space')
        pg.wait_for_timeout(260);clip('h%02d_a_fly'%h)
        pg.wait_for_timeout(500);clip('h%02d_b_hit'%h)
        # special (spin) and super
        pg.evaluate("(function(){var p=__arena().ps[0];p.spcd=0;})()");pg.keyboard.down('KeyK');pg.wait_for_timeout(60);pg.keyboard.up('KeyK');pg.wait_for_timeout(250);clip('h%02d_c_special'%h)
        pg.wait_for_timeout(600)
        pg.evaluate("(function(){var p=__arena().ps[0];p.sup=100;p.manS=false;})()");pg.keyboard.down('KeyL');pg.wait_for_timeout(60);pg.keyboard.up('KeyL');pg.wait_for_timeout(300);clip('h%02d_d_super'%h)
        pg.wait_for_timeout(500);clip('h%02d_e_super2'%h)
        print(h,'state',pg.evaluate('__arena().state'),'r3',pg.evaluate("(function(s){return [s.calls,s.low,s.fx]})(G3.r3state())"),flush=True)
    print('errors',E[:5])
