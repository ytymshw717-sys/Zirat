import sys,json
from playwright.sync_api import sync_playwright
H=sys.argv[1] if len(sys.argv)>1 else '7'
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True,device_scale_factor=2);c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
    pg.goto('file:///home/claude/arena3_gfx.html');pg.wait_for_timeout(3500)
    pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='hi:%s';document.getElementById('ov').appendChild(b);b.click();})()"%H);pg.wait_for_timeout(900)
    r=pg.evaluate("""(function(){var v=G3._v();if(!v)return null;v.g.updateMatrixWorld(true);var inv=new THREE.Matrix4().copy(v.g.matrixWorld).invert();
     function P(o){var p=new THREE.Vector3();o.getWorldPosition(p);p.applyMatrix4(inv);return [+p.x.toFixed(3),+p.y.toFixed(3),+p.z.toFixed(3)];}
     var bb=new THREE.Box3();v.g.traverse(function(o){if(o.isMesh&&o!==v.ring&&o.visible&&!o.userData.ol){o.geometry.computeBoundingBox();var b2=o.geometry.boundingBox.clone().applyMatrix4(new THREE.Matrix4().multiplyMatrices(inv,o.matrixWorld));bb.union(b2);}});
     return {bb:[bb.min.toArray().map(x=>+x.toFixed(3)),bb.max.toArray().map(x=>+x.toFixed(3))],legs:v.legs.map(P),knee:v.knee.map(P),arms:v.arms.map(P),fore:v.fore.map(P),head:P(v.head),torso:P(v.torso),wp:P(v.wp),gs:v.g.scale.x,headScale:v.head.scale.x};})()""")
    print(json.dumps(r));print('E',E[:3])
