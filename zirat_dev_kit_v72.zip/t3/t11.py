from playwright.sync_api import sync_playwright
res=[];errs=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for vp,mob in [((844,390),True),((390,844),True),((1280,720),False)]:
        tag='%dx%d'%vp
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=mob,is_mobile=mob,device_scale_factor=2 if mob else 1)
        c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();pg.on('pageerror',lambda e:errs.append(tag+str(e)))
        pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3600)
        def act(a):
            t=pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='%s';document.getElementById('ov').appendChild(b);var t=performance.now();b.click();return performance.now()-t})()"%a);pg.wait_for_timeout(60);return t
        t=act('hi:0');ok(tag+' hero window opens fast',t<300,'%.0fms'%t)
        pg.wait_for_timeout(1500)
        s=pg.evaluate("G3.showState()");ok(tag+' live 3D model on stage',s and s['live'] and s['inDom'] and pg.evaluate("document.getElementById('hvStage').classList.contains('live')"),str(s))
        ok(tag+' stage canvas has pixels',pg.evaluate("(function(){var c=document.querySelector('#hvStage canvas');return c&&c.width>100&&c.height>100})()"))
        pg.screenshot(path='/home/claude/t3/hv_%s.png'%tag)
        # animation running: model pose changes over time
        a1=pg.evaluate("G3.showState().act");pg.evaluate("G3.showPlay('kick')");pg.wait_for_timeout(500);a2=pg.evaluate("G3.showState().act")
        ok(tag+' plays actions (kick)',a2=='kick',str((a1,a2)))
        pg.wait_for_timeout(7000);ok(tag+' action ends, idle continues',pg.evaluate("G3.showState().act")!='kick')
        # drag rotate
        box=pg.evaluate("(function(){var r=document.getElementById('hvStage').getBoundingClientRect();return [r.left+r.width/2,r.top+r.height/2]})()")
        y0=pg.evaluate("G3.showState().yaw")
        if mob:
            cdp=c.new_cdp_session(pg)
            def tp(tt,pts):cdp.send('Input.dispatchTouchEvent',{'type':tt,'touchPoints':pts})
            tp('touchStart',[{'x':box[0],'y':box[1],'id':1}])
            for i in range(1,11):tp('touchMove',[{'x':box[0]+i*15,'y':box[1],'id':1}]);pg.wait_for_timeout(20)
            tp('touchEnd',[])
        else:
            pg.mouse.move(box[0],box[1]);pg.mouse.down()
            for i in range(10):pg.mouse.move(box[0]+i*15,box[1]);pg.wait_for_timeout(20)
            pg.mouse.up()
        y1=pg.evaluate("G3.showState().yaw")
        ok(tag+' drag rotates model',abs(y1-y0)>1.0,'%.2f -> %.2f'%(y0,y1))
        # tap → action
        pg.wait_for_timeout(300)
        if mob:tp('touchStart',[{'x':box[0],'y':box[1],'id':2}]);tp('touchEnd',[])
        else:pg.mouse.click(box[0],box[1])
        pg.wait_for_timeout(100);ok(tag+' tap plays a move',pg.evaluate("G3.showState().act") is not None)
        # skin preview does not change saved skin
        sk0=pg.evaluate("A3.sv.sk[0]||0");act('hsk:0:2');pg.wait_for_timeout(800)
        ok(tag+' skin preview shows on model',pg.evaluate("G3.showState().key")=='0_2')
        ok(tag+' preview does not change saved skin',pg.evaluate("A3.sv.sk[0]||0")==sk0 and 'תצוגה מקדימה' in pg.inner_text('#ov'))
        # hero strip switch
        n=pg.evaluate("document.querySelectorAll('#ov .hvH').length");ok(tag+' hero strip lists all heroes',n==20,str(n))
        pg.evaluate("document.querySelectorAll('#ov .hvH')[5].click()");pg.wait_for_timeout(800)
        ok(tag+' choose hero from strip shows it',pg.evaluate("G3.showState().key").startswith('5_') and pg.evaluate("A3.CH[5].nk") in pg.inner_text('#ov h1'))
        ok(tag+' info shown (rarity, level, stats, abilities)',all(x in pg.inner_text('#ov') for x in ['רמה','חיים','מהירות','התקפה','מכת־על','כלי עזר']))
        ok(tag+' no sideways overflow',pg.evaluate("document.getElementById('ov').scrollWidth<=document.getElementById('ov').clientWidth+1"))
        # leaving stops animation
        act('menu');pg.wait_for_timeout(300);ok(tag+' leaving window: 3D stage leaves the hero window (moves to the menu stage or stops)',not pg.evaluate("!!document.querySelector('#hvStage canvas')") and (not pg.evaluate("G3.showState().live") or pg.evaluate("!!document.querySelector('#mStage canvas')")))
        # reopen many times, single canvas reused
        for i in range(6):act('hi:%d'%i);pg.wait_for_timeout(150)
        ok(tag+' reopening reuses one stage canvas',pg.evaluate("document.querySelectorAll('#hvStage canvas').length")==1)
        act('menu')
        # frame rate in showcase
        act('hi:1');pg.wait_for_timeout(800)
        pg.evaluate("window.__ft=[];(function f(t){window.__ft.push(t);if(window.__ft.length<60)requestAnimationFrame(f);})(performance.now())");pg.wait_for_timeout(4000)
        print(tag,'showcase frame ms median/p95',pg.evaluate("(function(){var a=window.__ft,d=[];for(var i=1;i<a.length;i++)d.push(a[i]-a[i-1]);d.sort(function(x,y){return x-y});return [d.length,Math.round(d[Math.floor(d.length/2)]),Math.round(d[Math.floor(d.length*.95)])]})()"))
        act('menu')
        # renamed texts
        act('maps');t=pg.inner_text('#ov');ok(tag+' new map names',all(x in t for x in ['עמק הזוהר','דיונות השמש','סבך הניאון']) and 'יער הקסמים' not in t)
        act('menu');act('cat:md');t=pg.inner_text('#ov');ok(tag+' new mode names',all(x in t for x in ['כדור זירה','האחרון שנשאר','ציד קריסטלים','מוקד הלהבה','שוד האוצר']) and 'בראול' not in t)
        act('menu');ok(tag+' no Brawl terms anywhere in page source', pg.evaluate("(function(){var h=document.documentElement.innerHTML;return !/בראול|שואו־דאון|גאדג|קוביית כוח|פס מלך/.test(h)})()"))
        c.close()
    b.close()
print('ERRORS',errs);print('SUMMARY %d/%d'%(sum(res),len(res)))
