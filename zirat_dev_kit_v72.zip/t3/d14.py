from playwright.sync_api import sync_playwright
import time
mock=open('/home/claude/t/mock.js').read().replace('window.__skipIntro=1;','')
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2);c.add_init_script(script=mock+";window.__log=[];setInterval(function(){try{window.__log.push([Math.round(performance.now()),!!document.getElementById('introL'),!!document.querySelector('#ov [data-sp]'),!!document.querySelector('#ov [data-a=play]')].join(','));}catch(e){}},100);")
    pg=c.new_page();pg.on('pageerror',lambda e:print('ERR',e));pg.on('console',lambda m:print('CON',m.text))
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(9000)
    L=pg.evaluate("window.__log");prev=None
    for x in L:
        k=x.split(',',1)[1]
        if k!=prev:print(x);prev=k
