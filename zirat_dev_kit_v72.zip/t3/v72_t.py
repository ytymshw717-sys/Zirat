# v72: no wave shop, regen, auto-fire (+AUTO button), pause without sound/camera, settings rows, 3D mode hidden, save migration, calmer arms
import sys,math
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
res=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
SAVE='heroes_arena_save'
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    def page(w,h,save=None,nomig=True):
        c=b.new_context(viewport={'width':w,'height':h},has_touch=True,is_mobile=True);c.add_init_script(path='/home/claude/t/mock.js')
        if not nomig:c.add_init_script(script='window.__NOMIG=0;')
        if save:c.add_init_script(script='try{if(!sessionStorage.getItem("s0")){sessionStorage.setItem("s0",1);localStorage.setItem("%s",%r)}}catch(e){}'%(SAVE,save))
        pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)));pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3000);return c,pg,E
    def act(pg,a,t=200):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(t)
    def play(pg,md):
        act(pg,'menu');act(pg,'cat:md');act(pg,'sm:'+md);act(pg,'play',1200)
        for i in range(60):
            if pg.evaluate("__arena().state==='play'"):break
            pg.wait_for_timeout(200)
    # ---- survive: no shop, full heal between waves, regen, auto-fire ----
    c,pg,E=page(844,390,'{"owned":[0,1,3,5],"gold":500,"dm":60,"cfg":{"r3":false,"mu":false}}')
    play(pg,'survive')
    for i in range(40):
        if pg.evaluate("__arena().enemies.length>0"):break
        pg.wait_for_timeout(200)
    pg.evaluate("(function(){var A=__arena();A.ps[0].inv=99;A.ps[0].hp=Math.round(A.ps[0].mhp*.4);A.enemies.forEach(function(e){e.hp=0;});})()")
    st=pg.evaluate("(function(){var A=__arena();A.sim(20);var B=__arena();return [B.state,B.wave,B.ps[0].hp,B.ps[0].mhp]})()")
    ok('wave cleared → keeps playing (no shop), full health',st[0]=='play' and st[2]==st[3],str(st))
    st=pg.evaluate("(function(){var A=__arena();A.sim(100);var B=__arena();return [B.state,B.wave,B.enemies.length]})()")
    ok('next wave starts by itself',st[0]=='play' and st[1]>=2 and st[2]>0,str(st))
    # regen: rivals frozen far away, no damage for 3s → health climbs
    pg.evaluate("(function(){var A=__arena(),p=A.ps[0];A.enemies.forEach(function(e){e.stun=99;e.x=p.x>300?40:900;e.y=40;e.cd=99;});A.eshots.length=0;p.hp=Math.round(p.mhp*.4);p.lhp=p.hp;p.rgT=0;})()")
    r=pg.evaluate("(function(){var A=__arena(),p=A.ps[0],h0=p.hp;A.sim(60);var h1=__arena().ps[0].hp;A.sim(90);var p2=__arena().ps[0];return [h0,h1,p2.hp,p2.mhp]})()")
    ok('no regen in the first 2s after a hit',abs(r[1]-r[0])<1,str(r))
    ok('regen after 3s without damage (~12%/s)',r[2]>r[0]+0.15*r[3],str(r))
    pg.evaluate("(function(){var A=__arena(),p=A.ps[0];p.hp=Math.round(p.mhp*.5);p.lhp=p.hp;p.rgT=5;A.sim(1);p.hp-=10;A.sim(30);})()")
    r=pg.evaluate("(function(){var p=__arena().ps[0];return [p.rgT,p.hp,p.mhp]})()")
    ok('taking a hit resets the regen timer',r[0]<1.2,str(r))
    # auto-fire off: a rival right in front, nothing fires
    def setup():
        return pg.evaluate("""(function(){var A=__arena(),p=A.ps[0],e=A.enemies.filter(function(e){return e.hp>0})[0];A.enemies.forEach(function(o){if(o!==e){o.x=p.x>300?40:900;o.y=40;}o.stun=99;o.cd=99;});
          e.x=p.x+Math.min(40,(p.ch.rng||60)*.5);e.y=p.y;e.hid=false;e.hp=Math.max(e.hp,999);e.maxhp=Math.max(e.maxhp||0,999);p.cd=0;return [e.hp,p.ch.kind||'-',p.ch.rng]})()""")
    s0=setup();h=pg.evaluate("(function(){var A=__arena();A.sim(15);var e=__arena().enemies.filter(function(e){return e.hp>0}).sort(function(a,b){return Math.hypot(a.x-A.ps[0].x,a.y-A.ps[0].y)-Math.hypot(b.x-A.ps[0].x,b.y-A.ps[0].y)})[0];return [e.hp,A.ps[0].cd]})()")
    ok('auto-fire OFF: no shot by itself',h[1]<=0.001 and abs(h[0]-s0[0])<1,str(s0)+str(h))
    vis=pg.evaluate("(function(){var r=document.getElementById('afb').getBoundingClientRect();return r.width>40&&getComputedStyle(document.getElementById('afb')).display!=='none'})()")
    ok('🎯 AUTO button shows in battle',vis)
    pg.evaluate("document.getElementById('afb').click()");pg.wait_for_timeout(150)
    ok('AUTO button turns on + saves',pg.evaluate("document.getElementById('afb').classList.contains('on')&&JSON.parse(localStorage.getItem('%s')).cfg.af===true"%SAVE))
    s0=setup();h=pg.evaluate("(function(){var A=__arena();A.sim(15);var B=__arena();return [B.ps[0].cd,B.shots.length,B.enemies.filter(function(e){return e.hp>0}).map(function(e){return Math.round(e.hp)}).slice(0,3)]})()")
    ok('auto-fire ON: hero attacks the rival in reach',h[0]>0,str(s0)+str(h))
    pg.evaluate("(function(){var A=__arena(),p=A.ps[0];A.enemies.forEach(function(o){o.x=p.x>300?40:900;o.y=40;o.stun=99;});p.cd=0;})()")
    h=pg.evaluate("(function(){var A=__arena();A.sim(10);return __arena().ps[0].cd})()")
    ok('auto-fire ON: no rival in reach → no shot',h<=0.001,str(h))
    pg.evaluate("document.getElementById('afb').click()");pg.wait_for_timeout(100)
    # pause: no sound/camera rows any more
    pg.evaluate("document.getElementById('pz').click()");pg.wait_for_timeout(250)
    ok('pause = resume + menu only (sound/camera moved)',pg.evaluate("!document.querySelector('#ov [data-a=psnd]')&&!document.querySelector('#ov [data-a^=pyaw]')&&!!document.querySelector('#ov [data-a=res]')"))
    act(pg,'res');ok('no errors (survive)',not E,str(E[:3]));c.close()
    # ---- settings (landscape painted + portrait) ----
    for (w,h) in [(844,390),(390,844)]:
        tag='%dx%d'%(w,h)
        c,pg,E=page(w,h)
        act(pg,'menu');act(pg,'cfg',400)
        q=pg.evaluate("(function(){var o=document.getElementById('ov');return [!!o.querySelector('[data-a=\"tg:af\"]'),!!o.querySelector('[data-a=\"cyaw:1\"]'),!!o.querySelector('[data-a=\"tg:v25\"]')||!!o.querySelector('[data-a=\"tg:r3\"]')||!!o.querySelector('[data-a=\"tg:c3\"]'),!!o.querySelector('[data-a=\"tg:sn\"]')]})()")
        ok(tag+' settings: auto-fire + camera rows, sound stays, style switches gone',q==[True,True,False,True],str(q))
        pg.evaluate("document.querySelector('#ov [data-a=\"cyaw:1\"]').click()");pg.wait_for_timeout(250)
        y=pg.evaluate("[__yaw(),JSON.parse(localStorage.getItem('%s')).cfg.yaw,document.getElementById('ov').innerText.indexOf('45°')>=0]"%SAVE)
        ok(tag+' camera ⟳ → 45°, saved, shown',abs(y[0]-math.pi/4)<.02 and abs(y[1]-math.pi/4)<.02 and y[2],str(y))
        pg.evaluate("document.querySelector('#ov [data-a=\"tg:af\"]').click()");pg.wait_for_timeout(250)
        ok(tag+' auto-fire switch on in settings',pg.evaluate("JSON.parse(localStorage.getItem('%s')).cfg.af===true&&!!document.querySelector('#ov [data-a=\"tg:af\"].on, #ov .tg [data-a=\"tg:af\"].on2')"%SAVE))
        if w>h:
            pg.screenshot(path='/home/claude/ui/shots/v72_settings_%s.png'%tag)
            pg.reload();pg.wait_for_timeout(3000)
            ok(tag+' camera angle kept after reload',abs(pg.evaluate("__yaw()")-math.pi/4)<.02)
        act(pg,'menu');act(pg,'cat:md',300)
        ok(tag+' modes list: no "קרב 3D"',not pg.evaluate("!!document.querySelector('#ov [data-a=\"sm:3d\"]')"))
        ok(tag+' no errors',not E,str(E[:3]));c.close()
    # ---- old save with style switches off → back to the 3D world once ----
    c,pg,E=page(844,390,'{"owned":[0,1,3,5],"gold":500,"cfg":{"r3":false,"c3":false,"v25":false}}',nomig=False)
    m=pg.evaluate("(function(){var c=__arena().sv.cfg;return [c.r3,c.c3,c.v25,c.m72]})()")
    ok('old save: style switches reset to 3D',m==[True,True,True,1],str(m));c.close()
    # ---- calmer arms: guard keeps hands down, shoot raises one arm only ----
    c,pg,E=page(844,390)
    act(pg,'menu',1500)
    pg.evaluate("G3._frz('guard',.5,0)");pg.wait_for_timeout(700)
    g=pg.evaluate("(function(){var v=G3._v();return [v.arms[0].rotation.x,v.arms[1].rotation.x,v.arms[0].rotation.z,v.arms[1].rotation.z]})()")
    ok('menu guard: arms down at the sides (not raised to the middle)',abs(g[0])<.3 and abs(g[1])<.3 and g[2]>0 and g[3]<0,str([round(x,2) for x in g]))
    pg.evaluate("G3._frz('shoot',.5,0)");pg.wait_for_timeout(700)
    g=pg.evaluate("(function(){var v=G3._v();return [v.arms[0].rotation.x,v.arms[1].rotation.x,v.arms[0].rotation.z]})()")
    ok('menu shoot: one arm aims, the other stays down and out',g[1]<-1 and g[0]>-0.1 and g[2]>0,str([round(x,2) for x in g]))
    pg.evaluate("G3._frz(null)");ok('no errors (arms)',not E,str(E[:3]));c.close()
print('SUMMARY %d/%d'%(sum(res),len(res)))
