from playwright.sync_api import sync_playwright
THREE=open('/home/claude/mrdoob/three.js/build/three.min.js','rb').read()
errs=[]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for vp in [(844,390),(390,844)]:
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=True,is_mobile=True,device_scale_factor=2)
        c.add_init_script(path='/home/claude/t/mock.js');c.route('**/three.min.js',lambda r:r.fulfill(status=200,body=THREE,headers={'content-type':'application/javascript'}))
        pg=c.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
        pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3600)
        print(vp,'3d ready',pg.evaluate("G3.ready()"),'3d imgs in menu',pg.evaluate("[].filter.call(document.querySelectorAll('#ov img'),function(i){return i.naturalWidth>0}).length"))
        pg.screenshot(path='/home/claude/t3/p3_menu_%dx%d.png'%vp)
        pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='hi:0';document.getElementById('ov').appendChild(b);b.click();})()");pg.wait_for_timeout(500)
        pg.screenshot(path='/home/claude/t3/p3_hi_%dx%d.png'%vp)
        c.close()
print('ERR',errs)
