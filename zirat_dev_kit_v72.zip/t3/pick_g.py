from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True,device_scale_factor=2);c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
    pg.goto('file:///home/claude/arena3_gfx.html');pg.wait_for_timeout(3500)
    pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='pick:0';document.getElementById('ov').appendChild(b);b.click();})()")
    for i in range(40):
        pg.wait_for_timeout(500)
        if pg.evaluate("[].slice.call(document.querySelectorAll('#ov button img')).every(function(i){return i.src.indexOf('data:image/png')==0})"):break
    pg.screenshot(path='/home/claude/t3/pick_ninja.png',clip={'x':0,'y':100,'width':390,'height':130})
    print('errors',E[:3])
