from playwright.sync_api import sync_playwright
THREE=open('/home/claude/mrdoob/three.js/build/three.min.js','rb').read()
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':1280,'height':720});c.add_init_script(path='/home/claude/t/mock.js')
    c.route('**/three.min.js',lambda r:r.fulfill(status=200,body=THREE,headers={'content-type':'application/javascript'}))
    pg=c.new_page();pg.on('pageerror',lambda e:print('ERR',e))
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3300)
    pg.evaluate("document.querySelector('[data-a=\"sm:3d\"]').click()");pg.evaluate("document.querySelector('#ov [data-a=play]').click()")
    pg.wait_for_function("window.__g3&&__g3.st()",timeout=20000)
    for i in range(6):pg.wait_for_timeout(700);print(pg.evaluate("[__g3.st().paused,__g3.st().fps,document.hasFocus()]"))
    pg.keyboard.press('Escape');pg.wait_for_timeout(200);print('after esc',pg.evaluate("__g3.st().paused"))
    pg.click('#g3 [data-g3=res]');
    for i in range(4):pg.wait_for_timeout(300);print(pg.evaluate("__g3.st().paused"))
    pg.evaluate("__g3.freeze(false);__g3.set('p',{hp:12,x:0,z:4});__g3.set('e',{x:0,z:2.5});__g3.manual()")
    for i in range(40):
        pg.evaluate("__g3.step(30,1/60)");s=pg.evaluate("__g3.st()")
        if i%5==0 or s['over']:print(i,s['paused'],s['over'],s['p']['hp'],s['e']['phase'],round(s['e']['x'],2),round(s['e']['z'],2),s['hits'],s['e']['rng'])
        if s['over']:break

