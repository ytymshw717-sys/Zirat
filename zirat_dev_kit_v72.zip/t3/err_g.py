from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    pg=b.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)));pg.on('console',lambda m:E.append(m.type+':'+m.text[:300]) if m.type in('error','warning') else None)
    pg.add_init_script(path='/home/claude/t/mock.js');pg.goto('file:///home/claude/arena3_gfx.html');pg.wait_for_timeout(4000)
    pg.evaluate("G3.portrait(13,0,300)");print(E[:6])
