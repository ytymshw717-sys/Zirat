# crawler: from every screen, press every visible button once; record JS errors, blank screens and stuck states
import sys,json,re
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
START=['menu','pick:0','heroes','hi:0','hi:7','hp:0:2','shop','skall','cat:rw','cat:hr','cat:md','cat:shop','maps','cfg','prof','online','tr','qs','pass','skins:0']
SKIP=re.compile(r'^(reset|wipe|del|xfer|imp|exp|copy|share|sv?go|olink|oq|oh|oj|onew|ojoin|oleave|room)')
out={'errors':[],'blank':[],'clicked':0,'screens':0}
with sync_playwright() as p:
    b=p.chromium.launch()
    for vp in [(844,390),(390,844)]:
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=True,is_mobile=True)
        c.add_init_script(path='/home/claude/t/mock.js');c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify({owned:[0,1,3,5],gold:5000,dm:500}))}catch(e){};window.open=function(u){(window.__opened=window.__opened||[]).push(u);return null};window.confirm=function(){return false};window.alert=function(){};window.prompt=function(){return null};')
        pg=c.new_page();E=[]
        pg.on('pageerror',lambda e:E.append(str(e)));pg.on('console',lambda m:E.append('console: '+m.text) if m.type=='error' else None)
        pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3500)
        def act(a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;b.style.display='none';document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(120)
        def norm():
            st=pg.evaluate("__arena().state")
            if st in('play','pause','shop','over'):
                pg.keyboard.press('KeyP');pg.wait_for_timeout(80);act('menu')
            act('menu')
        for s in START:
            norm();act(s);out['screens']+=1
            btns=pg.evaluate("[].map.call(document.querySelectorAll('#ov [data-a]'),function(b){var r=b.getBoundingClientRect();return r.width>1&&getComputedStyle(b).display!=='none'?b.dataset.a:null}).filter(Boolean)")
            seen=set()
            for a in btns:
                if a in seen or SKIP.match(a) or a in('play',):continue
                seen.add(a);n0=len(E)
                norm();act(s)
                ok=pg.evaluate("(function(a){var b=[].filter.call(document.querySelectorAll('#ov [data-a]'),function(x){return x.dataset.a===a})[0];if(!b)return false;b.click();return true})(%s)"%json.dumps(a))
                if not ok:continue
                pg.wait_for_timeout(150);out['clicked']+=1
                st=pg.evaluate("[__arena().state,document.getElementById('ov').classList.contains('hide'),document.getElementById('ov').innerText.trim().length]")
                if not st[1] and st[2]<2 and st[0]=='menu':out['blank'].append('%dx%d %s -> %s'%(vp[0],vp[1],s,a))
                if len(E)>n0:out['errors'].append('%dx%d %s -> %s: %s'%(vp[0],vp[1],s,a,E[n0][:160]))
        c.close()
print(json.dumps(out,ensure_ascii=False,indent=1)[:4000])
okk=not out['errors'] and not out['blank'];print(('PASS' if okk else 'FAIL')+' crawler: %d buttons pressed on %d screens, errors %d, blank screens %d'%(out['clicked'],out['screens'],len(out['errors']),len(out['blank'])));print('SUMMARY %d/1'%(1 if okk else 0))
