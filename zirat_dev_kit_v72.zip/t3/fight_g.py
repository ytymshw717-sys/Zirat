from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True,device_scale_factor=2)
    c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();errs=[];pg.on('pageerror',lambda e:errs.append(str(e)));pg.on('console',lambda m:errs.append('con:'+m.text) if m.type=='error' else None)
    pg.goto('file:///home/claude/arena3_gfx.html');pg.wait_for_timeout(3500)
    pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='sm:3d';document.getElementById('ov').appendChild(b);b.click();})()");pg.wait_for_timeout(200)
    pg.evaluate("document.querySelector('#ov [data-a=play]').click()")
    pg.wait_for_function("window.__g3&&__g3.st()",timeout=20000);pg.wait_for_timeout(800)
    pg.keyboard.down('KeyW');pg.wait_for_timeout(1500);pg.keyboard.up('KeyW');pg.keyboard.down('Space');pg.wait_for_timeout(700)
    pg.screenshot(path='/home/claude/t3/fight_g.png');pg.keyboard.up('Space')
    print(pg.evaluate("__g3.st()"),errs[:5])
