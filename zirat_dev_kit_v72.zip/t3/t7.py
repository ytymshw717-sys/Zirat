from playwright.sync_api import sync_playwright
res=[];errs=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch()
    for vp,mob in [((844,390),True),((932,430),True),((667,375),True),((390,844),True),((1280,720),False)]:
        tag='%dx%d'%vp
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=mob,is_mobile=mob)
        c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();pg.on('pageerror',lambda e:errs.append(tag+':'+str(e)))
        pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3300)
        def click(a):
            n=pg.evaluate("(function(){var b=[].filter.call(document.querySelectorAll('#ov [data-a]'),function(x){return x.dataset.a==='%s'})[0];if(!b)return 0;b.click();return 1})()"%a);pg.wait_for_timeout(70);return n
        def txt():return pg.inner_text('#ov')
        def main():return pg.evaluate("!!document.querySelector('#ov [data-menu]')")
        # layout of main menu
        lay=pg.evaluate("""(function(){var bs=[].slice.call(document.querySelectorAll('#ov button')).filter(function(b){var r=b.getBoundingClientRect();return r.width>0}),bad=[];
          function vis(b){var r=b.getBoundingClientRect();return r.left>=-1&&r.right<=innerWidth+1&&r.top>=-1&&r.bottom<=innerHeight+1;}
          bs.forEach(function(b,i){if(!vis(b))bad.push('off:'+b.dataset.a);bs.slice(i+1).forEach(function(c){if(b.contains(c)||c.contains(b))return;var r=b.getBoundingClientRect(),q=c.getBoundingClientRect();if(r.left<q.right-2&&q.left<r.right-2&&r.top<q.bottom-2&&q.top<r.bottom-2)bad.push(b.dataset.a+'x'+c.dataset.a);});});
          return {n:bs.length,bad:bad,ow:document.getElementById('ov').scrollWidth>document.getElementById('ov').clientWidth+1};})()""")
        ok(tag+' main menu: all buttons on screen, none overlap, no sideways scroll',not lay['bad'] and not lay['ow'],'buttons=%d %s'%(lay['n'],lay['bad'][:4]))
        pg.screenshot(path='/home/claude/t3/ui_%s.png'%tag)
        for a in ['shop','cat:rw','cat:hr','maps','cat:md','play']:
            ok(tag+' main has '+a,pg.evaluate("[].some.call(document.querySelectorAll('#ov [data-a]'),function(x){return x.dataset.a==='%s'})"%a))
        # shop
        click('shop');ok(tag+' 🛒 opens shop','חנות' in txt());click('menu');ok(tag+' shop back → main',main())
        # rewards category
        click('cat:rw');ok(tag+' 🎁 opens rewards window','פרסים' in txt())
        for a,w in [('cg:rw:qs','משימות'),('cg:rw:pass','מסלול'),('cg:rw:tr','גביעים')]:
            click(a);t=txt();ok(tag+' rewards → '+a.split(':')[2],w in t,t[:20].replace('\n',' '))
            click('menu');ok(tag+'   back → rewards window','פרסים' in txt() and not main())
        click('menu');ok(tag+' rewards back → main',main())
        # heroes category
        click('cat:hr');ok(tag+' 🦸 opens heroes window','גיבורים' in txt())
        for a,chk in [('cg:hr:heroes',"document.querySelectorAll('#ov [data-a^=\"hi:\"]').length>=20"),('cg:hr:pick:0',"document.querySelectorAll('#ov [data-a^=\"hp:\"]').length>0"),('cg:hr:prof',"!!document.getElementById('pnm')"),('cg:hr:skall',"document.querySelectorAll('#ov img').length>=80")]:
            click(a);ok(tag+' heroes → '+a.split(':')[2],pg.evaluate(chk));click('menu');ok(tag+'   back → heroes window','גיבורים' in txt() and not main())
        h0=pg.evaluate("A3.sel()");click('cg:hr:hi:%d'%h0);ok(tag+' heroes → my hero window',pg.evaluate("!!document.getElementById('hiSk')"));click('menu');ok(tag+'   back → heroes window','גיבורים' in txt())
        click('menu');ok(tag+' heroes back → main',main())
        # maps
        click('maps');ok(tag+' 🗺️ opens maps (all worlds)',pg.evaluate("document.querySelectorAll('#ov [data-a^=\"mp:\"]').length")>=9)
        click('mp:2');ok(tag+' choose map returns to main',main())
        # skins gallery
        click('cat:hr');click('cg:hr:skall');n=pg.evaluate("document.querySelectorAll('#ov [data-a^=\"cg:sk:skins:\"]').length");ok(tag+' 🎨 skins gallery lists owned heroes',n==pg.evaluate("A3.sv.owned.length"),'rows=%d'%n)
        hh=pg.evaluate("A3.sv.owned[0]");click('cg:sk:skins:%d'%hh);ok(tag+'   → hero skins window','סקינים' in txt() and pg.evaluate("document.querySelectorAll('#ov [data-a^=\"seq:\"],#ov [data-a^=\"sbuy:\"]').length")==4)
        pg.evaluate("A3.sv.gold=5000");click('sbuy:%d:1'%hh);ok(tag+'   buy skin still works',pg.evaluate("(A3.sv.so[%d]||[]).indexOf(1)>=0"%hh))
        click('menu');ok(tag+'   back → skins gallery',pg.evaluate("document.querySelectorAll('#ov [data-a^=\"cg:sk:skins:\"]').length")>0)
        click('menu');ok(tag+' gallery back → heroes window','גיבורים' in txt());click('menu');ok(tag+' heroes back → main',main())
        # modes
        click('cat:md');ok(tag+' 🎮 modes window lists all modes (v72: without "קרב 3D")',pg.evaluate("document.querySelectorAll('#ov [data-a^=\"sm:\"]').length")==10 and not pg.evaluate("!!document.querySelector('#ov [data-a=\"sm:3d\"]')"))
        click('df2:2');ok(tag+' difficulty changes and stays in window',pg.evaluate("document.querySelector('#ov .chip.sel').textContent")=='קשה' and not main())
        click('sm:boss');ok(tag+' choose mode → highlighted, play button names it',not main() and pg.evaluate("document.querySelector('#ov .mdR.mdOn').dataset.a")=='sm:boss' and 'בוסים' in pg.inner_text('#ov .mdGo'))
        click('menu');ok(tag+' choose mode → main shows it',main() and 'בוסים' in pg.inner_text('#mdSel') and 'קשה' in pg.inner_text('#mdSel'))
        click('cat:md');click('cg:md:board');ok(tag+' modes → journey','מסע' in txt());click('menu');ok(tag+'   back → modes window','מצבי משחק' in txt())
        click('menu')
        # play still starts the selected mode
        click('play');pg.wait_for_timeout(600);ok(tag+' ▶ play starts selected mode',pg.evaluate("__arena().state==='play'&&__arena().mode==='boss'"))
        ok(tag+' single player in match',pg.evaluate("__arena().ps.length")==1)
        pg.keyboard.press('KeyP');pg.wait_for_timeout(100);click('menu');ok(tag+' pause → menu goes to main',main())
        # stale return cleared after a game
        click('cat:md');click('cg:md:train');pg.wait_for_timeout(500);ok(tag+' modes → training starts',pg.evaluate("__arena().mode")=='train')
        pg.keyboard.press('KeyP');pg.wait_for_timeout(100);click('menu');ok(tag+' after game, back goes to main (no stale return)',main())
        click('maps');click('menu');ok(tag+' later windows return to main',main())
        # opened window hides everything else
        for a in ['shop','cat:rw','maps','cat:md','cfg']:
            click(a)
            r=pg.evaluate("""(function(){var o=document.getElementById('ov'),cs=getComputedStyle(o),pts=[[5,5],[innerWidth-5,5],[5,innerHeight-5],[innerWidth-5,innerHeight-5],[innerWidth/2,innerHeight/2]],cov=pts.every(function(p){var e=document.elementFromPoint(p[0],p[1]);return e&&o.contains(e);});
              var op=cs.backgroundImage!=='none'||/rgb\(|rgba\([^)]*,\s*1\)/.test(cs.backgroundColor);var rot=document.getElementById('rot');return [cov,op,getComputedStyle(rot).display];})()""")
            ok(tag+' window '+a+' covers screen, opaque, nothing else shows',r[0] and r[1] and r[2]=='none',str(r))
            click('menu')
        # top bar untouched
        for a in ['cfg','prof']:
            click(a);ok(tag+' top '+a+' opens',not main());click('menu')
        ok(tag+' install-instructions button removed',not pg.evaluate("!!document.querySelector('#ov [data-a=inst]')"))
        ok(tag+' online button moved off main screen',not pg.evaluate("!!document.querySelector('#ov [data-a=online]')"))
        ok(tag+' multiplayer (players count) button removed',not pg.evaluate("!!document.querySelector('#ov [data-a=np]')||!!document.querySelector('#ov [data-a=\"pick:1\"]')"))
        click('shop');ok(tag+' shop has 🌐 online',pg.evaluate("!!document.querySelector('#ov [data-a=\"cg:shop:online\"]')"))
        click('cg:shop:online');ok(tag+' shop → online window','אונליין' in txt() and pg.evaluate("!!document.getElementById('oc')"))
        pg.fill('#oc','abc1');click('oj');pg.wait_for_timeout(300);ok(tag+' join room from shop → opens room on the game site',pg.evaluate("window.__opened.slice(-1)[0]")=='https://ytymshw717-sys.github.io/Zirat/?v=72#room-abc1')
        click('menu');ok(tag+' online back → shop','חנות' in txt() and not main())
        click('cg:shop:online');click('ol');click('menu');click('menu');ok(tag+' leave room, back to main',main())
        c.close()
    b.close()
print('ERRORS',errs);print('SUMMARY %d/%d'%(sum(res),len(res)))
