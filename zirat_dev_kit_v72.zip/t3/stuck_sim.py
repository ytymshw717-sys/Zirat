# Fast-forward simulation of every mode: finds bots that stop moving (stuck on rocks / walls / each other),
# matches that never end, and JS errors. Uses __arena().sim (runs update() without drawing) and __bot0 (AI for player 1).
import sys, json
from playwright.sync_api import sync_playwright
F = sys.argv[1] if len(sys.argv) > 1 else 'arena3_new.html'
MODES = sys.argv[2].split(',') if len(sys.argv) > 2 else ['team', 'survive', 'siege', 'boss', 'heist', 'gems', 'hot', 'ball', 'show']
SEC = float(sys.argv[3]) if len(sys.argv) > 3 else 150
RUNS = int(sys.argv[4]) if len(sys.argv) > 4 else 2
MAPS = [int(x) for x in sys.argv[5].split(',')] if len(sys.argv) > 5 else [None]
BOT = r"""
window.__bot0=function(p){var A=__arena(),tg=null,td=1e9;
 A.enemies.forEach(function(e){if(e.hp<=0||e.hid)return;var d=Math.hypot(e.x-p.x,e.y-p.y);if(d<td){td=d;tg=e;}});
 if(!tg&&A.structs)A.structs.forEach(function(e){if(e.hp<=0)return;var d=Math.hypot(e.x-p.x,e.y-p.y);if(d<td){td=d;tg=e;}});
 if(!tg)return {x:0,y:0,a:false,s:false,u:false,g:false};
 var rng=p.ch.kind?p.ch.rng*.8:p.ch.rng*.6,dx=tg.x-p.x,dy=tg.y-p.y,l=td||1,x=0,y=0;
 if(td>rng){x=dx/l;y=dy/l;var t=(Date.now()/700|0)%2?1:-1;x+=-dy/l*.3*t;y+=dx/l*.3*t;}
 return {x:x,y:y,a:td<=p.ch.rng+20,s:false,u:(p.sup||0)>=100,g:false};};
window.__trk=function(){var A=__arena(),o=[];function add(k,e,i){if(!e||e.hp<=0)return;var fo=[];
  if(k==='en')fo=A.ps.concat(A.tb);else fo=A.enemies.filter(function(x){return x.t==='hero'||k==='ps';});
  var nd=1e9;fo.forEach(function(f){if(f.hp>0)nd=Math.min(nd,Math.hypot(f.x-e.x,f.y-e.y));});
  var ob=1e9,obr=0;A.obs.forEach(function(b){if(b.k==='void')return;var d=Math.hypot(b.x-e.x,b.y-e.y)-b.r;if(d<ob){ob=d;obr=b.r;}});
  o.push({id:k+(e.slot!=null?e.slot:i)+':'+(e.t||'p')+':'+(e.ch?e.ch.idx:''),x:Math.round(e.x),y:Math.round(e.y),nd:Math.round(nd),rng:e.ch?e.ch.rng:(e.r||0),ob:Math.round(ob),stun:e.stun||0,t:e.t||'p'});}
 A.ps.forEach(function(e,i){add('ps',e,i);});A.tb.forEach(function(e,i){add('tb',e,i);});A.enemies.forEach(function(e,i){add('en',e,i);});return o;};
"""
out = {}
with sync_playwright() as p:
    b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
    for m in MODES:
        for run in range(RUNS * len(MAPS)):
            mp = MAPS[run % len(MAPS)]
            c = b.new_context(viewport={'width': 844, 'height': 390}, has_touch=True, is_mobile=True, device_scale_factor=1)
            c.add_init_script(path='/home/claude/t/mock.js')
            c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify({owned:[0,1,2,3,4,5,6,7,8,9],gold:500,dm:60,cfg:{r3:false}}))}catch(e){}')
            pg = c.new_page(); E = []
            pg.on('pageerror', lambda e: E.append(str(e)))
            pg.goto('file:///home/claude/' + F); pg.wait_for_timeout(2500)
            def act(a):
                pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')" % a); pg.wait_for_timeout(120)
            act('menu'); act('cat:md');
            if mp is not None: act('mp:%d' % mp)
            act('sm:' + m); act('play'); pg.wait_for_timeout(800)
            pg.evaluate(BOT)
            st = pg.evaluate("__arena().state")
            hist = {}; stuck = []; t = 0; ended = None
            # keep the player alive in 'show'/'survive' would hide game-over bugs; let it play naturally
            while t < SEC:
                s = pg.evaluate("__arena().sim(30,1/30)"); t += 1
                if s != 'play':
                    if s == 'shop':
                        pg.evaluate("(function(){var b=document.querySelector('#ov [data-a=\"next\"],#ov [data-a^=\"nw\"]');if(b)b.click();else{try{nextWave()}catch(e){}}})()")
                        pg.evaluate("document.querySelectorAll('#ov button').forEach(function(b){if(/המשך|גל הבא|הבא/.test(b.textContent))b.click()})")
                        s2 = pg.evaluate("__arena().state")
                        if s2 == 'play': continue
                    ended = (s, round(t)); break
                for e in pg.evaluate("__trk()"):
                    h = hist.setdefault(e['id'], [])
                    h.append((t, e['x'], e['y'], e))
                    if len(h) >= 3:
                        t0, x0, y0, _ = h[-3]
                        if abs(e['x'] - x0) + abs(e['y'] - y0) < 6 and e['nd'] > e['rng'] + 70 and e['nd'] < 5000 and e['stun'] <= 0 and e['t'] not in ('dummy', 'p'):
                            stuck.append((round(t), e['id'], e['x'], e['y'], 'foe', e['nd'], 'obs', e['ob']))
            A = pg.evaluate("(function(){var A=__arena();return {tko:A.tko,score:A.score,wave:A.wave,state:A.state,wi:A.wi}})()")
            key = '%s#%d/map%s' % (m, run, A['wi'])
            out[key] = {'start': st, 'ended': ended, 'stuck_n': len(stuck), 'stuck': stuck[:12], 'err': E[:4], 'end': A}
            print(key, json.dumps(out[key], ensure_ascii=False), flush=True)
            c.close()
json.dump(out, open('/tmp/stuck_out.json', 'w'), ensure_ascii=False, indent=1)
