# build the two "needs a redesign" contact sheets (Hebrew labels, priority, what to improve) and render them to PNG
import sys
from playwright.sync_api import sync_playwright
D = '/home/claude/t3/sheet'
HIGH = [
 ('pick_0', 'בחירת גיבור לפני משחק', 'רשת אפורה ושטוחה. כדאי: כרטיסים גדולים עם תמונת הגיבור, מסגרת בצבע הנדירות, אייקון מחלקה, מנעול יפה'),
 ('heroes', 'רשימת הגיבורים', 'רשימה צפופה של שורות טקסט. כדאי: אוסף כרטיסים בגריד (כמו אלבום), רמה וגביעים על כל כרטיס'),
 ('shop', 'חנות', 'אריחים כהים עם אימוג׳י קטן. כדאי: הצעות מיוחדות עם ציור גדול, תגית מחיר מבריקה, באנר "מבצע היום"'),
 ('tr', 'שביל הגביעים', 'רק רשימת מספרים. כדאי: שביל/דרך מצוירת עם תחנות פרס, הגיבור עומד על התחנה הנוכחית'),
 ('pass', 'מסלול הגיבור (פאס)', 'שני טורים של מספרים קטנים. כדאי: שני מסלולים לרוחב (חינם / זהב) עם תיבות פרס גדולות'),
 ('victory', 'מסך ניצחון', 'טקסט ממורכז על רקע כהה. כדאי: הגיבור במרכז על במה, כוכבים גדולים, פרסים שעפים, כפתורים כמו בתפריט'),
 ('over', 'מסך הפסד', 'אותו דבר. כדאי: הגיבור עצוב/נופל, צבעים קרים, כפתור "נסה שוב" גדול'),
 ('cat_rw', 'מרכז הפרסים', 'מסך כמעט ריק עם 3 כפתורים קטנים. כדאי: 3 אריחים גדולים מצוירים (שביל, מסלול, משימות)'),
 ('cat_hr', 'מרכז הגיבורים', 'מסך כמעט ריק עם 5 כפתורים קטנים. כדאי: אריחים גדולים מצוירים כמו בתפריט הראשי'),
]
MID = [
 ('skall', 'גלריית סקינים', 'הדמויות זעירות. כדאי: כרטיס סקין גדול לכל אחד עם מחיר/מנעול'),
 ('qs', 'משימות', 'שורות טקסט. כדאי: כרטיסי משימה עם פס התקדמות צבעוני ופרס בצד'),
 ('cat_md', 'מצבי משחק', 'סביר, אבל קטן. כדאי: כרטיסי מצב גדולים עם ציור לכל מצב'),
 ('prof', 'פרופיל', 'פשוט מאוד. כדאי: כרטיס שחקן עם באנר, אווטאר גדול וסטטיסטיקות'),
 ('game', 'המשחק עצמו (פס עליון וכפתורים)', 'הפס העליון דק וצפוף. כדאי: פס עליון בסגנון התפריט (גלולות כחולות), כפתורים מבריקים'),
 ('pause', 'השהיה', 'טקסט וכפתור בלבד. כדאי: חלון מעוצב באמצע עם כפתורים'),
 ('maps', 'מפות', 'סביר. אפשר לשפר עם מסגרות ושמות גדולים'),
 ('online', 'אונליין', 'פונקציונלי. כדאי: כרטיס "צור חדר"/"הצטרף" גדולים'),
 ('cfg', 'הגדרות', 'פונקציונלי, עדיפות נמוכה'),
 ('hi_0', 'מסך גיבור', 'כבר שופר (טירה + במה). אפשר רק ללטש את הלוחות בצדדים'),
]
CSS = """body{margin:0;background:#0f1330;font-family:system-ui,'Noto Sans Hebrew',sans-serif;color:#fff;direction:rtl;width:1320px}
h1{margin:18px 24px 4px;font-size:34px}p.s{margin:0 24px 14px;font-size:18px;opacity:.85}
.g{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;padding:0 20px 22px}
.c{background:#1b2250;border:2px solid #4f8dff;border-radius:16px;overflow:hidden}
.c img{display:block;width:100%;aspect-ratio:844/390;object-fit:cover;border-bottom:2px solid #4f8dff}
.t{display:flex;align-items:center;gap:10px;padding:8px 12px 0}.n{flex:none;width:34px;height:34px;border-radius:50%;background:#ffd21f;color:#111;font-weight:900;display:flex;align-items:center;justify-content:center;font-size:18px}
.t b{font-size:21px}.d{padding:4px 12px 12px;font-size:15px;line-height:1.35;opacity:.92}
.hi .n{background:#ff5d5d;color:#fff}"""
def page(title, sub, items, start, cls):
    cards = ''.join("<div class='c %s'><img src='%s/%s.png'><div class='t'><span class='n'>%d</span><b>%s</b></div><div class='d'>%s</div></div>" % (cls, D, f, start + i, n, d) for i, (f, n, d) in enumerate(items))
    return "<!doctype html><html lang='he'><meta charset='utf-8'><style>%s</style><h1>%s</h1><p class='s'>%s</p><div class='g'>%s</div></html>" % (CSS, title, sub, cards)
pages = [('sheet_high', page('🔥 עדיפות גבוהה — הכי צריכים עיצוב חדש', 'המסכים שהכי שונים מהתפריט החדש. לכל אחד אפשר להכין תמונת עיצוב (מוקאפ) כמו שעשית לתפריט', HIGH, 1, 'hi')),
         ('sheet_mid', page('✨ עדיפות בינונית ונמוכה', 'עובדים טוב, אבל ייראו הרבה יותר טוב בעיצוב חדש', MID, len(HIGH) + 1, ''))]
with sync_playwright() as p:
    b = p.chromium.launch()
    for name, html in pages:
        open('%s/%s.html' % (D, name), 'w').write(html)
        pg = b.new_page(viewport={'width': 1320, 'height': 800}, device_scale_factor=1)
        pg.goto('file://%s/%s.html' % (D, name)); pg.wait_for_timeout(800)
        pg.screenshot(path='%s/%s.png' % (D, name), full_page=True); pg.close()
print('ok')
