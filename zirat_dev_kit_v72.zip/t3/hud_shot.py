# battle HUD screenshots: show + team, landscape + portrait -> ui/shots/hud_<mode>_<w>x<h>.png
import sys
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
modes=sys.argv[2].split(',') if len(sys.argv)>2 else ['show','team']
sizes=[(844,390),(390,844)]
E=[]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for (w,h) in sizes:
        for md in modes:
            c=b.new_context(viewport={'width':w,'height':h},has_touch=True,is_mobile=True,device_scale_factor=2);c.add_init_script(path='/home/claude/t/mock.js')
            c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify({owned:[0,1,3,5],gold:500,dm:60,lv:{0:5,1:5,3:5,5:5}}))}catch(e){}')
            pg=c.new_page();pg.on('pageerror',lambda e:E.append(str(e)));pg.on('console',lambda m:E.append(m.text) if m.type=='error' else None)
            pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3500)
            def act(a,t=150):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(t)
            act('menu');act('cat:md');act('sm:'+md);act('play',1500)
            for i in range(60):
                if pg.evaluate("(function(){var A=__arena();return A.state==='play'&&A.enemies.length>0})()"):break
                pg.wait_for_timeout(250)
            pg.wait_for_timeout(6000)
            pg.screenshot(path='/home/claude/ui/shots/hud_%s_%dx%d.png'%(md,w,h))
            c.close()
print('ERR',E[:5])
