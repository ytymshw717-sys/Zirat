from playwright.sync_api import sync_playwright
mock=open('/home/claude/t/mock.js').read().replace('window.__skipIntro=1;','')
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390});c.add_init_script(script=mock);pg=c.new_page()
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_function("!!document.getElementById('introL')",timeout=15000)
    pg.wait_for_function("!document.getElementById('introL')",timeout=15000)
    print(repr(pg.inner_text('#ov')[:200]))
