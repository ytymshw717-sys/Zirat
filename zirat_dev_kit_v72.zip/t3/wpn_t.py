# v58 weapons: every hero has its own kind and range, all 20 weapons fire and hit, special behaviours work
# (lob over rocks, bounce, chain, poison, acid pool, lunge, slam, burst, wave grows, sine), rival bots use them too,
# manual aim shows a weapon-shaped indicator, a tap auto-aims, bombs land where you drag. No JS errors.
import sys
from playwright.sync_api import sync_playwright
F = sys.argv[1] if len(sys.argv) > 1 else 'arena3_new.html'
res = []
def ok(n, c, i=''):
    res.append(bool(c)); print(('PASS ' if c else 'FAIL ') + n, i, flush=True)
with sync_playwright() as p:
    b = p.chromium.launch(args=['--use-angle=swiftshader', '--enable-unsafe-swiftshader'])
    c = b.new_context(viewport={'width': 844, 'height': 390}, has_touch=True, is_mobile=True, device_scale_factor=1)
    c.add_init_script(path='/home/claude/t/mock.js')
    c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify({owned:[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19],gold:500,dm:60,ck:1}))}catch(e){}')
    pg = c.new_page(); E = []
    pg.on('pageerror', lambda e: E.append(str(e)))
    pg.goto('file:///home/claude/' + F); pg.wait_for_timeout(3000)
    pg.evaluate("window.__far=function(){__arena().enemies.push({t:'tank',x:945,y:15,r:18,hp:1e9,maxhp:1e9,state:'chase',wind:0,cd:99,stun:999,kx:0,ky:0,flash:0,dir:1,walk:0,speed:0})}")
    def act(a):
        pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')" % a); pg.wait_for_timeout(150)
    info = pg.evaluate("__arena().CH.map(function(c){return [c.kind||'',c.rng]})")
    kinds = [k for k, r in info]
    ok('all 20 heroes have a weapon kind', all(kinds), str(kinds))
    ok('at least 12 different weapon kinds', len(set(kinds)) >= 12, str(sorted(set(kinds))))
    rngs = [r for k, r in info]
    ok('only 3 heroes are close-range (<=115), 6+ are long (>=220)', sum(1 for r in rngs if r <= 115) <= 4 and sum(1 for r in rngs if r >= 220) >= 6, str(rngs))
    # each hero: stand still, a dummy in range, hold attack for a while (sim), the dummy loses health
    act('menu'); act('cat:md'); act('sm:survive'); act('play'); pg.wait_for_timeout(800)
    bad = []
    for i in range(20):
        r = pg.evaluate("""(function(i){var A=__arena(),p=A.ps[0];var ch=Object.assign({},A.CH[i]);ch.idx=i;p.ch=ch;p.x=300;p.y=270;p.hp=p.mhp=999;p.cd=0;p.aimO=0;
          A.enemies.length=0;A.obs.length=0;A.shots.length=0;A.eshots.length=0;
          var d=Math.min(ch.rng*.7,ch.rng-10);A.enemies.push({t:'tank',x:300+d,y:270,r:18,hp:500,maxhp:500,state:'chase',wind:0,cd:9,stun:99,kx:0,ky:0,flash:0,dir:1,walk:0,speed:0});
          __far();window.__bot0=function(){return {x:0,y:0,a:true,s:false,u:false,g:false}};A.sim(60,1/30);window.__bot0=null;
          var e=A.enemies[0];return [ch.kind,ch.rng,e?500-e.hp:-1,A.state];})(%d)""" % i)
        if not (r[2] > 0): bad.append((i, r))
    ok('every hero damages a target inside its range', not bad, str(bad))
    # lobbed bomb flies over a rock; a normal shot does not
    r = pg.evaluate("""(function(){var A=__arena(),p=A.ps[0],out=[];[8,6].forEach(function(i){A=__arena();A.shots.length=0;var ch=Object.assign({},A.CH[i]);ch.idx=i;p.ch=ch;p.x=300;p.y=270;p.cd=0;
      A.enemies.length=0;A.obs.length=0;A.obs.push({x:360,y:270,r:22,k:'rock'});A.enemies.push({t:'tank',x:450,y:270,r:18,hp:500,maxhp:500,state:'chase',wind:0,cd:9,stun:99,kx:0,ky:0,flash:0,dir:1,walk:0,speed:0});
      __far();window.__bot0=function(){return {x:0,y:0,a:true}};A.sim(60,1/30);window.__bot0=null;out.push(500-A.enemies[0].hp);});A.obs.length=0;return out;})()""")
    ok('bomb flies over a rock and hits; arrow is blocked by it', r[0] > 0 and r[1] == 0, str(r))
    # bounce: a shot off a rock reaches an enemy hiding at an angle
    r = pg.evaluate("""(function(){var A=__arena(),p=A.ps[0],ch=Object.assign({},A.CH[3]);ch.idx=3;p.ch=ch;p.cd=0;p.x=300;p.y=270;A.obs.length=0;A.obs.push({x:380,y:270,r:20,k:'rock'});A.shots.length=0;A.enemies.length=0;
      p.fx=1;p.fy=0;p.aimO=1;p.ax=1;p.ay=0;__far();window.__bot0=function(){return {x:0,y:0,a:true}};A.sim(2,1/30);window.__bot0=null;var s=__arena().shots[0];var v0=s?s.vx:0;A.sim(8,1/30);var s2=__arena().shots[0];return [v0,s2?s2.vx:null,s2?s2.bnc:null];})()""")
    ok('Kap\'s shot bounces back off a rock', r[0] > 0 and r[1] is not None and r[1] < 0 and r[2] == 1, str(r))
    # chain: lightning jumps to two more enemies
    r = pg.evaluate("""(function(){var A=__arena(),p=A.ps[0],ch=Object.assign({},A.CH[2]);ch.idx=2;p.ch=ch;p.x=300;p.y=270;p.cd=0;p.aimO=0;A.obs.length=0;A.shots.length=0;A.enemies.length=0;
      [[420,270],[480,300],[520,250]].forEach(function(q){A.enemies.push({t:'tank',x:q[0],y:q[1],r:18,hp:500,maxhp:500,state:'chase',wind:0,cd:9,stun:99,kx:0,ky:0,flash:0,dir:1,walk:0,speed:0});});
      __far();window.__bot0=function(){return {x:0,y:0,a:true}};A.sim(3,1/30);window.__bot0=null;A.sim(20,1/30);return A.enemies.slice(0,3).map(function(e){return 500-e.hp});})()""")
    ok('Zap\'s lightning chains to 3 enemies', len(r) == 3 and all(x > 0 for x in r), str(r))
    # poison keeps hurting after the hit; acid pool hurts over time
    r = pg.evaluate("""(function(){var A=__arena(),p=A.ps[0],out=[];[18,11].forEach(function(i){A=__arena();var ch=Object.assign({},A.CH[i]);ch.idx=i;p.ch=ch;p.x=300;p.y=270;p.cd=0;p.aimO=0;A.obs.length=0;A.shots.length=0;A.enemies.length=0;
      A.enemies.push({t:'tank',x:400,y:270,r:18,hp:500,maxhp:500,state:'chase',wind:0,cd:9,stun:99,kx:0,ky:0,flash:0,dir:1,walk:0,speed:0});
      __far();window.__bot0=function(){return {x:0,y:0,a:true}};A.sim(2,1/30);window.__bot0=null;A.sim(14,1/30);var h1=A.enemies[0].hp;A.sim(30,1/30);out.push([500-h1,h1-A.enemies[0].hp]);});return out;})()""")
    ok('Viper\'s venom and Nova\'s acid keep hurting after the hit', all(x[0] > 0 and x[1] > 0 for x in r), str(r))
    # lunge moves the hero forward, slam stuns
    r = pg.evaluate("""(function(){var A=__arena(),p=A.ps[0],out=[];var ch=Object.assign({},A.CH[10]);ch.idx=10;p.ch=ch;p.x=300;p.y=270;p.cd=0;p.kx=p.ky=0;A.obs.length=0;A.enemies.length=0;
      A.enemies.push({t:'tank',x:370,y:270,r:18,hp:500,maxhp:500,state:'chase',wind:0,cd:9,stun:0,kx:0,ky:0,flash:0,dir:1,walk:0,speed:0});
      __far();window.__bot0=function(){return {x:0,y:0,a:true}};A.sim(1,1/30);window.__bot0=null;A.sim(8,1/30);out.push(Math.round(p.x-300));
      ch=Object.assign({},A.CH[12]);ch.idx=12;p.ch=ch;p.cd=0;var e=A.enemies[0];e.x=p.x+60;e.y=p.y;e.stun=0;__far();window.__bot0=function(){return {x:0,y:0,a:true}};A.sim(1,1/30);window.__bot0=null;out.push(e.stun);return out;})()""")
    ok('Derek lunges forward; Tank\'s slam stuns', r[0] > 25 and r[1] > .2, str(r))
    # burst fires 3, sonic wave grows, sine wiggles
    r = pg.evaluate("""(function(){var A=__arena(),p=A.ps[0],out={};A.enemies.length=0;A.obs.length=0;
      function go(i,n){var ch=Object.assign({},A.CH[i]);ch.idx=i;p.ch=ch;p.x=300;p.y=270;p.cd=0;p.aimO=1;p.ax=1;p.ay=0;A.shots.length=0;__far();window.__bot0=function(){return {x:0,y:0,a:true}};A.sim(1,1/30);window.__bot0=null;A.sim(n,1/30);A=__arena();return A.shots;}
      out.burst=go(17,8).length;var w=go(16,10);out.sonic=w[0]?w[0].r:0;var s=go(14,6);out.sine=s[0]?Math.abs(s[0].y-270):0;return out;})()""")
    ok('Sol fires a 3-shot burst, Riff\'s wave grows, Bo\'s wisp wiggles', r['burst'] == 3 and r['sonic'] > 8 and r['sine'] > 2, str(r))
    # rival bots: 3 vs 3 with all kinds for a while, no errors, the player team takes damage from rivals
    act('menu'); act('cat:md'); act('sm:team'); act('play'); pg.wait_for_timeout(800)
    pg.evaluate("window.__bot0=function(p){return {x:0,y:0,a:false}}")
    seen = set(); hurt = 0
    for k in range(6):
        r = pg.evaluate("""(function(){var A=__arena(),hs=[[2,4,8],[10,12,17],[3,11,18],[14,16,19],[1,13,15],[0,5,9]][%d];A.enemies.forEach(function(e,j){if(e.t==='hero'){var ch=Object.assign({},A.CH[hs[j%%3]]);ch.idx=hs[j%%3];e.ch=ch;}});
          var h0=A.ps[0].hp+A.tb.reduce(function(s,b){return s+b.hp},0);A.ps[0].hp=A.ps[0].mhp=9999;A.sim(150,1/30);var h1=A.ps[0].hp+A.tb.reduce(function(s,b){return s+b.hp},0);return [A.state,A.enemies.filter(function(e){return e.t==='hero'}).map(function(e){return e.ch.kind}),9999-A.ps[0].hp,A.tko[1]];})()""" % k)
        seen.update(r[1]); hurt += r[2] + r[3]
        if r[0] != 'play': break
    ok('rival bots fight with the new weapons and hurt the player team', hurt > 0, 'kinds seen %s hurt %s' % (sorted(seen), hurt))
    pg.evaluate("window.__bot0=null")
    # manual aim: drag the attack button -> weapon-shaped indicator; release -> fires that way; bomb lands where dragged
    act('menu'); act('cat:md'); act('sm:survive'); act('play'); pg.wait_for_timeout(1500)
    pg.evaluate("(function(){var A=__arena(),p=A.ps[0],ch=Object.assign({},A.CH[8]);ch.idx=8;p.ch=ch;p.cd=0;A.enemies.length=0;__far();})()")
    bb = pg.query_selector('#atk').bounding_box(); cx = bb['x'] + bb['width'] / 2; cy = bb['y'] + bb['height'] / 2
    pg.mouse.move(cx, cy); pg.mouse.down(); pg.mouse.move(cx - 20, cy, steps=3); pg.mouse.move(cx - 45, cy, steps=3); pg.wait_for_timeout(400)
    pg.screenshot(path='/home/claude/t3/wpn_aim_bomb.png')
    pg.evaluate("(function(){var A=__arena();window.__lob=null;var f=function(){var s=__arena().shots.filter(function(s){return s.lob})[0];if(s&&!window.__lob)window.__lob=[s.vx<0,Math.round(s.life*250),__arena().ps[0].aimP];if(!window.__lob)requestAnimationFrame(f);};f();})()")
    pg.mouse.up(); pg.wait_for_timeout(400)
    r = pg.evaluate("window.__lob")
    ok('drag left on the attack button throws the bomb left, about half range', r and r[0] and 60 < r[1] < 180, str(r))
    pg.evaluate("(function(){var A=__arena(),p=A.ps[0],ch=Object.assign({},A.CH[7]);ch.idx=7;p.ch=ch;p.cd=0;})()")
    pg.mouse.move(cx, cy); pg.mouse.down(); pg.mouse.move(cx, cy - 50, steps=4); pg.wait_for_timeout(400)
    pg.screenshot(path='/home/claude/t3/wpn_aim_cone.png')
    pg.evaluate("(function(){window.__up=0;var f=function(){var A=__arena();var n=A.shots.filter(function(s){return s.o===A.ps[0]&&s.vy<-50}).length;if(n>window.__up)window.__up=n;if(n<5)requestAnimationFrame(f);};f();})()")
    pg.mouse.up(); pg.wait_for_timeout(500)
    r = pg.evaluate("window.__up")
    ok('drag up with the shotgun fires 5 pellets upward', r >= 5, str(r))
    # tap = auto aim at the nearest enemy in range
    r = pg.evaluate("""(function(){var A=__arena(),p=A.ps[0],ch=Object.assign({},A.CH[6]);ch.idx=6;p.ch=ch;p.cd=0;p.fx=1;p.fy=0;A.shots.length=0;A.enemies.length=0;
      /* v67: the test enemy may land in a bush, and hidden enemies are (by design) not auto-targeted; a lit enemy (flash) stays visible */
      __far();A.enemies.unshift({t:'tank',x:p.x,y:Math.max(20,p.y-150),r:18,hp:500,maxhp:500,state:'chase',wind:0,cd:9,stun:99,kx:0,ky:0,flash:99,dir:1,walk:0,speed:0});return 1;})()""")
    pg.wait_for_timeout(600); pg.screenshot(path='/home/claude/t3/wpn_auto.png')
    pg.evaluate("(function(){window.__tap=null;var f=function(){var A=__arena();var s=A.shots.filter(function(s){return s.o===A.ps[0]})[0];if(s){window.__tap=[Math.round(s.vx),Math.round(s.vy)];return;}requestAnimationFrame(f);};f();})()")
    pg.mouse.move(cx, cy); pg.mouse.down(); pg.wait_for_timeout(60); pg.mouse.up(); pg.wait_for_timeout(500)
    r = pg.evaluate("window.__tap")
    ok('a tap auto-aims at the enemy (shot goes up although facing right)', r and r[1] < -200 and abs(r[0]) < 120, str(r))
    ok('no errors', not E, str(E[:4]))
    print('SUMMARY %d/%d' % (sum(res), len(res)))
