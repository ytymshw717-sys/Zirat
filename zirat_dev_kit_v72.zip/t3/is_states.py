# painted screens in other states: in a room, on the site (not inside Claude), royal pass owned, other avatar, transfer box, several screen sizes
import sys
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    def ctx(vp,save):
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=True,is_mobile=True,device_scale_factor=2)
        c.add_init_script(path='/home/claude/t/mock.js')
        c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify(%s))}catch(e){}'%save)
        pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)));pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(4000);return pg,E
    def act(pg,a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;b.style.display='none';document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(600)
    pg,E=ctx((844,390),'{"owned":[0,1,3,5,7,9],"gold":500,"dm":200,"xp":1300,"rp":true,"av":3,"nm":"דני","st":{"k":57,"w":4,"s":12,"c":3}}')
    act(pg,'menu');act(pg,'pass');pg.wait_for_timeout(800);pg.screenshot(path='/home/claude/t3/is/st_pass_rp.png')
    act(pg,'menu');act(pg,'prof');pg.wait_for_timeout(2500);act(pg,'xfer');pg.wait_for_timeout(600);pg.screenshot(path='/home/claude/t3/is/st_prof_av.png')
    # fake "in a room" state on the online screen
    pg.evaluate("(function(){var N=__net();})()") if False else None
    print('errors1',E[:3])
    for vp in [(568,320),(932,430),(1280,720),(1024,768),(1100,420)]:
        pg,E=ctx(vp,'{"owned":[0,1,3,5],"gold":500,"dm":60,"xp":400}')
        for s in ['cfg','pass','prof','online','cat:hr']:
            act(pg,'menu');act(pg,s);pg.wait_for_timeout(700)
            if s in('pass','online'):pg.screenshot(path='/home/claude/t3/is/sz_%s_%dx%d.png'%(s.replace(':','_'),vp[0],vp[1]))
        print(vp,'errors',E[:3])
