# bug sweep: every mode, auto-fire on, random stick, 90s of game time each → no exceptions, no NaN, no frozen state
import sys,json
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
MODES=['survive','team','siege','boss','heist','gems','hot','ball','show','train']
res=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for md in MODES:
        c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True);c.add_init_script(path='/home/claude/t/mock.js')
        c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify({owned:[0,1,3,5],gold:500,dm:60,lv:{0:3},cfg:{af:true,mu:false}}))}catch(e){}')
        pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
        pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(2500)
        def act(a,t=200):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(t)
        act('menu');act('sm:'+md);act('play',1500)
        for i in range(40):
            if pg.evaluate("__arena().state==='play'"):break
            pg.wait_for_timeout(200)
        st0=pg.evaluate("__arena().state")
        bad=[];states=[]
        for chunk in range(18):  # 18 x 5s = 90s
            r=pg.evaluate("""(function(){var A=__arena();var dx=Math.cos(Date.now()/700),dy=Math.sin(Date.now()/900);window.__joy&&window.__joy(dx,dy);
              var s=A.sim(150);A=__arena();var nan=[];A.ps.concat(A.enemies).concat(A.tb||[]).forEach(function(o){if(!isFinite(o.x)||!isFinite(o.y)||!isFinite(o.hp))nan.push((o.nm||o.t||'?')+':'+o.x+','+o.y+','+o.hp);});
              return [s,nan.slice(0,3),A.ps[0].hp,A.enemies.length,A.wave];})()""")
            states.append(r[0])
            if r[1]:bad+=r[1]
            if r[0]!='play':break
        ok('%s: started'%md,st0=='play',st0)
        ok('%s: no NaN positions/health'%md,not bad,str(bad[:3]))
        ok('%s: no errors'%md,not E,str(E[:3]))
        print('   %s states: %s'%(md,' '.join(states[-3:])),flush=True)
        c.close()
print('SUMMARY %d/%d'%(sum(res),len(res)))
