# fire each kind of projectile in 3D and photograph trail / muzzle flash / impact; also an enemy death
import sys
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},device_scale_factor=2);c.add_init_script(path='/home/claude/t/mock.js')
    c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify({owned:[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19],gold:500,dm:60}))}catch(e){}')
    pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)));pg.on('console',lambda m:E.append(m.text) if m.type=='error' else None)
    pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3500)
    wp=pg.evaluate("__arena().CH.map(function(c,i){return [i,c.nk,c.wp||'',c.kind||'']})")
    print(wp)
    def act(a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a)
    seen=set();picks=[]
    for i,nk,w,k in wp:
        if k and w not in seen:seen.add(w);picks.append((i,w))
    for i,w in picks[:int(sys.argv[2]) if len(sys.argv)>2 else 12]:
        act('menu');pg.wait_for_timeout(200);act('pk:0:%d'%i);pg.wait_for_timeout(300);act('menu');act('mode:survive');pg.wait_for_timeout(2200)
        pg.evaluate("(function(){var A=__arena(),p=A.ps[0];A.enemies.forEach(function(e,j){e.stun=99;e.cd=99;e.x=p.x+150+j*30;e.y=p.y+(j%2?40:-10);});p.fx=1;p.fy=0;})()")
        for k in range(3):
            pg.evaluate("(function(){var p=__arena().ps[0];p.cd=0;p.fx=1;p.fy=0;})()");pg.keyboard.down('Space');pg.wait_for_timeout(60);pg.keyboard.up('Space');pg.wait_for_timeout(110)
        pg.screenshot(path='/home/claude/t3/fx_%02d_%s.png'%(i,w))
        print(i,w,'shots',pg.evaluate("__arena().shots.length"),'fx',pg.evaluate("G3.r3state?JSON.stringify(G3.r3state()).slice(0,80):''"))
    # enemy death
    pg.evaluate("(function(){var A=__arena();A.enemies.forEach(function(e){e.hp=0.01;});})()")
    pg.evaluate("(function(){var p=__arena().ps[0];p.cd=0;})()");pg.keyboard.down('Space');pg.wait_for_timeout(60);pg.keyboard.up('Space')
    pg.evaluate("(function(){var A=__arena();A.enemies.slice(0,2).forEach(function(e){e.hp=-1;});})()")
    for k in range(4):pg.wait_for_timeout(70);pg.screenshot(path='/home/claude/t3/fx_die%d.png'%k)
    print('errors',E[:5])
