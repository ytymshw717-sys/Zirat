from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch();pg=b.new_page();pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3300)
    h=pg.evaluate("A3.CH.map(function(c,i){return i}).filter(function(i){return A3.sv.owned.indexOf(i)<0})[0]")
    pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='hi:%d';document.getElementById('ov').appendChild(b);b.click();})()"%h)
    print(pg.evaluate("[].map.call(document.querySelectorAll('#hiSk button'),function(b){return b.dataset.a+'|'+b.textContent})"))
