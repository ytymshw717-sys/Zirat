from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True,device_scale_factor=2)
    c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();pg.goto('file:///home/claude/arena3_gfx.html');pg.wait_for_timeout(3500)
    for h in [13,6]:
        pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='hi:%d';document.getElementById('ov').appendChild(b);b.click();})()"%h);pg.wait_for_timeout(2500)
        pg.locator('#hvStage').screenshot(path='/home/claude/t3/hv_round_%d.png'%h)
