from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2);c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(4000)
    def act(a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(700)
    def rot(name,w=844,h=390):
        pg.set_viewport_size({'width':w,'height':h});pg.wait_for_timeout(900);pg.screenshot(path='/home/claude/t3/rot/%s_L.png'%name)
        m=pg.evaluate("(function(){var o=document.getElementById('ov');return [document.documentElement.scrollWidth,innerWidth,o.scrollWidth,o.clientWidth,o.scrollHeight,o.clientHeight]})()")
        pg.set_viewport_size({'width':390,'height':844});pg.wait_for_timeout(700);return m
    print('menu',rot('menu'))
    act('hi:0');print('hero',rot('hero'))
    act('menu');act('shop');act('cg:shop:online');print('online',rot('online'))
    act('menu');act('menu');act('pick:0');print('pick',rot('pick'))
    act('menu');act('mode:survive');pg.wait_for_timeout(1500);print('game',rot('game'))
    print('errors',E[:3])
