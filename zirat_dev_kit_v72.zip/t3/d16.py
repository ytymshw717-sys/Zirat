from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True,device_scale_factor=2)
    c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page()
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3500)
    pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='mode:survive';document.getElementById('ov').appendChild(b);b.click();})()");pg.wait_for_timeout(1500)
    pg.evaluate("__arena().enemies.forEach(function(e){e.stun=99;e.cd=99;})")
    for k in range(10):
        yaw=[0,1.57,3.14,4.2][k%4]
        pg.evaluate("__yaw(%f);var p=__arena().ps[0];p.x=480;p.y=270;__arena().obs.length=0;window.__lg=[];window.__iv&&clearInterval(window.__iv);window.__iv=setInterval(function(){var A=__arena();window.__lg.push([Math.round(A.ps[0].x),A.state,A.enemies.length].join(':'))},60)"%yaw);pg.wait_for_timeout(900)
        pg.keyboard.down('KeyD');pg.wait_for_timeout(450);pg.keyboard.up('KeyD');pg.wait_for_timeout(200)
        lg=pg.evaluate("window.__lg");print(yaw,lg[0],lg[len(lg)//2],lg[-1],len(lg))
