import math
from playwright.sync_api import sync_playwright
THREE=open('/home/claude/mrdoob/three.js/build/three.min.js','rb').read()
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True)
    c.add_init_script(path='/home/claude/t/mock.js');c.route('**/three.min.js',lambda r:r.fulfill(status=200,body=THREE,headers={'content-type':'application/javascript'}))
    pg=c.new_page();pg.on('pageerror',lambda e:print('ERR',e));pg.on('console',lambda m:print('CON',m.text) if m.type=='error' else None)
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3300)
    pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='sm:3d';document.getElementById('ov').appendChild(b);b.click();})()");pg.evaluate("document.querySelector('#ov [data-a=play]').click()")
    pg.wait_for_function("window.__g3&&__g3.st()",timeout=20000);pg.wait_for_timeout(500)
    pg.evaluate("__g3.manual();__g3.set('p',{hp:1,x:0,z:4});__g3.set('e',{x:0,z:2.5})")
    for i in range(40):
        pg.evaluate("__g3.step(30,1/60)")
        if pg.evaluate("__g3.st().over"):break
    print('lost',pg.evaluate("__g3.st().over"),pg.inner_text('#g3 .msg3')[:20])
    pg.evaluate("__g3.manual(false)");pg.click('#g3 [data-g3=again]');pg.wait_for_function("window.__g3&&__g3.st()&&!__g3.st().over",timeout=20000);pg.wait_for_timeout(300)
    print('restarted',pg.evaluate("__g3.st()"))
    pg.evaluate("__g3.freeze();__g3.manual();__g3.set('e',{hp:5,x:-2.7,z:-8,vx:0,vz:0,kbx:0,kbz:0,stag:0,inv:0});__g3.set('p',{x:-4,z:-8,face:Math.PI/2,cool:0,phase:'idle',stag:0,vx:0,vz:0})")
    print(pg.evaluate("__g3.attack('p')"))
    for i in range(6):
        pg.evaluate("__g3.step(25,1/60)");s=pg.evaluate("__g3.st()");print(s['p']['phase'],s['e']['hp'],s['e']['dead'],s['over'],s['shots'],round(s['e']['x'],2),s['check'])
