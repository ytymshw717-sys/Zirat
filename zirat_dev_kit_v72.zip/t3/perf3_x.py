from playwright.sync_api import sync_playwright
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for r3 in [True,False]:
        c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True,device_scale_factor=3)
        c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();pg.goto('file:///home/claude/arena3_gfx.html');pg.wait_for_timeout(3500)
        pg.evaluate("A3.sv.cfg.r3=%s"%('true' if r3 else 'false'))
        pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='mode:survive';document.getElementById('ov').appendChild(b);b.click();})()");pg.wait_for_timeout(2500)
        pg.evaluate("window.__ft=[];(function f(t){window.__ft.push(t);if(window.__ft.length<150)requestAnimationFrame(f);})(performance.now())")
        pg.keyboard.down('KeyD');pg.wait_for_timeout(6000);pg.keyboard.up('KeyD')
        print('3D' if r3 else '2.5D',pg.evaluate("(function(){var a=window.__ft,d=[];for(var i=1;i<a.length;i++)d.push(a[i]-a[i-1]);d.sort(function(x,y){return x-y});return [d.length,Math.round(d[Math.floor(d.length/2)]),Math.round(d[Math.floor(d.length*.95)])]})()"),pg.evaluate("G3.r3state()&&G3.r3state().low"))
        if r3:
            pg.evaluate("__arena().ps[0].spcd=0");pg.keyboard.press('KeyK');pg.wait_for_timeout(150);pg.screenshot(path='/home/claude/t3/r3_spin.png')
        c.close()
