# combat effects regression: fast shots can't tunnel, every hero's attack/special/super runs without errors in 3D and 2D, effect queue never grows, particles stay within budget
import sys
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
res=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
SAVE='{"owned":[0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19],"gold":500,"dm":60,"xp":5000,"lv":{"0":5,"1":5,"2":5,"3":5,"4":5,"5":5,"6":5,"7":5,"8":5,"9":5,"10":5,"11":5,"12":5,"13":5,"14":5,"15":5,"16":5,"17":5,"18":5,"19":5}%s}'
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for r3 in (True,False):
        tag='3D' if r3 else '2D'
        c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True);c.add_init_script(path='/home/claude/t/mock.js')
        c.add_init_script(script='try{localStorage.setItem("heroes_arena_save",JSON.stringify(%s))}catch(e){}'%(SAVE%('' if r3 else ',"cfg":{"r3":false}')))
        pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)));pg.on('console',lambda m:E.append(m.text) if m.type=='error' else None)
        pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3500)
        def act(a):pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a);pg.wait_for_timeout(150)
        act('menu');act('pk:0:6');act('menu');act('mode:survive');pg.wait_for_timeout(1500)
        for i in range(40):
            if pg.evaluate('__arena().enemies.length')>=1:break
            pg.wait_for_timeout(200)
        # a very fast shot jumps far past the enemy in a single frame: it must still hit
        hp=pg.evaluate("(function(){var A=__arena(),p=A.ps[0],e=A.enemies[0];e.stun=99;e.cd=99;e.hp=50;e.maxhp=50;e.x=p.x+120;e.y=p.y;A.enemies.slice(1).forEach(function(q){q.x=p.x-300;q.y=p.y-200;q.stun=99;});A.shots.push({x:p.x+20,y:p.y,vx:9000,vy:0,life:.2,dmg:3,r:4,boom:0,col:'#fff',o:p});return e.hp;})()")
        pg.wait_for_timeout(500)
        hp2=pg.evaluate("__arena().enemies[0]?__arena().enemies[0].hp:-1")
        ok(tag+' fast shot cannot pass through an enemy (swept hit)',hp2<hp,'%s -> %s'%(hp,hp2))
        for h in range(20):
            act('menu');act('pk:0:%d'%h);act('menu');act('mode:survive');pg.wait_for_timeout(700)
            pg.evaluate("(function(){var A=__arena(),p=A.ps[0];p.hp=1e5;p.mhp=1e5;})()")
            for k in range(3):
                pg.evaluate("(function(){var p=__arena().ps[0];p.cd=0;})()");pg.keyboard.down('Space');pg.wait_for_timeout(50);pg.keyboard.up('Space');pg.wait_for_timeout(80)
            pg.evaluate("(function(){var p=__arena().ps[0];p.spcd=0;})()");pg.keyboard.down('KeyK');pg.wait_for_timeout(50);pg.keyboard.up('KeyK');pg.wait_for_timeout(120)
            pg.evaluate("(function(){var p=__arena().ps[0];p.sup=100;})()");pg.keyboard.down('KeyL');pg.wait_for_timeout(50);pg.keyboard.up('KeyL');pg.wait_for_timeout(500)
        ok(tag+' every hero: attack + special + super run with no errors',not E,str(E[:2]))
        q=pg.evaluate("(function(){try{return G3.r3state();}catch(e){return null}})()")
        if r3:
            ok('3D: particle pools stay within budget',q and q['parts'][0]<=300 and q['parts'][1]<=420 and q['parts'][2]<=170,str(q and q['parts']))
            ok('3D: draw calls stay reasonable',q and q['calls']<400,str(q and q['calls']))
        c.close()
    print('SUMMARY %d/%d'%(sum(res),len(res)))
