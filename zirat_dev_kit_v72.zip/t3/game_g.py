import sys
from playwright.sync_api import sync_playwright
F='file:///home/claude/'+sys.argv[1]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for tag,vp,mob in [('iphone',(390,844),True),('desktop',(1280,720),False)]:
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=mob,is_mobile=mob,device_scale_factor=2 if mob else 1)
        c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)));pg.on('console',lambda m:E.append(m.text) if m.type=='error' else None)
        pg.goto(F);pg.wait_for_timeout(5000)
        pg.screenshot(path='/home/claude/t3/game_%s_menu.png'%tag)
        pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='hi:12';document.getElementById('ov').appendChild(b);b.click();})()");pg.wait_for_timeout(3000)
        pg.screenshot(path='/home/claude/t3/game_%s_hero.png'%tag)
        print(tag,'errors:',E[:5])
        c.close()
