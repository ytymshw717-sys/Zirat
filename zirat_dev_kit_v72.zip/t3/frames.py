import sys
from playwright.sync_api import sync_playwright
H=[int(x) for x in sys.argv[1].split(',')];out=sys.argv[2];F=sys.argv[3] if len(sys.argv)>3 else 'arena3_gfx.html'
W0=int(sys.argv[4]) if len(sys.argv)>4 else 200
PO=[('guard',.5,-.35),('slash',.35,-.35),('slash',.55,-.9),('kick',.4,-.6),('punch',.25,-.35),('victory',.3,-.35),('wave',.4,.3),('cast',.5,-.35),('shoot',.5,-.6)]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True,device_scale_factor=1);c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
    pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3500)
    from PIL import Image
    rows=[]
    for h in H:
        pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='hi:%d';document.getElementById('ov').appendChild(b);b.click();})()"%h);pg.wait_for_timeout(900)
        bb=pg.evaluate("(function(){var r=document.getElementById('hvStage').getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height}})()")
        ims=[]
        for a,pp,y in PO:
            pg.evaluate("([a,p,y])=>G3._frz(a,p,y)",[a,pp,y]);pg.wait_for_timeout(450)
            pg.screenshot(path='/tmp/claude-0/-home-claude/b0ae6ea6-7673-5629-85ca-afcd48e28043/scratchpad/f.png',clip=bb)
            ims.append(Image.open('/tmp/claude-0/-home-claude/b0ae6ea6-7673-5629-85ca-afcd48e28043/scratchpad/f.png').convert('RGB').resize((W0,int(W0*bb["height"]/bb["width"]))))
        pg.evaluate("G3._frz(null)")
        rows.append(ims)
    w=W0*len(PO);hh=rows[0][0].height
    s=Image.new('RGB',(w,hh*len(rows)))
    for r,ims in enumerate(rows):
        for i,im in enumerate(ims):s.paste(im,(i*W0,r*hh))
    s.save(out);print('E',E[:2])
