import sys
from playwright.sync_api import sync_playwright
mock=open('/home/claude/t/mock.js').read().replace('window.__skipIntro=1;','')
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for f in sys.argv[1:]:
        c=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True);c.add_init_script(script=mock);pg=c.new_page()
        pg.goto('file:///home/claude/'+f);pg.wait_for_function("!!document.getElementById('introL')",timeout=15000);pg.tap('#introL')
        out=[]
        for i in range(12):
            pg.wait_for_timeout(200);out.append((i*200+200,pg.evaluate("!!document.getElementById('introL')"),pg.inner_text('#ov')[:20].replace('\n',' ')))
        print(f,out);c.close()
