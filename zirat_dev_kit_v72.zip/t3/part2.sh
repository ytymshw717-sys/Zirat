#!/bin/bash
cd /home/claude
SP=/tmp/claude-0/-home-claude/b0ae6ea6-7673-5629-85ca-afcd48e28043/scratchpad
cp arena3_new.html $SP/arena3_new.html
pkill -f "http.server 9912" 2>/dev/null; (cd $SP && python3 -m http.server 9912 >/dev/null 2>&1 &)
for i in $(seq 1 30); do curl -s -o /dev/null http://127.0.0.1:9912/arena3_new.html && break; sleep 0.5; done
run(){ echo "=== $*"; timeout 900 python3 "$@" 2>&1 | grep -E "PASS|FAIL|SUMMARY|Error|error" | grep -v "^PASS" ; }
bash net/start_sig.sh
run net/t_relay.py
for p in $(pgrep -f "^node net/sig.js"); do kill $p; done
run t3/t3.py
run t/t1.py arena3_new.html
run t3/t15.py
echo DONE
