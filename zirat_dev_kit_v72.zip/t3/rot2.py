import sys
from playwright.sync_api import sync_playwright
f=sys.argv[1]
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    for start,tag in [((844,390),'fresh'),((390,844),'rotated')]:
        c=b.new_context(viewport={'width':start[0],'height':start[1]},is_mobile=True,has_touch=True,device_scale_factor=2);c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page()
        pg.goto('file:///home/claude/'+f);pg.wait_for_timeout(4000)
        pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('mode:survive')");pg.wait_for_timeout(1500)
        if tag=='rotated':pg.set_viewport_size({'width':844,'height':390});pg.wait_for_timeout(1200)
        m=pg.evaluate("(function(){var cv=document.getElementById('cv'),r=cv.getBoundingClientRect(),c3=document.getElementById('cv3'),r3=c3?c3.getBoundingClientRect():null,t=document.getElementById('top').getBoundingClientRect();return {cv:[r.x|0,r.y|0,r.width|0,r.height|0],cv3:r3&&[r3.x|0,r3.y|0,r3.width|0,r3.height|0],top:[t.height|0],bg:getComputedStyle(document.body).backgroundColor}})()")
        print(f,tag,m);pg.screenshot(path='/home/claude/t3/rot/game_%s_%s.png'%(f.split('.')[0],tag));c.close()
