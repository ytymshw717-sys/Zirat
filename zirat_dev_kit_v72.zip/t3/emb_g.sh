cd /home/claude && node -e "new Function(require('fs').readFileSync('/home/claude/g3/g3.js','utf8'))" && python3 - <<'PY'
s=open('/home/claude/g3/g3.js').read()
h=open('/home/claude/arena3_new.html').read()
i=h.index("<script>\n/* ===== זירת גיבורים 3D");j=h.index("</script>",i)
open('/home/claude/arena3_gfx.html','w').write(h[:i]+"<script>\n"+s+"\n"+h[j:])
PY
