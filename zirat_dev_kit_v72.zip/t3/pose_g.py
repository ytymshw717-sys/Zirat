import sys,json
from playwright.sync_api import sync_playwright
H=sys.argv[1] if len(sys.argv)>1 else '7';out=sys.argv[2] if len(sys.argv)>2 else 'pose'
POSES={'rest':{},'walk':{'legs0':[.85,0,0],'legs1':[-.85,0,0],'knee0':[.1,0,0],'knee1':[1.1,0,0],'arms0':[-.7,0,.17],'arms1':[.7,0,-.17],'fore0':[-1.2,0,0],'fore1':[-1.2,0,0]},
 'shoot':{'arms1':[-1.5,0,-.12],'fore1':[0,0,0],'arms0':[-1.05,0,-.25],'torso':[-.1,0,0]},
 'swing':{'arms1':[-2.7,0,-.2],'fore1':[-1.4,0,0],'torso':[0,.55,0]}}
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':390,'height':844},has_touch=True,is_mobile=True,device_scale_factor=2);c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)))
    pg.goto('file:///home/claude/arena3_gfx.html');pg.wait_for_timeout(3500)
    pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='hi:%s';document.getElementById('ov').appendChild(b);b.click();})()"%H);pg.wait_for_timeout(900)
    bb=pg.evaluate("(function(){var r=document.getElementById('hvStage').getBoundingClientRect();return {x:r.x,y:r.y,width:r.width,height:r.height}})()")
    for n,P in POSES.items():
        pg.evaluate("""(P)=>{var v=G3._v();var M={torso:v.torso,head:v.head,legs0:v.legs[0],legs1:v.legs[1],knee0:v.knee[0],knee1:v.knee[1],arms0:v.arms[0],arms1:v.arms[1],fore0:v.fore[0],fore1:v.fore[1]};
          for(var k in M){var o=M[k];var r=P[k]||[0,0,0];delete o.rotation.set;o.rotation.set(r[0],r[1],r[2]);o.rotation.set=function(){return this;};}
          v.body.position.set(0,0,0);v.body.scale.set(1,1,1);var ps=v.body.position.set;v.body.position.set=function(){return this;};}""",P)
        pg.wait_for_timeout(250);pg.screenshot(path='/home/claude/t3/%s_%s.png'%(out,n),clip=bb)
    print('errors',E[:3])
