import sys,json
from playwright.sync_api import sync_playwright
def run(f,tag,vp,mob,shots):
    with sync_playwright() as p:
        b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
        c=b.new_context(viewport={'width':vp[0],'height':vp[1]},has_touch=mob,is_mobile=mob,device_scale_factor=2 if mob else 1)
        c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)));pg.on('console',lambda m:E.append(m.text) if m.type=='error' else None)
        pg.goto('file:///home/claude/'+f);pg.wait_for_timeout(4000)
        out={}
        for a,sel in [('pick:0',"#ov button[data-a^='pk:'],#ov button[data-a^='hi:']"),('heroes',"#ov .r button[data-a^='hi:']"),('hi:0',"#ov .hvH")]:
            pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('%s')"%a)
            for i in range(60):
                pg.wait_for_timeout(500)
                n=pg.evaluate("(function(s){var a=[].slice.call(document.querySelectorAll(s)).map(function(e){return e.querySelector('img')}).filter(Boolean),k=0;for(var i=0;i<a.length;i++)if(a[i].src.indexOf('data:image/png')==0)k++;return [k,a.length]})(\"%s\")"%sel)
                if n[1] and n[0]>=n[1]:break
            boxes=pg.evaluate("(function(s){return [].slice.call(document.querySelectorAll(s)).map(function(e){var r=e.getBoundingClientRect(),i=e.querySelector('img').getBoundingClientRect();return [Math.round(r.x),Math.round(r.y),Math.round(r.width),Math.round(r.height),Math.round(i.width),Math.round(i.height)]})})(\"%s\")"%sel)
            out[a]=(n,boxes)
            if shots:pg.screenshot(path='/home/claude/t3/bust_%s_%s.png'%(tag,a.replace(':','')))
            pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='menu';document.getElementById('ov').appendChild(b);b.click();})()");pg.wait_for_timeout(400)
        print(f,tag,'errors',E[:3]);return out
res={}
for tag,vp,mob in [('iphone',(390,844),True),('desktop',(1280,720),False)]:
    a=run('arena3.preBust.html',tag,vp,mob,False);b=run('arena3_new.html',tag,vp,mob,True)
    for k in a: print(tag,k,'loaded',b[k][0],'layout identical:',[x[:4] for x in a[k][1]]==[x[:4] for x in b[k][1]],'img sizes identical:',[x[4:] for x in a[k][1]]==[x[4:] for x in b[k][1]])
