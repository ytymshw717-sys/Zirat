from playwright.sync_api import sync_playwright
res=[];errs=[]
def ok(n,c,i=''):res.append(bool(c));print(('PASS ' if c else 'FAIL ')+n,i,flush=True)
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},has_touch=True,is_mobile=True,device_scale_factor=3)
    c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();pg.on('pageerror',lambda e:errs.append(str(e)))
    pg.goto('file:///home/claude/arena3_new.html');pg.wait_for_timeout(3600)
    def act(a):pg.evaluate("(function(){var b=document.createElement('button');b.dataset.a='%s';document.getElementById('ov').appendChild(b);b.click();})()"%a);pg.wait_for_timeout(50)
    PH="[].filter.call(document.querySelectorAll('#ov img'),function(i){return /^data:image\\/svg/.test(i.getAttribute('src'))}).length"
    for w,n in [('menu',1),('heroes',20),('maps',11),('cat:md',10),('pick:0',4),('skall',80)]:
        act(w);t=0
        while pg.evaluate(PH)>0 and t<120:pg.wait_for_timeout(500);t+=1
        ok('window %s: all pictures filled in'%w,pg.evaluate(PH)==0,'%.1fs, imgs=%d'%(t*.5,pg.evaluate("document.querySelectorAll('#ov img').length")))
        ok('window %s: 3D/real images loaded'%w,pg.evaluate("[].every.call(document.querySelectorAll('#ov img'),function(i){return i.complete&&i.naturalWidth>1})"))
        act('menu')
    pg.screenshot(path='/home/claude/t3/after_menu.png')
    act('heroes');pg.wait_for_timeout(300);pg.screenshot(path='/home/claude/t3/after_heroes.png');act('menu')
    # adaptive resolution
    act('play');pg.wait_for_timeout(1000);w0=pg.evaluate("document.getElementById('cv').width")
    pg.keyboard.down('KeyD');pg.wait_for_timeout(25000);pg.keyboard.up('KeyD')
    w1=pg.evaluate("document.getElementById('cv').width")
    r3s=pg.evaluate("G3.r3state()")
    ok('slow device → resolution lowers automatically (2D) or 3D adapts',w1<w0 or (r3s is not None),'%d -> %d, 3d=%s'%(w0,w1,r3s))
    ok('saved quality setting unchanged',pg.evaluate("A3.sv.cfg.q")==2)
    st=pg.evaluate("__arena().state");f0=pg.evaluate("new Promise(function(r){var n=0;(function f(){n++;if(n<10)requestAnimationFrame(f);else r(n);})();})")
    ok('game not frozen (frames still running)',f0==10 and st in ('play','shop','over'),'state='+st)
    pg.screenshot(path='/home/claude/t3/after_play.png')
    b.close()
print('ERRORS',errs);print('SUMMARY %d/%d'%(sum(res),len(res)))
