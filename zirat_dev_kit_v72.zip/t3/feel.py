import sys
from playwright.sync_api import sync_playwright
F=sys.argv[1] if len(sys.argv)>1 else 'arena3_new.html'
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':844,'height':390},device_scale_factor=2);c.add_init_script(path='/home/claude/t/mock.js');pg=c.new_page();E=[];pg.on('pageerror',lambda e:E.append(str(e)));pg.on('console',lambda m:E.append(m.text) if m.type=='error' else None)
    pg.goto('file:///home/claude/'+F);pg.wait_for_timeout(3500)
    pg.evaluate("(function(a){var b=document.createElement('button');b.dataset.a=a;document.getElementById('ov').appendChild(b);b.click();})('mode:survive')");pg.wait_for_timeout(2500)
    pg.evaluate("__arena().enemies.forEach(function(e){e.stun=99;e.cd=99;});")
    def shot(n):
        r=pg.evaluate("(function(){var p=__arena().ps[0],c=document.getElementById('cv').getBoundingClientRect();var q=G3.r3proj(p.x,p.y,1);return q?[q[0]*c.width/640,q[1]*c.height/360,c.left,c.top]:null})()")
        if r:
            x,y=r[0]+r[2],r[1]+r[3];pg.screenshot(path='/home/claude/t3/feel_%s.png'%n,clip={'x':max(0,x-110),'y':max(0,y-130),'width':220,'height':190})
    pg.keyboard.down('KeyD');pg.wait_for_timeout(700);shot('run1');pg.wait_for_timeout(90);shot('run2');pg.keyboard.up('KeyD');pg.wait_for_timeout(500);shot('stop')
    pg.evaluate("__arena().ps[0].cd=0");pg.keyboard.down('Space');pg.wait_for_timeout(40);pg.keyboard.up('Space')
    for k in range(5):pg.wait_for_timeout(70);shot('atk%d'%k)
    pg.wait_for_timeout(600);pg.evaluate("var p=__arena().ps[0];p.flash=.14");pg.wait_for_timeout(80);shot('hit')
    st=pg.evaluate("G3.r3state()");print('r3',st,'fx alive:',pg.evaluate("1"),'errors',E[:3])
