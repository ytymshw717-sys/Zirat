from playwright.sync_api import sync_playwright
mock=open('/home/claude/t/mock.js').read().replace('window.__skipIntro=1;','')
with sync_playwright() as p:
    b=p.chromium.launch(args=['--use-angle=swiftshader','--enable-unsafe-swiftshader'])
    c=b.new_context(viewport={'width':390,'height':844},is_mobile=True,has_touch=True,device_scale_factor=2);c.add_init_script(script=mock);pg=c.new_page()
    pg.goto('file:///home/claude/arena3_new.html',wait_until='commit')
    import time;t0=time.time()
    for i in range(40):
        try:s=pg.evaluate("[!!document.getElementById('introL'),(document.getElementById('ov')||{}).innerText?document.getElementById('ov').innerText.slice(0,12):'',!!document.querySelector('#ov [data-a=play]')]")
        except Exception as e:s=str(e)[:40]
        print(round(time.time()-t0,1),s);pg.wait_for_timeout(250)
